param([string]$DalamudHome = $env:DALAMUD_HOME)
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($DalamudHome)) {
    $DalamudHome = Join-Path $env:APPDATA 'XIVLauncherCN\addon\Hooks\dev'
}
if (!(Test-Path -LiteralPath (Join-Path $DalamudHome 'Dalamud.dll'))) {
    throw "找不到 Dalamud.dll：$DalamudHome"
}
$project = Join-Path $PSScriptRoot 'source\DiceStats\DiceStats.csproj'
dotnet run --project (Join-Path $PSScriptRoot 'source\DiceStats.Core.Tests\DiceStats.Core.Tests.csproj') -c Release
if ($LASTEXITCODE -ne 0) { throw '核心回归测试失败' }
dotnet build $project -c Release --nologo "-p:DalamudHome=$DalamudHome"
if ($LASTEXITCODE -ne 0) { throw '构建失败' }
$built = Join-Path $PSScriptRoot 'source\DiceStats\bin\Release\net10.0-windows'
$destination = Join-Path $PSScriptRoot 'plugin'
New-Item -ItemType Directory -Path $destination -Force | Out-Null
foreach ($name in @('DiceStats.dll','DiceStats.pdb','DiceStats.deps.json','DiceStats.json','DiceStats.Core.dll','DiceStats.Core.pdb')) {
    Copy-Item -LiteralPath (Join-Path $built $name) -Destination (Join-Path $destination $name) -Force
}
Write-Output "构建完成：$destination"
