using System.Globalization;
using System.Text;
using DiceStats.Core;

var tests = new (string Name, Action Run)[]
{
    ("empty inputs", Empty),
    ("all rolls contribute to player summary", Summary),
    ("names and worlds form case-insensitive identities", Identity),
    ("highest per player and competition ties", Highest),
    ("lowest per player includes zero", Lowest),
    ("closest ties above and below target", ClosestTies),
    ("target change recalculates selected rolls", TargetChange),
    ("equal distance chooses earliest roll", EarliestClosest),
    ("same timestamp retains input order", EqualTimestamp),
    ("summary is chronological even with unordered input", Chronology),
    ("invalid inputs rejected", InvalidInput),
    ("Chinese English Japanese formats", ParserFormats),
    ("Chinese native icon and custom random limit", ParserNativeLimits),
    ("parser rejects unrelated and malformed text", ParserRejects),
    ("CSV keeps Unicode quotes and commas", CsvEscaping),
    ("CSV neutralizes formula starts", CsvFormulaSafety),
    ("CSV uses invariant decimals and target distance", CsvCulture),
    ("history CSV preserves every event ID timestamp and field", CsvHistory),
    ("announcement defaults and empty finish", AnnouncementDefaults),
    ("announcement highest and lowest all tied players", AnnouncementExtremes),
    ("announcement closest ties pair player and value", AnnouncementClosest),
    ("announcement tokens only substitute once", AnnouncementOnePass),
    ("announcement blank template suppresses event", AnnouncementBlank),
    ("announcement settings validate every field", AnnouncementValidation),
    ("announcement commands force every channel prefix", AnnouncementPrefixes),
    ("announcement commands split lines and strip controls", AnnouncementLines),
    ("announcement command UTF8 limit includes prefix", AnnouncementByteLimit),
    ("announcement rune splitting round trips Unicode", AnnouncementRunes),
};
var failures = 0;
foreach (var test in tests)
{
    try { test.Run(); Console.WriteLine($"PASS {test.Name}"); }
    catch (Exception error) { failures++; Console.Error.WriteLine($"FAIL {test.Name}: {error.Message}"); }
}
Console.WriteLine($"{tests.Length - failures}/{tests.Length} tests passed.");
return failures == 0 ? 0 : 1;

static RollEntry Roll(string name, int value, int time = 0, string world = "测试服") =>
    new(Guid.NewGuid(), DateTimeOffset.UnixEpoch.AddSeconds(time), name, world, value);

static void Equal<T>(T expected, T actual)
{
    if (!EqualityComparer<T>.Default.Equals(expected, actual))
        throw new Exception($"Expected {expected}; actual {actual}.");
}

static void Check(bool condition, string detail = "Assertion failed")
{
    if (!condition) throw new Exception(detail);
}

static void Throws<T>(Action action) where T : Exception
{
    try { action(); }
    catch (T) { return; }
    throw new Exception($"Expected {typeof(T).Name}.");
}

static void Empty()
{
    Equal(0, Statistics.Calculate([], RankingMode.Highest).Count);
    Equal(1, Statistics.ExportCsv([], RankingMode.Closest).Split("\r\n", StringSplitOptions.RemoveEmptyEntries).Length);
}

static void Summary()
{
    var result = Statistics.Calculate([Roll("甲", 100), Roll("甲", 0, 1), Roll("甲", 999, 2)], RankingMode.Highest).Single();
    Equal(3, result.Count); Equal(1099L, result.Total); Equal(100, result.First);
    Equal(999, result.Latest); Equal(999, result.Highest); Equal(0, result.Lowest);
    Equal(1099d / 3, result.Average); Equal(999, result.Selected); Equal(999L, result.Score);
}

static void Identity()
{
    var result = Statistics.Calculate([
        Roll("Alice Test", 10, 0, "Alpha"), Roll("alice test", 30, 1, "alpha"),
        Roll("Alice Test", 20, 2, "Beta"), Roll(" Alice Test ", 40, 3, " Alpha "),
        Roll("Alice Test", 50, 4, ""),
    ], RankingMode.Highest);
    Equal(3, result.Count);
    Equal(3, result.Single(r => r.World == "Alpha").Count);
    Equal(1, result.Single(r => r.World == "Beta").Count);
    Equal(1, result.Single(r => r.World == "").Count);
}

static void Highest()
{
    var result = Statistics.Calculate([
        Roll("Bob", 500), Roll("Alice", 999), Roll("Bob", 999, 1), Roll("Carol", 998),
    ], RankingMode.Highest);
    Equal("Alice", result[0].PlayerName); Equal("Bob", result[1].PlayerName);
    Equal(1, result[0].Rank); Equal(1, result[1].Rank); Equal(3, result[2].Rank);
    Equal(999, result[1].Selected);
}

static void Lowest()
{
    var result = Statistics.Calculate([Roll("Alice", 100), Roll("Alice", 0, 1), Roll("Bob", 1)], RankingMode.Lowest);
    Equal("Alice", result[0].PlayerName); Equal(0, result[0].Score); Equal(0, result[0].Selected);
}

static void ClosestTies()
{
    var result = Statistics.Calculate([Roll("Bob", 100), Roll("Alice", 98), Roll("Carol", 102)], RankingMode.Closest, 99);
    Equal("Alice", result[0].PlayerName); Equal(98, result[0].Selected);
    Equal(100, result[1].Selected); Equal(1L, result[0].Score); Equal(1L, result[1].Score);
    Equal(1, result[0].Rank); Equal(1, result[1].Rank); Equal(3, result[2].Rank);
}

static void TargetChange()
{
    var entries = new[] { Roll("Alice", 0), Roll("Alice", 999, 1), Roll("Bob", 99) };
    var at99 = Statistics.Calculate(entries, RankingMode.Closest, 99);
    Equal("Bob", at99[0].PlayerName); Equal(0L, at99[0].Score);
    var at999 = Statistics.Calculate(entries, RankingMode.Closest, 999);
    Equal("Alice", at999[0].PlayerName); Equal(999, at999[0].Selected);
    var at0 = Statistics.Calculate(entries, RankingMode.Closest, 0);
    Equal("Alice", at0[0].PlayerName); Equal(0, at0[0].Selected);
}

static void EarliestClosest()
{
    var result = Statistics.Calculate([Roll("Alice", 100, 2), Roll("Alice", 98, 1)], RankingMode.Closest, 99).Single();
    Equal(98, result.Selected); Equal(1L, result.Score);
}

static void EqualTimestamp()
{
    var result = Statistics.Calculate([Roll("Alice", 100), Roll("Alice", 98)], RankingMode.Closest, 99).Single();
    Equal(100, result.Selected); Equal(100, result.First); Equal(98, result.Latest);
}

static void Chronology()
{
    var result = Statistics.Calculate([Roll("Alice", 10, 10), Roll("Alice", 30, 30), Roll("Alice", 20, 20)], RankingMode.Highest).Single();
    Equal(10, result.First); Equal(30, result.Latest);
}

static void InvalidInput()
{
    Throws<ArgumentOutOfRangeException>(() => Statistics.Calculate([], RankingMode.Closest, -1));
    Throws<ArgumentOutOfRangeException>(() => Statistics.Calculate([], RankingMode.Closest, 1000));
    Throws<ArgumentOutOfRangeException>(() => Statistics.Calculate([], (RankingMode)99));
    Throws<ArgumentException>(() => Statistics.Calculate([Roll("Alice", 1000)], RankingMode.Highest));
    Throws<ArgumentException>(() => Statistics.Calculate([Roll(" ", 50)], RankingMode.Highest));
    Throws<ArgumentNullException>(() => Statistics.Calculate(null!, RankingMode.Highest));
}

static void ParserFormats()
{
    var examples = new (string Text, string Name, int Value)[]
    {
        ("测试玩家掷出了123点！", "测试玩家", 123),
        ("测试玩家 掷出了 0 点。", "测试玩家", 0),
        ("\uE070 测试玩家掷出了999点！ \uE071", "测试玩家", 999),
        ("Alice Test rolls a 123!", "Alice Test", 123),
        ("Alice O'test rolls a 42.", "Alice O'test", 42),
        ("テストは、ダイスで99の目を出した！", "テスト", 99),
        ("Alice Testは、ダイスで 0 を出した。", "Alice Test", 0),
        ("Alice Test\uE05DAlpha rolls a 99!", "Alice Test\uE05DAlpha", 99),
    };
    foreach (var (text, name, value) in examples)
    {
        Check(RollParser.TryParse(text, out var result), text);
        Equal(name, result!.PlayerName); Equal(value, result.Value);
    }
}

static void ParserRejects()
{
    string[] examples = [
        "", "hello", "掷出了123点！", "Alice rolls a -1!", "Alice rolls a 1000!",
        "Alice rolls a １２３!", "Alice rolls a 999x", "Alice rolls a 99! appended chat",
        "Alice rolls a 9.5!", "Alice rolls a +9!", "Alice rolls a 0000!",
        "测试玩家掷出了99点！后面的聊天", "测试玩家掷出了999999999999999999999点！",
        "[Party] Alice rolls a 99!", "Someone: Alice rolls a 99!",
        "Alice\nTest rolls a 99!", "Alice rolls a 99!\nextra", "99 rolls a 99!",
    ];
    foreach (var text in examples)
    {
        Check(!RollParser.TryParse(text, out var result), text);
        Check(result is null, "Rejected parse must clear output.");
    }
}

static void ParserNativeLimits()
{
    foreach (var text in new[] { "测试玩家掷出了\uE07099点！", "测试玩家掷出了99点！（最大99）", "测试玩家掷出了\uE070 99点！（最大999）" })
    {
        Check(RollParser.TryParse(text, out var result), text);
        Equal(99, result!.Value); Equal("测试玩家", result.PlayerName);
    }
    foreach (var text in new[] {
        "测试玩家掷出了0点！（最大16）", "测试玩家掷出了17点！（最大16）",
        "测试玩家掷出了1点！（最大1）", "测试玩家掷出了1点！（最大1000）",
        "测试玩家掷出了1点！（最大16）随便聊天", "测试玩家掷出了1点！（最小16）",
    }) Check(!RollParser.TryParse(text, out _), text);
}

static void CsvEscaping()
{
    var csv = Statistics.ExportCsv([Roll("测试,\"玩家\"", 99, 0, "服务器")], RankingMode.Highest);
    Check(csv.Contains("\"测试,\"\"玩家\"\"\"", StringComparison.Ordinal));
    Check(csv.Contains("\"服务器\"", StringComparison.Ordinal));
    Check(csv.StartsWith("\"排名\",\"玩家\"", StringComparison.Ordinal));
}

static void CsvFormulaSafety()
{
    var csv = Statistics.ExportCsv([
        Roll("=HYPERLINK(\"url\")", 99, 0, "@SUM(1)"), Roll("+1+1", 98),
        Roll("-1+1", 97), Roll("  =1+1", 96),
    ], RankingMode.Highest);
    Check(csv.Contains("\"'=HYPERLINK(\"\"url\"\")\"", StringComparison.Ordinal));
    Check(csv.Contains("\"'@SUM(1)\"", StringComparison.Ordinal));
    Check(csv.Contains("\"'+1+1\"", StringComparison.Ordinal));
    Check(csv.Contains("\"'-1+1\"", StringComparison.Ordinal));
    Check(csv.Contains("\"'=1+1\"", StringComparison.Ordinal));
}

static void CsvCulture()
{
    var previous = CultureInfo.CurrentCulture;
    try
    {
        CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR");
        var csv = Statistics.ExportCsv([Roll("Alice", 98), Roll("Alice", 99, 1)], RankingMode.Closest, 99);
        Check(csv.Contains("\"最接近目标\",\"99\",\"99\",\"0\"", StringComparison.Ordinal));
        Check(csv.Contains("\"98.5\"", StringComparison.Ordinal));
        Check(!csv.Contains("\"98,5\"", StringComparison.Ordinal));
    }
    finally { CultureInfo.CurrentCulture = previous; }
}

static void CsvHistory()
{
    var first = new RollEntry(Guid.Parse("c54f6920-441c-48c5-a9f4-28b67b4b23ba"),
        new DateTimeOffset(2026, 9, 23, 12, 34, 56, TimeSpan.FromHours(8)), "=测试,\"玩家\"", "@世界", 99);
    var second = first with { Id = Guid.Parse("611c7592-f9d0-4c19-9035-19533875b779"), Value = 100 };
    var csv = Statistics.ExportHistoryCsv([first, second]);
    Equal(3, csv.Split("\r\n", StringSplitOptions.RemoveEmptyEntries).Length);
    Check(csv.StartsWith("\"记录ID\",\"时间\",\"玩家\",\"服务器\",\"点数\"\r\n", StringComparison.Ordinal));
    Check(csv.Contains("\"2026-09-23T12:34:56.0000000+08:00\"", StringComparison.Ordinal));
    Check(csv.Contains("\"'=测试,\"\"玩家\"\"\",\"'@世界\",\"99\"", StringComparison.Ordinal));
    Check(csv.IndexOf(first.Id.ToString(), StringComparison.Ordinal) < csv.IndexOf(second.Id.ToString(), StringComparison.Ordinal));
    Check(csv.EndsWith("\"100\"\r\n", StringComparison.Ordinal));
    Equal(1, Statistics.ExportHistoryCsv([]).Split("\r\n", StringSplitOptions.RemoveEmptyEntries).Length);
    Throws<ArgumentNullException>(() => Statistics.ExportHistoryCsv(null!));
}

static void AnnouncementDefaults()
{
    var settings = new AnnouncementSettings();
    Check(Announcements.IsValid(settings));
    Equal(AnnouncementChannel.Shout, settings.Channel);
    var start = Announcements.RenderStart(settings, [], RankingMode.Closest, 99);
    Check(start.Contains("/random", StringComparison.Ordinal));
    Check(start.Contains("最接近 99 点", StringComparison.Ordinal));
    Check(!start.Contains("结束", StringComparison.Ordinal));
    Equal(settings.EmptyText, Announcements.RenderEnd(settings, [], RankingMode.Highest));
    var customizedEmpty = settings with { EmptyText = "{人数}/{次数}/{最高点数}/{最低点数}/{结果}" };
    Equal("0/0/无/无/无", Announcements.RenderEnd(customizedEmpty, [], RankingMode.Lowest));
}

static void AnnouncementExtremes()
{
    var settings = new AnnouncementSettings
    {
        HighestText = "{规则}|{结果}|{点数}|{人数}|{次数}|{最高点数}|{最低点数}|{最高玩家}|{最低玩家}",
        LowestText = "{结果}",
    };
    var entries = new[]
    {
        Roll("Alice", 999, 0, "One"), Roll("Alice", 0, 1, "One"),
        Roll("Alice", 999, 0, "Two"), Roll("Bob", 0, 1, ""), Roll("Carol", 55),
    };
    var highest = Announcements.RenderEnd(settings, entries, RankingMode.Highest);
    Equal("最高点数|Alice@One（999 点）、Alice@Two（999 点）|999|4|5|999|0|Alice@One、Alice@Two|Alice@One、Bob", highest);
    Equal("Alice@One（0 点）、Bob（0 点）", Announcements.RenderEnd(settings, entries, RankingMode.Lowest));
}

static void AnnouncementClosest()
{
    var settings = new AnnouncementSettings { ClosestText = "{规则}|{结果}|{玩家}|{点数}|{差值}|{目标}" };
    var entries = new[] { Roll("Bob", 100), Roll("Alice", 98), Roll("Carol", 102) };
    Equal("最接近 99 点|Alice@测试服（98 点，差 1 点）、Bob@测试服（100 点，差 1 点）|Alice@测试服、Bob@测试服|98、100|1|99",
        Announcements.RenderEnd(settings, entries, RankingMode.Closest, 99));
    var changed = Announcements.RenderEnd(settings, entries, RankingMode.Closest, 100);
    Check(changed.Contains("Bob@测试服（100 点，差 0 点）", StringComparison.Ordinal));
    Check(!changed.Contains("Alice", StringComparison.Ordinal));
}

static void AnnouncementOnePass()
{
    var settings = new AnnouncementSettings { HighestText = "{结果}|{玩家}|{目标}|{未知}" };
    var rendered = Announcements.RenderEnd(settings, [Roll("{目标}", 42, 0, "{人数}")], RankingMode.Highest, 99);
    Equal("{目标}@{人数}（42 点）|{目标}@{人数}|99|{未知}", rendered);
}

static void AnnouncementBlank()
{
    var settings = new AnnouncementSettings { StartText = "", HighestText = "", EmptyText = "" };
    Check(Announcements.IsValid(settings));
    Equal("", Announcements.RenderStart(settings, [], RankingMode.Highest));
    Equal("", Announcements.RenderEnd(settings, [Roll("Alice", 99)], RankingMode.Highest));
    Equal("", Announcements.RenderEnd(settings, [], RankingMode.Highest));
    Equal(0, Announcements.PrepareCommands(" \r\n\t", AnnouncementChannel.Shout).Count);
}

static void AnnouncementValidation()
{
    var settings = new AnnouncementSettings();
    Check(!Announcements.IsValid(null));
    Check(!Announcements.IsValid(settings with { Channel = (AnnouncementChannel)100 }));
    Check(!Announcements.IsValid(settings with { StartText = null! }));
    Check(!Announcements.IsValid(settings with { HighestText = null! }));
    Check(!Announcements.IsValid(settings with { LowestText = null! }));
    Check(!Announcements.IsValid(settings with { ClosestText = null! }));
    Check(!Announcements.IsValid(settings with { EmptyText = null! }));
    var longText = new string('中', Announcements.MaxTemplateLength + 1);
    Check(!Announcements.IsValid(settings with { StartText = longText }));
    Check(!Announcements.IsValid(settings with { HighestText = longText }));
    Check(!Announcements.IsValid(settings with { LowestText = longText }));
    Check(!Announcements.IsValid(settings with { ClosestText = longText }));
    Check(!Announcements.IsValid(settings with { EmptyText = longText }));
    Check(Announcements.IsValid(settings with { StartText = longText[..Announcements.MaxTemplateLength] }));
    Throws<ArgumentException>(() => Announcements.RenderStart(settings with { StartText = null! }, [], RankingMode.Highest));
    Throws<ArgumentOutOfRangeException>(() => Announcements.RenderEnd(settings, [], (RankingMode)999));
    Throws<ArgumentOutOfRangeException>(() => Announcements.RenderStart(settings, [], RankingMode.Closest, 1000));
    Throws<ArgumentNullException>(() => Announcements.PrepareCommands(null!, AnnouncementChannel.Shout));
    Throws<ArgumentOutOfRangeException>(() => Announcements.PrepareCommands("hello", (AnnouncementChannel)999));
}

static void AnnouncementPrefixes()
{
    var expected = new Dictionary<AnnouncementChannel, string>
    {
        [AnnouncementChannel.Say] = "/s ", [AnnouncementChannel.Yell] = "/y ",
        [AnnouncementChannel.Shout] = "/sh ", [AnnouncementChannel.Party] = "/p ",
        [AnnouncementChannel.Alliance] = "/a ", [AnnouncementChannel.Echo] = "/e ",
    };
    foreach (var (channel, prefix) in expected)
    {
        Equal(prefix, Announcements.GetChannelPrefix(channel));
        var commands = Announcements.PrepareCommands("/logout\n/shutdown", channel);
        Equal(2, commands.Count); Equal(prefix + "/logout", commands[0]); Equal(prefix + "/shutdown", commands[1]);
    }
}

static void AnnouncementLines()
{
    var commands = Announcements.PrepareCommands(" 甲\u0000\u0002乙\u0003\t \r\n丙\r丁\n\n戊\u2028己\u2029庚\u007f ", AnnouncementChannel.Shout);
    Equal(6, commands.Count);
    Equal("/sh 甲乙", commands[0]); Equal("/sh 丙", commands[1]); Equal("/sh 丁", commands[2]);
    Equal("/sh 戊", commands[3]); Equal("/sh 己", commands[4]); Equal("/sh 庚", commands[5]);
    foreach (var command in commands) Check(!command.Any(char.IsControl));
}

static void AnnouncementByteLimit()
{
    foreach (var channel in Enum.GetValues<AnnouncementChannel>())
    {
        var prefix = Announcements.GetChannelPrefix(channel);
        var length = Announcements.MaxCommandBytes - Encoding.UTF8.GetByteCount(prefix);
        var exact = Announcements.PrepareCommands(new string('x', length), channel);
        Equal(1, exact.Count); Equal(480, Encoding.UTF8.GetByteCount(exact[0]));
        var split = Announcements.PrepareCommands(new string('x', length + 1), channel);
        Equal(2, split.Count); Equal(prefix + "x", split[1]);
        foreach (var command in split) Check(Encoding.UTF8.GetByteCount(command) <= 480);
    }
}

static void AnnouncementRunes()
{
    var text = new string('x', 475) + string.Concat(Enumerable.Repeat("🎲中文𠮷", 500));
    var commands = Announcements.PrepareCommands(text, AnnouncementChannel.Shout);
    var prefix = Announcements.GetChannelPrefix(AnnouncementChannel.Shout);
    var strictUtf8 = new UTF8Encoding(false, true);
    foreach (var command in commands)
    {
        Check(command.StartsWith(prefix, StringComparison.Ordinal));
        Check(strictUtf8.GetByteCount(command) <= Announcements.MaxCommandBytes);
        Check(!command.Contains('\uFFFD'));
    }
    Equal(text, string.Concat(commands.Select(c => c[prefix.Length..])));
}
