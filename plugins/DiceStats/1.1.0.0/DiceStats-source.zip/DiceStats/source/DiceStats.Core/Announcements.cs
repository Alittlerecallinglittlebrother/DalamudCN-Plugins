using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace DiceStats.Core;

public enum AnnouncementChannel
{
    Say,
    Yell,
    Shout,
    Party,
    Alliance,
    Echo,
}

public sealed record AnnouncementSettings
{
    public AnnouncementChannel Channel { get; init; } = AnnouncementChannel.Shout;
    public string StartText { get; init; } = "点数统计开始～请参与玩家使用 /random 掷骰。规则：{规则}";
    public string HighestText { get; init; } = "点数统计结束！\n最高分：{结果}\n共 {人数} 人，{次数} 次掷骰。";
    public string LowestText { get; init; } = "点数统计结束！\n最低分：{结果}\n共 {人数} 人，{次数} 次掷骰。";
    public string ClosestText { get; init; } = "点数统计结束！\n最接近 {目标} 点：{结果}\n共 {人数} 人，{次数} 次掷骰。";
    public string EmptyText { get; init; } = "点数统计结束，没有玩家参与。";
}

/// <summary>Pure rendering and command preparation; this class never sends a message.</summary>
public static partial class Announcements
{
    public const int MaxTemplateLength = 2000;
    public const int MaxCommandBytes = 480;

    public static bool IsValid(AnnouncementSettings? settings) =>
        settings is not null && Enum.IsDefined(settings.Channel) &&
        ValidText(settings.StartText) && ValidText(settings.HighestText) &&
        ValidText(settings.LowestText) && ValidText(settings.ClosestText) &&
        ValidText(settings.EmptyText);

    public static string RenderStart(
        AnnouncementSettings settings,
        IEnumerable<RollEntry> entries,
        RankingMode mode,
        int target = 99) => Render(settings, entries, mode, target, isStart: true);

    public static string RenderEnd(
        AnnouncementSettings settings,
        IEnumerable<RollEntry> entries,
        RankingMode mode,
        int target = 99) => Render(settings, entries, mode, target, isStart: false);

    /// <summary>Returns a fixed game chat command prefix, including the separating space.</summary>
    public static string GetChannelPrefix(AnnouncementChannel channel) => channel switch
    {
        AnnouncementChannel.Say => "/s ",
        AnnouncementChannel.Yell => "/y ",
        AnnouncementChannel.Shout => "/sh ",
        AnnouncementChannel.Party => "/p ",
        AnnouncementChannel.Alliance => "/a ",
        AnnouncementChannel.Echo => "/e ",
        _ => throw new ArgumentOutOfRangeException(nameof(channel)),
    };

    /// <summary>
    /// Splits lines into rune-safe commands whose UTF-8 length includes the
    /// fixed channel prefix. User text is always chat content, even if it
    /// begins with a slash. Control characters cannot reach the native sender.
    /// </summary>
    public static IReadOnlyList<string> PrepareCommands(string text, AnnouncementChannel channel)
    {
        ArgumentNullException.ThrowIfNull(text);
        var prefix = GetChannelPrefix(channel);
        var contentBudget = MaxCommandBytes - Encoding.UTF8.GetByteCount(prefix);
        var commands = new List<string>();
        var line = new StringBuilder();

        void FlushLine()
        {
            var content = line.ToString().Trim();
            line.Clear();
            if (content.Length == 0) return;

            var chunk = new StringBuilder();
            var bytes = 0;
            foreach (var rune in content.EnumerateRunes())
            {
                if (bytes + rune.Utf8SequenceLength > contentBudget)
                {
                    commands.Add(prefix + chunk);
                    chunk.Clear();
                    bytes = 0;
                }
                chunk.Append(rune.ToString());
                bytes += rune.Utf8SequenceLength;
            }
            if (chunk.Length > 0) commands.Add(prefix + chunk);
        }

        foreach (var rune in text.EnumerateRunes())
        {
            if (rune.Value is '\r' or '\n' or 0x2028 or 0x2029)
                FlushLine();
            else if (!Rune.IsControl(rune))
                line.Append(rune.ToString());
        }
        FlushLine();
        return commands;
    }

    private static bool ValidText(string? text) => text is not null && text.Length <= MaxTemplateLength;

    private static string Render(
        AnnouncementSettings settings,
        IEnumerable<RollEntry> entries,
        RankingMode mode,
        int target,
        bool isStart)
    {
        if (!IsValid(settings)) throw new ArgumentException("Invalid announcement settings.", nameof(settings));
        var summaries = Statistics.Calculate(entries, mode, target);
        var template = isStart ? settings.StartText : summaries.Count == 0 ? settings.EmptyText : mode switch
        {
            RankingMode.Highest => settings.HighestText,
            RankingMode.Lowest => settings.LowestText,
            RankingMode.Closest => settings.ClosestText,
            _ => throw new ArgumentOutOfRangeException(nameof(mode)),
        };
        if (template.Length == 0) return string.Empty;

        var winners = summaries.Where(p => p.Rank == 1).ToArray();
        var high = summaries.Count == 0 ? (int?)null : summaries.Max(p => p.Highest);
        var low = summaries.Count == 0 ? (int?)null : summaries.Min(p => p.Lowest);
        var tokens = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["{规则}"] = mode switch
            {
                RankingMode.Highest => "最高点数",
                RankingMode.Lowest => "最低点数",
                RankingMode.Closest => $"最接近 {Format(target)} 点",
                _ => throw new ArgumentOutOfRangeException(nameof(mode)),
            },
            ["{目标}"] = Format(target),
            ["{结果}"] = JoinOrNone(winners.Select(p => mode == RankingMode.Closest
                ? $"{PlayerLabel(p)}（{Format(p.Selected)} 点，差 {Format(p.Score)} 点）"
                : $"{PlayerLabel(p)}（{Format(p.Selected)} 点）")),
            ["{玩家}"] = JoinOrNone(winners.Select(PlayerLabel)),
            ["{点数}"] = JoinOrNone(winners.Select(p => p.Selected).Distinct().Order().Select(Format)),
            ["{差值}"] = JoinOrNone(winners.Select(p => Math.Abs(p.Selected - target)).Distinct().Order().Select(Format)),
            ["{人数}"] = Format(summaries.Count),
            ["{次数}"] = Format(summaries.Sum(p => (long)p.Count)),
            ["{最高点数}"] = high is null ? "无" : Format(high.Value),
            ["{最低点数}"] = low is null ? "无" : Format(low.Value),
            ["{最高玩家}"] = JoinOrNone(OrderPlayers(summaries.Where(p => p.Highest == high)).Select(PlayerLabel)),
            ["{最低玩家}"] = JoinOrNone(OrderPlayers(summaries.Where(p => p.Lowest == low)).Select(PlayerLabel)),
        };
        // MatchEvaluator replacements are inserted literally. A player's name
        // containing another token cannot trigger a second substitution.
        return TemplateToken().Replace(template, match => tokens[match.Value]);
    }

    private static IOrderedEnumerable<PlayerStats> OrderPlayers(IEnumerable<PlayerStats> players) =>
        players.OrderBy(p => p.PlayerName, StringComparer.OrdinalIgnoreCase)
            .ThenBy(p => p.World, StringComparer.OrdinalIgnoreCase);

    private static string PlayerLabel(PlayerStats player) => string.IsNullOrEmpty(player.World)
        ? player.PlayerName : player.PlayerName + "@" + player.World;

    private static string Format(int value) => value.ToString(CultureInfo.InvariantCulture);
    private static string Format(long value) => value.ToString(CultureInfo.InvariantCulture);
    private static string JoinOrNone(IEnumerable<string> values)
    {
        var result = string.Join("、", values);
        return result.Length == 0 ? "无" : result;
    }

    [GeneratedRegex(@"\{(?:规则|目标|结果|玩家|点数|差值|人数|次数|最高点数|最低点数|最高玩家|最低玩家)\}", RegexOptions.CultureInvariant, 100)]
    private static partial Regex TemplateToken();
}
