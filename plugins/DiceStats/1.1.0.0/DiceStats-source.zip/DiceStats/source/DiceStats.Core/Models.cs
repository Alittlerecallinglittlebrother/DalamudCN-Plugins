namespace DiceStats.Core;

public enum RankingMode
{
    Highest,
    Lowest,
    Closest,
}

public sealed record RollEntry(
    Guid Id,
    DateTimeOffset Timestamp,
    string PlayerName,
    string World,
    int Value);

public sealed record PlayerStats(
    string PlayerName,
    string World,
    int Count,
    long Total,
    int Latest,
    int Highest,
    int Lowest,
    int First,
    double Average,
    int Selected,
    long Score,
    int Rank);

public sealed record ParsedRoll(string PlayerName, int Value);
