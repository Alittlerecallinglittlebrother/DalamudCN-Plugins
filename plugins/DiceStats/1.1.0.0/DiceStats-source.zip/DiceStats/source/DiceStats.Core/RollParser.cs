using System.Globalization;
using System.Text.RegularExpressions;

namespace DiceStats.Core;

/// <summary>
/// Parses the supported /random text forms. The caller MUST also require the
/// game's native random-roll log kind; text alone cannot authenticate a roll.
/// </summary>
public static partial class RollParser
{
    public static bool TryParse(string text, out ParsedRoll? roll)
    {
        roll = null;
        if (string.IsNullOrWhiteSpace(text) || text.Length > 512) return false;
        // Icon glyphs wrap some rendered system lines. Preserve interior text
        // so malformed suffixes cannot become valid by removing their content.
        var start = 0;
        var end = text.Length;
        while (start < end && IsBoundary(text[start])) start++;
        while (end > start && IsBoundary(text[end - 1])) end--;
        var cleaned = text[start..end];
        var match = RollLine().Match(cleaned);
        if (!match.Success || !int.TryParse(match.Groups["value"].Value,
                NumberStyles.None, CultureInfo.InvariantCulture, out var value) ||
            value is < Statistics.MinimumRoll or > Statistics.MaximumRoll)
            return false;

        if (match.Groups["maximum"].Success &&
            (!int.TryParse(match.Groups["maximum"].Value, NumberStyles.None,
                 CultureInfo.InvariantCulture, out var maximum) ||
             maximum is < 2 or > Statistics.MaximumRoll || value < 1 || value > maximum))
            return false;

        var player = match.Groups["name"].Value.Trim();
        if (player.Length == 0) return false;
        roll = new ParsedRoll(player, value);
        return true;
    }

    private static bool IsBoundary(char c) => char.IsWhiteSpace(c) || c is >= '\uE000' and <= '\uF8FF';

    // Match the entire line, use ASCII digits, and constrain the player portion
    // instead of treating arbitrary prefixes or appended chat as a roll.
    // U+E05D is the home-world icon sometimes included in flattened player links.
    // CN LogMessage 856: <player>掷出了<dice icon><value>点！
    // CN LogMessage 3887 adds （最大<maximum>）. Explicit /random caps
    // are 2..999, and their resulting values are 1..maximum.
    [GeneratedRegex(@"\A(?<name>[\p{L}\p{M}][\p{L}\p{M}'’・·\- \uE05D]{0,127}?)\s*(?:掷出了[\s\uE000-\uF8FF]*(?<value>[0-9]{1,3})\s*点[!！。.]?(?:（最大\s*(?<maximum>[0-9]{1,3})）)?|rolls a\s+(?<value>[0-9]{1,3})[!！.]?|は、ダイスで\s*(?<value>[0-9]{1,3})\s*(?:の目を出した|を出した)[!！。.]?)\z", RegexOptions.CultureInvariant | RegexOptions.ExplicitCapture, 100)]
    private static partial Regex RollLine();
}
