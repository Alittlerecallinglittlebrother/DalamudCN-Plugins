using System.Globalization;
using System.Text;

namespace DiceStats.Core;

public static class Statistics
{
    public const int MinimumRoll = 0;
    public const int MaximumRoll = 999;

    /// <summary>
    /// Each player is identified by both name and home world, ignoring case.
    /// Every roll contributes to the summary; each mode selects that player's
    /// best matching roll. Equal scores share a competition rank (1, 1, 3).
    /// </summary>
    public static IReadOnlyList<PlayerStats> Calculate(
        IEnumerable<RollEntry> entries,
        RankingMode mode,
        int target = 99)
    {
        ArgumentNullException.ThrowIfNull(entries);
        if (!Enum.IsDefined(mode)) throw new ArgumentOutOfRangeException(nameof(mode));
        if (target is < MinimumRoll or > MaximumRoll)
            throw new ArgumentOutOfRangeException(nameof(target), "Target must be between 0 and 999.");

        var groups = new Dictionary<PlayerIdentity, List<RollEntry>>(PlayerIdentityComparer.Instance);
        // OrderBy is stable: equal timestamps retain the recorded input order.
        foreach (var entry in entries.OrderBy(e => e.Timestamp))
        {
            if (string.IsNullOrWhiteSpace(entry.PlayerName))
                throw new ArgumentException("Every roll must have a player name.", nameof(entries));
            if (entry.Value is < MinimumRoll or > MaximumRoll)
                throw new ArgumentException("Every roll must be between 0 and 999.", nameof(entries));

            var key = new PlayerIdentity(entry.PlayerName.Trim(), entry.World?.Trim() ?? string.Empty);
            if (!groups.TryGetValue(key, out var rolls))
                groups.Add(key, rolls = []);
            rolls.Add(entry);
        }

        var summaries = new List<PlayerStats>(groups.Count);
        foreach (var (identity, rolls) in groups)
        {
            var highest = rolls.Max(e => e.Value);
            var lowest = rolls.Min(e => e.Value);
            var total = rolls.Sum(e => (long)e.Value);
            // MinBy selects the first equal-distance candidate in chronological order.
            var selected = mode switch
            {
                RankingMode.Highest => highest,
                RankingMode.Lowest => lowest,
                RankingMode.Closest => rolls.MinBy(e => Math.Abs(e.Value - target))!.Value,
                _ => throw new ArgumentOutOfRangeException(nameof(mode)),
            };
            var score = mode == RankingMode.Closest ? Math.Abs(selected - target) : selected;
            summaries.Add(new PlayerStats(identity.Name, identity.World, rolls.Count, total,
                rolls[^1].Value, highest, lowest, rolls[0].Value, (double)total / rolls.Count,
                selected, score, 0));
        }

        var byScore = mode == RankingMode.Highest
            ? summaries.OrderByDescending(s => s.Score)
            : summaries.OrderBy(s => s.Score);
        var ordered = byScore
            .ThenBy(s => s.PlayerName, StringComparer.OrdinalIgnoreCase)
            .ThenBy(s => s.World, StringComparer.OrdinalIgnoreCase)
            .ToList();

        var rank = 0;
        long? previousScore = null;
        for (var i = 0; i < ordered.Count; i++)
        {
            if (previousScore != ordered[i].Score) rank = i + 1;
            previousScore = ordered[i].Score;
            ordered[i] = ordered[i] with { Rank = rank };
        }
        return ordered;
    }

    /// <summary>Returns a Unicode CSV summary. The file writer selects its UTF-8 encoding/BOM.</summary>
    public static string ExportCsv(IEnumerable<RollEntry> entries, RankingMode mode, int target = 99)
    {
        var summaries = Calculate(entries, mode, target);
        var output = new StringBuilder();
        AppendCsvRow(output, ["排名", "玩家", "服务器", "判定规则", "目标点数", "选定点数", "距目标差值",
            "掷骰次数", "总点数", "首次点数", "最近点数", "最高点数", "最低点数", "平均点数"]);
        var label = mode switch
        {
            RankingMode.Highest => "最高点数",
            RankingMode.Lowest => "最低点数",
            RankingMode.Closest => "最接近目标",
            _ => throw new ArgumentOutOfRangeException(nameof(mode)),
        };
        foreach (var row in summaries)
        {
            AppendCsvRow(output,
            [
                Format(row.Rank), row.PlayerName, row.World, label,
                mode == RankingMode.Closest ? Format(target) : string.Empty,
                Format(row.Selected), mode == RankingMode.Closest ? Format(row.Score) : string.Empty,
                Format(row.Count), Format(row.Total), Format(row.First), Format(row.Latest),
                Format(row.Highest), Format(row.Lowest), row.Average.ToString("0.##", CultureInfo.InvariantCulture),
            ]);
        }
        return output.ToString();
    }

    /// <summary>Exports every recorded event in input order, including its stable ID and offset-aware timestamp.</summary>
    public static string ExportHistoryCsv(IEnumerable<RollEntry> entries)
    {
        ArgumentNullException.ThrowIfNull(entries);
        var output = new StringBuilder();
        AppendCsvRow(output, ["记录ID", "时间", "玩家", "服务器", "点数"]);
        foreach (var entry in entries)
        {
            AppendCsvRow(output,
            [
                entry.Id.ToString("D"),
                entry.Timestamp.ToString("O", CultureInfo.InvariantCulture),
                entry.PlayerName,
                entry.World ?? string.Empty,
                Format(entry.Value),
            ]);
        }
        return output.ToString();
    }

    private static string Format(long value) => value.ToString(CultureInfo.InvariantCulture);

    private static void AppendCsvRow(StringBuilder output, IEnumerable<string> fields)
    {
        output.AppendJoin(',', fields.Select(EscapeCsv));
        output.Append("\r\n");
    }

    private static string EscapeCsv(string value)
    {
        var trimmed = value.AsSpan().TrimStart();
        // CSV quoting alone does not prevent Excel/Calc from interpreting a formula.
        if ((!trimmed.IsEmpty && trimmed[0] is '=' or '+' or '-' or '@') ||
            (value.Length > 0 && value[0] is '\t' or '\r' or '\n'))
            value = "'" + value;
        return "\"" + value.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
    }

    private readonly record struct PlayerIdentity(string Name, string World);

    private sealed class PlayerIdentityComparer : IEqualityComparer<PlayerIdentity>
    {
        public static PlayerIdentityComparer Instance { get; } = new();

        public bool Equals(PlayerIdentity x, PlayerIdentity y) =>
            StringComparer.OrdinalIgnoreCase.Equals(x.Name, y.Name) &&
            StringComparer.OrdinalIgnoreCase.Equals(x.World, y.World);

        public int GetHashCode(PlayerIdentity obj) => HashCode.Combine(
            StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Name),
            StringComparer.OrdinalIgnoreCase.GetHashCode(obj.World));
    }
}
