using System.Text.Json;
using DiceStats;
using DiceStats.Core;

internal static class AnnouncementRegression
{
 public static void Run(string scratch,Action<bool,string> check)
 {
  var directory=Path.Combine(scratch,"announcement-lifecycle");
  var sent=new List<(string Text,AnnouncementChannel Channel)>();
  var settings=new AnnouncementSettings {Channel=AnnouncementChannel.Party,StartText="开始 {规则} 目标{目标}",HighestText="最高 {结果} 总{人数}人/{次数}次",LowestText="最低 {结果}",ClosestText="最近{目标} {结果}",EmptyText="无人参与"};
  using(var c=new StatsController(directory)) {
   c.AnnouncementRequested+=(text,channel)=>sent.Add((text,channel)); c.SetAnnouncements(settings);
   check(!c.CanEnd,"never-started empty session cannot be ended"); c.End(); check(sent.Count==0,"ending a never-started session requests no announcement");
   c.SetMode(RankingMode.Closest);c.SetTarget(99);c.Start();check(sent.Count==1 && sent[0]==("开始 最接近 99 点 目标99",AnnouncementChannel.Party),"start resolves target/rule tokens and selected channel");
   c.Start();check(sent.Count==1,"repeated Start while recording does not duplicate announcement");
   c.Pause();check(sent.Count==1 && c.CanEnd,"Pause requests no announcement and session remains endable");
   c.Start();check(sent.Count==2,"resuming paused recording requests one fresh start announcement");
   c.Record("甲","一区",98);c.Record("乙","二区",100);c.Record("甲","一区",800);
   var expected=c.PreviewEnd();c.End();check(c.HasEnded && !c.CanEnd && !c.IsRecording && sent.Count==3,"End stops recording, sets final state, and emits once");
   check(sent[^1].Text==expected && expected.Contains("甲@一区（98 点，差 1 点）") && expected.Contains("乙@二区（100 点，差 1 点）"),"closest-mode announcement includes equal-distance winners on both sides");
   var snapshot=sent[^1];c.SetTarget(400);c.SetMode(RankingMode.Highest);c.End();
   check(sent.Count==3 && sent[^1]==snapshot,"queued end announcement is an immutable snapshot and repeated End is ignored");
   check(!c.Record("结束后","一区",999),"ended sessions ignore future rolls");
  }
  using(var c=new StatsController(directory)) {
   c.AnnouncementRequested+=(text,channel)=>sent.Add((text,channel));
   check(c.HasEnded && !c.IsRecording && c.Rolls.Count==3,"ended state and history persist across restart");
   check(c.AnnouncementOptions==settings && c.Mode==RankingMode.Highest && c.Target==400,"channel, all templates, rule, and target persist across restart");
   c.Start();check(c.IsRecording && !c.HasEnded && c.Rolls.Count==0 && sent.Count==4,"Start after End automatically opens and starts fresh round");
   var archive=Directory.GetFiles(Path.Combine(directory,"archive"),"*.json");
   var old=JsonSerializer.Deserialize<SessionDocument>(File.ReadAllText(archive.Single()))!;
   check(old.Ended && old.Rolls.Count==3 && old.Announcements==settings,"automatic new round archives ended snapshot and original templates");
   check(c.AnnouncementOptions==settings,"templates and selected channel survive automatic new round");
   c.End();check(sent[^1]==("无人参与",AnnouncementChannel.Party),"started session without participants emits configured empty result");
  }
  foreach(var mode in new[]{RankingMode.Highest,RankingMode.Lowest,RankingMode.Closest}) {
   using var c=new StatsController(Path.Combine(scratch,"mode-"+mode));
   var messages=new List<string>();c.AnnouncementRequested+=(text,_)=>messages.Add(text);c.SetMode(mode);c.Start();
   c.Record("甲","",0);c.Record("甲","",999);c.Record("甲","",99);c.Record("乙","",0);c.Record("乙","",999);c.Record("乙","",99);c.Record("丙","",500);
   var expected=c.PreviewEnd();c.End();
   check(messages.Count==2 && messages[1]==expected && expected.Contains("甲") && expected.Contains("乙") && !expected.Contains("丙"),$"{mode}: ending publishes selected rule and every tied winner, excluding nonwinners");
  }
  var legacy=Path.Combine(scratch,"legacy-migration");Directory.CreateDirectory(legacy);
  File.WriteAllText(Path.Combine(legacy,"session.json"),"{\"Version\":1,\"Mode\":2,\"Target\":99,\"Rolls\":[{\"PlayerName\":\"旧版玩家\",\"World\":\"一区\",\"Value\":99}]}" );
  using(var c=new StatsController(legacy)) check(!c.IsReadOnly && !c.HasEnded && !c.IsRecording && c.CanEnd && c.AnnouncementOptions==new AnnouncementSettings() && c.Rolls.Count==1,"v1.0 session migrates missing announcement fields to defaults and remains paused");
  using(var c=new StatsController(Path.Combine(scratch,"empty-templates"))) {
   var requested=0;c.AnnouncementRequested+=(_,_)=>requested++;
   c.SetAnnouncements(settings with {StartText="",HighestText="",LowestText="",ClosestText="",EmptyText=""});c.Start();c.End();c.Start();c.Record("参与者","",99);c.End();
   check(requested==0 && c.HasEnded,"blank start/result/empty templates suppress announcement events while lifecycle works");
  }
  using(var c=new StatsController(Path.Combine(scratch,"start-guard"),()=>false)) {
   var requested=0;c.AnnouncementRequested+=(_,_)=>requested++;c.Start();
   check(!c.IsRecording && requested==0 && c.IsError,"game-state start guard prevents recording and announcements");
  }
  using(var c=new StatsController(Path.Combine(scratch,"end-enqueue-retry"))) {
   var outbox=new ChatOutbox();c.AnnouncementRequested+=outbox.Enqueue;
   c.SetAnnouncements(settings with {StartText="",HighestText=string.Join('\n',Enumerable.Repeat("甲",600))});c.Start();c.Record("参与者","一区",99);c.End();
   check(outbox.Count==0 && !c.IsRecording && !c.HasEnded && c.CanEnd && c.Rolls.Count==1 && c.IsError,"oversized end announcement rejects atomically while preserving records and allowing retry");
   c.SetAnnouncements(c.AnnouncementOptions with {HighestText="胜者 {结果}"});c.End();
   check(outbox.Count==1 && c.HasEnded && !c.CanEnd && c.Rolls.Count==1,"corrected end template retries successfully without losing records");
   c.End();var actuallySent=new List<string>();outbox.Tick(DateTimeOffset.UtcNow,actuallySent.Add);outbox.Tick(DateTimeOffset.UtcNow.AddMinutes(1),actuallySent.Add);
   check(actuallySent.Count==1 && actuallySent[0].Contains("胜者 参与者@一区（99 点）"),"successful retry and duplicate End produce exactly one results command");
  }
 }

 public static void Outbox(Action<bool,string> check)
 {
  var q=new ChatOutbox();var sent=new List<string>();var now=DateTimeOffset.Parse("2026-09-23T00:00:00Z");
  q.Enqueue("第一条\n第二条",AnnouncementChannel.Party);q.Enqueue("第三条",AnnouncementChannel.Shout);
  q.Tick(now,sent.Add);check(sent.SequenceEqual(new[]{"/p 第一条"}) && q.Count==2,"outbox emits at most one first command, preserving order and channel");
  q.Tick(now,sent.Add);q.Tick(now.AddMilliseconds(2999),sent.Add);check(sent.Count==1 && q.Count==2,"outbox suppresses sends before full three-second interval");
  q.Tick(now.AddSeconds(3),sent.Add);q.Tick(now.AddHours(1),sent.Add);check(sent.SequenceEqual(new[]{"/p 第一条","/p 第二条","/sh 第三条"}) && q.Count==0,"outbox sends one FIFO command per eligible Tick even after long idle");
  q.Enqueue("待清理1\n待清理2",AnnouncementChannel.Echo);q.Clear();q.Tick(now.AddHours(2),sent.Add);check(q.Count==0 && sent.Count==3,"Clear removes all queued messages before any further send");
  q.Enqueue("失败\n不得发送",AnnouncementChannel.Say);var thrown=false;try{q.Tick(now.AddHours(3),_=>throw new IOException("simulated sender failure"));}catch(IOException){thrown=true;}
  check(thrown && q.Count==0,"sender exception propagates and clears remaining queue");
  var full=new ChatOutbox();full.Enqueue(string.Join('\n',Enumerable.Repeat("保留",511)),AnnouncementChannel.Echo);var rejected=false;
  try{full.Enqueue("超限1\n超限2",AnnouncementChannel.Party);}catch(InvalidOperationException){rejected=true;}
  check(rejected && full.Count==511,"512-command queue limit rejects overflow atomically without a partial enqueue");
  full.Enqueue("最后",AnnouncementChannel.Say);check(full.Count==512,"queue accepts exactly 512 commands");
  full.Clear();check(full.Count==0,"capacity-filled queue can be cleared");
 }
}
