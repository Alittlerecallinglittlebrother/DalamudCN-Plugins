using System.Numerics;
using System.Text.Json;
using Dalamud.Bindings.ImGui;
using DiceStats;
using DiceStats.Core;

var output = Path.GetFullPath(args.ElementAtOrDefault(0) ?? Path.Combine(AppContext.BaseDirectory, "validation"));
var scratch = Path.Combine(Path.GetFullPath(args.ElementAtOrDefault(1) ?? Path.Combine(Path.GetTempPath(), "DiceStats-tests")), Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(output); Directory.CreateDirectory(scratch);
var log = new List<string>();
var failures = 0;
void Check(bool ok, string label) { var line = (ok ? "PASS " : "FAIL ") + label; Console.WriteLine(line); log.Add(line); if (!ok) failures++; }
void Test(string name, Action action) { try { action(); } catch (Exception e) { Check(false, name + ": " + e); } }
Test("controller lifecycle", () => {
 var path=Path.Combine(scratch,"lifecycle");
 using(var c=new StatsController(path)) {
  Check(!c.IsRecording && !c.Record("未开始","拉诺西亚",99),"new controller starts paused and ignores unsolicited rolls");
  c.Start(); Check(c.Record("小树","拉诺西亚",0) && c.Record("小树","拉诺西亚",999) && c.Record("小树","拉诺西亚",99),"started session accepts complete roll history including zero");
  c.SetMode(RankingMode.Closest); c.SetTarget(98); c.Pause();
  Check(!c.Record("已暂停","拉诺西亚",98) && c.Rolls.Count==3,"pause ignores future rolls without erasing history");
  Check(c.Rows.Single().Selected==99 && c.Rows.Single().Score==1,"controller recalculates nearest target from full history");
 }
 using(var c=new StatsController(path)) {
  Check(!c.IsRecording && c.Rolls.Count==3 && c.Mode==RankingMode.Closest && c.Target==98,"restart restores data and preferences while remaining paused");
  var csv=c.Export(); Check(csv!=null && File.Exists(csv) && File.Exists(Path.ChangeExtension(csv,".ranking.csv")),"export creates history and ranking CSV files");
  Check(File.ReadAllLines(csv!).Length==4 && File.ReadAllLines(Path.ChangeExtension(csv!,".ranking.csv")).Length==2,"history export contains all three rolls while ranking has one player");
  Check(File.ReadAllBytes(csv!).Take(3).SequenceEqual(new byte[]{239,187,191}),"CSV uses UTF-8 BOM for Chinese spreadsheet text");
  Check(c.NewRound() && c.Rolls.Count==0 && !c.IsRecording && c.Mode==RankingMode.Closest && c.Target==98,"new round empties records, remains paused, and preserves ranking preferences");
  var archive=Directory.GetFiles(Path.Combine(path,"archive"),"*.json");
  Check(archive.Length==1 && JsonSerializer.Deserialize<SessionDocument>(File.ReadAllText(archive[0]))!.Rolls.Count==3,"new round archives all previous records");
 }
 using(var c=new StatsController(path)) Check(c.Rolls.Count==0 && c.Target==98,"new empty round survives reload");
});
foreach(var pair in new[]{("broken-json","{this is not JSON"),("invalid-version","{\"Version\":2,\"Target\":99,\"Rolls\":[]}"),("invalid-target","{\"Version\":1,\"Target\":1000,\"Rolls\":[]}"),("null-rolls","{\"Rolls\":null}"),("invalid-roll","{\"Rolls\":[{\"PlayerName\":\"玩家\",\"World\":\"\",\"Value\":1000}]}"),("empty-name","{\"Rolls\":[{\"PlayerName\":\"\",\"World\":\"\",\"Value\":99}]}")}) Test(pair.Item1,()=>{
 var dir=Path.Combine(scratch,pair.Item1); Directory.CreateDirectory(dir); var file=Path.Combine(dir,"session.json"); File.WriteAllText(file,pair.Item2);
 using(var c=new StatsController(dir)) { Check(c.IsReadOnly && c.IsError,"invalid session enters read-only state: "+pair.Item1); c.Start(); c.SetTarget(50); Check(!c.Record("甲","",99) && !c.NewRound(),"read-only controller rejects recording and reset: "+pair.Item1); }
 Check(File.ReadAllText(file)==pair.Item2,"invalid original remains byte-preserved: "+pair.Item1);
});
Test("save failure",()=>{
 var dir=Path.Combine(scratch,"save-failure"); using var c=new StatsController(dir); c.Start(); c.Record("可导出记录","",99); Directory.CreateDirectory(Path.Combine(dir,"session.json.tmp")); c.Pause();
 Check(c.IsReadOnly && c.IsError && !c.IsRecording && c.Rolls.Count==1,"save failure pauses into read-only mode and retains in-memory records");
 Check(c.Export() is {} p && File.Exists(p),"in-memory records remain exportable after save failure");
});
Test("announcements controller",()=>AnnouncementRegression.Run(scratch,Check));
Test("outbox",()=>AnnouncementRegression.Outbox(Check));
Test("native UI",()=>RuntimeUi.Run(output,scratch,Check));
log.Add($"RESULT {log.Count(l=>l.StartsWith("PASS "))} passed; {failures} failed. Offline native UI and filesystem tests; not in-game validation.");
File.WriteAllLines(Path.Combine(output,"runtime-validation.txt"),log); Console.WriteLine(log[^1]); return failures==0?0:1;

internal static unsafe class RuntimeUi {
 public static void Run(string output,string scratch,Action<bool,string> check) {
  var context=ImGui.CreateContext();
  try {
   var io=ImGui.GetIO(); io.IniFilename=null; io.DeltaTime=1f/60;
   io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc",17,default,io.Fonts.GetGlyphRangesChineseFull());
   if(!io.Fonts.Build()) throw new Exception("Chinese font atlas failed"); ImGui.StyleColorsDark();
   var style=ImGui.GetStyle(); style.WindowRounding=0; style.FrameRounding=3;
   using var c=new StatsController(Path.Combine(scratch,"ui")); var view=new StatsView(c);
   var requested=new List<(string Text,AnnouncementChannel Channel)>(); c.AnnouncementRequested+=(text,channel)=>requested.Add((text,channel));
   Render(view,850,600,Path.Combine(output,"ui-empty-850x600.png"));
   Render(view,520,400,Path.Combine(output,"ui-empty-520x400.png"));
   Frame(view,850,600); Frame(view,850,600);
   Click(view,50,96); check(c.IsRecording,"native start button starts recording");
   check(requested.Count==1,"native start button requests exactly one announcement without sending to game");
   c.Start();
   c.Record("星河","拉诺西亚",999); c.Record("星河","拉诺西亚",0); c.Record("星河","拉诺西亚",98);
   c.Record("星河","幻影群岛",100); c.Record("月见","红玉海",99); c.Record("海风","萌芽池",300);
   for(var i=1;i<=25;i++) c.Record($"参与者{i:D2}","宇宙和音",(i*41)%1000);
   c.SetMode(RankingMode.Closest); c.SetTarget(99);
   Render(view,850,600,Path.Combine(output,"ui-filled-850x600.png"));
   Render(view,520,400,Path.Combine(output,"ui-filled-520x400.png"));
   Frame(view,850,600); Frame(view,850,600); Click(view,50,96); check(!c.IsRecording,"native pause button stops recording");
   c.Pause();
   Click(view,138,135); check(c.Mode==RankingMode.Lowest,"native minimum-mode radio button changes ranking");
   Render(view,850,600,Path.Combine(output,"ui-lowest-850x600.png"));
   Click(view,96,242); Render(view,850,600,Path.Combine(output,"ui-history-850x600.png"));
   Click(view,164,242); Frame(view,850,600); Frame(view,850,600);
   var beforeEditor=requested.Count;
   EnterText(view,180,366,"掷骰开始！{规则}，目标 {目标}。请使用 /random。");
   check(c.AnnouncementOptions.StartText=="掷骰开始！{规则}，目标 {目标}。请使用 /random。","native announcement editor updates stored start template");
   check(requested.Count==beforeEditor && c.PreviewStart().Contains("最低点数，目标 99"),"editing and preview substitute current values without requesting a message");
   Render(view,850,600,Path.Combine(output,"ui-announcements-850x600.png"));
   Wheel(view,780,480,-20); SoftwareRenderer.Save(Path.Combine(output,"ui-announcements-preview-850x600.png"));
   Frame(view,520,400);Frame(view,520,400);Wheel(view,505,340,-20,520,400);Wheel(view,440,340,-40,520,400);Render(view,520,400,Path.Combine(output,"ui-announcements-preview-520x400.png"));
   Wheel(view,440,280,40,520,400); Render(view,520,400,Path.Combine(output,"ui-announcements-520x400.png"));
   Frame(view,850,600); Frame(view,850,600); Click(view,35,242); Frame(view,850,600);
   var beforeEnd=requested.Count; Click(view,195,96); check(c.HasEnded && !c.IsRecording && requested.Count==beforeEnd+1,"native end button finalizes and requests one results announcement");
   Render(view,850,600,Path.Combine(output,"ui-ended-850x600.png"));
   Click(view,195,96); check(requested.Count==beforeEnd+1,"disabled native end button cannot duplicate announcement");
   view.RequestNewRound(); Frame(view,850,600); Frame(view,850,600); SoftwareRenderer.Save(Path.Combine(output,"ui-new-round-confirm.png"));
   check(ImGui.GetDrawData().TotalVtxCount>0,"native modal renders without invalid ImGui state");
   check(Directory.GetFiles(output,"ui-*.png").Length>=12,"twelve nonblank PNG captures saved with Chinese glyphs");
  } finally {ImGui.DestroyContext(context);}
 }
 static void Render(StatsView view,int width,int height,string path) { ImGui.GetIO().AddMousePosEvent(-100,-100); Frame(view,width,height); Frame(view,width,height); SoftwareRenderer.Save(path); }
 static void Click(StatsView view,float x,float y,int width=850,int height=600) {var io=ImGui.GetIO();io.AddMousePosEvent(x,y);Frame(view,width,height);io.AddMouseButtonEvent(0,true);Frame(view,width,height);io.AddMouseButtonEvent(0,false);Frame(view,width,height);}
 static void Wheel(StatsView view,float x,float y,float amount,int width=850,int height=600) {var io=ImGui.GetIO();io.AddMousePosEvent(x,y);Frame(view,width,height);io.AddMouseWheelEvent(0,amount);Frame(view,width,height);Frame(view,width,height);}
 static void EnterText(StatsView view,float x,float y,string value) {Click(view,x,y);var io=ImGui.GetIO();io.AddKeyEvent(ImGuiKey.ModCtrl,true);io.AddKeyEvent(ImGuiKey.A,true);Frame(view,850,600);io.AddKeyEvent(ImGuiKey.A,false);io.AddKeyEvent(ImGuiKey.ModCtrl,false);Frame(view,850,600);foreach(var character in value)io.AddInputCharacter(character);Frame(view,850,600);Click(view,800,540);}
 static void Frame(StatsView view,int width,int height) {ImGui.GetIO().DisplaySize=new(width,height);ImGui.NewFrame();ImGui.SetNextWindowPos(Vector2.Zero);ImGui.SetNextWindowSize(new(width,height));ImGui.Begin("点数统计##DiceStatsRuntime",ImGuiWindowFlags.NoResize|ImGuiWindowFlags.NoMove);view.Draw();ImGui.End();ImGui.Render();if(ImGui.GetDrawData().TotalVtxCount==0)throw new Exception("blank UI frame");}
}
