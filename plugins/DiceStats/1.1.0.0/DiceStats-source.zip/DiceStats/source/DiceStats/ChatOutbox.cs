using DiceStats.Core;

namespace DiceStats;

/// <summary>FIFO, fixed chat-channel prefix, and one send per three seconds. Never persists pending chat.</summary>
public sealed class ChatOutbox
{
    private readonly Queue<string> pending = new();
    private DateTimeOffset nextSend;
    public int Count => pending.Count;

    public void Enqueue(string text, AnnouncementChannel channel)
    {
        var commands = Announcements.PrepareCommands(text, channel);
        if (pending.Count + commands.Count > 512) throw new InvalidOperationException("公告过长或积压过多，请缩短模板或导出结果。");
        foreach (var command in commands) pending.Enqueue(command);
    }

    public void Tick(DateTimeOffset now, Action<string> send)
    {
        if (pending.Count == 0 || now < nextSend) return;
        var command = pending.Dequeue();
        nextSend = now.AddSeconds(3);
        try { send(command); }
        catch { Clear(); throw; }
    }

    public void Clear() => pending.Clear();
}
