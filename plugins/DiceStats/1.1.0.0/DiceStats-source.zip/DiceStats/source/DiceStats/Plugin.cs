using System.Numerics;
using Dalamud.Game.Chat;
using Dalamud.Game.Command;
using Dalamud.Game.Text;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.Game.Text.SeStringHandling.Payloads;
using Dalamud.Interface.Windowing;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using DiceStats.Core;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI;

namespace DiceStats;

public sealed class Plugin : IDalamudPlugin
{
    [PluginService] internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;
    [PluginService] internal static ICommandManager CommandManager { get; private set; } = null!;
    [PluginService] internal static IChatGui ChatGui { get; private set; } = null!;
    [PluginService] internal static IClientState ClientState { get; private set; } = null!;
    [PluginService] internal static IFramework Framework { get; private set; } = null!;
    [PluginService] internal static IPluginLog Log { get; private set; } = null!;
    private readonly WindowSystem windows = new("DiceStats");
    private readonly StatsController controller;
    private readonly StatsWindow window;
    private readonly ChatOutbox outbox = new();
    private bool disposed;

    public Plugin()
    {
        controller = new StatsController(PluginInterface.ConfigDirectory.FullName, () => ClientState.IsLoggedIn && !ClientState.IsGPosing);
        controller.AnnouncementRequested += QueueAnnouncement;
        window = new StatsWindow(controller);
        windows.AddWindow(window);
        CommandManager.AddHandler("/dstat", new CommandInfo(OnCommand) { HelpMessage = "点数统计：start 开始并公告，end 结束并公布结果，pause 暂停，export 导出，clear 新一轮。" });
        PluginInterface.UiBuilder.Draw += windows.Draw;
        PluginInterface.UiBuilder.OpenMainUi += Open;
        PluginInterface.UiBuilder.OpenConfigUi += Open;
        ChatGui.ChatMessage += OnChat;
        Framework.Update += Update;
    }

    private void Open() => window.IsOpen = true;
    private void OnCommand(string command, string arguments)
    {
        switch (arguments.Trim().ToLowerInvariant())
        {
            case "start": case "开始": controller.Start(); Open(); break;
            case "pause": case "暂停": controller.Pause(); Open(); break;
            case "end": case "stop": case "结束": controller.End(); Open(); break;
            case "export": case "导出": controller.Export(); Open(); break;
            case "clear": case "新一轮": Open(); window.View.RequestNewRound(); break;
            default: Open(); break;
        }
    }

    private void Update(IFramework framework)
    {
        if (disposed) return;
        if (!ClientState.IsLoggedIn)
        {
            if (controller.IsRecording) controller.Pause();
            outbox.Clear();
        }
        controller.Tick();
        if (!ClientState.IsLoggedIn || ClientState.IsGPosing) return;
        try { outbox.Tick(DateTimeOffset.UtcNow, SendChat); }
        catch (Exception ex)
        {
            Log.Error(ex, "DiceStats announcement send failed.");
            controller.SetStatus("公告发送失败，剩余队列已取消，请查看 Dalamud 日志。", true);
        }
    }

    private void QueueAnnouncement(string text, AnnouncementChannel channel)
    {
        if (disposed) throw new ObjectDisposedException(nameof(Plugin));
        if (!ClientState.IsLoggedIn) throw new InvalidOperationException("角色未登录，无法发送公告。");
        outbox.Enqueue(text, channel);
    }

    private static unsafe void SendChat(string command)
    {
        var module = UIModule.Instance();
        if (module is null) throw new InvalidOperationException("聊天模块尚未就绪。");
        using var text = new Utf8String(command);
        module->ProcessChatBoxEntry(&text, 0, false);
    }

    private void OnChat(IHandleableChatMessage message)
    {
        if (disposed || !controller.IsRecording) return;
        try
        {
            IChatMessage chat = message;
            // Real /random results use log kind 74, verified against the current CN client.
            // Say/tell/echo text imitating a roll is never considered.
            if (chat.LogKind != XivChatType.RandomNumber || !RollParser.TryParse(message.Message.TextValue, out var roll) || roll is null) return;
            var payload = message.Message.Payloads.OfType<PlayerPayload>().FirstOrDefault() ??
                          message.Sender.Payloads.OfType<PlayerPayload>().FirstOrDefault();
            var name = roll.PlayerName;
            var world = string.Empty;
            if (payload is not null && !string.IsNullOrWhiteSpace(payload.PlayerName))
            {
                name = payload.PlayerName;
                if (payload.World.IsValid) world = payload.World.Value.Name.ToString();
                else if (payload.World.RowId != 0) world = "World#" + payload.World.RowId;
            }
            else
            {
                var separator = name.IndexOf('\ue05d');
                if (separator > 0) { world = name[(separator + 1)..].Trim(); name = name[..separator].Trim(); }
            }
            controller.Record(name, world, roll.Value);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "DiceStats could not process a random-number message.");
            controller.SetStatus("一条骰点消息解析失败，可在 Dalamud 日志中查看原因。", true);
        }
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        ChatGui.ChatMessage -= OnChat;
        Framework.Update -= Update;
        PluginInterface.UiBuilder.Draw -= windows.Draw;
        PluginInterface.UiBuilder.OpenMainUi -= Open;
        PluginInterface.UiBuilder.OpenConfigUi -= Open;
        CommandManager.RemoveHandler("/dstat");
        controller.AnnouncementRequested -= QueueAnnouncement;
        outbox.Clear();
        windows.RemoveAllWindows();
        controller.Dispose();
    }

    private sealed class StatsWindow : Window
    {
        public StatsView View { get; }
        public StatsWindow(StatsController controller) : base("点数统计###DiceStats")
        {
            View = new StatsView(controller);
            Size = new Vector2(850, 600);
            SizeCondition = Dalamud.Bindings.ImGui.ImGuiCond.FirstUseEver;
            SizeConstraints = new WindowSizeConstraints { MinimumSize = new Vector2(520, 400), MaximumSize = new Vector2(float.MaxValue) };
        }
        public override void Draw() => View.Draw();
    }
}
