using System.Text;
using System.Text.Json;
using DiceStats.Core;

namespace DiceStats;

public sealed class SessionDocument
{
    public int Version { get; set; } = 1;
    public DateTimeOffset StartedAt { get; set; } = DateTimeOffset.Now;
    public RankingMode Mode { get; set; } = RankingMode.Highest;
    public int Target { get; set; } = 99;
    public bool WasStarted { get; set; }
    public bool Ended { get; set; }
    public AnnouncementSettings Announcements { get; set; } = new();
    public List<RollEntry> Rolls { get; set; } = [];
}

public sealed class StatsController : IDisposable
{
    public const int MaxRecords = 20000;
    private readonly string directory;
    private readonly string sessionPath;
    private readonly Func<bool>? canStart;
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private SessionDocument state = new();
    private IReadOnlyList<PlayerStats>? rows;
    private string? startPreview;
    private string? endPreview;
    private bool dirty;
    private DateTimeOffset nextSave;

    public StatsController(string directory, Func<bool>? canStart = null)
    {
        this.directory = directory;
        this.canStart = canStart;
        sessionPath = Path.Combine(directory, "session.json");
        try
        {
            Directory.CreateDirectory(directory);
            if (File.Exists(sessionPath))
            {
                var loaded = JsonSerializer.Deserialize<SessionDocument>(File.ReadAllText(sessionPath), JsonOptions);
                if (loaded is null || loaded.Version != 1 || loaded.Rolls is null ||
                    loaded.Rolls.Count > MaxRecords || !Enum.IsDefined(loaded.Mode) || loaded.Target is < 0 or > 999 ||
                    !DiceStats.Core.Announcements.IsValid(loaded.Announcements) ||
                    loaded.Rolls.Any(r => r is null || string.IsNullOrWhiteSpace(r.PlayerName) || r.Value is < 0 or > 999))
                    throw new InvalidDataException("统计文件格式无效或版本不兼容");
                state = loaded;
                Status = $"已恢复 {state.Rolls.Count} 条记录；点击开始统计继续。";
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or InvalidDataException)
        {
            IsReadOnly = true;
            IsError = true;
            Status = "无法读取统计文件，原文件已保留：" + ex.Message;
        }
    }

    public bool IsRecording { get; private set; }
    public bool HasEnded => state.Ended;
    public bool CanEnd => !IsReadOnly && !HasEnded && (state.WasStarted || IsRecording || state.Rolls.Count > 0);
    public AnnouncementSettings AnnouncementOptions => state.Announcements;
    public event Action<string, AnnouncementChannel>? AnnouncementRequested;
    public bool IsReadOnly { get; private set; }
    public bool IsError { get; private set; }
    public string Status { get; private set; } = "准备就绪，点击开始统计后接收 /random 点数。";
    public RankingMode Mode => state.Mode;
    public int Target => state.Target;
    public DateTimeOffset StartedAt => state.StartedAt;
    public IReadOnlyList<RollEntry> Rolls => state.Rolls;
    public IReadOnlyList<PlayerStats> Rows => rows ??= Statistics.Calculate(state.Rolls, state.Mode, state.Target);

    public void Start()
    {
        if (IsReadOnly || IsRecording) return;
        if (canStart is not null && !canStart()) { SetStatus("请登录角色并退出集体姿势后开始统计。", true); return; }
        if (HasEnded && !NewRound()) return;
        if (state.Rolls.Count >= MaxRecords) { SetStatus("本轮记录已满，请先导出并开始新一轮。", true); return; }
        IsRecording = true;
        state.WasStarted = true;
        Changed();
        SetStatus("正在统计 /random，关闭窗口继续统计。");
        if (Publish(PreviewStart()) == AnnouncementOutcome.Queued) SetStatus("正在统计 /random；开始公告已加入发送队列。关闭窗口继续统计。");
    }

    public void Pause()
    {
        IsRecording = false;
        SetStatus("统计已暂停，现有记录已保留。");
        Save();
    }

    public void End()
    {
        if (!CanEnd) return;
        // Freeze the result before enqueueing; later target/rule changes cannot alter this announcement.
        var text = DiceStats.Core.Announcements.RenderEnd(state.Announcements, state.Rolls, Mode, Target);
        IsRecording = false;
        SetStatus("统计已停止，正在生成结果公告。");
        var outcome = Publish(text);
        // A rejected queue entry sends nothing. Keep this round paused and retryable
        // so the host can shorten the template or reconnect without clearing rolls.
        state.Ended = outcome != AnnouncementOutcome.Failed;
        Changed();
        Save();
        if (!IsError) SetStatus(outcome == AnnouncementOutcome.Queued
            ? "统计已结束，结果公告已加入发送队列；记录已保留。"
            : "统计已结束，记录已保留。");
    }

    public void SetAnnouncements(AnnouncementSettings settings)
    {
        if (IsReadOnly) return;
        if (!DiceStats.Core.Announcements.IsValid(settings)) { SetStatus("公告设置无效，每段文字最多 2000 个字符。", true); return; }
        state.Announcements = settings;
        Changed();
    }

    public string PreviewStart() => startPreview ??= DiceStats.Core.Announcements.RenderStart(state.Announcements, state.Rolls, Mode, Target);
    public string PreviewEnd() => endPreview ??= DiceStats.Core.Announcements.RenderEnd(state.Announcements, state.Rolls, Mode, Target);

    private enum AnnouncementOutcome { Suppressed, Queued, Failed }

    private AnnouncementOutcome Publish(string text)
    {
        if (string.IsNullOrWhiteSpace(text) || AnnouncementRequested is null) return AnnouncementOutcome.Suppressed;
        try { AnnouncementRequested.Invoke(text, state.Announcements.Channel); return AnnouncementOutcome.Queued; }
        catch (Exception ex) { SetStatus("公告未能加入发送队列，可调整设置后重试：" + ex.Message, true); return AnnouncementOutcome.Failed; }
    }

    public bool Record(string playerName, string world, int value, DateTimeOffset? timestamp = null)
    {
        if (!IsRecording || IsReadOnly || string.IsNullOrWhiteSpace(playerName) || value is < 0 or > 999) return false;
        if (state.Rolls.Count >= MaxRecords) { IsRecording = false; SetStatus("本轮记录已满，统计已暂停。请先导出或开始新一轮。", true); return false; }
        state.Rolls.Add(new RollEntry(Guid.NewGuid(), timestamp ?? DateTimeOffset.Now, playerName.Trim(), world.Trim(), value));
        Changed();
        return true;
    }

    public void SetMode(RankingMode mode)
    {
        if (IsReadOnly || !Enum.IsDefined(mode)) return;
        state.Mode = mode;
        Changed();
    }

    public void SetTarget(int target)
    {
        if (IsReadOnly) return;
        state.Target = Math.Clamp(target, 0, 999);
        Changed();
    }

    public bool NewRound()
    {
        if (IsReadOnly) return false;
        try
        {
            if (state.Rolls.Count > 0)
            {
                Directory.CreateDirectory(Path.Combine(directory, "archive"));
                File.WriteAllText(UniqueFile("archive", "session", ".json"), JsonSerializer.Serialize(state, JsonOptions));
            }
            state = new SessionDocument { Mode = Mode, Target = Target, Announcements = state.Announcements };
            IsRecording = false;
            Changed();
            Save();
            if (IsReadOnly) return false;
            SetStatus("新一轮已准备好；上一轮已自动归档，点击开始统计即可。 ");
            return true;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            SetStatus("归档失败，保留当前记录：" + ex.Message, true);
            return false;
        }
    }

    public string? Export()
    {
        try
        {
            Directory.CreateDirectory(Path.Combine(directory, "exports"));
            var path = UniqueFile("exports", "rolls", ".csv");
            File.WriteAllText(path, Statistics.ExportHistoryCsv(state.Rolls), new UTF8Encoding(true));
            File.WriteAllText(Path.ChangeExtension(path, ".ranking.csv"), Statistics.ExportCsv(state.Rolls, Mode, Target), new UTF8Encoding(true));
            SetStatus("已导出逐次记录和当前排名：" + path);
            return path;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            SetStatus("导出失败：" + ex.Message, true);
            return null;
        }
    }

    public void Tick()
    {
        if (dirty && DateTimeOffset.UtcNow >= nextSave) Save();
    }

    public void Dispose() => Save();

    public void SetStatus(string text, bool error = false) { Status = text; IsError = error; }

    private void Changed()
    {
        rows = null;
        startPreview = null;
        endPreview = null;
        if (!dirty) nextSave = DateTimeOffset.UtcNow.AddSeconds(1);
        dirty = true;
    }

    private string UniqueFile(string folder, string prefix, string extension) =>
        Path.Combine(directory, folder, $"{prefix}-{DateTime.Now:yyyyMMdd-HHmmss-fff}-{Guid.NewGuid().ToString("N")[..6]}{extension}");

    private void Save()
    {
        if (!dirty || IsReadOnly) return;
        try
        {
            var temporary = sessionPath + ".tmp";
            File.WriteAllText(temporary, JsonSerializer.Serialize(state, JsonOptions));
            if (File.Exists(sessionPath)) File.Replace(temporary, sessionPath, sessionPath + ".bak", true);
            else File.Move(temporary, sessionPath);
            dirty = false;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            IsRecording = false;
            IsReadOnly = true;
            SetStatus("保存失败，已暂停统计；内存中的记录仍可导出：" + ex.Message, true);
        }
    }
}
