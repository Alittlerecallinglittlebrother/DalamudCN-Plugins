using System.Numerics;
using Dalamud.Bindings.ImGui;
using DiceStats.Core;

namespace DiceStats;

/// <summary>The same view is rendered in Dalamud and the native offline smoke harness.</summary>
public sealed class StatsView(StatsController controller)
{
    private string search = string.Empty;
    private bool clearRequested;
    private static readonly Vector4 Accent = new(0.35f, 0.82f, 0.75f, 1);

    public void RequestNewRound() => clearRequested = true;

    public void Draw()
    {
        ImGui.TextColored(Accent, "点数统计");
        ImGui.SameLine();
        ImGui.TextDisabled(controller.IsRecording ? "  正在记录 /random" : controller.HasEnded ? "  已结束" : "  已暂停");
        ImGui.TextDisabled($"本轮开始于 {controller.StartedAt.LocalDateTime:MM-dd HH:mm}  ·  {controller.Rows.Count} 位玩家  ·  {controller.Rolls.Count} 次掷骰");
        ImGui.Spacing();
        ImGui.BeginDisabled(controller.IsReadOnly);
        if (ImGui.Button(controller.IsRecording ? "暂停统计" : controller.HasEnded ? "开始新一轮" : "开始统计", new Vector2(112, 30)))
        {
            if (controller.IsRecording) controller.Pause(); else controller.Start();
        }
        ImGui.SameLine();
        ImGui.BeginDisabled(!controller.CanEnd);
        if (ImGui.Button("结束并公布结果", new Vector2(135, 30))) controller.End();
        ImGui.EndDisabled();
        ImGui.SameLine();
        if (ImGui.Button("新一轮", new Vector2(85, 30))) clearRequested = true;
        ImGui.EndDisabled();
        if (ImGui.GetContentRegionAvail().X > 650) ImGui.SameLine();
        if (ImGui.Button("导出 CSV", new Vector2(105, 30))) controller.Export();
        ImGui.SameLine();
        if (ImGui.Button("复制排名", new Vector2(100, 30)))
        {
            var title = controller.Mode switch { RankingMode.Highest => "最高点数", RankingMode.Lowest => "最低点数", _ => $"最接近 {controller.Target}" };
            ImGui.SetClipboardText(title + Environment.NewLine + string.Join(Environment.NewLine,
                controller.Rows.Select(r => $"第{r.Rank}名 {DisplayPlayer(r.PlayerName, r.World)}：{r.Selected}点" +
                    (controller.Mode == RankingMode.Closest ? $"（差{r.Score}）" : string.Empty))));
            controller.SetStatus("当前排名已复制到剪贴板。");
        }

        ImGui.Spacing();
        ImGui.Separator();
        ImGui.Spacing();
        ImGui.BeginDisabled(controller.IsReadOnly);
        if (ImGui.RadioButton("最高点数", controller.Mode == RankingMode.Highest)) controller.SetMode(RankingMode.Highest);
        ImGui.SameLine();
        if (ImGui.RadioButton("最低点数", controller.Mode == RankingMode.Lowest)) controller.SetMode(RankingMode.Lowest);
        ImGui.SameLine();
        if (ImGui.RadioButton("最接近目标", controller.Mode == RankingMode.Closest)) controller.SetMode(RankingMode.Closest);
        if (ImGui.GetContentRegionAvail().X > 620) ImGui.SameLine();
        ImGui.SetNextItemWidth(130);
        var target = controller.Target;
        if (ImGui.InputInt("目标数字", ref target)) controller.SetTarget(target);
        ImGui.EndDisabled();
        ImGui.TextDisabled(controller.Mode switch
        {
            RankingMode.Highest => "每位玩家取本轮最高的一次，点数越大排名越靠前。",
            RankingMode.Lowest => "每位玩家取本轮最低的一次，点数越小排名越靠前。",
            _ => $"每位玩家取最接近 {controller.Target} 的一次；两侧等距并列，命中目标优先。",
        });

        if (controller.Rolls.Count > 0)
        {
            var max = controller.Rows.Max(r => r.Highest);
            var min = controller.Rows.Min(r => r.Lowest);
            var nearest = controller.Rolls.Min(r => Math.Abs(r.Value - controller.Target));
            ImGui.Spacing();
            ImGui.TextColored(Accent, $"全场最高 {max}    全场最低 {min}    距 {controller.Target} 最近相差 {nearest}");
        }
        ImGui.Spacing();
        ImGui.SetNextItemWidth(Math.Min(320, ImGui.GetContentRegionAvail().X));
        ImGui.InputTextWithHint("##search", "筛选玩家 / 服务器", ref search, 120);
        ImGui.Spacing();

        if (ImGui.BeginTabBar("stats-tabs"))
        {
            if (ImGui.BeginTabItem("玩家排名"))
            {
                DrawRanking();
                ImGui.EndTabItem();
            }
            if (ImGui.BeginTabItem("逐次记录"))
            {
                DrawHistory();
                ImGui.EndTabItem();
            }
            if (ImGui.BeginTabItem("公告设置"))
            {
                DrawAnnouncements();
                ImGui.EndTabItem();
            }
            ImGui.EndTabBar();
        }
        ImGui.Spacing();
        if (controller.IsError) ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(1, 0.55f, 0.4f, 1));
        ImGui.TextWrapped(controller.Status);
        if (controller.IsError) ImGui.PopStyleColor();

        if (clearRequested) { ImGui.OpenPopup("开始新一轮？"); clearRequested = false; }
        if (ImGui.BeginPopupModal("开始新一轮？", ImGuiWindowFlags.AlwaysAutoResize))
        {
            ImGui.TextUnformatted("当前记录会自动归档，新一轮从空白开始。\n新一轮保持暂停，点击开始统计后再接收点数。");
            ImGui.Spacing();
            if (ImGui.Button("归档并新建", new Vector2(135, 30))) { controller.NewRound(); ImGui.CloseCurrentPopup(); }
            ImGui.SameLine();
            if (ImGui.Button("取消", new Vector2(90, 30))) ImGui.CloseCurrentPopup();
            ImGui.EndPopup();
        }
    }

    private void DrawAnnouncements()
    {
        var visible = ImGui.BeginChild("announcement-editor", new Vector2(0, Math.Max(150, ImGui.GetContentRegionAvail().Y - 65)), false);
        if (visible)
        {
            ImGui.TextWrapped("开始或继续统计时发送开始公告；点击「结束并公布结果」时发送所选规则的结果。暂停不会发结束公告。");
            ImGui.BeginDisabled(controller.IsReadOnly);
            var options = controller.AnnouncementOptions;
            var channelIndex = (int)options.Channel;
            ImGui.SetNextItemWidth(200);
            if (ImGui.Combo("发送频道", ref channelIndex, "说话 /say\0喊话 /yell\0呼喊 /shout\0小队 /party\0团队 /alliance\0默语 /echo\0"))
                controller.SetAnnouncements(options with { Channel = (AnnouncementChannel)channelIndex });
            ImGui.TextWrapped("可以写多行文字，留空则不发送该公告。修改自动保存。长消息会分段发送。默认发送至呼喊频道。");
            Template("开始公告", controller.AnnouncementOptions.StartText, value => controller.AnnouncementOptions with { StartText = value });
            Template("最高点数 · 结束公告", controller.AnnouncementOptions.HighestText, value => controller.AnnouncementOptions with { HighestText = value });
            Template("最低点数 · 结束公告", controller.AnnouncementOptions.LowestText, value => controller.AnnouncementOptions with { LowestText = value });
            Template("最接近目标 · 结束公告", controller.AnnouncementOptions.ClosestText, value => controller.AnnouncementOptions with { ClosestText = value });
            Template("没有玩家参与时", controller.AnnouncementOptions.EmptyText, value => controller.AnnouncementOptions with { EmptyText = value });
            ImGui.EndDisabled();
            ImGui.Spacing();
            ImGui.TextWrapped("可用变量：{规则} {目标} {结果} {玩家} {点数} {差值} {人数} {次数} {最高点数} {最低点数} {最高玩家} {最低玩家}");
            ImGui.TextWrapped("{结果} 会列出所选规则全部并列第一的玩家及各自点数；{玩家} 只列名字。{差值} 是距离目标的差值。示例：恭喜 {结果} 获得本轮第一！");
            ImGui.Separator();
            ImGui.TextColored(Accent, "开始公告预览（只预览，不发送）");
            ImGui.TextWrapped(controller.PreviewStart());
            ImGui.TextColored(Accent, "结束公告预览（按当前规则和记录）");
            ImGui.TextWrapped(controller.PreviewEnd());
        }
        ImGui.EndChild();
    }

    private void Template(string label, string value, Func<string, AnnouncementSettings> update)
    {
        ImGui.TextUnformatted(label);
        if (ImGui.InputTextMultiline("##" + label, ref value, 8001, new Vector2(-1, 65)))
            controller.SetAnnouncements(update(value));
    }

    private void DrawRanking()
    {
        if (controller.Rows.Count == 0)
        {
            ImGui.Spacing();
            ImGui.TextWrapped("还没有点数记录。点击「开始统计」，让参与玩家在游戏中使用 /random 掷骰。\n排名会实时更新；暂停后仍可切换规则或修改目标数字。");
            return;
        }
        var height = Math.Max(70, ImGui.GetContentRegionAvail().Y - 65);
        if (!ImGui.BeginTable("ranking", 8, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerH |
                ImGuiTableFlags.ScrollY | ImGuiTableFlags.ScrollX | ImGuiTableFlags.SizingFixedFit, new Vector2(0, height))) return;
        ImGui.TableSetupScrollFreeze(2, 1);
        string[] titles = ["名次", "玩家 / 服务器", "选定点数", "距目标", "次数", "最近", "最低", "最高"];
        for (var i = 0; i < titles.Length; i++) ImGui.TableSetupColumn(titles[i], ImGuiTableColumnFlags.WidthFixed, i == 1 ? 220 : 62);
        ImGui.TableHeadersRow();
        foreach (var row in controller.Rows)
        {
            if (!Matches(row.PlayerName, row.World)) continue;
            ImGui.TableNextRow();
            Cell(row.Rank.ToString()); Cell(DisplayPlayer(row.PlayerName, row.World)); Cell(row.Selected.ToString());
            Cell(controller.Mode == RankingMode.Closest ? row.Score.ToString() : "—");
            Cell(row.Count.ToString()); Cell(row.Latest.ToString()); Cell(row.Lowest.ToString()); Cell(row.Highest.ToString());
        }
        ImGui.EndTable();
    }

    private void DrawHistory()
    {
        ImGui.TextDisabled("最新记录在上方；界面展示最近 500 条，导出包含本轮全部记录。");
        var height = Math.Max(65, ImGui.GetContentRegionAvail().Y - 65);
        if (!ImGui.BeginTable("history", 3, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerH |
                ImGuiTableFlags.ScrollY | ImGuiTableFlags.ScrollX, new Vector2(0, height))) return;
        ImGui.TableSetupScrollFreeze(0, 1);
        ImGui.TableSetupColumn("时间", ImGuiTableColumnFlags.WidthFixed, 155);
        ImGui.TableSetupColumn("玩家 / 服务器", ImGuiTableColumnFlags.WidthStretch);
        ImGui.TableSetupColumn("点数", ImGuiTableColumnFlags.WidthFixed, 65);
        ImGui.TableHeadersRow();
        foreach (var roll in controller.Rolls.Reverse().Where(r => Matches(r.PlayerName, r.World)).Take(500))
        {
            ImGui.TableNextRow(); Cell(roll.Timestamp.LocalDateTime.ToString("MM-dd HH:mm:ss"));
            Cell(DisplayPlayer(roll.PlayerName, roll.World)); Cell(roll.Value.ToString());
        }
        ImGui.EndTable();
    }

    private bool Matches(string name, string world) => string.IsNullOrWhiteSpace(search) ||
        DisplayPlayer(name, world).Contains(search.Trim(), StringComparison.OrdinalIgnoreCase);
    private static string DisplayPlayer(string name, string world) => string.IsNullOrWhiteSpace(world) ? name : $"{name}@{world}";
    private static void Cell(string value) { ImGui.TableNextColumn(); ImGui.TextUnformatted(value); }
}
