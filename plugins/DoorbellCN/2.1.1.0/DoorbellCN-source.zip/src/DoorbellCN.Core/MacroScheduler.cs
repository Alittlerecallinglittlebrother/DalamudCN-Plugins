namespace DoorbellCN.Core;

public enum ArrivalResult { NewBatch, JoinedBatch, Duplicate, RecordedOnly, Busy, RateLimit, WindowClosed }
public enum BatchState { Empty, Collecting, Ready, CancelledBusy, CancelledAbsent, CancelledLate, CancelledLimit }
public enum ExecutionUpdate { None, Watching, Finished, Uncertain }
public sealed record BatchPoll(BatchState State, int PresentCount = 0);

/// <summary>
/// Exactly one fixed arrival batch, no waiting queue. A durable reservation precedes every native call.
/// Pausing/detaching discards only volatile work, never the scene ledger or character-wide rate limits.
/// </summary>
public sealed class MacroScheduler
{
    private sealed class Batch(double openedAt)
    {
        public double ReadyAt = openedAt + MacroPolicy.BatchSeconds;
        public Dictionary<string, Visitor> Visitors = new(StringComparer.Ordinal);
    }

    private Batch? batch;
    private HouseSession? activeHouse;
    private SceneLedger? scene;
    private CharacterLedger? character;
    private double? idleSince;
    private double watchStarted;
    private bool uncertain;
    public WelcomeLedger Ledger { get; }
    public bool Dirty { get; private set; }
    public bool IsExecuting => character?.InFlight == true;
    public bool IsUncertain => uncertain;
    public int PendingCount => batch?.Visitors.Count ?? 0;
    public long Round => scene?.Round ?? 0;
    public long Attempts => scene?.Attempts ?? 0;
    public int SeenCount => scene?.SeenVisitors.Count ?? 0;

    public MacroScheduler(WelcomeLedger? ledger = null)
    {
        Ledger = ledger ?? new WelcomeLedger();
        Ledger.Validate();
        if (Ledger.Version == 1)
        {
            // Keep identities, rounds, starts and in-flight state; discard legacy cooldown fields.
            Ledger.Version = 2;
            Dirty = true;
        }
    }

    public void Activate(HouseSession house, double now, DateTimeOffset utc)
    {
        if (!house.IsValid) throw new ArgumentException("住宅身份无效。", nameof(house));
        CheckClock(utc);
        if (activeHouse == house) return;
        Detach();
        var sceneKey = Ledger.SceneKey(house);
        var characterKey = Ledger.CharacterKey(house);
        if (!Ledger.Scenes.TryGetValue(sceneKey, out scene))
        {
            if (Ledger.Scenes.Count >= 128) throw new InvalidOperationException("住宅记录已满。");
            Ledger.Scenes.Add(sceneKey, scene = new());
            Touch(utc);
        }
        if (!Ledger.Characters.TryGetValue(characterKey, out character))
        {
            if (Ledger.Characters.Count >= 64) throw new InvalidOperationException("角色记录已满。");
            Ledger.Characters.Add(characterKey, character = new());
            Touch(utc);
        }
        activeHouse = house;
        // A persisted in-flight reservation may have run before a crash/reload. Never replay it.
        watchStarted = now;
        idleSince = null;
    }

    public void Detach()
    {
        batch = null;
        activeHouse = null;
        scene = null;
        character = null;
        idleSince = null;
        uncertain = false;
    }

    public void CancelBatch() => batch = null;
    public void MarkSaved() => Dirty = false;

    public ArrivalResult RecordArrival(double now, DateTimeOffset utc, Visitor visitor,
        bool eligible, MacroObservation observation)
    {
        RequireActive();
        CheckClock(utc);
        if (!RecordSeen(visitor, utc)) return ArrivalResult.Duplicate;
        if (!eligible || uncertain) return ArrivalResult.RecordedOnly;
        if (IsExecuting || !observation.CanExecute)
        {
            CancelBatch();
            return ArrivalResult.Busy;
        }
        if (RateRemaining(utc) > 0) return ArrivalResult.RateLimit;
        if (batch is not null && now > batch.ReadyAt) return ArrivalResult.WindowClosed;
        var result = batch is null ? ArrivalResult.NewBatch : ArrivalResult.JoinedBatch;
        batch ??= new(now);
        batch.Visitors.TryAdd(visitor.Key, visitor);
        return result;
    }

    private bool RecordSeen(Visitor visitor, DateTimeOffset utc)
    {
        var token = Ledger.VisitorKey(visitor);
        if (scene!.SeenVisitors.Contains(token)) return false;
        if (scene.SeenVisitors.Count >= 10000 || Ledger.Scenes.Values.Sum(s => s.SeenVisitors.Count) >= 50000)
            throw new InvalidOperationException("访客记录已满，请开始新一场。");
        scene.SeenVisitors.Add(token);
        Touch(utc);
        return true;
    }

    public BatchPoll Poll(double now, DateTimeOffset utc, MacroObservation observation, Func<string, bool> isVisible)
    {
        if (batch is null) return new(BatchState.Empty);
        CheckClock(utc);
        if (uncertain || IsExecuting || !observation.CanExecute)
            return Cancel(BatchState.CancelledBusy);
        if (RateRemaining(utc) > 0)
            return Cancel(BatchState.CancelledLimit);
        var present = batch.Visitors.Values.Count(v => isVisible(v.Key));
        if (present == 0) return Cancel(BatchState.CancelledAbsent);
        if (now > batch.ReadyAt + MacroPolicy.MaxBatchLatenessSeconds)
            return Cancel(BatchState.CancelledLate);
        return new(now >= batch.ReadyAt ? BatchState.Ready : BatchState.Collecting, present);
    }

    private BatchPoll Cancel(BatchState state)
    {
        batch = null;
        return new(state);
    }

    public bool TryReserve(double now, DateTimeOffset utc, MacroObservation observation,
        Func<string, bool> isVisible, bool manual = false)
    {
        RequireActive();
        CheckClock(utc);
        if (uncertain || IsExecuting || !observation.CanExecute || RateRemaining(utc) > 0)
        {
            CancelBatch();
            return false;
        }
        if (!manual && Poll(now, utc, observation, isVisible).State != BatchState.Ready) return false;
        batch = null;
        character!.StartsUtc.RemoveAll(t => utc - t >= TimeSpan.FromSeconds(MacroPolicy.WindowSeconds));
        character.StartsUtc.Add(utc);
        character.InFlight = true;
        scene!.Attempts = checked(scene.Attempts + 1);
        watchStarted = now;
        idleSince = null;
        Touch(utc);
        return true; // Caller MUST durably save before issuing the native macro call.
    }

    public ExecutionUpdate ObserveExecution(double now, DateTimeOffset utc, MacroObservation observation)
    {
        if (!IsExecuting) return ExecutionUpdate.None;
        CheckClock(utc);
        if (uncertain) return ExecutionUpdate.Uncertain;
        if (observation.State == MacroRunState.Unavailable ||
            now - watchStarted > MacroPolicy.ExecutionWatchLimitSeconds)
        {
            uncertain = true;
            CancelBatch();
            return ExecutionUpdate.Uncertain;
        }
        if (observation.State == MacroRunState.Running)
        {
            idleSince = null;
            return ExecutionUpdate.Watching;
        }
        idleSince ??= now;
        if (now - idleSince < MacroPolicy.IdleConfirmationSeconds) return ExecutionUpdate.Watching;
        FinishReservation(utc);
        return ExecutionUpdate.Finished;
    }

    public void FinishReservation(DateTimeOffset utc)
    {
        RequireActive();
        if (!IsExecuting) return;
        CheckClock(utc);
        character!.InFlight = false;
        idleSince = null;
        Touch(utc);
    }

    public void MarkUncertain()
    {
        uncertain = true;
        CancelBatch();
        // The durable in-flight flag is intentionally retained for recovery on next load.
    }

    public void BeginNewRound(DateTimeOffset utc, IEnumerable<Visitor> present)
    {
        RequireActive();
        CheckClock(utc);
        if (IsExecuting || uncertain) throw new InvalidOperationException("宏运行期间不能开始新一场。");
        batch = null;
        scene!.SeenVisitors.Clear();
        scene.Round = checked(scene.Round + 1);
        scene.Attempts = 0;
        foreach (var visitor in present) RecordSeen(visitor, utc);
        Touch(utc);
        // The character-wide rolling rate limit is deliberately preserved.
    }

    public double RateRemaining(DateTimeOffset utc)
    {
        if (character is null) return 0;
        var recent = character.StartsUtc.Where(t => (utc - t).TotalSeconds < MacroPolicy.WindowSeconds).Order().ToArray();
        return recent.Length < MacroPolicy.MaxStarts ? 0 :
            Math.Max(0, (recent[0].AddSeconds(MacroPolicy.WindowSeconds) - utc).TotalSeconds);
    }

    public int RecentStarts(DateTimeOffset utc) =>
        character?.StartsUtc.Count(t => (utc - t).TotalSeconds < MacroPolicy.WindowSeconds) ?? 0;

    private void RequireActive()
    {
        if (scene is null || character is null || activeHouse is null)
            throw new InvalidOperationException("尚未进入住宅。");
    }

    private void CheckClock(DateTimeOffset utc)
    {
        if (utc < Ledger.LastSavedUtc)
            throw new InvalidOperationException("系统时间早于迎宾记录时间，已暂停自动迎宾。");
    }

    private void Touch(DateTimeOffset utc)
    {
        Ledger.LastSavedUtc = utc;
        Dirty = true;
    }
}
