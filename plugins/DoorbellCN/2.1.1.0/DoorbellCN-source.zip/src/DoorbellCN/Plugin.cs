using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using DoorbellCN.Core;
using DoorbellCN.Services;
using DoorbellCN.Windows;

namespace DoorbellCN;

public sealed record ActivityEntry(DateTime Time, string Category, string Message);

public sealed class Plugin : IDalamudPlugin
{
    private readonly IDalamudPluginInterface pluginInterface;
    private readonly IFramework framework;
    private readonly IClientState clientState;
    private readonly ICommandManager commands;
    private readonly IChatGui chat;
    private readonly IPluginLog log;
    private readonly GameGateway game;
    private readonly SoundService sound;
    private readonly NotificationService notifications;
    private readonly WindowSystem windows = new("DoorbellCN");
    private readonly MainWindow window;
    private readonly DateTimeOffset clockOrigin = DateTimeOffset.UtcNow;
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private readonly ConcurrentQueue<Action> requests = new();
    private readonly VisitorTracker tracker = new();
    private readonly MacroScheduler scheduler;
    private readonly LedgerFileStore? ledgerStore;
    private readonly SessionGuard guard = new();
    private readonly Queue<ActivityEntry> history = new();
    private HouseSession? currentHouse;
    private MacroObservation observation = new(MacroRunState.Unavailable);
    private string armedFingerprint = "";
    private double nextScan;
    private double sessionStarted;
    private double? silenceUntil;
    private bool silenced;
    private bool disposed;

    public object SyncRoot { get; } = new();
    public Configuration Config { get; }
    public string Status { get; private set; } = "等待进入住宅";
    public string? Fault { get; private set; }
    public MacroPreview Preview { get; private set; } = MacroPreview.Unavailable("请选择并读取宏。");
    public MacroSelection? PreviewSelection { get; private set; }
    public HouseSession? CurrentHouse => currentHouse;
    public bool IsArmed => guard.IsArmed;
    public bool IsSilenced => silenced;
    public bool IsInside => currentHouse.HasValue;
    public bool IsExecuting => scheduler.IsExecuting;
    public int VisitorCount => tracker.Count;
    public int SeenCount => scheduler.SeenCount;
    public long Round => scheduler.Round;
    public long Attempts => scheduler.Attempts;
    public int RecentStarts => scheduler.RecentStarts(UtcNow);
    public int PendingCount => scheduler.PendingCount;
    public double RateRemaining => scheduler.RateRemaining(UtcNow);
    public bool CanTest => !IsExecuting && observation.CanExecute && RateRemaining <= 0;
    public bool CanStartNewRound => IsInside && WarmupRemaining <= 0 && !IsExecuting &&
        observation.CanExecute && Fault is null && Config.Enabled && !IsSilenced;
    public double WarmupRemaining => IsInside ? Math.Max(0, Config.WarmupSeconds - (Now - sessionStarted)) : 0;
    public string SilenceLabel => !silenced ? "未静音" : silenceUntil is { } until
        ? $"剩余 {Math.Max(0, until - Now):0} 秒" : "至离开住宅";
    public IReadOnlyList<ActivityEntry> History => history.Reverse().ToArray();
    private double Now => clock.Elapsed.TotalSeconds;
    // Wall-clock persistence is anchored to the monotonic clock while this instance is running.
    private DateTimeOffset UtcNow => clockOrigin + clock.Elapsed;

    public Plugin(IDalamudPluginInterface pluginInterface, IFramework framework, IClientState clientState,
        IObjectTable objects, IPlayerState playerState, ICondition condition, ICommandManager commands,
        IChatGui chat, IPluginLog log)
    {
        this.pluginInterface = pluginInterface;
        this.framework = framework;
        this.clientState = clientState;
        this.commands = commands;
        this.chat = chat;
        this.log = log;
        try { Config = pluginInterface.GetPluginConfig() as Configuration ?? new Configuration(); }
        catch (Exception ex)
        {
            log.Error(ex, "门铃迎宾：读取配置失败。");
            Config = new Configuration();
        }
        Config.Normalize();
        try
        {
            ledgerStore = new(pluginInterface.ConfigDirectory.FullName);
            scheduler = new(ledgerStore.Load());
        }
        catch (Exception ex)
        {
            ledgerStore?.Dispose();
            ledgerStore = null;
            scheduler = new();
            Fault = "迎宾记录不可用，已暂停。";
            log.Error(ex, "门铃迎宾：防重复记录读取失败或正在被其他实例使用；不会清空后重试。");
        }
        game = new(framework, clientState, objects, playerState, condition);
        sound = new(Path.Combine(pluginInterface.AssemblyLocation.Directory!.FullName, "doorbell.wav"), log);
        notifications = new(chat, sound);
        window = new(this);
        windows.AddWindow(window);
        var ownsPrimaryCommand = false;
        try
        {
            ownsPrimaryCommand = commands.AddHandler("/doorbellcn", new CommandInfo(OnCommand)
            {
                HelpMessage = "门铃迎宾：打开设置。stop 暂停；silence [分钟] 静音；status 查看状态。",
            });
            if (!ownsPrimaryCommand || !commands.AddHandler("/menling", new CommandInfo(OnCommand) { HelpMessage = "打开门铃迎宾。" }))
                throw new InvalidOperationException("门铃命令已被占用，请先停用旧版门铃迎宾。");
        }
        catch
        {
            if (ownsPrimaryCommand) commands.RemoveHandler("/doorbellcn");
            sound.Dispose();
            ledgerStore?.Dispose();
            throw;
        }
        pluginInterface.UiBuilder.Draw += Draw;
        pluginInterface.UiBuilder.OpenConfigUi += OpenWindow;
        pluginInterface.UiBuilder.OpenMainUi += OpenWindow;
        framework.Update += OnUpdate;
        clientState.TerritoryChanged += OnTerritoryChanged;
        AddActivity("系统", Fault ?? "门铃已加载，自动迎宾未开启。");
    }

    private void Draw()
    {
        lock (SyncRoot) { if (!disposed) windows.Draw(); }
    }

    private void OpenWindow()
    {
        lock (SyncRoot) { if (!disposed) window.IsOpen = true; }
    }

    public void Post(Action action)
    {
        lock (SyncRoot) { if (!disposed) requests.Enqueue(action); }
    }

    private void OnTerritoryChanged(uint _) => Post(() => LeaveHouse("区域已变化，迎宾暂停。"));

    private void OnCommand(string command, string arguments)
    {
        var args = arguments.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (args.Length == 0) { OpenWindow(); return; }
        Post(() =>
        {
            switch (args[0].ToLowerInvariant())
            {
                case "stop": case "停止":
                    StopWelcome();
                    chat.Print("[门铃迎宾] 已暂停。正在运行的宏不会被中断。");
                    return;
                case "status": case "状态":
                    chat.Print($"[门铃迎宾] {Status}；静音：{SilenceLabel}。");
                    return;
                case "silence": case "静音":
                    if (args.Length == 1)
                    {
                        SetSilence(silenced ? 0 : null);
                        chat.Print($"[门铃迎宾] 静音：{SilenceLabel}。");
                        return;
                    }
                    if (args.Length == 2 && double.TryParse(args[1], NumberStyles.Float,
                            CultureInfo.InvariantCulture, out var minutes) && double.IsFinite(minutes) && minutes is >= 0 and <= 1440)
                    {
                        SetSilence(minutes);
                        chat.Print($"[门铃迎宾] 静音：{SilenceLabel}。");
                        return;
                    }
                    break;
            }
            chat.PrintError("[门铃迎宾] 用法：/doorbellcn；/doorbellcn stop；/doorbellcn silence [0–1440 分钟]；/doorbellcn status。");
        });
    }

    private void OnUpdate(IFramework _)
    {
        lock (SyncRoot)
        {
            if (disposed) return;
            try
            {
                for (var i = 0; i < 32 && requests.TryDequeue(out var action); i++) action();
                var now = Now;
                if (now < nextScan) return;
                nextScan = now + 0.25;
                if (silenced && silenceUntil is { } until && now >= until) SetSilence(0);
                if (Fault is not null) { Status = Fault; return; }
                if (!Config.Enabled)
                {
                    LeaveHouse("门铃已停用。");
                    Status = "已停用";
                    return;
                }
                if (!game.TryGetHouse(out var house))
                {
                    LeaveHouse("已离开住宅，迎宾暂停。");
                    Status = "等待进入住宅";
                    return;
                }
                var utc = UtcNow;
                if (currentHouse != house)
                {
                    LeaveHouse("住宅或角色已变化，迎宾暂停。");
                    currentHouse = house;
                    scheduler.Activate(house, now, utc);
                    sessionStarted = now;
                    tracker.Reset(now);
                    AddActivity("住宅", "已进入住宅。");
                }
                if (guard.IsArmed && !guard.Matches(house, Config.Selection)) StopWelcome("宏或住宅已变化，迎宾暂停。");
                observation = game.ReadMacroObservation();
                var executionUpdate = scheduler.ObserveExecution(now, utc, observation);
                if (executionUpdate == ExecutionUpdate.Uncertain ||
                    (guard.IsArmed && observation.State == MacroRunState.Unavailable))
                    throw new InvalidOperationException("无法确认宏的运行状态。");
                if (executionUpdate == ExecutionUpdate.Finished) AddActivity("迎宾", "宏已结束。");

                foreach (var visit in tracker.Observe(now, game.ReadVisitors(), Config.Detection))
                {
                    var label = visit.Kind switch { VisitKind.Entered => "进入", VisitKind.Left => "离开", _ => "已在场" };
                    AddActivity(label, visit.Visitor.DisplayName);
                    if (visit.Kind != VisitKind.Left)
                    {
                        var eligible = visit.Kind == VisitKind.Entered && guard.IsArmed && !silenced && WarmupRemaining <= 0;
                        var arrival = scheduler.RecordArrival(now, utc, visit.Visitor, eligible, observation);
                        if (eligible) LogArrival(arrival, visit.Visitor);
                    }
                    if (!silenced) notifications.Notify(visit, Config.For(visit.Kind));
                }
                // Persist all confirmed visitors, including those skipped while busy, paused or rate-limited.
                PersistLedger();
                if (guard.IsArmed && !silenced)
                {
                    var poll = scheduler.Poll(now, utc, observation, tracker.IsVisible);
                    if (poll.State == BatchState.Ready)
                        SubmitMacro(Config.Selection, house, armedFingerprint, manual: false);
                    else if (poll.State is not (BatchState.Empty or BatchState.Collecting))
                        AddActivity("跳过", poll.State switch
                        {
                            BatchState.CancelledAbsent => "这批访客已离开。",
                            BatchState.CancelledLate => "等待时间已过，本次不再迎宾。",
                            BatchState.CancelledLimit => "已达五分钟次数上限，本次跳过。",
                            _ => "宏正在运行或角色正忙，本次跳过。",
                        });
                }
                UpdateStatus();
            }
            catch (Exception ex) { EnterFault(ex); }
        }
    }

    private void LogArrival(ArrivalResult result, Visitor visitor)
    {
        var message = result switch
        {
            ArrivalResult.NewBatch => "开始合并本批到访。",
            ArrivalResult.JoinedBatch => "加入本批迎宾。",
            ArrivalResult.Duplicate => "本场已登记，不重复迎宾。",
            ArrivalResult.Busy => "宏运行中或角色正忙，不再补发。",
            ArrivalResult.RateLimit => "已达五分钟次数上限，不再补发。",
            _ => "本次仅登记。",
        };
        AddActivity("迎宾", visitor.DisplayName + "：" + message);
    }

    private void SubmitMacro(MacroSelection selection, HouseSession house, string fingerprint, bool manual)
    {
        var fresh = game.ReadMacroObservation();
        var dispatch = MacroDispatcher.Submit(scheduler, Now, UtcNow, fresh,
            tracker.IsVisible, PersistLedger, () => game.Execute(selection, house, fingerprint), manual);
        if (!dispatch.Reserved || dispatch.Result is not { } result)
        {
            AddActivity("跳过", "尚未满足迎宾条件，本次已取消。");
            return;
        }
        if (result.State == ExecuteState.Executed)
        {
            AddActivity(manual ? "测试" : "执行", result.Message);
        }
        else
        {
            // Known refusal: conservatively consume this attempt without retry.
            scheduler.FinishReservation(UtcNow);
            PersistLedger();
            AddActivity("跳过", result.Message);
            if (result.State == ExecuteState.Refused) StopWelcome(result.Message);
        }
        if (manual) chat.Print($"[门铃迎宾] {result.Message}");
    }

    private void PersistLedger()
    {
        if (!scheduler.Dirty) return;
        if (ledgerStore is null) throw new IOException("迎宾记录无法保存。");
        ledgerStore.Save(scheduler.Ledger);
        scheduler.MarkSaved();
    }

    private void EnterFault(Exception ex)
    {
        scheduler.MarkUncertain();
        StopWelcome("状态异常，迎宾已暂停。");
        Fault = "迎宾已暂停，请查看运行记录";
        Status = Fault;
        AddActivity("错误", ex.Message);
        log.Error(ex, "门铃迎宾：自动迎宾保护停用，不会自动重试。");
    }

    private void UpdateStatus()
    {
        Status = Fault ?? (!Config.Enabled ? "已停用" : !IsInside ? "等待进入住宅" :
            IsExecuting ? "正在执行宏" : WarmupRemaining > 0 ? $"准备中 · {WarmupRemaining:0} 秒" :
            !guard.IsArmed ? "已暂停" :
            RateRemaining > 0 ? $"次数已达上限 · {Math.Ceiling(RateRemaining):0} 秒后恢复" :
            PendingCount > 0 ? $"合并到访 · {PendingCount} 人" : "等待新访客");
    }

    private void LeaveHouse(string reason)
    {
        if (currentHouse.HasValue || guard.IsArmed)
        {
            AddActivity("系统", reason);
            sound.StopAll();
        }
        PersistLedger();
        currentHouse = null;
        guard.Disarm();
        armedFingerprint = "";
        scheduler.Detach();
        observation = new(MacroRunState.Unavailable);
        tracker.Reset(Now);
        if (silenced && silenceUntil is null) silenced = false;
    }

    public void SettingsChanged(bool macroSelectionChanged = false)
    {
        Config.Normalize();
        StopWelcome("设置已改变，迎宾暂停。");
        if (macroSelectionChanged)
        {
            Preview = MacroPreview.Unavailable("请选择并读取宏。");
            PreviewSelection = null;
        }
        tracker.Reset(Now);
        sessionStarted = Now;
        Save();
        UpdateStatus();
    }

    public void Save()
    {
        try { pluginInterface.SavePluginConfig(Config); }
        catch (Exception ex)
        {
            AddActivity("错误", "设置保存失败。");
            log.Error(ex, "门铃迎宾：设置保存失败。");
        }
    }

    public void RefreshPreview()
    {
        if (Fault is not null) return;
        PreviewSelection = Config.Selection;
        Preview = game.ReadMacro(Config.Selection);
        AddActivity("预览", Preview.Available ? $"已读取 {Config.Selection.Label}「{Preview.Name}」。" : Preview.Error);
    }

    public void ArmWelcome(bool userConfirmed)
    {
        if (!userConfirmed || !ValidateContext(out var house)) return;
        if (IsExecuting || scheduler.IsUncertain)
        { AddActivity("拒绝", "请等待宏结束。"); return; }
        if (PreviewSelection != Config.Selection || !Preview.HasContent)
        { AddActivity("拒绝", "请先读取并检查宏。"); return; }
        var latest = game.ReadMacro(Config.Selection);
        if (latest.Fingerprint != Preview.Fingerprint)
        { Preview = latest; AddActivity("拒绝", "宏内容已变化，请重新确认。"); return; }
        if (game.ReadMacroObservation().State == MacroRunState.Unavailable)
        { AddActivity("拒绝", "宏暂不可用。"); return; }
        PersistLedger();
        scheduler.CancelBatch();
        if (!guard.Arm(house, Config.Selection)) return;
        armedFingerprint = latest.Fingerprint;
        AddActivity("开启", $"已开启迎宾：{Config.Selection.Label}「{latest.Name}」。");
        UpdateStatus();
    }

    private bool ValidateContext(out HouseSession house)
    {
        house = default;
        if (Fault is not null || !Config.Enabled || silenced || WarmupRemaining > 0 || !currentHouse.HasValue)
        { AddActivity("拒绝", "请进入住宅，解除静音并等待准备完成。"); return false; }
        if (!game.TryGetHouse(out house) || house != currentHouse.Value)
        { AddActivity("拒绝", "住宅或角色已变化。"); return false; }
        return true;
    }

    public void TestMacro(MacroSelection selection, string fingerprint, HouseSession expectedHouse)
    {
        if (selection != Config.Selection || !ValidateContext(out var house) || house != expectedHouse) return;
        StopWelcome("手动测试，自动迎宾已暂停。");
        SubmitMacro(selection, house, fingerprint, manual: true);
        UpdateStatus();
    }

    public void BeginNewRound(HouseSession expectedHouse)
    {
        if (!ValidateContext(out var house) || house != expectedHouse || !game.ReadMacroObservation().CanExecute || IsExecuting)
        { AddActivity("拒绝", "当前无法开始新一场。"); return; }
        StopWelcome("正在开始新一场。");
        scheduler.BeginNewRound(UtcNow, game.ReadVisitors());
        PersistLedger();
        tracker.Reset(Now);
        sessionStarted = Now;
        AddActivity("场次", $"已开始第 {Round} 场，请重新开启迎宾。");
        UpdateStatus();
    }

    public void StopWelcome(string reason = "迎宾已暂停。")
    {
        var wasArmed = guard.IsArmed || scheduler.PendingCount > 0;
        guard.Disarm();
        armedFingerprint = "";
        scheduler.CancelBatch();
        if (wasArmed) AddActivity("暂停", reason);
        UpdateStatus();
    }

    public void SetSilence(double? minutes)
    {
        if (minutes == 0)
        {
            silenced = false;
            silenceUntil = null;
            AddActivity("提醒", "已解除静音，迎宾仍需手动开启。");
            return;
        }
        StopWelcome("已静音，迎宾暂停。");
        sound.StopAll();
        silenced = true;
        silenceUntil = minutes is { } value ? Now + Math.Clamp(value, 0, 1440) * 60 : null;
        AddActivity("静音", SilenceLabel);
    }

    public void TestSound(AlertOptions options) => sound.Play(options.SoundFile, options.Volume);
    public void ClearHistory() => history.Clear();
    public void AddActivity(string category, string message)
    {
        history.Enqueue(new(DateTime.Now, category, message));
        while (history.Count > 200) history.Dequeue();
    }

    public void Dispose()
    {
        lock (SyncRoot)
        {
            if (disposed) return;
            disposed = true;
            framework.Update -= OnUpdate;
            clientState.TerritoryChanged -= OnTerritoryChanged;
            pluginInterface.UiBuilder.Draw -= Draw;
            pluginInterface.UiBuilder.OpenConfigUi -= OpenWindow;
            pluginInterface.UiBuilder.OpenMainUi -= OpenWindow;
            commands.RemoveHandler("/doorbellcn");
            commands.RemoveHandler("/menling");
            requests.Clear();
            guard.Disarm();
            scheduler.CancelBatch();
            try { PersistLedger(); } catch (Exception ex) { log.Error(ex, "门铃迎宾：卸载时保存记录失败。"); }
            windows.RemoveAllWindows();
        }
        try { sound.Dispose(); }
        finally { ledgerStore?.Dispose(); }
    }
}
