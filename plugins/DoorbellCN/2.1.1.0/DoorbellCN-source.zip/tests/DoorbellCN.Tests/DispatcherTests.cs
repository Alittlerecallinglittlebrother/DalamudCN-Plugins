using DoorbellCN.Core;
using Xunit;

namespace DoorbellCN.Tests;

public sealed class DispatcherTests
{
    private static readonly DateTimeOffset Time = new(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);
    private static readonly MacroObservation Idle = new(MacroRunState.Idle);
    private readonly MacroScheduler scheduler = new();

    public DispatcherTests() => scheduler.Activate(new(100, 200, 0, 282), 0, Time);

    [Fact]
    public void DurableSaveAlwaysPrecedesNativeExecution()
    {
        var order = new List<string>();
        var result = MacroDispatcher.Submit(scheduler, 0, Time, Idle, _ => true,
            () =>
            {
                Assert.True(scheduler.IsExecuting);
                Assert.Equal(1, scheduler.RecentStarts(Time));
                order.Add("save");
            },
            () => { order.Add("native"); return "submitted"; }, manual: true);
        Assert.True(result.Reserved);
        Assert.Equal(new[] { "save", "native" }, order);
    }

    [Fact]
    public void DiskFailureCannotSendMacro()
    {
        var calls = 0;
        Assert.Throws<IOException>(() => MacroDispatcher.Submit(scheduler, 0, Time, Idle, _ => true,
            () => throw new IOException("disk full"),
            () => { calls++; return "submitted"; }, manual: true));
        Assert.Equal(0, calls);
        Assert.True(scheduler.IsUncertain);
    }

    [Fact]
    public void ExceptionAfterNativeSideEffectIsNotRetried()
    {
        var calls = 0;
        Assert.Throws<InvalidOperationException>(() => MacroDispatcher.Submit<string>(scheduler, 0, Time, Idle,
            _ => true, () => { }, () => { calls++; throw new InvalidOperationException("uncertain"); }, manual: true));
        var second = MacroDispatcher.Submit(scheduler, 1, Time.AddSeconds(1), Idle, _ => true,
            () => { }, () => { calls++; return "submitted"; }, manual: true);
        Assert.False(second.Reserved);
        Assert.Equal(1, calls);
    }

    [Fact]
    public void DoubleClickCannotDispatchTwoMacros()
    {
        var calls = 0;
        for (var i = 0; i < 20; i++)
            MacroDispatcher.Submit(scheduler, 0, Time, Idle, _ => true,
                () => { }, () => { calls++; return "submitted"; }, manual: true);
        Assert.Equal(1, calls);
    }

    [Fact]
    public void FinishedManualTestDoesNotImposeCooldown()
    {
        MacroDispatcher.Submit(scheduler, 0, Time, Idle, _ => true,
            () => { }, () => "submitted", manual: true);
        scheduler.FinishReservation(Time.AddSeconds(1));
        var calls = 0;
        var result = MacroDispatcher.Submit(scheduler, 2, Time.AddSeconds(2), Idle, _ => true,
            () => { }, () => { calls++; return "submitted"; }, manual: true);
        Assert.True(result.Reserved);
        Assert.Equal(1, calls);
    }

    [Fact]
    public void ManualTestingStillCannotBypassRollingRateLimit()
    {
        var calls = 0;
        foreach (var time in new[] { 0, 2, 4 })
        {
            var result = MacroDispatcher.Submit(scheduler, time, Time.AddSeconds(time), Idle,
                _ => true, () => { }, () => { calls++; return "submitted"; }, manual: true);
            Assert.True(result.Reserved);
            scheduler.FinishReservation(Time.AddSeconds(time + 1));
        }
        var fourth = MacroDispatcher.Submit(scheduler, 6, Time.AddSeconds(6), Idle,
            _ => true, () => { }, () => { calls++; return "submitted"; }, manual: true);
        Assert.False(fourth.Reserved);
        Assert.Equal(3, calls);
    }

    [Fact]
    public void BusyAtFinalDispatchDropsBatchWithoutNativeCall()
    {
        scheduler.RecordArrival(0, Time, new("访客", 1, "测试服"), true, Idle);
        var calls = 0;
        var result = MacroDispatcher.Submit(scheduler, 3, Time.AddSeconds(3), new(MacroRunState.Running),
            _ => true, () => { }, () => { calls++; return "submitted"; });
        Assert.False(result.Reserved);
        Assert.Equal(0, calls);
        Assert.Equal(0, scheduler.PendingCount);
    }
}
