using DoorbellCN.Core;
using Xunit;

namespace DoorbellCN.Tests;

public sealed class SchedulerTests
{
    private static readonly DateTimeOffset Epoch = new(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);
    private static DateTimeOffset U(double seconds) => Epoch.AddSeconds(seconds);
    private static readonly HouseSession House = new(100, 200, 1, 282);
    private static readonly Visitor Alice = new("访客甲", 1, "测试服");
    private static readonly Visitor Bob = new("访客乙", 1, "测试服");
    private static readonly MacroObservation Idle = new(MacroRunState.Idle);
    private static readonly MacroObservation Running = new(MacroRunState.Running);
    private readonly MacroScheduler scheduler = new();

    public SchedulerTests() => scheduler.Activate(House, 0, U(0));
    private ArrivalResult Arrive(double now, Visitor visitor, bool eligible = true, MacroObservation? state = null) =>
        scheduler.RecordArrival(now, U(now), visitor, eligible, state ?? Idle);
    private bool Reserve(double now, bool manual = false) =>
        scheduler.TryReserve(now, U(now), Idle, _ => true, manual);
    private void Manual(double at)
    {
        Assert.True(Reserve(at, manual: true));
        scheduler.FinishReservation(U(at + 1));
    }

    [Fact]
    public void FiveVisitorsProduceOneFixedBatch()
    {
        Assert.Equal(ArrivalResult.NewBatch, Arrive(0, Alice));
        for (var i = 1; i < 5; i++)
            Assert.Equal(ArrivalResult.JoinedBatch, Arrive(i * 0.5, Bob with { Name = "客" + i }));
        Assert.Equal(5, scheduler.PendingCount);
        Assert.Equal(BatchState.Collecting, scheduler.Poll(2.99, U(2.99), Idle, _ => true).State);
        var ready = scheduler.Poll(3, U(3), Idle, _ => true);
        Assert.Equal(BatchState.Ready, ready.State);
        Assert.Equal(5, ready.PresentCount);
        Assert.True(Reserve(3));
        Assert.False(Reserve(3));
        Assert.Equal(1, scheduler.Attempts);
    }

    [Fact]
    public void LateJoinDoesNotExtendBatchDeadline()
    {
        Arrive(0, Alice);
        Arrive(2.9, Bob);
        Assert.Equal(BatchState.Ready, scheduler.Poll(3, U(3), Idle, _ => true).State);
    }

    [Fact]
    public void ArrivalAfterWindowDoesNotCreateSecondQueuedBatch()
    {
        Arrive(0, Alice);
        Assert.Equal(ArrivalResult.WindowClosed, Arrive(4, Bob));
        Assert.Equal(1, scheduler.PendingCount);
        Assert.Equal(2, scheduler.SeenCount);
    }

    [Fact]
    public void AllBatchMembersAreRememberedAfterExecution()
    {
        Arrive(0, Alice);
        Arrive(1, Bob);
        Assert.True(Reserve(3));
        scheduler.FinishReservation(U(4));
        Assert.Equal(ArrivalResult.Duplicate, Arrive(200, Alice));
        Assert.Equal(ArrivalResult.Duplicate, Arrive(201, Bob));
    }

    [Fact]
    public void TwoVisitorsReenteringTwentyTimesCannotCreateNewGreeting()
    {
        Arrive(0, Alice);
        Arrive(1, Bob);
        Reserve(3);
        scheduler.FinishReservation(U(4));
        for (var i = 0; i < 20; i++)
        {
            Assert.Equal(ArrivalResult.Duplicate, Arrive(100 + i * 10, Alice));
            Assert.Equal(ArrivalResult.Duplicate, Arrive(101 + i * 10, Bob));
        }
        Assert.Equal(1, scheduler.Attempts);
        Assert.Equal(0, scheduler.PendingCount);
    }

    [Fact]
    public void FirstVisitorLeavingDoesNotCancelOtherPresentMembers()
    {
        Arrive(0, Alice);
        Arrive(1, Bob);
        var poll = scheduler.Poll(3, U(3), Idle, key => key == Bob.Key);
        Assert.Equal(BatchState.Ready, poll.State);
        Assert.Equal(1, poll.PresentCount);
    }

    [Fact]
    public void EntireBatchLeavingIsCancelledWithoutRetry()
    {
        Arrive(0, Alice);
        Arrive(1, Bob);
        Assert.Equal(BatchState.CancelledAbsent, scheduler.Poll(2, U(2), Idle, _ => false).State);
        Assert.Equal(ArrivalResult.Duplicate, Arrive(10, Bob));
        Assert.Equal(0, scheduler.PendingCount);
    }

    [Fact]
    public void MacroBusyCancelsRatherThanWaits()
    {
        Arrive(0, Alice);
        Assert.Equal(BatchState.CancelledBusy, scheduler.Poll(1, U(1), Running, _ => true).State);
        Assert.Equal(BatchState.Empty, scheduler.Poll(4, U(4), Idle, _ => true).State);
        Assert.Equal(ArrivalResult.Duplicate, Arrive(5, Alice));
    }

    [Fact]
    public void BusyArrivalIsRecordedAndNeverBackfilled()
    {
        Assert.Equal(ArrivalResult.Busy, Arrive(0, Alice, state: Running));
        Assert.Equal(ArrivalResult.Duplicate, Arrive(10, Alice));
        Assert.Equal(0, scheduler.PendingCount);
    }

    [Fact]
    public void BlockedActivityAlsoDropsArrival()
    {
        Assert.Equal(ArrivalResult.Busy, Arrive(0, Alice, state: new(MacroRunState.Idle, true)));
        Assert.Equal(ArrivalResult.Duplicate, Arrive(100, Alice));
    }

    [Fact]
    public void FinishedMacroAllowsNewVisitorWithinSeconds()
    {
        Manual(0);
        Assert.Equal(ArrivalResult.NewBatch, Arrive(2, Alice));
        Assert.Equal(BatchState.Ready, scheduler.Poll(5, U(5), Idle, _ => true).State);
        Assert.True(Reserve(5));
        Assert.Equal(2, scheduler.Attempts);
    }

    [Fact]
    public void PausedAndInitialGuestsAreRecordedWithoutTriggering()
    {
        Assert.Equal(ArrivalResult.RecordedOnly, Arrive(0, Alice, eligible: false));
        Assert.Equal(ArrivalResult.Duplicate, Arrive(100, Alice));
        Assert.Equal(0, scheduler.PendingCount);
    }

    [Fact]
    public void LongMacroAcceptsNewBatchAsSoonAsItsEndIsConfirmed()
    {
        Assert.True(Reserve(0, manual: true));
        Assert.Equal(ExecutionUpdate.Watching, scheduler.ObserveExecution(0.25, U(0.25), Running));
        Assert.Equal(ArrivalResult.Busy, Arrive(80, Alice));
        Assert.Equal(ExecutionUpdate.Watching, scheduler.ObserveExecution(90, U(90), Idle));
        Assert.Equal(ExecutionUpdate.Finished, scheduler.ObserveExecution(91, U(91), Idle));
        Assert.Equal(ArrivalResult.NewBatch, Arrive(91, Bob));
        Assert.Equal(ArrivalResult.Duplicate, Arrive(92, Alice));
        Assert.True(Reserve(94));
    }

    [Fact]
    public void OneLineMacroStillRequiresStableIdleConfirmation()
    {
        Reserve(0, manual: true);
        Assert.Equal(ExecutionUpdate.Watching, scheduler.ObserveExecution(0.25, U(0.25), Idle));
        Assert.Equal(ExecutionUpdate.Watching, scheduler.ObserveExecution(1, U(1), Idle));
        Assert.Equal(ExecutionUpdate.Finished, scheduler.ObserveExecution(1.25, U(1.25), Idle));
    }

    [Fact]
    public void RunningAgainResetsIdleConfirmation()
    {
        Reserve(0, manual: true);
        scheduler.ObserveExecution(1, U(1), Idle);
        scheduler.ObserveExecution(1.5, U(1.5), Running);
        Assert.Equal(ExecutionUpdate.Watching, scheduler.ObserveExecution(2, U(2), Idle));
        Assert.Equal(ExecutionUpdate.Finished, scheduler.ObserveExecution(3, U(3), Idle));
    }

    [Fact]
    public void UnknownExecutionStateStopsAndDoesNotAutomaticallyRecover()
    {
        Reserve(0, manual: true);
        Assert.Equal(ExecutionUpdate.Uncertain, scheduler.ObserveExecution(1, U(1), new(MacroRunState.Unavailable)));
        Assert.Equal(ExecutionUpdate.Uncertain, scheduler.ObserveExecution(2, U(2), Idle));
        Assert.True(scheduler.IsExecuting);
        Assert.False(Reserve(100, manual: true));
    }

    [Fact]
    public void ExtremelyLongExecutionStopsInsteadOfRetiming()
    {
        Reserve(0, manual: true);
        Assert.Equal(ExecutionUpdate.Uncertain,
            scheduler.ObserveExecution(1021, U(1021), Running));
        Assert.False(Reserve(2000, manual: true));
    }

    [Fact]
    public void NewRoundPreservesRateButDoesNotCreateCooldown()
    {
        Arrive(0, Alice);
        Reserve(3);
        scheduler.FinishReservation(U(4));
        scheduler.BeginNewRound(U(10), []);
        Assert.Equal(1, scheduler.RecentStarts(U(10)));
        Assert.Equal(2, scheduler.Round);
        Assert.Equal(0, scheduler.Attempts);
        Assert.Equal(ArrivalResult.NewBatch, Arrive(11, Alice));
        Assert.True(Reserve(14));
        Assert.Equal(2, scheduler.RecentStarts(U(14)));
    }

    [Fact]
    public void NewRoundSeedsPeopleWhoAreAlreadyInside()
    {
        scheduler.BeginNewRound(U(1), [Alice, Bob]);
        Assert.Equal(ArrivalResult.Duplicate, Arrive(20, Alice));
        Assert.Equal(ArrivalResult.Duplicate, Arrive(21, Bob));
    }

    [Fact]
    public void NewRoundCannotRunWhileMacroIsExecuting()
    {
        Reserve(0, manual: true);
        Assert.Throws<InvalidOperationException>(() => scheduler.BeginNewRound(U(1), []));
    }

    [Fact]
    public void PausingCancelsOnlyPendingWork()
    {
        Arrive(0, Alice);
        scheduler.CancelBatch();
        Assert.Equal(ArrivalResult.Duplicate, Arrive(10, Alice));
        Assert.Equal(0, scheduler.PendingCount);
    }

    [Fact]
    public void PausingAnExecutingMacroDoesNotLoseItsCompletionWatch()
    {
        Reserve(0, manual: true);
        scheduler.CancelBatch();
        Assert.True(scheduler.IsExecuting);
        scheduler.ObserveExecution(10, U(10), Idle);
        scheduler.ObserveExecution(11, U(11), Idle);
        Assert.False(scheduler.IsExecuting);
        Assert.True(Reserve(11, manual: true));
    }

    [Fact]
    public void LeavingAndReturningDoesNotForgetVisitorsOrLimits()
    {
        Arrive(0, Alice);
        Reserve(3);
        scheduler.FinishReservation(U(4));
        scheduler.Detach();
        scheduler.Activate(House, 10, U(10));
        Assert.Equal(ArrivalResult.Duplicate, Arrive(10, Alice));
        Assert.Equal(1, scheduler.RecentStarts(U(10)));
        Assert.Equal(ArrivalResult.NewBatch, Arrive(11, Bob));
    }

    [Fact]
    public void OtherHouseKeepsCharacterWideThrottle()
    {
        Manual(0);
        Manual(2);
        Manual(4);
        scheduler.Detach();
        scheduler.Activate(House with { HouseId = 201 }, 10, U(10));
        Assert.Equal(ArrivalResult.RateLimit, Arrive(10, Alice));
        Assert.Equal(3, scheduler.RecentStarts(U(10)));
    }

    [Fact]
    public void DifferentCharactersHaveSeparateLedgers()
    {
        Manual(0);
        scheduler.Detach();
        scheduler.Activate(House with { CharacterId = 101 }, 10, U(10));
        Assert.Equal(ArrivalResult.NewBatch, Arrive(10, Alice));
        Assert.Equal(0, scheduler.RecentStarts(U(10)));
    }

    [Fact]
    public void ThreePerRollingFiveMinutesCannotBeBypassedByNewRound()
    {
        Manual(0);
        Manual(2);
        Manual(4);
        scheduler.BeginNewRound(U(10), []);
        Assert.Equal(290, scheduler.RateRemaining(U(10)));
        Assert.Equal(ArrivalResult.RateLimit, Arrive(10, Alice));
        Assert.False(Reserve(299, manual: true));
        Assert.Equal(0, scheduler.RateRemaining(U(300)));
        Assert.True(Reserve(300, manual: true));
    }

    [Fact]
    public void RateLimitedArrivalDoesNotExecuteWhenLimitExpires()
    {
        Manual(0);
        Manual(2);
        Manual(4);
        Assert.Equal(ArrivalResult.RateLimit, Arrive(10, Alice));
        Assert.Equal(ArrivalResult.Duplicate, Arrive(300, Alice));
        Assert.Equal(BatchState.Empty, scheduler.Poll(303, U(303), Idle, _ => true).State);
    }

    [Fact]
    public void FrameStallDropsLateBatch()
    {
        Arrive(0, Alice);
        Assert.Equal(BatchState.CancelledLate, scheduler.Poll(5.01, U(5.01), Idle, _ => true).State);
        Assert.False(Reserve(6));
    }

    [Fact]
    public void SameNameOnDifferentWorldIsAnotherGuest()
    {
        Arrive(0, Alice);
        Assert.Equal(ArrivalResult.JoinedBatch, Arrive(1, Alice with { HomeWorld = 2 }));
        Assert.Equal(2, scheduler.SeenCount);
    }

    [Fact]
    public void ThreeFinishedMacrosCanStartWithinSixtySecondsButFourthIsLimited()
    {
        Manual(0);
        Manual(2);
        Manual(4);
        Assert.Equal(3, scheduler.Attempts);
        Assert.False(Reserve(6, manual: true));
        Assert.Equal(294, scheduler.RateRemaining(U(6)));
    }

    [Fact]
    public void ClockRollbackIsRejected()
    {
        Arrive(10, Alice);
        Assert.Throws<InvalidOperationException>(() => Arrive(9, Bob));
    }

    [Fact]
    public void ReservationImmediatelyBlocksAnotherManualOrAutomaticCall()
    {
        Assert.True(Reserve(0, manual: true));
        Assert.False(Reserve(0.01, manual: true));
        Assert.Equal(1, scheduler.RecentStarts(U(0.01)));
    }

    [Fact]
    public void MetadataTokensDoNotUseTransientEntityIdentity()
    {
        var original = scheduler.Ledger.VisitorKey(Alice);
        Assert.Equal(original, scheduler.Ledger.VisitorKey(Alice with { WorldName = "改过的显示名" }));
        Assert.NotEqual(original, scheduler.Ledger.VisitorKey(Alice with { HomeWorld = 2 }));
    }

    [Theory]
    [InlineData(1)]
    [InlineData(2)]
    public void SupportedLedgerVersionsRetainHistoryOnUpgrade(int version)
    {
        Arrive(0, Alice);
        scheduler.Ledger.Version = version;
        var restored = new MacroScheduler(scheduler.Ledger);
        restored.Activate(House, 1, U(1));
        Assert.Equal(2, restored.Ledger.Version);
        Assert.Equal(ArrivalResult.Duplicate, restored.RecordArrival(1, U(1), Alice, true, Idle));
    }
}
