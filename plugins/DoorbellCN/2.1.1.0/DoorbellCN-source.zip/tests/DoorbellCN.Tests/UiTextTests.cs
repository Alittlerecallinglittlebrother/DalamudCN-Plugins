using System.Text.RegularExpressions;
using Xunit;

namespace DoorbellCN.Tests;

public sealed class UiTextTests
{
    private static string Source => File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "SourceContracts", "MainWindow.cs"));

    [Fact]
    public void NoPermanentDeveloperFootnotesOrSdkBanner()
    {
        var literals = Regex.Matches(Source, "\\\"(?:[^\\\"\\\\]|\\\\.)*\\\"").Select(m => m.Value).ToArray();
        foreach (var forbidden in new[] { "采样", "队列", "API", "Dalamud", "服务器访客日志", "住宅标识" })
            Assert.DoesNotContain(literals, value => value.Contains(forbidden, StringComparison.Ordinal));
        Assert.DoesNotContain("ImGui.TextDisabled(", Source);
    }

    [Fact]
    public void TestAndNewRoundStillRequireExplicitConfirmation()
    {
        Assert.Contains("确认执行游戏宏", Source);
        Assert.Contains("确认开始新一场", Source);
        Assert.Contains("确认执行一次", Source);
        Assert.Contains("自动执行风险", Source);
    }

    [Fact]
    public void OldQueueAndRepeatIntervalControlsAreGone()
    {
        Assert.DoesNotContain("QueueExpirySeconds", Source);
        Assert.DoesNotContain("VisitorCooldownSeconds", Source);
        Assert.DoesNotContain("TriggerDelaySeconds", Source);
        Assert.DoesNotContain("宏结束后间隔", Source);
        Assert.DoesNotContain("CooldownRemaining", Source);
        Assert.DoesNotContain("GlobalCooldownSeconds", Source);
        Assert.DoesNotContain("冷却剩余", Source);
        Assert.Contains("本场仅一次", Source);
    }
}
