#requires -Version 7.0
[CmdletBinding()]
param(
    [string]$DalamudHome = (Join-Path $env:APPDATA 'XIVLauncherCN\addon\Hooks\dev')
)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$DalamudHome = [IO.Path]::GetFullPath($DalamudHome)
if (!(Test-Path (Join-Path $DalamudHome 'Dalamud.dll'))) { throw "未找到国服 Dalamud：$DalamudHome" }
if (!(Get-Command dotnet -ErrorAction SilentlyContinue)) { throw '请先安装 .NET 10 SDK。' }
$dalamudVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $DalamudHome 'Dalamud.dll')).FileVersion
if ($dalamudVersion -notlike '15.*') { throw "仅支持 API 15 的构建目标；当前组件版本为 $dalamudVersion。" }
$oldHome = $env:DALAMUD_HOME
$oldLocation = Get-Location
$artifacts = Join-Path $root 'artifacts'
New-Item -ItemType Directory -Path $artifacts -Force | Out-Null
try {
    Set-Location $root
    $env:DALAMUD_HOME = $DalamudHome
    & dotnet restore DoorbellCN.sln --locked-mode --nologo
    if ($LASTEXITCODE -ne 0) { throw '依赖还原失败。' }
    & dotnet build DoorbellCN.sln -c Release --no-restore --nologo 2>&1 |
        Tee-Object -FilePath (Join-Path $artifacts 'build.log')
    if ($LASTEXITCODE -ne 0) { throw '编译失败，停止打包。' }
    & dotnet test tests/DoorbellCN.Tests/DoorbellCN.Tests.csproj -c Release --no-build --nologo --logger 'trx;LogFileName=core-tests.trx' --results-directory (Join-Path $artifacts 'test-results')
    if ($LASTEXITCODE -ne 0) { throw '核心测试失败，停止打包。' }

    # A separate PS7 process prevents previously verified DLLs from being locked during rebuilding.
    $pwsh = Join-Path $PSHOME 'pwsh.exe'
    $smokeText = & $pwsh -NoProfile -File (Join-Path $PSScriptRoot 'verify-build.ps1') -DalamudHome $DalamudHome
    if ($LASTEXITCODE -ne 0) { throw '离线配置 / 资源检查失败，停止打包。' }
    $smokeJson = $smokeText -join [Environment]::NewLine
    $smoke = $smokeJson | ConvertFrom-Json
    $smokeJson | Set-Content -LiteralPath (Join-Path $artifacts 'offline-checks.json') -Encoding utf8

    $testPath = Join-Path $artifacts 'test-results\core-tests.trx'
    [xml]$tests = [IO.File]::ReadAllText($testPath)
    $counters = $tests.TestRun.ResultSummary.Counters
    if ([int]$counters.failed -ne 0 -or [int]$counters.total -lt 1) { throw '测试结果不完整。' }

    $buildDirectory = Join-Path $root 'src\DoorbellCN\bin\x64\Release'
    $delivery = Join-Path $root '交付'
    $packageName = '门铃迎宾_国服_v2.1.1'
    $package = Join-Path $delivery $packageName
    New-Item -ItemType Directory -Path $package -Force | Out-Null
    $required = @('DoorbellCN.dll','DoorbellCN.Core.dll','DoorbellCN.json','DoorbellCN.deps.json',
        'doorbell.wav','NAudio.Core.dll','NAudio.WinMM.dll','NAudio.Wasapi.dll')
    foreach ($file in $required) { Copy-Item -LiteralPath (Join-Path $buildDirectory $file) -Destination $package -Force }
    Copy-Item (Join-Path $root 'README.md') (Join-Path $package '使用说明.md') -Force
    Copy-Item (Join-Path $root 'NOTICE.md') $package -Force
    Copy-Item (Join-Path $root 'docs\实机验收清单.md') $package -Force
    New-Item -ItemType Directory -Path (Join-Path $package 'licenses') -Force | Out-Null
    Copy-Item (Join-Path $root 'licenses\NAudio-LICENSE.txt') (Join-Path $package 'licenses') -Force

    $sdk = (& dotnet --version).Trim()
    $buildTime = Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'
    $info = [ordered]@{
        Plugin = 'DoorbellCN'; Version = '2.1.1.0'; BuiltAt = $buildTime
        Author = 'Aida Enna、断水剑'; Description = '6'; Punchline = '6'
        Region = 'CN'; DalamudApi = 15; DalamudFileVersion = $dalamudVersion; DotnetSdk = $sdk
        DalamudSha256 = (Get-FileHash (Join-Path $DalamudHome 'Dalamud.dll') -Algorithm SHA256).Hash
        ClientStructsSha256 = (Get-FileHash (Join-Path $DalamudHome 'FFXIVClientStructs.dll') -Algorithm SHA256).Hash
        CoreTests = [int]$counters.total; CorePassed = [int]$counters.passed
        OfflineChecks = $smoke.Checks
        GameTested = $false; Installed = $false; GameMacrosExecuted = $false
    }
    $info | ConvertTo-Json | Set-Content (Join-Path $package 'build-info.json') -Encoding utf8
    $report = @'
# 门铃迎宾 2.1.1 验证报告

## 已验证

- 构建时间：__TIME__
- 国服 Dalamud 文件版本：__DALAMUD__，目标 API 15。
- .NET SDK：__SDK__。
- Release 编译通过；启用 TreatWarningsAsErrors，构建为 0 警告、0 错误。
- 核心自动测试：__PASSED__ / __TOTAL__ 通过。
- 离线配置 / 资源检查：__SMOKE__ 项通过。
- 测试覆盖：移除宏结束后固定冷却、新客可在结束后几秒内进入下一批、旧未来冷却不再阻塞、迁移保留本场记录和限额、旧未决宏不重放、三秒批次、多人反复进出、五分钟三次上限、先落盘后执行、异常不重试。
- 场景模拟覆盖：五位访客二十分钟反复进出只提交一次；持续新客可在六十秒内多次迎宾但不超过五分钟次数上限；长宏不重叠且无附加六十秒等待。模拟不调用真实游戏。
- 离线检查覆盖：作者精确为 Aida Enna、断水剑；长短简介精确为 6；版本一致、2.0 / 2.1 配置迁移、冷却字段移除、中文 JSON 往返、依赖和 WAV 解码。
- 完整核心测试结果保留在源码目录 artifacts/test-results/core-tests.trx。
- 编译日志保留在源码目录 artifacts/build.log。
- 本包不附带 Dalamud.dll / FFXIVClientStructs.dll，不修改或替换宿主。

## 尚未验证

- 没有启动 / 注入游戏插件，未执行任何游戏宏。
- 尚未确认游戏内中文界面的布局、弹窗、链接交互和音频输出设备。
- 尚未实测住宅、公寓、个人房间、不同内装的房屋身份识别。
- 尚未实测原生宏模块在当前国服游戏中的实际执行、忙闲状态和结束观测；仍保留约一秒空闲确认，不存在六十秒结束后冷却。
- 尚未验证后续国服游戏 / 卫月更新的兼容性。

**交付性质：已编译和离线验证的本地重构版本，不是已完成游戏内验收的成品保证。**

请先按“实机验收清单.md”使用 /echo 宏验证。没有自动安装，也没有改动原 Doorbell 或卫月配置。
'@
    $report = $report.Replace('__TIME__', $buildTime).Replace('__DALAMUD__', $dalamudVersion).
        Replace('__SDK__', $sdk).Replace('__PASSED__', [string]$counters.passed).
        Replace('__TOTAL__', [string]$counters.total).Replace('__SMOKE__', [string]$smoke.Checks)
    $report | Set-Content (Join-Path $root 'docs\验证报告.md') -Encoding utf8
    $report | Set-Content (Join-Path $package '验证报告.md') -Encoding utf8
    $smokeJson | Set-Content (Join-Path $package 'offline-checks.json') -Encoding utf8

    # Hash every package file; consumers can verify without executing the plugin.
    $hashes = foreach ($file in Get-ChildItem $package -File -Recurse | Where-Object Name -ne 'SHA256SUMS.txt' | Sort-Object FullName) {
        $relative = [IO.Path]::GetRelativePath($package, $file.FullName).Replace('\','/')
        '{0}  {1}' -f (Get-FileHash $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant(), $relative
    }
    $hashes | Set-Content (Join-Path $package 'SHA256SUMS.txt') -Encoding utf8
    $zipPath = Join-Path $delivery ($packageName + '.zip')
    Compress-Archive -Path (Join-Path $package '*') -DestinationPath $zipPath -Force

    # Source archive: include project files only, not binaries, user data, caches or other cwd projects.
    $sourceStage = Join-Path $artifacts 'source-package'
    if (Test-Path $sourceStage) { Remove-Item $sourceStage -Recurse -Force }
    New-Item -ItemType Directory -Path $sourceStage -Force | Out-Null
    foreach ($folder in @('src','tests','tools','licenses','docs')) {
        foreach ($file in Get-ChildItem (Join-Path $root $folder) -File -Recurse |
                Where-Object { $_.FullName -notmatch '[\\/](bin|obj)[\\/]' }) {
            $relative = [IO.Path]::GetRelativePath($root, $file.FullName)
            $destination = Join-Path $sourceStage $relative
            New-Item -ItemType Directory -Path (Split-Path $destination) -Force | Out-Null
            Copy-Item $file.FullName $destination -Force
        }
    }
    foreach ($file in @('.gitignore','Directory.Build.props','DoorbellCN.sln','README.md','NOTICE.md')) {
        Copy-Item (Join-Path $root $file) $sourceStage -Force
    }
    $sourceZip = Join-Path $delivery ($packageName + '_源码.zip')
    Compress-Archive -Path (Join-Path $sourceStage '*') -DestinationPath $sourceZip -Force
    Copy-Item (Join-Path $package '使用说明.md') $delivery -Force
    Copy-Item (Join-Path $package '验证报告.md') $delivery -Force
    Get-FileHash $zipPath,$sourceZip -Algorithm SHA256 |
        ForEach-Object { '{0}  {1}' -f $_.Hash.ToLowerInvariant(), (Split-Path $_.Path -Leaf) } |
        Set-Content (Join-Path $delivery 'SHA256SUMS.txt') -Encoding utf8
    Write-Output "核心测试：$($counters.passed)/$($counters.total)；离线检查：$($smoke.Checks)"
    Write-Output $zipPath
    Write-Output $sourceZip
    Write-Output (Join-Path $delivery '使用说明.md')
} finally {
    $env:DALAMUD_HOME = $oldHome
    Set-Location $oldLocation
}
