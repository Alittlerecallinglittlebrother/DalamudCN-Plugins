using System.Text.Json;

namespace DoorbellCN.Core;

/// <summary>Exclusive writer, atomic replacement, and flush-before-native-dispatch.</summary>
public sealed class LedgerFileStore : IDisposable
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private readonly string path;
    private readonly FileStream writerLock;
    public LedgerFileStore(string directory)
    {
        Directory.CreateDirectory(directory);
        path = Path.Combine(directory, "welcome-ledger-v1.json");
        writerLock = new FileStream(path + ".lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
    }

    public WelcomeLedger Load()
    {
        if (!File.Exists(path))
        {
            if (File.Exists(path + ".bak")) throw new InvalidDataException("迎宾记录缺失，已暂停；不会使用旧备份重放。");
            return new WelcomeLedger();
        }
        if (new FileInfo(path).Length > 8 * 1024 * 1024)
            throw new InvalidDataException("迎宾记录文件过大，已停止自动迎宾。");
        var state = JsonSerializer.Deserialize<WelcomeLedger>(File.ReadAllBytes(path), JsonOptions)
                    ?? throw new InvalidDataException("迎宾记录为空。");
        state.Validate();
        return state;
    }

    public void Save(WelcomeLedger state)
    {
        state.Validate();
        var temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            var bytes = JsonSerializer.SerializeToUtf8Bytes(state, JsonOptions);
            using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                       4096, FileOptions.WriteThrough))
            {
                stream.Write(bytes);
                stream.Flush(flushToDisk: true);
            }
            if (File.Exists(path)) File.Replace(temp, path, path + ".bak", ignoreMetadataErrors: true);
            else File.Move(temp, path);
        }
        finally
        {
            if (File.Exists(temp)) File.Delete(temp);
        }
    }

    public void Dispose() => writerLock.Dispose();
}
