namespace DoorbellCN.Core;

public sealed record DispatchAttempt<T>(bool Reserved, T? Result) where T : class;

public static class MacroDispatcher
{
    public static DispatchAttempt<T> Submit<T>(MacroScheduler scheduler, double now, DateTimeOffset utc,
        MacroObservation observation, Func<string, bool> isVisible,
        Action persist, Func<T> nativeCall, bool manual = false) where T : class
    {
        if (!scheduler.TryReserve(now, utc, observation, isVisible, manual)) return new(false, null);
        try
        {
            persist(); // No native side effect is allowed until this succeeds.
            return new(true, nativeCall());
        }
        catch
        {
            scheduler.MarkUncertain();
            throw; // No retries: the side effect may already have happened.
        }
    }
}
