using System.Security.Cryptography;
using System.Text;

namespace DoorbellCN.Core;

public static class MacroFingerprint
{
    public static string Compute(MacroSelection selection, string name, IReadOnlyList<string> lines)
    {
        // Include the set, slot, name and all 15 lines. No trimmed or partially matching approvals.
        var input = selection.Label + "\0" + name + "\0" + string.Join("\n", lines);
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(input)));
    }
}
