namespace DoorbellCN.Core;

public sealed record Visitor(string Name, uint HomeWorld, string WorldName)
{
    // EntityId can change on re-entry. Name + home world is stable within a session.
    public string Key => $"{HomeWorld}:{Name}";
    public string DisplayName => $"{Name}@{WorldName}";
}

public enum VisitKind { Entered, Left, AlreadyHere }
public sealed record VisitEvent(VisitKind Kind, Visitor Visitor);
public sealed record DetectionPolicy(double WarmupSeconds = 5, double ConfirmationSeconds = 0.5,
    double DepartureGraceSeconds = 3);
public static class MacroPolicy
{
    public const double BatchSeconds = 3;
    public const double IdleConfirmationSeconds = 1;
    public const double MaxBatchLatenessSeconds = 2;
    public const double ExecutionWatchLimitSeconds = 1020;
}

public enum MacroRunState { Idle, Running, Unavailable }
public readonly record struct MacroObservation(MacroRunState State, bool Blocked = false)
{
    public bool CanExecute => State == MacroRunState.Idle && !Blocked;
}

public readonly record struct MacroSelection(int Set, int Slot)
{
    public bool IsValid => Set is 0 or 1 && Slot is >= 0 and < 100;
    public string Label => $"{(Set == 0 ? "个人宏" : "共通宏")} {Slot:00}";
}

public readonly record struct HouseSession(ulong CharacterId, ulong HouseId, short Room, uint TerritoryId)
{
    public bool IsValid => CharacterId != 0 && HouseId is not (0 or ulong.MaxValue) && TerritoryId != 0;
}

public sealed class SessionGuard
{
    public HouseSession? Session { get; private set; }
    public MacroSelection? Selection { get; private set; }
    public bool IsArmed => Session.HasValue;

    public bool Arm(HouseSession session, MacroSelection selection)
    {
        Disarm();
        if (!session.IsValid || !selection.IsValid) return false;
        Session = session;
        Selection = selection;
        return true;
    }

    public bool Matches(HouseSession session, MacroSelection selection) =>
        IsArmed && session.IsValid && selection.IsValid && Session == session && Selection == selection;

    public void Disarm()
    {
        Session = null;
        Selection = null;
    }
}
