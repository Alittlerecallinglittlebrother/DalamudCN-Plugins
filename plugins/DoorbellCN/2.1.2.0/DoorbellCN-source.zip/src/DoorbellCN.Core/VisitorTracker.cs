namespace DoorbellCN.Core;

/// <summary>Pure, monotonic-time state machine. No game pointers or frame-rate assumptions.</summary>
public sealed class VisitorTracker
{
    private sealed class Entry(Visitor visitor, double now, bool alreadyHere)
    {
        public Visitor Visitor = visitor;
        public double FirstSeen = now;
        public double LastSeen = now;
        public bool AlreadyHere = alreadyHere;
        public bool Announced;
    }

    private readonly Dictionary<string, Entry> entries = new(StringComparer.Ordinal);
    private readonly HashSet<string> visible = new(StringComparer.Ordinal);
    private double startedAt;

    public int Count => entries.Values.Count(e => e.Announced);
    public bool IsVisible(string key) => visible.Contains(key);
    public bool IsWarmingUp(double now, DetectionPolicy policy) => now - startedAt < policy.WarmupSeconds;

    public void Reset(double now)
    {
        entries.Clear();
        visible.Clear();
        startedAt = now;
    }

    public IReadOnlyList<VisitEvent> Observe(double now, IEnumerable<Visitor> players, DetectionPolicy policy)
    {
        var events = new List<VisitEvent>();
        var previouslyVisible = new HashSet<string>(visible, StringComparer.Ordinal);
        visible.Clear();
        foreach (var visitor in players)
        {
            if (!visible.Add(visitor.Key)) continue;
            if (!entries.TryGetValue(visitor.Key, out var entry))
            {
                entry = new Entry(visitor, now, IsWarmingUp(now, policy));
                entries.Add(visitor.Key, entry);
            }
            else if (!entry.Announced && (!previouslyVisible.Contains(visitor.Key) || now - entry.LastSeen > 0.75))
            {
                // A brief one-frame object should not pass continuous-presence confirmation.
                entry.FirstSeen = now;
            }

            entry.LastSeen = now;
            entry.Visitor = visitor;
            if (!entry.Announced && now - entry.FirstSeen >= policy.ConfirmationSeconds)
            {
                entry.Announced = true;
                events.Add(new(entry.AlreadyHere ? VisitKind.AlreadyHere : VisitKind.Entered, visitor));
            }
        }

        foreach (var (key, entry) in entries.ToArray())
        {
            if (visible.Contains(key) || now - entry.LastSeen < policy.DepartureGraceSeconds) continue;
            entries.Remove(key);
            if (entry.Announced) events.Add(new(VisitKind.Left, entry.Visitor));
        }
        return events;
    }
}
