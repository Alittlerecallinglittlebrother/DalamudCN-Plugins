using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Serialization;

namespace DoorbellCN.Core;

public sealed class WelcomeLedger
{
    [JsonRequired] public int Version { get; set; } = 3;
    [JsonRequired] public string Salt { get; set; } = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
    [JsonRequired] public DateTimeOffset LastSavedUtc { get; set; }
    [JsonRequired] public Dictionary<string, SceneLedger> Scenes { get; set; } = [];
    [JsonRequired] public Dictionary<string, CharacterLedger> Characters { get; set; } = [];

    public string Token(string value) => Convert.ToHexString(
        HMACSHA256.HashData(Convert.FromBase64String(Salt), Encoding.UTF8.GetBytes(value)));

    public string SceneKey(HouseSession house) => Token($"house:{house.CharacterId}:{house.HouseId}:{house.Room}");
    public string CharacterKey(HouseSession house) => Token($"character:{house.CharacterId}");
    public string VisitorKey(Visitor visitor) => Token("visitor:" + visitor.Key);

    public void Validate()
    {
        if (Version is not (1 or 2 or 3) || Convert.FromBase64String(Salt).Length != 32)
            throw new InvalidDataException("迎宾记录版本或校验信息不正确。");
        if (Scenes is null || Characters is null || Scenes.Count > 128 || Characters.Count > 64)
            throw new InvalidDataException("迎宾记录容量异常。");
        foreach (var (key, scene) in Scenes)
        {
            if (!IsToken(key) || scene is null || scene.SeenVisitors is null ||
                scene.SeenVisitors.Count > 10000 || scene.SeenVisitors.Any(v => !IsToken(v)) ||
                scene.Round < 1 || scene.Attempts < 0)
                throw new InvalidDataException("访客记录不完整。");
        }
        if (Scenes.Values.Sum(s => s.SeenVisitors.Count) > 50000)
            throw new InvalidDataException("访客记录总量过大。");
        foreach (var (key, character) in Characters)
        {
            if (!IsToken(key) || character is null)
                throw new InvalidDataException("迎宾执行记录不完整。");
        }
    }

    private static bool IsToken(string? value) =>
        value is { Length: 64 } && value.All(c => char.IsAsciiHexDigit(c));
}

public sealed class SceneLedger
{
    [JsonRequired] public long Round { get; set; } = 1;
    [JsonRequired] public long Attempts { get; set; }
    [JsonRequired] public HashSet<string> SeenVisitors { get; set; } = new(StringComparer.Ordinal);
}

public sealed class CharacterLedger
{
    [JsonRequired] public bool InFlight { get; set; }
}
