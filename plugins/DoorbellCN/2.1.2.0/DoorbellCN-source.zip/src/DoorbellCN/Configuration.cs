using Dalamud.Configuration;
using DoorbellCN.Core;
using Newtonsoft.Json;

namespace DoorbellCN;

public sealed class AlertOptions
{
    public bool ChatEnabled;
    public bool SoundEnabled;
    public string Message = "";
    public string SoundFile = "";
    public float Volume = 0.65f;
}

public sealed class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 3;
    public bool Enabled = true;
    public int MacroSet;
    public int MacroSlot;
    public double WarmupSeconds = 5;
    public double ConfirmationSeconds = 0.5;
    public double DepartureGraceSeconds = 3;

    public AlertOptions Entered = new()
    {
        ChatEnabled = true, SoundEnabled = true, Message = "<link> 进入了住宅。",
    };
    public AlertOptions Left = new() { Message = "<link> 离开了住宅。" };
    public AlertOptions AlreadyHere = new() { Message = "你到达时，<link> 已在住宅内。" };

    [JsonIgnore] public MacroSelection Selection => new(MacroSet, MacroSlot);
    [JsonIgnore] public DetectionPolicy Detection => new(WarmupSeconds, ConfirmationSeconds, DepartureGraceSeconds);

    public AlertOptions For(VisitKind kind) => kind switch
    {
        VisitKind.Entered => Entered,
        VisitKind.Left => Left,
        _ => AlreadyHere,
    };

    public void Normalize()
    {
        // Invalid stored selections return to a safe default. Arming is never persisted and requires preview.
        if (!Selection.IsValid) { MacroSet = 0; MacroSlot = 0; }
        WarmupSeconds = Bound(WarmupSeconds, 5, 3, 30);
        ConfirmationSeconds = Bound(ConfirmationSeconds, 0.5, 0.25, 2);
        DepartureGraceSeconds = Bound(DepartureGraceSeconds, 3, 1, 15);
        // Legacy cooldown values are ignored and are no longer serialized.
        Version = 3;
        Entered ??= new() { ChatEnabled = true, SoundEnabled = true, Message = "<link> 进入了住宅。" };
        Left ??= new() { Message = "<link> 离开了住宅。" };
        AlreadyHere ??= new() { Message = "你到达时，<link> 已在住宅内。" };
        foreach (var alert in new[] { Entered, Left, AlreadyHere })
        {
            alert.Message ??= "";
            alert.SoundFile ??= "";
            alert.Volume = float.IsFinite(alert.Volume) ? Math.Clamp(alert.Volume, 0, 1) : 0.65f;
        }
    }

    private static double Bound(double value, double fallback, double min, double max) =>
        double.IsFinite(value) ? Math.Clamp(value, min, max) : fallback;
}
