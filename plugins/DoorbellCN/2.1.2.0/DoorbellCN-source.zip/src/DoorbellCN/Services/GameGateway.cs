using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Plugin.Services;
using DoorbellCN.Core;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;
using FFXIVClientStructs.FFXIV.Client.UI.Shell;

namespace DoorbellCN.Services;

public sealed record MacroPreview(bool Available, string Name, string[] Lines, string Fingerprint, string Error)
{
    public bool HasContent => Available && Lines.Any(line => !string.IsNullOrWhiteSpace(line));
    public static MacroPreview Unavailable(string reason) => new(false, "", [], "", reason);
}

public enum ExecuteState { Executed, Busy, Refused }
public sealed record ExecuteResult(ExecuteState State, string Message);

/// <summary>Only this adapter touches native memory. Every public call runs on Framework.Update.</summary>
public sealed unsafe class GameGateway(IFramework framework, IClientState clientState,
    IObjectTable objects, IPlayerState playerState, ICondition condition)
{
    private void AssertFramework()
    {
        if (!framework.IsInFrameworkUpdateThread)
            throw new InvalidOperationException("游戏接口只能在框架更新线程调用。");
    }

    public bool TryGetHouse(out HouseSession session)
    {
        AssertFramework();
        session = default;
        if (!clientState.IsLoggedIn || !playerState.IsLoaded || objects.LocalPlayer is null ||
            condition[ConditionFlag.BetweenAreas] || condition[ConditionFlag.BetweenAreas51])
            return false;

        var manager = HousingManager.Instance();
        if (manager == null || manager->IndoorTerritory == null ||
            manager->CurrentTerritory != (HousingTerritory*)manager->IndoorTerritory)
            return false;

        // A full house identity, not just TerritoryType (many houses share that value).
        var house = manager->GetCurrentIndoorHouseId();
        session = new(playerState.ContentId, house.Id, manager->GetCurrentRoom(), clientState.TerritoryType);
        return session.IsValid;
    }

    public IReadOnlyList<Visitor> ReadVisitors()
    {
        AssertFramework();
        var local = objects.LocalPlayer;
        if (local is null) return [];
        var result = new List<Visitor>();
        foreach (var obj in objects)
        {
            if (obj is not IPlayerCharacter pc || pc.ObjectIndex >= 200 || pc.EntityId == local.EntityId)
                continue;
            var name = pc.Name.TextValue;
            if (string.IsNullOrWhiteSpace(name) || pc.HomeWorld.RowId == 0) continue;
            var world = pc.HomeWorld.RowId;
            var worldName = pc.HomeWorld.Value.Name.ToString();
            result.Add(new(name, world, string.IsNullOrWhiteSpace(worldName) ? world.ToString() : worldName));
        }
        return result;
    }

    public MacroObservation ReadMacroObservation()
    {
        AssertFramework();
        if (!clientState.IsLoggedIn || !playerState.IsLoaded || objects.LocalPlayer is null ||
            condition[ConditionFlag.BetweenAreas] || condition[ConditionFlag.BetweenAreas51])
            return new(MacroRunState.Unavailable);
        var shell = RaptureShellModule.Instance();
        if (shell == null || shell->MacroCurrentLine is < -1 or > 15)
            return new(MacroRunState.Unavailable);
        var running = shell->MacroCurrentLine >= 0 || shell->MacroLocked;
        return new(running ? MacroRunState.Running : MacroRunState.Idle,
            shell->IsTextCommandUnavailable || IsUnsafeActivity());
    }

    private bool IsUnsafeActivity() =>
        condition[ConditionFlag.InCombat] || condition[ConditionFlag.Unconscious] ||
        condition[ConditionFlag.Crafting] || condition[ConditionFlag.Gathering] ||
        condition[ConditionFlag.Performing] || condition[ConditionFlag.Occupied] ||
        condition[ConditionFlag.OccupiedInEvent] || condition[ConditionFlag.OccupiedInQuestEvent] ||
        condition[ConditionFlag.OccupiedInCutSceneEvent] || condition[ConditionFlag.WatchingCutscene] ||
        condition[ConditionFlag.WatchingCutscene78];

    public MacroPreview ReadMacro(MacroSelection selection)
    {
        AssertFramework();
        if (!selection.IsValid) return MacroPreview.Unavailable("宏编号无效，必须为 0–99。");
        if (!clientState.IsLoggedIn || !playerState.IsLoaded || objects.LocalPlayer is null)
            return MacroPreview.Unavailable("请先登录角色。");
        var module = RaptureMacroModule.Instance();
        if (module == null) return MacroPreview.Unavailable("游戏宏模块尚未就绪。");
        var macro = module->GetMacro((uint)selection.Set, (uint)selection.Slot);
        if (macro == null) return MacroPreview.Unavailable("无法读取指定宏。");
        var lines = new string[15];
        for (var i = 0; i < lines.Length; i++) lines[i] = macro->Lines[i].ToString();
        var name = macro->Name.ToString();
        var fingerprint = MacroFingerprint.Compute(selection, name, lines);
        return new(true, name, lines, fingerprint, "");
    }

    public ExecuteResult Execute(MacroSelection selection, HouseSession expectedSession, string fingerprint)
    {
        AssertFramework();
        if (!TryGetHouse(out var current) || current != expectedSession)
            return new(ExecuteState.Refused, "住宅或角色已变化，已拒绝执行。");
        var observation = ReadMacroObservation();
        if (observation.State == MacroRunState.Unavailable)
            return new(ExecuteState.Refused, "无法确认宏状态，已拒绝执行。");
        if (!observation.CanExecute) return new(ExecuteState.Busy, "游戏正忙，本次迎宾已取消。");
        var preview = ReadMacro(selection);
        if (!preview.HasContent) return new(ExecuteState.Refused, "所选宏为空或不可用。");
        if (string.IsNullOrEmpty(fingerprint) || preview.Fingerprint != fingerprint)
            return new(ExecuteState.Refused, "宏内容已改变，请重新预览并开启迎宾。");

        var module = RaptureMacroModule.Instance();
        var shell = RaptureShellModule.Instance();
        if (module == null || shell == null) return new(ExecuteState.Refused, "游戏宏模块不可用。");
        var macro = module->GetMacro((uint)selection.Set, (uint)selection.Slot);
        if (macro == null) return new(ExecuteState.Refused, "指定宏不可用。");

        // Execute the saved macro in place. Never rewrite user macros, change targets or inject chat text.
        shell->ExecuteMacro(macro);
        return new(ExecuteState.Executed, $"已提交 {selection.Label}「{preview.Name}」给游戏执行。");
    }
}
