using System.Text.RegularExpressions;
using Dalamud.Game.Text;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.Game.Text.SeStringHandling.Payloads;
using Dalamud.Plugin.Services;
using DoorbellCN.Core;

namespace DoorbellCN.Services;

public sealed class NotificationService(IChatGui chat, SoundService sound)
{
    public void Notify(VisitEvent visit, AlertOptions options)
    {
        if (options.ChatEnabled)
        {
            var player = visit.Visitor;
            var builder = new SeStringBuilder().AddText("[门铃迎宾] ");
            foreach (var part in Regex.Split(options.Message, "(<name>|<world>|<link>)"))
            {
                switch (part)
                {
                    case "<name>": builder.AddText(player.Name); break;
                    case "<world>": builder.AddText(player.WorldName); break;
                    case "<link>":
                        builder.Add(new PlayerPayload(player.Name, player.HomeWorld))
                            .AddText(player.DisplayName).Add(RawPayload.LinkTerminator);
                        break;
                    default: builder.AddText(part); break;
                }
            }
            // Local chat display only. Public chat can only come from the user's explicitly selected macro.
            chat.Print(new XivChatEntry { Message = builder.Build() });
        }
        if (options.SoundEnabled) sound.Play(options.SoundFile, options.Volume);
    }
}
