using System.Diagnostics;
using System.Threading.Channels;
using Dalamud.Plugin.Services;
using NAudio.Wave;

namespace DoorbellCN.Services;

/// <summary>One bounded worker owns every audio object; no per-visitor task storm or cached-file race.</summary>
public sealed class SoundService : IDisposable
{
    private sealed record Request(string Path, float Volume, long EnqueuedAt, int Generation);
    private readonly Channel<Request> queue = Channel.CreateBounded<Request>(new BoundedChannelOptions(1)
    {
        FullMode = BoundedChannelFullMode.DropOldest, SingleReader = true,
    });
    private readonly CancellationTokenSource cancellation = new();
    private readonly Task worker;
    private readonly IPluginLog log;
    private readonly string defaultPath;
    private bool disposed;
    private int generation;

    public SoundService(string defaultPath, IPluginLog log)
    {
        this.defaultPath = defaultPath;
        this.log = log;
        worker = Task.Run(Run);
    }

    public void Play(string path, float volume)
    {
        if (disposed) return;
        var resolved = string.IsNullOrWhiteSpace(path) ? defaultPath : path.Trim().Trim('"');
        // Local files only. A network location must not stall the game or silently fetch third-party audio.
        if (!Path.IsPathFullyQualified(resolved) || resolved.StartsWith(@"\\") ||
            !new[] { ".wav", ".mp3", ".aiff", ".aif" }.Contains(Path.GetExtension(resolved).ToLowerInvariant()))
        {
            log.Warning("门铃迎宾：提示音必须为本地 WAV、MP3 或 AIFF 文件。");
            return;
        }
        queue.Writer.TryWrite(new(resolved, Math.Clamp(volume, 0, 1), Stopwatch.GetTimestamp(), Volatile.Read(ref generation)));
    }

    public void StopAll() => Interlocked.Increment(ref generation);

    private async Task Run()
    {
        try
        {
            await foreach (var request in queue.Reader.ReadAllAsync(cancellation.Token))
            {
                if (request.Generation != Volatile.Read(ref generation) ||
                    Stopwatch.GetElapsedTime(request.EnqueuedAt).TotalSeconds > 2) continue;
                try
                {
                    if (!File.Exists(request.Path))
                    {
                        log.Warning("门铃迎宾：提示音文件不存在：{Path}", request.Path);
                        continue;
                    }
                    using WaveStream reader = Path.GetExtension(request.Path).ToLowerInvariant() switch
                    {
                        ".wav" => new WaveFileReader(request.Path),
                        ".aiff" or ".aif" => new AiffFileReader(request.Path),
                        _ => new MediaFoundationReader(request.Path),
                    };
                    using var output = new WaveOutEvent();
                    output.Init(reader);
                    output.Volume = request.Volume;
                    output.Play();
                    var started = Stopwatch.GetTimestamp();
                    while (output.PlaybackState == PlaybackState.Playing &&
                           request.Generation == Volatile.Read(ref generation) &&
                           Stopwatch.GetElapsedTime(started).TotalSeconds < 8)
                        await Task.Delay(50, cancellation.Token).ConfigureAwait(false);
                    output.Stop();
                }
                catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { break; }
                catch (Exception ex) { log.Error(ex, "门铃迎宾：播放提示音失败。"); }
            }
        }
        catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { }
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        queue.Writer.TryComplete();
        cancellation.Cancel();
        worker.GetAwaiter().GetResult();
        cancellation.Dispose();
    }
}
