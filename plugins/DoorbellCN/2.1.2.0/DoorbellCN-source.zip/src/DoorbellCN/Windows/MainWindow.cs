using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;
using DoorbellCN.Core;

namespace DoorbellCN.Windows;

public sealed class MainWindow : Window
{
    private static readonly Vector4 Green = new(0.40f, 0.85f, 0.67f, 1);
    private static readonly Vector4 Amber = new(1, 0.77f, 0.36f, 1);
    private readonly Plugin plugin;
    private bool automationConfirmed;
    private string confirmedPreviewFingerprint = "";
    private bool testModalOpen;
    private MacroSelection testSelection;
    private HouseSession testHouse;
    private string testFingerprint = "";
    private string[] testLines = [];
    private bool roundModalOpen;
    private HouseSession roundHouse;
    private int silenceMinutes = 30;

    public MainWindow(Plugin plugin) : base("门铃迎宾###DoorbellCN", ImGuiWindowFlags.NoCollapse)
    {
        this.plugin = plugin;
        Size = new(720, 590);
        SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new() { MinimumSize = new(620, 440), MaximumSize = new(float.MaxValue, float.MaxValue) };
    }

    public override void Draw()
    {
        ImGui.TextColored(plugin.IsArmed ? Green : Amber, plugin.Status);
        ImGui.Separator();
        if (ImGui.BeginTabBar("门铃页面"))
        {
            if (ImGui.BeginTabItem("总览")) { DrawOverview(); ImGui.EndTabItem(); }
            if (ImGui.BeginTabItem("迎宾宏")) { DrawMacro(); ImGui.EndTabItem(); }
            if (ImGui.BeginTabItem("声音与提醒")) { DrawAlerts(); ImGui.EndTabItem(); }
            if (ImGui.BeginTabItem("迎宾设置")) { DrawTiming(); ImGui.EndTabItem(); }
            if (ImGui.BeginTabItem("运行记录")) { DrawHistory(); ImGui.EndTabItem(); }
            ImGui.EndTabBar();
        }
    }

    private void DrawOverview()
    {
        ImGui.Spacing();
        if (ImGui.Checkbox("启用门铃", ref plugin.Config.Enabled)) plugin.SettingsChanged();
        ImGui.TextUnformatted(plugin.IsInside ? "位置：住宅内" : "位置：未进入住宅");
        ImGui.TextUnformatted($"当前访客：{plugin.VisitorCount} 人");
        ImGui.TextUnformatted($"本场到访：{plugin.SeenCount} 人");
        ImGui.TextUnformatted($"本场迎宾：{plugin.Attempts} 次");
        ImGui.Separator();
        ImGui.BeginDisabled(!plugin.IsArmed);
        if (ImGui.Button("暂停迎宾")) plugin.Post(() => plugin.StopWelcome());
        ImGui.EndDisabled();
        ImGui.SameLine();
        ImGui.BeginDisabled(!plugin.CanStartNewRound);
        if (ImGui.Button("开始新一场") && plugin.CurrentHouse is { } house)
        {
            roundHouse = house;
            roundModalOpen = true;
            ImGui.OpenPopup("确认开始新一场");
        }
        ImGui.EndDisabled();
        ImGui.Separator();
        ImGui.TextUnformatted($"静音：{plugin.SilenceLabel}");
        if (plugin.IsSilenced)
        {
            if (ImGui.Button("解除静音")) plugin.Post(() => plugin.SetSilence(0));
        }
        else
        {
            if (ImGui.Button("静音至离开住宅")) plugin.Post(() => plugin.SetSilence(null));
            ImGui.SetNextItemWidth(140);
            ImGui.InputInt("分钟", ref silenceMinutes);
            silenceMinutes = Math.Clamp(silenceMinutes, 1, 1440);
            if (ImGui.Button("定时静音"))
            {
                var minutes = silenceMinutes;
                plugin.Post(() => plugin.SetSilence(minutes));
            }
        }
        DrawRoundModal();
    }

    private void DrawRoundModal()
    {
        ImGui.SetNextWindowSize(new Vector2(470, 0), ImGuiCond.Appearing);
        if (!ImGui.BeginPopupModal("确认开始新一场", ref roundModalOpen, ImGuiWindowFlags.AlwaysAutoResize)) return;
        Wrapped("清空本住宅的本场访客记录并开始新一场？");
        if (ImGui.Button("确认开始"))
        {
            var expected = roundHouse;
            plugin.Post(() => plugin.BeginNewRound(expected));
            ImGui.CloseCurrentPopup();
            roundModalOpen = false;
        }
        ImGui.SameLine();
        if (ImGui.Button("取消")) { ImGui.CloseCurrentPopup(); roundModalOpen = false; }
        ImGui.EndPopup();
    }

    private void DrawMacro()
    {
        ImGui.Spacing();
        var setChanged = ImGui.Combo("宏分类", ref plugin.Config.MacroSet, new[] { "个人宏", "共通宏" }, 2);
        ImGui.SetNextItemWidth(160);
        var slotChanged = ImGui.InputInt("宏编号（0–99）", ref plugin.Config.MacroSlot);
        if (setChanged || slotChanged)
        {
            plugin.Config.MacroSlot = Math.Clamp(plugin.Config.MacroSlot, 0, 99);
            automationConfirmed = false;
            plugin.SettingsChanged(macroSelectionChanged: true);
        }
        if (ImGui.Button("读取宏")) plugin.Post(plugin.RefreshPreview);
        ImGui.SameLine();
        ImGui.TextUnformatted(plugin.Config.Selection.Label);
        var preview = plugin.Preview;
        if (preview.Fingerprint != confirmedPreviewFingerprint)
        {
            automationConfirmed = false;
            confirmedPreviewFingerprint = preview.Fingerprint;
        }
        if (preview.Available)
        {
            ImGui.TextUnformatted($"宏名称：{(string.IsNullOrWhiteSpace(preview.Name) ? "未命名" : preview.Name)}");
            if (ImGui.BeginChild("宏内容预览", new Vector2(0, 205), true))
            {
                for (var i = 0; i < preview.Lines.Length; i++)
                    ImGui.TextUnformatted($"{i + 1,2}  {preview.Lines[i]}");
            }
            ImGui.EndChild();
            if (!preview.HasContent) ImGui.TextColored(Amber, "所选宏为空");
        }
        else Wrapped(preview.Error);

        ImGui.Checkbox("我已确认宏内容及自动执行风险", ref automationConfirmed);
        var ready = automationConfirmed && preview.HasContent && plugin.PreviewSelection == plugin.Config.Selection &&
                    plugin.IsInside && plugin.WarmupRemaining <= 0 && !plugin.IsSilenced &&
                    plugin.Config.Enabled && plugin.Fault is null;
        ImGui.BeginDisabled(!ready || plugin.IsArmed || plugin.IsExecuting);
        if (ImGui.Button("开启迎宾")) plugin.Post(() => plugin.ArmWelcome(true));
        ImGui.EndDisabled();
        ImGui.SameLine();
        ImGui.BeginDisabled(!plugin.IsArmed);
        if (ImGui.Button("暂停迎宾")) plugin.Post(() => plugin.StopWelcome());
        ImGui.EndDisabled();
        ImGui.SameLine();
        ImGui.BeginDisabled(!ready || !plugin.CanTest);
        if (ImGui.Button("测试一次") && plugin.CurrentHouse is { } house)
        {
            testHouse = house;
            testSelection = plugin.Config.Selection;
            testFingerprint = preview.Fingerprint;
            testLines = preview.Lines.ToArray();
            testModalOpen = true;
            ImGui.OpenPopup("确认执行游戏宏");
        }
        ImGui.EndDisabled();
        // OpenPopup and BeginPopupModal share the same tab ID stack.
        DrawTestModal();
    }

    private void DrawTestModal()
    {
        ImGui.SetNextWindowSize(new Vector2(560, 0), ImGuiCond.Appearing);
        if (!ImGui.BeginPopupModal("确认执行游戏宏", ref testModalOpen, ImGuiWindowFlags.AlwaysAutoResize)) return;
        Wrapped($"确认执行 {testSelection.Label}？这会真实执行宏，可能发送聊天消息。");
        foreach (var line in testLines.Where(line => !string.IsNullOrWhiteSpace(line))) ImGui.TextUnformatted(line);
        ImGui.Separator();
        if (ImGui.Button("确认执行一次"))
        {
            var selection = testSelection;
            var fingerprint = testFingerprint;
            var expectedHouse = testHouse;
            plugin.Post(() => plugin.TestMacro(selection, fingerprint, expectedHouse));
            ImGui.CloseCurrentPopup();
            testModalOpen = false;
        }
        ImGui.SameLine();
        if (ImGui.Button("取消")) { ImGui.CloseCurrentPopup(); testModalOpen = false; }
        ImGui.EndPopup();
    }

    private void DrawAlerts()
    {
        DrawAlert("玩家进入", "进入", plugin.Config.Entered);
        DrawAlert("玩家离开", "离开", plugin.Config.Left);
        DrawAlert("已在场的玩家", "已在场", plugin.Config.AlreadyHere);
    }

    private void DrawAlert(string title, string id, AlertOptions options)
    {
        ImGui.PushID(id);
        if (ImGui.CollapsingHeader(title, ImGuiTreeNodeFlags.DefaultOpen))
        {
            var changed = ImGui.Checkbox("本地聊天提醒", ref options.ChatEnabled);
            changed |= ImGui.InputText("提示文字", ref options.Message, 400);
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("<name> 玩家名；<world> 服务器；<link> 玩家链接。");
            changed |= ImGui.Checkbox("播放提示音", ref options.SoundEnabled);
            changed |= ImGui.InputTextWithHint("音频文件", "留空使用内置门铃", ref options.SoundFile, 1024);
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("支持本地 WAV、MP3、AIFF 文件。");
            changed |= ImGui.SliderFloat("音量", ref options.Volume, 0, 1, "%.2f");
            if (ImGui.Button("试听")) plugin.TestSound(options);
            if (changed) plugin.SettingsChanged();
        }
        ImGui.PopID();
    }

    private void DrawTiming()
    {
        var changed = false;
        ImGui.TextUnformatted("同一访客：本场仅一次");
        ImGui.TextUnformatted("合并到访：3 秒");
        ImGui.Separator();
        if (ImGui.CollapsingHeader("进出识别"))
        {
            changed |= Slider("进屋等待（秒）", ref plugin.Config.WarmupSeconds, 3, 30);
            changed |= Slider("访客确认（秒）", ref plugin.Config.ConfirmationSeconds, 0.25f, 2);
            changed |= Slider("离开确认（秒）", ref plugin.Config.DepartureGraceSeconds, 1, 15);
        }
        if (changed) plugin.SettingsChanged();
    }

    private void DrawHistory()
    {
        if (ImGui.Button("清空运行记录")) plugin.ClearHistory();
        ImGui.Separator();
        if (ImGui.BeginChild("运行记录列表", new Vector2(0, 0), false))
        {
            foreach (var entry in plugin.History)
            {
                ImGui.PushTextWrapPos(0);
                ImGui.TextUnformatted($"{entry.Time:HH:mm:ss}  [{entry.Category}] {entry.Message}");
                ImGui.PopTextWrapPos();
            }
        }
        ImGui.EndChild();
    }

    private static bool Slider(string label, ref double value, float min, float max)
    {
        var number = (float)value;
        if (!ImGui.SliderFloat(label, ref number, min, max, max <= 2 ? "%.2f" : "%.0f")) return false;
        value = max <= 2 ? number : MathF.Round(number);
        return true;
    }

    private static void Wrapped(string text)
    {
        ImGui.PushTextWrapPos(0);
        ImGui.TextUnformatted(text);
        ImGui.PopTextWrapPos();
    }
}
