using DoorbellCN.Core;
using Xunit;

namespace DoorbellCN.Tests;

public sealed class FingerprintTests
{
    private static readonly MacroSelection Macro = new(0, 42);
    private static readonly string[] Lines = ["/echo 门铃测试", "/wait 1", "/echo 完成"];

    [Fact]
    public void UnchangedMacroKeepsFingerprint() =>
        Assert.Equal(MacroFingerprint.Compute(Macro, "测试", Lines),
            MacroFingerprint.Compute(Macro, "测试", Lines.ToArray()));

    [Theory]
    [InlineData(1, 42)]
    [InlineData(0, 41)]
    public void SetAndSlotArePartOfApproval(int set, int slot) =>
        Assert.NotEqual(MacroFingerprint.Compute(Macro, "测试", Lines),
            MacroFingerprint.Compute(new(set, slot), "测试", Lines));

    [Fact]
    public void NameChangeInvalidatesApproval() =>
        Assert.NotEqual(MacroFingerprint.Compute(Macro, "测试", Lines),
            MacroFingerprint.Compute(Macro, "改名", Lines));

    [Fact]
    public void LastLineChangeInvalidatesApproval()
    {
        var original = Enumerable.Repeat("", 15).ToArray();
        original[0] = "/echo 你好";
        var edited = original.ToArray();
        edited[14] = "/s 欢迎光临";
        Assert.NotEqual(MacroFingerprint.Compute(Macro, "测试", original),
            MacroFingerprint.Compute(Macro, "测试", edited));
    }

    [Fact]
    public void PublicChatReplacingLocalEchoInvalidatesApproval() =>
        Assert.NotEqual(MacroFingerprint.Compute(Macro, "测试", ["/echo 你好"]),
            MacroFingerprint.Compute(Macro, "测试", ["/s 你好"]));

    [Fact]
    public void LineOrderingIsNotIgnored() =>
        Assert.NotEqual(MacroFingerprint.Compute(Macro, "测试", Lines),
            MacroFingerprint.Compute(Macro, "测试", Lines.Reverse().ToArray()));
}
