using DoorbellCN.Core;
using Xunit;

namespace DoorbellCN.Tests;

public sealed class GuardTests
{
    private static readonly HouseSession House = new(100, 200, 1, 282);
    private static readonly MacroSelection Macro = new(0, 42);
    private readonly SessionGuard guard = new();

    [Fact]
    public void NeverArmsByDefault() => Assert.False(guard.IsArmed);

    [Fact]
    public void ExplicitArmBindsCharacterHouseRoomAndMacro()
    {
        Assert.True(guard.Arm(House, Macro));
        Assert.True(guard.Matches(House, Macro));
    }

    [Theory]
    [InlineData(1, 200, 1, 282)]
    [InlineData(100, 201, 1, 282)]
    [InlineData(100, 200, 2, 282)]
    [InlineData(100, 200, 1, 283)]
    public void ContextChangeFailsClosed(ulong character, ulong house, short room, uint territory)
    {
        guard.Arm(House, Macro);
        Assert.False(guard.Matches(new(character, house, room, territory), Macro));
    }

    [Theory]
    [InlineData(0, 41)]
    [InlineData(1, 42)]
    public void MacroSelectionChangeRequiresRearm(int set, int slot)
    {
        guard.Arm(House, Macro);
        Assert.False(guard.Matches(House, new(set, slot)));
    }

    [Theory]
    [InlineData(-1, 0)]
    [InlineData(2, 0)]
    [InlineData(0, -1)]
    [InlineData(0, 100)]
    public void InvalidMacroCannotArm(int set, int slot)
    {
        Assert.False(guard.Arm(House, new(set, slot)));
        Assert.False(guard.IsArmed);
    }

    [Theory]
    [InlineData(0UL)]
    [InlineData(18446744073709551615UL)]
    public void UnknownHouseCannotArm(ulong house)
    {
        Assert.False(guard.Arm(House with { HouseId = house }, Macro));
    }

    [Fact]
    public void InvalidRearmAlsoDisarmsPreviousSession()
    {
        guard.Arm(House, Macro);
        guard.Arm(default, Macro);
        Assert.False(guard.IsArmed);
    }

    [Fact]
    public void DisarmForMuteOrLogoutDoesNotResumeItself()
    {
        guard.Arm(House, Macro);
        guard.Disarm();
        Assert.False(guard.Matches(House, Macro));
        Assert.Null(guard.Selection);
    }

    [Theory]
    [InlineData(0, 0)]
    [InlineData(0, 99)]
    [InlineData(1, 0)]
    [InlineData(1, 99)]
    public void MacroSlotBoundsAreZeroBased(int set, int slot) =>
        Assert.True(new MacroSelection(set, slot).IsValid);
}
