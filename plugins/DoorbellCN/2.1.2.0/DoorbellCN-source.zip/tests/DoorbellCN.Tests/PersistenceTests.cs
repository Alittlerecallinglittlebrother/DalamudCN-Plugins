using System.Text.Json;
using System.Text.Json.Nodes;
using DoorbellCN.Core;
using Xunit;

namespace DoorbellCN.Tests;

public sealed class PersistenceTests : IDisposable
{
    private readonly string directory = Path.Combine(Path.GetTempPath(), "doorbell-tests-" + Guid.NewGuid().ToString("N"));
    private static readonly DateTimeOffset Epoch = new(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);
    private static DateTimeOffset U(double t) => Epoch.AddSeconds(t);
    private static readonly HouseSession House = new(100, 200, 1, 282);
    private static readonly Visitor Alice = new("不可明文保存的访客", 1, "测试服");
    private static readonly MacroObservation Idle = new(MacroRunState.Idle);

    private static MacroScheduler Engine()
    {
        var engine = new MacroScheduler();
        engine.Activate(House, 0, U(0));
        return engine;
    }

    [Fact]
    public void GuestsAndAttemptCountSurviveActualFileReload()
    {
        using (var store = new LedgerFileStore(directory))
        {
            var engine = Engine();
            engine.RecordArrival(0, U(0), Alice, true, Idle);
            engine.TryReserve(3, U(3), Idle, _ => true);
            engine.FinishReservation(U(4));
            store.Save(engine.Ledger);
        }
        using var reopened = new LedgerFileStore(directory);
        var restored = new MacroScheduler(reopened.Load());
        restored.Activate(House, 0, U(10));
        Assert.Equal(ArrivalResult.Duplicate, restored.RecordArrival(1, U(11), Alice, true, Idle));
        Assert.Equal(1, restored.Attempts);
        Assert.Equal(0, restored.PendingCount);
        Assert.Equal(ArrivalResult.NewBatch, restored.RecordArrival(2, U(12), Alice with { Name = "新访客" }, true, Idle));
    }

    [Fact]
    public void CrashAfterReservationDoesNotReplayButAllowsNewWorkOnceIdle()
    {
        using var store = new LedgerFileStore(directory);
        var engine = Engine();
        Assert.True(engine.TryReserve(0, U(0), Idle, _ => true, manual: true));
        store.Save(engine.Ledger);
        var restored = new MacroScheduler(store.Load());
        restored.Activate(House, 0, U(100));
        Assert.True(restored.IsExecuting);
        Assert.False(restored.TryReserve(0, U(100), Idle, _ => true, manual: true));
        Assert.Equal(ExecutionUpdate.Watching, restored.ObserveExecution(0, U(100), Idle));
        Assert.Equal(ExecutionUpdate.Finished, restored.ObserveExecution(1, U(101), Idle));
        Assert.Equal(0, restored.PendingCount);
        Assert.True(restored.TryReserve(1, U(101), Idle, _ => true, manual: true));
    }

    [Fact]
    public void ReloadDuringRunningMacroKeepsWaitingForActualIdle()
    {
        var old = Engine();
        old.TryReserve(0, U(0), Idle, _ => true, manual: true);
        var data = JsonSerializer.Deserialize<WelcomeLedger>(JsonSerializer.Serialize(old.Ledger))!;
        var restored = new MacroScheduler(data);
        restored.Activate(House, 0, U(50));
        Assert.Equal(ExecutionUpdate.Watching, restored.ObserveExecution(0, U(50), new(MacroRunState.Running)));
        Assert.Equal(ExecutionUpdate.Watching, restored.ObserveExecution(40, U(90), Idle));
        Assert.Equal(ExecutionUpdate.Finished, restored.ObserveExecution(41, U(91), Idle));
        Assert.True(restored.TryReserve(41, U(91), Idle, _ => true, manual: true));
    }

    [Fact]
    public void FileContainsNoPlainVisitorNamesAndStablePrivateTokens()
    {
        using var store = new LedgerFileStore(directory);
        var engine = Engine();
        engine.RecordArrival(0, U(0), Alice, false, Idle);
        store.Save(engine.Ledger);
        var json = File.ReadAllText(Path.Combine(directory, "welcome-ledger-v1.json"));
        Assert.DoesNotContain(Alice.Name, json);
        Assert.DoesNotContain("HouseId", json);
        Assert.DoesNotContain("CharacterId", json);
        var loaded = store.Load();
        Assert.Equal(engine.Ledger.VisitorKey(Alice), loaded.VisitorKey(Alice));
    }

    [Fact]
    public void CorruptFileFailsClosedWithoutOverwritingIt()
    {
        using var store = new LedgerFileStore(directory);
        var path = Path.Combine(directory, "welcome-ledger-v1.json");
        File.WriteAllText(path, "{broken");
        Assert.Throws<JsonException>(() => store.Load());
        Assert.Equal("{broken", File.ReadAllText(path));
    }

    [Theory]
    [InlineData("{}")]
    [InlineData("{\"Version\":1}")]
    public void MissingLedgerFieldsCannotSilentlyResetHistory(string data)
    {
        using var store = new LedgerFileStore(directory);
        File.WriteAllText(Path.Combine(directory, "welcome-ledger-v1.json"), data);
        Assert.Throws<JsonException>(() => store.Load());
    }

    [Fact]
    public void TwoInstancesCannotWriteSameLedgerConcurrently()
    {
        using var first = new LedgerFileStore(directory);
        Assert.Throws<IOException>(() => new LedgerFileStore(directory));
    }

    [Fact]
    public void WriterLockIsReleasedOnDispose()
    {
        using (var first = new LedgerFileStore(directory)) first.Save(Engine().Ledger);
        using var second = new LedgerFileStore(directory);
        Assert.NotNull(second.Load());
    }

    [Fact]
    public void SaveIsAtomicAndRetainsPreviousFileAsBackup()
    {
        using var store = new LedgerFileStore(directory);
        var engine = Engine();
        store.Save(engine.Ledger);
        engine.RecordArrival(1, U(1), Alice, false, Idle);
        store.Save(engine.Ledger);
        Assert.Single(store.Load().Scenes.Values.Single().SeenVisitors);
        var previous = JsonSerializer.Deserialize<WelcomeLedger>(
            File.ReadAllText(Path.Combine(directory, "welcome-ledger-v1.json.bak")))!;
        Assert.Empty(previous.Scenes.Values.Single().SeenVisitors);
        Assert.Empty(Directory.GetFiles(directory, "*.tmp"));
    }

    [Fact]
    public void MissingPrimaryWithBackupCannotResetLedger()
    {
        using var store = new LedgerFileStore(directory);
        File.WriteAllText(Path.Combine(directory, "welcome-ledger-v1.json.bak"), "{}");
        Assert.Throws<InvalidDataException>(() => store.Load());
        Assert.False(File.Exists(Path.Combine(directory, "welcome-ledger-v1.json")));
    }

    [Fact]
    public void UnsupportedStateVersionDoesNotSave()
    {
        using var store = new LedgerFileStore(directory);
        var state = Engine().Ledger;
        state.Version = 99;
        Assert.Throws<InvalidDataException>(() => store.Save(state));
        Assert.False(File.Exists(Path.Combine(directory, "welcome-ledger-v1.json")));
    }

    [Theory]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    public void MissingExecutionStateStillFailsClosed(int version)
    {
        using var store = new LedgerFileStore(directory);
        var data = JsonNode.Parse(JsonSerializer.Serialize(Engine().Ledger))!.AsObject();
        data["Version"] = version;
        data["Characters"]!.AsObject().Single().Value!.AsObject().Remove("InFlight");
        File.WriteAllText(Path.Combine(directory, "welcome-ledger-v1.json"), data.ToJsonString());
        Assert.Throws<JsonException>(() => store.Load());
    }

    [Fact]
    public void NewRoundAndPresentVisitorsSurviveReload()
    {
        using var store = new LedgerFileStore(directory);
        var engine = Engine();
        engine.TryReserve(0, U(0), Idle, _ => true, manual: true);
        engine.FinishReservation(U(1));
        engine.BeginNewRound(U(10), [Alice]);
        store.Save(engine.Ledger);
        var restored = new MacroScheduler(store.Load());
        restored.Activate(House, 0, U(20));
        Assert.Equal(2, restored.Round);
        Assert.Equal(0, restored.Attempts);
        Assert.Equal(ArrivalResult.Duplicate, restored.RecordArrival(0, U(20), Alice, true, Idle));
        Assert.True(restored.TryReserve(1, U(21), Idle, _ => true, manual: true));
    }

    [Fact]
    public void BackwardsClockAfterRestartIsRejected()
    {
        var engine = Engine();
        engine.RecordArrival(10, U(10), Alice, true, Idle);
        var restored = new MacroScheduler(engine.Ledger);
        Assert.Throws<InvalidOperationException>(() => restored.Activate(House, 0, U(9)));
    }

    [Theory]
    [InlineData(1)]
    [InlineData(2)]
    public void LegacyThrottlingIsDiscardedWithoutErasingVisitorsOrAttemptCount(int version)
    {
        using var store = new LedgerFileStore(directory);
        var old = Engine();
        old.RecordArrival(0, U(0), Alice, true, Idle);
        old.TryReserve(3, U(3), Idle, _ => true);
        old.FinishReservation(U(4));
        WriteLegacyFile(old.Ledger, version);
        var restored = new MacroScheduler(store.Load());
        Assert.True(restored.Dirty);
        restored.Activate(House, 10, U(10));
        Assert.Equal(3, restored.Ledger.Version);
        Assert.Equal(old.Ledger.VisitorKey(Alice), restored.Ledger.VisitorKey(Alice));
        Assert.Equal(ArrivalResult.Duplicate, restored.RecordArrival(10, U(10), Alice, true, Idle));
        Assert.Equal(1, restored.Attempts);
        Assert.Equal(ArrivalResult.NewBatch, restored.RecordArrival(11, U(11), Alice with { Name = "新访客" }, true, Idle));
        Assert.True(restored.TryReserve(14, U(14), Idle, _ => true));
        store.Save(restored.Ledger);
        var migratedJson = File.ReadAllText(Path.Combine(directory, "welcome-ledger-v1.json"));
        Assert.DoesNotContain("Cooldown", migratedJson);
        Assert.DoesNotContain("StartsUtc", migratedJson);
    }

    [Theory]
    [InlineData(1)]
    [InlineData(2)]
    public void LegacyInflightStillWaitsForIdleButNotItsStoredThrottle(int version)
    {
        using var store = new LedgerFileStore(directory);
        var old = Engine();
        old.TryReserve(0, U(0), Idle, _ => true, manual: true);
        WriteLegacyFile(old.Ledger, version);
        var restored = new MacroScheduler(store.Load());
        restored.Activate(House, 0, U(10));
        Assert.Equal(ExecutionUpdate.Watching, restored.ObserveExecution(0, U(10), new(MacroRunState.Running)));
        Assert.False(restored.TryReserve(0, U(10), Idle, _ => true, manual: true));
        Assert.Equal(ExecutionUpdate.Watching, restored.ObserveExecution(1, U(11), Idle));
        Assert.Equal(ExecutionUpdate.Finished, restored.ObserveExecution(2, U(12), Idle));
        Assert.True(restored.TryReserve(2, U(12), Idle, _ => true, manual: true));
    }

    [Theory]
    [InlineData(1)]
    [InlineData(2)]
    public void LegacyFullQuotaDoesNotBlockTheNextVisitorAfterUpgrade(int version)
    {
        using var store = new LedgerFileStore(directory);
        var old = Engine();
        foreach (var time in new[] { 0, 2, 4 })
        {
            Assert.True(old.TryReserve(time, U(time), Idle, _ => true, manual: true));
            old.FinishReservation(U(time + 1));
        }
        old.RecordArrival(6, U(6), Alice, false, Idle);
        WriteLegacyFile(old.Ledger, version);
        var restored = new MacroScheduler(store.Load());
        restored.Activate(House, 0, U(10));
        Assert.Equal(3, restored.Attempts);
        Assert.Equal(ArrivalResult.Duplicate, restored.RecordArrival(0, U(10), Alice, true, Idle));
        Assert.Equal(ArrivalResult.NewBatch, restored.RecordArrival(1, U(11), Alice with { Name = "第四位新客" }, true, Idle));
        Assert.True(restored.TryReserve(4, U(14), Idle, _ => true));
        Assert.Equal(4, restored.Attempts);
    }

    [Fact]
    public void ManyStartsCanBeSavedAndReloadedWithoutRestoringAnyQuota()
    {
        using var store = new LedgerFileStore(directory);
        var engine = Engine();
        for (var i = 0; i < 25; i++)
        {
            Assert.True(engine.TryReserve(i * 2, U(i * 2), Idle, _ => true, manual: true));
            engine.FinishReservation(U(i * 2 + 1));
        }
        store.Save(engine.Ledger);
        var restored = new MacroScheduler(store.Load());
        restored.Activate(House, 0, U(50));
        Assert.Equal(25, restored.Attempts);
        Assert.True(restored.TryReserve(0, U(50), Idle, _ => true, manual: true));
        Assert.Equal(26, restored.Attempts);
    }

    private void WriteLegacyFile(WelcomeLedger ledger, int version)
    {
        var data = JsonNode.Parse(JsonSerializer.Serialize(ledger))!.AsObject();
        data["Version"] = version;
        foreach (var (_, node) in data["Characters"]!.AsObject())
        {
            node!["CooldownUntilUtc"] = U(600).ToString("O");
            node["InFlightCooldownSeconds"] = 600;
            node["StartsUtc"] = JsonSerializer.SerializeToNode(new[]
            {
                ledger.LastSavedUtc.AddSeconds(-4), ledger.LastSavedUtc.AddSeconds(-2), ledger.LastSavedUtc,
            });
        }
        File.WriteAllText(Path.Combine(directory, "welcome-ledger-v1.json"), data.ToJsonString());
    }

    public void Dispose()
    {
        if (Directory.Exists(directory)) Directory.Delete(directory, recursive: true);
    }
}
