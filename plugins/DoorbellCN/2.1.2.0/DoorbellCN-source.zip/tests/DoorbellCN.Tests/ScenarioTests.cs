using DoorbellCN.Core;
using Xunit;

namespace DoorbellCN.Tests;

public sealed class ScenarioTests
{
    private static readonly DateTimeOffset Epoch = new(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);

    private static List<double> Simulate(double duration, double macroDuration,
        Func<double, IReadOnlyList<Visitor>> guests, Func<double, bool>? armed = null)
    {
        var tracker = new VisitorTracker();
        var scheduler = new MacroScheduler();
        var calls = new List<double>();
        var busyUntil = double.NegativeInfinity;
        tracker.Reset(0);
        scheduler.Activate(new(100, 200, 0, 282), 0, Epoch);
        for (var t = 0.0; t <= duration; t += 0.25)
        {
            var utc = Epoch.AddSeconds(t);
            var observation = new MacroObservation(t < busyUntil ? MacroRunState.Running : MacroRunState.Idle);
            scheduler.ObserveExecution(t, utc, observation);
            foreach (var visit in tracker.Observe(t, guests(t), new()))
                if (visit.Kind != VisitKind.Left)
                    scheduler.RecordArrival(t, utc, visit.Visitor,
                        visit.Kind == VisitKind.Entered && t >= 5 && (armed?.Invoke(t) ?? true), observation);
            if (!(armed?.Invoke(t) ?? true)) scheduler.CancelBatch();
            if (scheduler.Poll(t, utc, observation, tracker.IsVisible).State == BatchState.Ready)
                MacroDispatcher.Submit(scheduler, t, utc, observation, tracker.IsVisible,
                    () => { scheduler.Ledger.Validate(); scheduler.MarkSaved(); },
                    () => { calls.Add(t); busyUntil = t + macroDuration; return "submitted"; });
        }
        return calls;
    }

    [Fact]
    public void FiveRepeatedVisitorsOverTwentyMinutesTriggerOnlyOneMacro()
    {
        var guests = Enumerable.Range(1, 5).Select(i => new Visitor("访客" + i, 1, "测试服")).ToArray();
        var calls = Simulate(1200, 2, t => t >= 6 && (int)((t - 6) / 5) % 2 == 0 ? guests : []);
        Assert.Single(calls);
    }

    [Fact]
    public void ConstantNewTrafficHasNoRollingCapOrPostMacroCooldown()
    {
        var calls = Simulate(1200, 2, t => t < 6 ? [] :
            [new Visitor("访客" + (int)((t - 6) / 4), 1, "测试服")]);
        Assert.True(calls.Count > 100);
        Assert.True(calls.Count(t => t < 300) > 20);
        var gaps = calls.Zip(calls.Skip(1), (a, b) => b - a).ToArray();
        Assert.All(gaps, gap => Assert.InRange(gap, 6, 10));
    }

    [Fact]
    public void NinetySecondMacrosDoNotOverlapButNeedNoExtraSixtySeconds()
    {
        var calls = Simulate(800, 90, t => t < 6 ? [] :
            [new Visitor("访客" + (int)((t - 6) / 4), 1, "测试服")]);
        Assert.True(calls.Count(t => t < 300) > 3);
        var gaps = calls.Zip(calls.Skip(1), (a, b) => b - a).ToArray();
        Assert.All(gaps, gap => Assert.InRange(gap, 94, 100));
    }

    [Fact]
    public void GuestsAlreadyPresentAtStartupNeverGreet()
    {
        var calls = Simulate(100, 2, _ => [new("已有访客", 1, "测试服")]);
        Assert.Empty(calls);
    }

    [Fact]
    public void GuestsSeenWhilePausedDoNotGreetAfterResume()
    {
        var guests = new[] { new Visitor("暂停时进入", 1, "测试服") };
        var calls = Simulate(300, 2, t => t >= 6 && (int)((t - 6) / 5) % 2 == 0 ? guests : [], t => t >= 60);
        Assert.Empty(calls);
    }

    [Fact]
    public void BrieflyVisibleObjectsDoNotCauseMacros()
    {
        var calls = Simulate(100, 2, t => t >= 6 && t % 2 == 0 ? [new("瞬时对象", 1, "测试服")] : []);
        Assert.Empty(calls);
    }
}
