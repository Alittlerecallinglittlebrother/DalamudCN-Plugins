using DoorbellCN.Core;
using Xunit;

namespace DoorbellCN.Tests;

public sealed class TrackerTests
{
    private static readonly Visitor Alice = new("访客甲", 1, "测试服");
    private static readonly DetectionPolicy Policy = new(5, 0.5, 3);
    private readonly VisitorTracker tracker = new();

    public TrackerTests() => tracker.Reset(0);

    [Fact]
    public void ExistingGuestNeverBecomesAnArrival()
    {
        Assert.Empty(tracker.Observe(0, [Alice], Policy));
        var visit = Assert.Single(tracker.Observe(0.5, [Alice], Policy));
        Assert.Equal(VisitKind.AlreadyHere, visit.Kind);
        Assert.Empty(tracker.Observe(6, [Alice], Policy));
    }

    [Fact]
    public void NewGuestRequiresConfirmation()
    {
        Assert.Empty(tracker.Observe(6, [Alice], Policy));
        Assert.Empty(tracker.Observe(6.25, [Alice], Policy));
        var visit = Assert.Single(tracker.Observe(6.5, [Alice], Policy));
        Assert.Equal(VisitKind.Entered, visit.Kind);
    }

    [Fact]
    public void SeenDuringWarmupButConfirmedAfterWarmupIsStillExisting()
    {
        tracker.Observe(4.75, [Alice], Policy);
        Assert.Equal(VisitKind.AlreadyHere, Assert.Single(tracker.Observe(5.25, [Alice], Policy)).Kind);
    }

    [Fact]
    public void BriefObjectDoesNotProduceEntryOrDeparture()
    {
        tracker.Observe(6, [Alice], Policy);
        Assert.Empty(tracker.Observe(6.25, [], Policy));
        Assert.Empty(tracker.Observe(9, [], Policy));
        Assert.Equal(0, tracker.Count);
    }

    [Fact]
    public void ShortVisibilityGapDoesNotGenerateDuplicateEntry()
    {
        tracker.Observe(6, [Alice], Policy);
        tracker.Observe(6.5, [Alice], Policy);
        Assert.Empty(tracker.Observe(7, [], Policy));
        Assert.Empty(tracker.Observe(8, [Alice], Policy));
    }

    [Fact]
    public void DepartureUsesTimeNotFrameCount()
    {
        tracker.Observe(6, [Alice], Policy);
        tracker.Observe(6.5, [Alice], Policy);
        for (var i = 0; i < 100; i++) Assert.Empty(tracker.Observe(7, [], Policy));
        Assert.Empty(tracker.Observe(9.49, [], Policy));
        Assert.Equal(VisitKind.Left, Assert.Single(tracker.Observe(9.5, [], Policy)).Kind);
    }

    [Fact]
    public void AllDeparturesProcessedWithoutMutatingEnumeration()
    {
        var bob = new Visitor("访客乙", 1, "测试服");
        tracker.Observe(6, [Alice, bob], Policy);
        tracker.Observe(6.5, [Alice, bob], Policy);
        Assert.Equal(2, tracker.Observe(10, [], Policy).Count);
        Assert.Equal(0, tracker.Count);
    }

    [Fact]
    public void SameNameOnDifferentWorldsRemainsDistinct()
    {
        var other = Alice with { HomeWorld = 2, WorldName = "另一服" };
        tracker.Observe(6, [Alice, other], Policy);
        Assert.Equal(2, tracker.Observe(6.5, [Alice, other], Policy).Count);
    }

    [Fact]
    public void DuplicateObjectEntriesAreDeduplicated()
    {
        tracker.Observe(6, [Alice, Alice], Policy);
        Assert.Single(tracker.Observe(6.5, [Alice, Alice], Policy));
    }

    [Fact]
    public void ResetStartsANewBaseline()
    {
        tracker.Observe(6, [Alice], Policy);
        tracker.Observe(6.5, [Alice], Policy);
        tracker.Reset(10);
        Assert.False(tracker.IsVisible(Alice.Key));
        tracker.Observe(10, [Alice], Policy);
        Assert.Equal(VisitKind.AlreadyHere, Assert.Single(tracker.Observe(10.5, [Alice], Policy)).Kind);
    }

    [Fact]
    public void GracePeriodDoesNotPretendAbsentGuestIsCurrentlyVisible()
    {
        tracker.Observe(6, [Alice], Policy);
        tracker.Observe(6.5, [Alice], Policy);
        tracker.Observe(7, [], Policy);
        Assert.Equal(1, tracker.Count);
        Assert.False(tracker.IsVisible(Alice.Key));
    }

    [Fact]
    public void InterruptedCandidateMustRestartContinuousConfirmation()
    {
        tracker.Observe(6, [Alice], Policy);
        tracker.Observe(6.25, [], Policy);
        Assert.Empty(tracker.Observe(6.5, [Alice], Policy));
        Assert.Empty(tracker.Observe(6.75, [Alice], Policy));
        Assert.Equal(VisitKind.Entered, Assert.Single(tracker.Observe(7, [Alice], Policy)).Kind);
    }

    [Fact]
    public void LongFrameStallCannotConfirmOneOldSample()
    {
        tracker.Observe(6, [Alice], Policy);
        Assert.Empty(tracker.Observe(20, [Alice], Policy));
        Assert.Equal(VisitKind.Entered, Assert.Single(tracker.Observe(20.5, [Alice], Policy)).Kind);
    }

    [Fact]
    public void ReentryAfterConfirmedDepartureIsNewArrival()
    {
        tracker.Observe(6, [Alice], Policy);
        tracker.Observe(6.5, [Alice], Policy);
        tracker.Observe(10, [], Policy);
        tracker.Observe(12, [Alice], Policy);
        Assert.Equal(VisitKind.Entered, Assert.Single(tracker.Observe(12.5, [Alice], Policy)).Kind);
    }
}
