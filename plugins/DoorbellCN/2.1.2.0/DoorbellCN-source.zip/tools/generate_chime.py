"""Generate an original, quiet two-note PCM chime; no upstream audio is copied."""
import math
import pathlib
import struct
import wave

output = pathlib.Path(__file__).resolve().parents[1] / "src/DoorbellCN/Assets/doorbell.wav"
output.parent.mkdir(parents=True, exist_ok=True)
rate = 44100
duration = 1.4
frames = bytearray()
for i in range(int(rate * duration)):
    t = i / rate
    value = 0.0
    for start, frequency in ((0.0, 659.255), (0.36, 523.251)):
        local = t - start
        if local >= 0:
            attack = min(1.0, local / 0.008)
            envelope = attack * math.exp(-local * 5.0)
            value += 0.24 * envelope * (
                math.sin(2 * math.pi * frequency * local)
                + 0.16 * math.sin(2 * math.pi * frequency * 2 * local)
            )
    fade = min(1.0, max(0.0, duration - t) / 0.05)
    frames.extend(struct.pack("<h", int(max(-1.0, min(1.0, value * fade)) * 32767)))
with wave.open(str(output), "wb") as wav:
    wav.setparams((1, 2, rate, 0, "NONE", "not compressed"))
    wav.writeframes(frames)
print(output)
