#requires -Version 7.0
[CmdletBinding()]
param(
    [string]$DalamudHome = (Join-Path $env:APPDATA 'XIVLauncherCN\addon\Hooks\dev'),
    [string]$BuildDirectory = (Join-Path $PSScriptRoot '..\src\DoorbellCN\bin\x64\Release')
)
$ErrorActionPreference = 'Stop'
$BuildDirectory = [IO.Path]::GetFullPath($BuildDirectory)
$DalamudHome = [IO.Path]::GetFullPath($DalamudHome)
$checks = [Collections.Generic.List[string]]::new()
function Assert-Check([bool]$Condition, [string]$Description) {
    if (!$Condition) { throw "验证失败：$Description" }
    $checks.Add($Description)
}
$required = @('DoorbellCN.dll','DoorbellCN.Core.dll','DoorbellCN.json','DoorbellCN.deps.json',
    'doorbell.wav','NAudio.Core.dll','NAudio.WinMM.dll','NAudio.Wasapi.dll')
foreach ($file in $required) {
    Assert-Check (Test-Path (Join-Path $BuildDirectory $file) -PathType Leaf) "文件存在：$file"
}
$manifest = [IO.File]::ReadAllText((Join-Path $BuildDirectory 'DoorbellCN.json')) | ConvertFrom-Json
Assert-Check ($manifest.InternalName -eq 'DoorbellCN') '插件标识独立于原版'
Assert-Check ($manifest.DalamudApiLevel -eq 15) '清单声明 Dalamud API 15'
Assert-Check ($manifest.Name -eq '门铃迎宾') '清单为中文名称'
Assert-Check ($manifest.Author -ceq 'Aida Enna、断水剑') '作者顺序：原作者 Aida Enna、断水剑'
Assert-Check ($manifest.Description -is [string] -and $manifest.Description -ceq '6') '插件简介精确为 6'
Assert-Check ($manifest.Punchline -is [string] -and $manifest.Punchline -ceq '6') '插件列表短简介精确为 6'
$version = [Reflection.AssemblyName]::GetAssemblyName((Join-Path $BuildDirectory 'DoorbellCN.dll')).Version
Assert-Check ($version.ToString() -eq $manifest.AssemblyVersion) '清单版本与程序集一致'
Assert-Check (!(Test-Path (Join-Path $BuildDirectory 'Dalamud.dll'))) '不捆绑或替换宿主 Dalamud'
Assert-Check (!(Test-Path (Join-Path $BuildDirectory 'FFXIVClientStructs.dll'))) '不捆绑或替换游戏结构库'

# Pure configuration and metadata only: never instantiate the plugin or call game entry points.
foreach ($file in @('Newtonsoft.Json.dll','Dalamud.dll','InteropGenerator.Runtime.dll',
        'FFXIVClientStructs.dll','Dalamud.Bindings.ImGui.dll','Lumina.dll','Lumina.Excel.dll')) {
    [Reflection.Assembly]::LoadFrom((Join-Path $DalamudHome $file)) | Out-Null
}
$coreAssembly = [Reflection.Assembly]::LoadFrom((Join-Path $BuildDirectory 'DoorbellCN.Core.dll'))
$assembly = [Reflection.Assembly]::LoadFrom((Join-Path $BuildDirectory 'DoorbellCN.dll'))
$configType = $assembly.GetType('DoorbellCN.Configuration', $true)
$config = [Activator]::CreateInstance($configType)
Assert-Check ($config.Enabled -and $config.Entered.ChatEnabled -and $config.Entered.SoundEnabled) '默认开启入场提醒'
Assert-Check (!$config.Left.ChatEnabled -and !$config.Left.SoundEnabled) '默认关闭离场提醒'
Assert-Check (!$config.AlreadyHere.ChatEnabled -and !$config.AlreadyHere.SoundEnabled) '默认关闭已有访客提醒'
Assert-Check ($configType.GetField('IsArmed') -eq $null -and $configType.GetProperty('IsArmed') -eq $null) '配置不保存自动迎宾开启状态'
Assert-Check ($configType.GetField('GlobalCooldownSeconds') -eq $null) '宏结束间隔配置字段已彻底移除'
$policyType = $coreAssembly.GetType('DoorbellCN.Core.MacroPolicy', $true)
$schedulerType = $coreAssembly.GetType('DoorbellCN.Core.MacroScheduler', $true)
$characterType = $coreAssembly.GetType('DoorbellCN.Core.CharacterLedger', $true)
Assert-Check ($policyType.GetField('MaxStarts') -eq $null -and $policyType.GetField('WindowSeconds') -eq $null) '五分钟次数上限及窗口常量已移除'
Assert-Check ($schedulerType.GetMethod('RateRemaining') -eq $null -and $schedulerType.GetMethod('RecentStarts') -eq $null) '次数限流与倒计时接口已移除'
Assert-Check ($characterType.GetProperty('StartsUtc') -eq $null) '旧启动时间列表不再写入迎宾记录'

$config.WarmupSeconds = [double]::PositiveInfinity
$config.MacroSet = 7
$config.MacroSlot = 999
$config.Entered.Volume = [float]::NaN
$config.Left = $null
$config.Normalize()
Assert-Check ($config.WarmupSeconds -eq 5) '无穷缓冲时间回退到默认值'
Assert-Check ($config.Version -eq 3) '配置版本更新为 3'
Assert-Check ($config.MacroSet -eq 0 -and $config.MacroSlot -eq 0) '无效宏选择安全回退且不自动启用'
Assert-Check ([float]::IsFinite($config.Entered.Volume)) '异常音量恢复到有限值'
Assert-Check ($null -ne $config.Left) '空提醒配置被修复'

$json = [Newtonsoft.Json.JsonConvert]::SerializeObject($config)
$data = $json | ConvertFrom-Json
$keys = @($data.PSObject.Properties.Name)
Assert-Check ($keys -notcontains 'Selection' -and $keys -notcontains 'Detection' -and $keys -notcontains 'MacroPolicy') '派生配置不重复序列化'
$roundTrip = [Newtonsoft.Json.JsonConvert]::DeserializeObject($json, $configType)
Assert-Check ($roundTrip.Entered.Message -eq '<link> 进入了住宅。') '中文配置往返序列化正常'
Assert-Check ($roundTrip.Version -eq 3) '设置往返序列化正常'
foreach ($oldVersion in @(1,2)) {
    $oldJson = '{"Version":' + $oldVersion + ',"MacroSet":1,"MacroSlot":42,"GlobalCooldownSeconds":600,"TriggerDelaySeconds":1,"VisitorCooldownSeconds":120,"QueueExpirySeconds":20}'
    $legacy = [Newtonsoft.Json.JsonConvert]::DeserializeObject($oldJson, $configType)
    $legacy.Normalize()
    Assert-Check ($legacy.Version -eq 3 -and $legacy.MacroSet -eq 1 -and $legacy.MacroSlot -eq 42) "旧配置版本 $oldVersion 升级且保留宏选择"
    $legacyJson = [Newtonsoft.Json.JsonConvert]::SerializeObject($legacy) | ConvertFrom-Json
    $legacyKeys = @($legacyJson.PSObject.Properties.Name)
    Assert-Check ($legacyKeys -notcontains 'GlobalCooldownSeconds' -and $legacyKeys -notcontains 'VisitorCooldownSeconds' -and $legacyKeys -notcontains 'QueueExpirySeconds') "旧配置版本 $oldVersion 的冷却及旧队列字段不再写回"
}

[Reflection.Assembly]::LoadFrom((Join-Path $BuildDirectory 'NAudio.Core.dll')) | Out-Null
$reader = [NAudio.Wave.WaveFileReader]::new((Join-Path $BuildDirectory 'doorbell.wav'))
try {
    Assert-Check ($reader.WaveFormat.SampleRate -eq 44100 -and $reader.WaveFormat.Channels -eq 1) '内置提示音为 44.1 kHz 单声道'
    Assert-Check ($reader.WaveFormat.BitsPerSample -eq 16) '内置提示音为 16 位 PCM'
    Assert-Check ([Math]::Abs($reader.TotalTime.TotalSeconds - 1.4) -lt 0.01) '内置提示音可解码且长 1.4 秒'
} finally { $reader.Dispose() }

[pscustomobject]@{
    Result = 'Passed'
    Checks = $checks.Count
    Items = @($checks)
    Note = '仅离线配置与资源验证；未创建游戏插件实例，未播放声音，未执行游戏宏。'
} | ConvertTo-Json -Depth 4
