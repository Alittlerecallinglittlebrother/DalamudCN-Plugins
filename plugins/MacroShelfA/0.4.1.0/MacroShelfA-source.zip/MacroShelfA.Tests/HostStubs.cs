using Dalamud.Plugin.Services;

// Host boundary only: all scheduling, CRUD, migration, exchange and UI code is production source.
namespace MacroShelfA
{
    internal static class Plugin
    {
        public static FakeConfigStore PluginInterface { get; } = new();
        public static FakeFramework Framework { get; } = new();
        public static FakeClientState ClientState { get; } = new();
        public static FakeCommands CommandManager { get; } = new();
        public static FakeChat ChatGui { get; } = new();
        public static FakeLog Log { get; } = new();
    }
    internal sealed class FakeConfigStore
    {
        public string Json = "";
        public void SavePluginConfig(object value) => Json = Newtonsoft.Json.JsonConvert.SerializeObject(value);
    }
    internal sealed class FakeFramework
    {
        public event Action<IFramework>? Update;
        public void Tick() => Update?.Invoke(null!);
        public int Subscribers => Update?.GetInvocationList().Length ?? 0;
    }
    internal sealed class FakeClientState { public bool IsLoggedIn { get; set; } = true; }
    internal sealed class FakeCommands
    {
        public readonly List<string> Sent = [];
        public bool ProcessCommand(string command) { Sent.Add(command); return true; }
    }
    internal sealed class FakeChat
    {
        public readonly List<string> Errors = [];
        public void PrintError(string text) => Errors.Add(text);
        public void Print(string text) { }
    }
    internal sealed class FakeLog { public void Error(Exception error, string message) { } }
}
namespace MacroShelfA.Runtime
{
    internal sealed class BetterWaitPatch
    {
        public string StatusText => "测试宿主 · 未应用内存补丁";
        public void SetEnabled(bool enabled) { }
    }
    internal static class NativeCommandSender
    {
        public static void Send(string command) => throw new InvalidOperationException("Native game calls disabled in test host");
    }
}
namespace Dalamud.Interface.Utility
{
    internal static class ImGuiHelpers { public static float GlobalScale { get; set; } = 1; }
}
