using System.IO;
using System.Text.Json;

namespace MacroShelfA;

internal static class ConfigurationBackup
{
    // A one-time pre-migration snapshot; never replace an earlier backup.
    public static void BeforeGroupMigration(Configuration configuration, string directory)
    {
        if (configuration.Version >= 4) return;
        SaveOnce(configuration, directory, "config-before-groups-v4.json");
    }

    public static void BeforeLongMacroMigration(Configuration configuration, string directory)
    {
        if (configuration.Version >= 5) return;
        SaveOnce(configuration, directory, "config-before-long-macros-v5.json");
    }

    private static void SaveOnce(Configuration configuration, string directory, string filename)
    {
        Directory.CreateDirectory(directory);
        var path = Path.Combine(directory, filename);
        if (File.Exists(path)) return;
        using var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None);
        JsonSerializer.Serialize(stream, configuration, new JsonSerializerOptions { WriteIndented = true });
    }
}
