using System;
using Dalamud.Game.Command;
using Dalamud.Interface.Textures;
using Dalamud.Interface.Windowing;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

namespace MacroShelfA;

public sealed class Plugin : IDalamudPlugin
{
    private const string CommandName = "/aklmacro";

    [PluginService]
    internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;

    [PluginService]
    internal static ICommandManager CommandManager { get; private set; } = null!;

    [PluginService]
    internal static IFramework Framework { get; private set; } = null!;

    [PluginService]
    internal static IClientState ClientState { get; private set; } = null!;

    [PluginService]
    internal static ISigScanner SigScanner { get; private set; } = null!;

    [PluginService]
    internal static IChatGui ChatGui { get; private set; } = null!;

    [PluginService]
    internal static IPluginLog Log { get; private set; } = null!;

    [PluginService]
    internal static ITextureProvider TextureProvider { get; private set; } = null!;

    private readonly WindowSystem windowSystem = new("MacroShelfA");
    private readonly MacroExecutor macroExecutor;
    private readonly BetterWaitPatch betterWaitPatch;
    private readonly MainWindow mainWindow;
    private readonly FloatingLauncherWindow floatingLauncherWindow;

    internal Configuration Configuration { get; }

    public Plugin()
    {
        Configuration = PluginInterface.GetPluginConfig() as Configuration ?? Configuration.CreateDefault();
        try
        {
            ConfigurationBackup.BeforeGroupMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
            ConfigurationBackup.BeforeLongMacroMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
        }
        catch (Exception exception)
        {
            Log.Error(exception, "无法备份升级前配置；请通过导出配置保留副本。");
            ChatGui.PrintError("[Macro Shelf-A] 升级前配置备份失败，请先导出配置保留副本。");
        }
        Configuration.Normalize();

        macroExecutor = new MacroExecutor(Configuration);
        betterWaitPatch = new BetterWaitPatch(SigScanner, Log);
        betterWaitPatch.SetEnabled(Configuration.BetterWaitEnabled);
        mainWindow = new MainWindow(Configuration, macroExecutor, betterWaitPatch);
        floatingLauncherWindow = new FloatingLauncherWindow(Configuration, mainWindow);
        windowSystem.AddWindow(mainWindow);
        windowSystem.AddWindow(floatingLauncherWindow);

        CommandManager.AddHandler(CommandName, new CommandInfo(OnCommand)
        {
            HelpMessage = "打开或关闭 Macro Shelf-A 宏命令窗口。",
        });

        PluginInterface.UiBuilder.Draw += windowSystem.Draw;
        PluginInterface.UiBuilder.OpenMainUi += OpenMainUi;
        PluginInterface.UiBuilder.OpenConfigUi += OpenMainUi;
        Log.Information("Macro Shelf-A 已加载。使用 {Command} 打开窗口。", CommandName);
    }

    public void Dispose()
    {
        PluginInterface.UiBuilder.Draw -= windowSystem.Draw;
        PluginInterface.UiBuilder.OpenMainUi -= OpenMainUi;
        PluginInterface.UiBuilder.OpenConfigUi -= OpenMainUi;
        CommandManager.RemoveHandler(CommandName);

        Configuration.Save();
        windowSystem.RemoveAllWindows();
        mainWindow.Dispose();
        macroExecutor.Dispose();
        betterWaitPatch.Dispose();
    }

    private void OnCommand(string command, string arguments)
    {
        mainWindow.Toggle();
    }

    private void OpenMainUi()
    {
        mainWindow.IsOpen = true;
    }
}
