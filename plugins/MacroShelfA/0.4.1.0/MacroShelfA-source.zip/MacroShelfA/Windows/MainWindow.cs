using System;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Windowing;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed class MainWindow : Window, IDisposable
{
    private static readonly Vector4 AccentColor = new(0.18f, 0.53f, 0.92f, 1f);
    private static readonly Vector4 AccentHoverColor = new(0.26f, 0.62f, 1f, 1f);
    private static readonly Vector4 SuccessColor = new(0.12f, 0.62f, 0.39f, 1f);
    private static readonly Vector4 SuccessHoverColor = new(0.17f, 0.72f, 0.46f, 1f);
    private static readonly Vector4 DangerColor = new(0.75f, 0.25f, 0.28f, 1f);
    private static readonly Vector4 DangerHoverColor = new(0.86f, 0.31f, 0.34f, 1f);

    private readonly Configuration configuration;
    private readonly MacroExecutor macroExecutor;
    private readonly BetterWaitPatch betterWaitPatch;
    private MacroEntry? selectedMacro;
    private MacroEntry? pendingDelete;
    private bool openDeletePopup;
    private bool openImportPopup;
    private bool confirmReplaceImport;
    private string searchText = string.Empty;
    private string importText = string.Empty;
    private string transferStatus = string.Empty;
    private bool transferStatusIsError;

    public MainWindow(Configuration configuration, MacroExecutor macroExecutor, BetterWaitPatch betterWaitPatch)
        : base("Macro Shelf-A###MacroShelfAMain")
    {
        this.configuration = configuration;
        this.macroExecutor = macroExecutor;
        this.betterWaitPatch = betterWaitPatch;
        selectedMacro = configuration.Macros.FirstOrDefault();

        SizeConstraints = new WindowSizeConstraints
        {
            MinimumSize = new Vector2(720, 500),
            MaximumSize = new Vector2(1200, 900),
        };
    }

    public void Dispose()
    {
    }

    public override void Draw()
    {
        PushUiTheme();
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(9, 8) * ImGuiHelpers.GlobalScale);
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(9, 6) * ImGuiHelpers.GlobalScale);
        ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 5 * ImGuiHelpers.GlobalScale);

        DrawExecutionStatus();
        DrawBetterWaitSetting();
        DrawFloatingLauncherSetting();
        DrawLineLimitSetting();
        ImGui.Separator();

        if (ImGui.BeginTabBar("##MacroShelfTabs"))
        {
            if (ImGui.BeginTabItem("执行面板"))
            {
                DrawRunPanel();
                ImGui.EndTabItem();
            }

            if (ImGui.BeginTabItem("编辑宏"))
            {
                DrawEditor();
                ImGui.EndTabItem();
            }

            ImGui.EndTabBar();
        }

        if (openDeletePopup)
        {
            ImGui.OpenPopup("删除宏");
            openDeletePopup = false;
        }

        if (openImportPopup)
        {
            ImGui.OpenPopup("导入配置");
            openImportPopup = false;
        }

        DrawDeleteConfirmation();
        DrawImportPopup();
        ImGui.PopStyleVar(3);
        ImGui.PopStyleColor(15);
    }

    private void DrawLineLimitSetting()
    {
        var enabled = configuration.AllowLongMacros;
        if (ImGui.Checkbox("解除 15 行限制", ref enabled))
        {
            configuration.AllowLongMacros = enabled;
            configuration.Save();
        }
        if (ImGui.IsItemHovered())
            ImGui.SetTooltip("对独立宏和所有子宏生效。关闭不会删除长宏内容。\n修改只影响下次启动，不改变正在执行的流程。");
        ImGui.SameLine();
        ImGui.TextDisabled(enabled ? "已解除 · 每宏最多 64,000 字符" : "未解除 · 每个独立宏 / 子宏最多 15 行");
    }

    private void DrawBetterWaitSetting()
    {
        var enabled = configuration.BetterWaitEnabled;
        if (ImGui.Checkbox("启用更好的等待", ref enabled))
        {
            configuration.BetterWaitEnabled = enabled;
            configuration.Save();
            betterWaitPatch.SetEnabled(enabled);
        }

        ImGui.SameLine();
        ImGui.TextDisabled(betterWaitPatch.StatusText);
        ImGui.SameLine();
        ImGui.TextDisabled("支持小数等待与长时间 /wait");
        if (ImGui.IsItemHovered())
        {
            ImGui.SetTooltip("宏中可使用 /wait 0.1、/wait 120 或 <wait.0.1>。\n若 Daily Routines 的同类功能仍启用，请先关闭，避免两个内存补丁冲突。");
        }
    }

    private void DrawFloatingLauncherSetting()
    {
        ImGui.Spacing();
        var visible = configuration.ShowFloatingLauncher;
        if (ImGui.Checkbox("显示悬浮入口", ref visible))
        {
            configuration.ShowFloatingLauncher = visible;
            configuration.Save();
        }

        ImGui.SameLine();
        ImGui.TextDisabled(visible ? "关闭主窗口后显示" : "已隐藏");
        if (!visible)
        {
            return;
        }

        ImGui.SameLine();
        var locked = configuration.LockFloatingLauncher;
        if (ImGui.Checkbox("锁定位置", ref locked))
        {
            configuration.LockFloatingLauncher = locked;
            configuration.Save();
        }

        ImGui.SameLine();
        ImGui.SetNextItemWidth(150 * ImGuiHelpers.GlobalScale);
        var size = configuration.FloatingLauncherSize;
        if (ImGui.SliderFloat("图标尺寸", ref size, 32f, 96f, "%.0f px"))
        {
            configuration.FloatingLauncherSize = size;
            configuration.Save();
        }
    }

    private void DrawExecutionStatus()
    {
        ImGui.TextUnformatted("Macro Shelf-A");
        ImGui.SameLine();
        if (!macroExecutor.IsRunning)
        {
            ImGui.TextDisabled($"{configuration.Macros.Count} 个入口 · {configuration.Macros.Count(m => m.IsGroup)} 个宏组 · 空闲");
            return;
        }
        ImGui.TextColored(SuccessColor, "正在执行");
        ImGui.SameLine();
        if (DrawColoredButton("中止整组", DangerColor, DangerHoverColor)) macroExecutor.Stop();
        if (!macroExecutor.IsRunning) return;
        ImGui.TextWrapped($"{macroExecutor.CurrentMacroName}  /  {macroExecutor.CurrentChildIndex}/{macroExecutor.TotalChildren} · {macroExecutor.CurrentChildName}");
        var progress = macroExecutor.TotalLines == 0 ? 0f : (float)macroExecutor.ExecutedLines / macroExecutor.TotalLines;
        ImGui.ProgressBar(progress, new Vector2(-1, 0),
            $"{macroExecutor.ExecutedLines}/{macroExecutor.TotalLines} 行 · 等待 {macroExecutor.RemainingWait:F1}s");
    }

    private void DrawRunPanel()
    {
        ImGui.TextWrapped("点击宏组总按钮按顺序运行全部子宏；展开后也可单独运行其中一个。");
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##MacroSearch", "搜索宏组、子宏名称或标签", ref searchText, 96);
        ImGui.Spacing();
        var macros = configuration.Macros.Where(MatchesSearch).OrderByDescending(m => m.Pinned).ToList();
        if (macros.Count == 0)
        {
            ImGui.TextDisabled(configuration.Macros.Count == 0 ? "还没有宏。前往“编辑宏”新建宏或宏组。" : "没有匹配结果，请换一个关键词。");
            return;
        }
        ImGui.BeginChild("##RunList", Vector2.Zero, false);
        foreach (var category in macros.GroupBy(GetTag).OrderBy(g => g.Key == "未分类").ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase))
        {
            DrawGroupHeader(category.Key, category.Count());
            foreach (var macro in category)
            {
                ImGui.PushID(macro.Id);
                ImGui.BeginDisabled(macroExecutor.IsRunning || (macro.IsGroup && macro.Children.Count == 0));
                var label = macro.IsGroup ? $"运行整组 · {macro.Name}  ({macro.Children.Count} 个子宏)" : $"运行 · {macro.Name}";
                if (DrawColoredButton($"{label}###RunRoot", macro.IsGroup || macro.Pinned ? AccentColor : new Vector4(0.10f, 0.17f, 0.26f, 0.96f), AccentHoverColor,
                        new Vector2(-1, 42 * ImGuiHelpers.GlobalScale))) macroExecutor.Start(macro);
                ImGui.EndDisabled();
                if (ImGui.IsItemHovered()) ImGui.SetTooltip(macro.Name);
                if (macro.IsGroup)
                {
                    if (ImGui.CollapsingHeader($"子宏 · 从上到下依次衔接###Children", ImGuiTreeNodeFlags.DefaultOpen))
                    {
                        ImGui.Indent(18 * ImGuiHelpers.GlobalScale);
                        if (macro.Children.Count == 0) ImGui.TextDisabled("此组暂无子宏，请到编辑页添加。");
                        for (var i = 0; i < macro.Children.Count; i++)
                        {
                            var child = macro.Children[i];
                            ImGui.PushID(child.Id);
                            ImGui.BeginDisabled(macroExecutor.IsRunning);
                            if (ImGui.Button($"{i + 1:00}  {child.Name} · 单独运行###RunChild", new Vector2(-1, 0))) macroExecutor.Start(child);
                            ImGui.EndDisabled();
                            if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{child.Name}\n仅运行此子宏，不启动后续子宏。");
                            ImGui.PopID();
                        }
                        ImGui.Unindent(18 * ImGuiHelpers.GlobalScale);
                    }
                }
                ImGui.PopID();
                ImGui.Spacing();
            }
        }
        ImGui.EndChild();
    }

    private static void DrawGroupHeader(string tag, int count)
    {
        ImGui.TextColored(AccentColor, tag);
        ImGui.SameLine();
        ImGui.TextDisabled($"{count} 个入口");
        ImGui.Separator();
    }

    private void DrawEditor()
    {
        var listWidth = MathF.Min(230 * ImGuiHelpers.GlobalScale, ImGui.GetContentRegionAvail().X * 0.32f);
        ImGui.BeginChild("##MacroList", new Vector2(listWidth, 0), true);
        ImGui.TextUnformatted("宏与宏组");
        ImGui.BeginDisabled(configuration.CountEntries() + 2 > Configuration.MaxEntries);
        if (DrawColoredButton("新建宏组", AccentColor, AccentHoverColor, new Vector2(-1, 0)))
            selectedMacro = configuration.AddMacro(isGroup: true) ?? selectedMacro;
        ImGui.EndDisabled();
        ImGui.BeginDisabled(configuration.CountEntries() >= Configuration.MaxEntries);
        if (ImGui.Button("新建独立宏", new Vector2(-1, 0))) selectedMacro = configuration.AddMacro() ?? selectedMacro;
        ImGui.EndDisabled();
        ImGui.TextDisabled($"条目 {configuration.CountEntries()}/{Configuration.MaxEntries}");
        if (ImGui.Button("导出配置", new Vector2(-1, 0))) ExportConfiguration();
        if (ImGui.Button("导入配置", new Vector2(-1, 0)))
        {
            importText = ImGui.GetClipboardText() ?? string.Empty;
            transferStatus = string.Empty;
            confirmReplaceImport = false;
            openImportPopup = true;
        }
        if (!string.IsNullOrEmpty(transferStatus)) ImGui.TextWrapped(transferStatus);
        ImGui.Separator();
        foreach (var macro in configuration.Macros)
        {
            DrawEntrySelection(macro, macro.IsGroup ? $"宏组 · {macro.Name}" : macro.Name);
            if (!macro.IsGroup) continue;
            ImGui.Indent(12 * ImGuiHelpers.GlobalScale);
            for (var i = 0; i < macro.Children.Count; i++)
                DrawEntrySelection(macro.Children[i], $"{i + 1:00}  {macro.Children[i].Name}");
            ImGui.Unindent(12 * ImGuiHelpers.GlobalScale);
        }
        ImGui.EndChild();
        ImGui.SameLine();
        ImGui.BeginChild("##MacroEditor", Vector2.Zero, false);
        DrawSelectedMacroEditor();
        ImGui.EndChild();
    }

    private void DrawEntrySelection(MacroEntry macro, string label)
    {
        ImGui.PushID(macro.Id);
        if (ImGui.Selectable($"{label}###Select", ReferenceEquals(selectedMacro, macro), ImGuiSelectableFlags.None,
                new Vector2(MathF.Max(1, ImGui.GetContentRegionAvail().X), 0))) selectedMacro = macro;
        if (ImGui.IsItemHovered()) ImGui.SetTooltip(label);
        ImGui.PopID();
    }

    private void DrawSelectedMacroEditor()
    {
        if (selectedMacro == null)
        {
            ImGui.TextWrapped("新建宏组，为它命名，再添加宏 A、宏 B 等子宏。执行面板将显示一个总按钮与其下的子宏。");
            return;
        }
        var entry = selectedMacro;
        var parent = configuration.FindParent(entry);
        ImGui.PushID(entry.Id);
        if (parent != null)
        {
            if (ImGui.Button("返回所属宏组")) selectedMacro = parent;
            ImGui.TextWrapped($"所属宏组：{parent.Name} · 顺序 {parent.Children.IndexOf(entry) + 1}/{parent.Children.Count}");
        }
        ImGui.TextUnformatted(entry.IsGroup ? "宏组编辑" : parent == null ? "独立宏编辑" : "子宏编辑");
        ImGui.SameLine();
        ImGui.TextDisabled("自动保存");
        if (macroExecutor.IsRunning) ImGui.TextWrapped("正在执行的是启动时的内容；本次编辑会在下次运行生效。");
        ImGui.Separator();
        var name = entry.Name;
        ImGui.TextUnformatted(entry.IsGroup ? "总按钮名称" : "宏名称");
        ImGui.SetNextItemWidth(-1);
        if (ImGui.InputText("##MacroName", ref name, 128)) entry.Name = name;
        // Save on edit completion so normalization does not consume spaces while typing.
        if (ImGui.IsItemDeactivatedAfterEdit()) configuration.Save();
        if (parent == null)
        {
            var group = entry.Group;
            ImGui.TextUnformatted("分类标签");
            ImGui.SetNextItemWidth(-1);
            if (ImGui.InputText("##MacroTag", ref group, 96)) entry.Group = group;
            if (ImGui.IsItemDeactivatedAfterEdit()) configuration.Save();
            var pinned = entry.Pinned;
            if (ImGui.Checkbox("在执行面板置顶", ref pinned)) { entry.Pinned = pinned; configuration.Save(); }
        }
        if (entry.IsGroup) DrawGroupEditor(entry);
        else DrawCommandEditor(entry);
        DrawEntryActions(entry, parent);
        ImGui.PopID();
    }

    private void DrawGroupEditor(MacroEntry group)
    {
        ImGui.Separator();
        ImGui.TextWrapped(configuration.AllowLongMacros
            ? "子宏按顺序衔接，已解除 15 行限制；末尾等待结束后进入下一个。无需 /nextmacro。"
            : "子宏按顺序衔接，每个子宏最多 15 行；末尾等待结束后进入下一个。无需 /nextmacro。");
        var full = group.Children.Count >= Configuration.MaxChildren || configuration.CountEntries() >= Configuration.MaxEntries;
        ImGui.BeginDisabled(full);
        if (ImGui.Button("添加子宏")) selectedMacro = configuration.AddChild(group) ?? selectedMacro;
        ImGui.SetNextItemWidth(-1);
        if (ImGui.BeginCombo("##CopyExisting", "添加已有独立宏的副本…"))
        {
            var existing = configuration.Macros.Where(m => !m.IsGroup).ToList();
            if (existing.Count == 0) ImGui.TextDisabled("没有可添加的独立宏");
            foreach (var source in existing)
            {
                ImGui.PushID(source.Id);
                if (ImGui.Selectable($"{source.Name}###Copy")) selectedMacro = configuration.AddChild(group, source) ?? selectedMacro;
                ImGui.PopID();
            }
            ImGui.EndCombo();
        }
        ImGui.EndDisabled();
        ImGui.TextDisabled($"{group.Children.Count}/{Configuration.MaxChildren} 个子宏 · 添加副本不会修改原宏");
        for (var i = 0; i < group.Children.Count; i++)
        {
            var child = group.Children[i];
            ImGui.PushID(child.Id);
            if (ImGui.Selectable($"{i + 1:00}  {child.Name} · 编辑###EditChild")) selectedMacro = child;
            if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{child.Name}\n点击编辑名称、命令或调整顺序。");
            ImGui.PopID();
        }
        if (group.Children.Count == 0) ImGui.TextDisabled("添加第一个子宏后即可编辑命令。");
        ImGui.Spacing();
    }

    private void DrawCommandEditor(MacroEntry entry)
    {
        ImGui.Spacing();
        var effectiveLines = CountEffectiveLines(entry.Commands);
        ImGui.TextUnformatted("命令内容");
        ImGui.SameLine();
        var overLineLimit = !configuration.AllowLongMacros && effectiveLines > MacroExecutor.MaximumLines;
        var overTextLimit = entry.Commands.Length > Configuration.MaxCommandLength;
        ImGui.TextColored(overLineLimit || overTextLimit ? DangerColor : new Vector4(0.65f, 0.75f, 0.85f, 1),
            configuration.AllowLongMacros ? $"{effectiveLines} 有效行 · 已解除限制" : $"{effectiveLines}/{MacroExecutor.MaximumLines} 有效行");
        if (overLineLimit) ImGui.TextWrapped("此宏超过 15 行，请勾选窗口上方“解除 15 行限制”后再运行。");
        if (overTextLimit) ImGui.TextWrapped("此宏超过 64,000 字符，请拆分；已保存内容不会被截断。");
        var commands = entry.Commands;
        var editorHeight = MathF.Max(140 * ImGuiHelpers.GlobalScale, ImGui.GetContentRegionAvail().Y - 150 * ImGuiHelpers.GlobalScale);
        // ImGui capacity is UTF-8 bytes, not UTF-16 characters; allow a full CJK document.
        var bufferSize = Math.Max(Configuration.MaxCommandLength * 3 + 1, System.Text.Encoding.UTF8.GetByteCount(commands) + 1);
        if (ImGui.InputTextMultiline("##MacroCommands", ref commands, bufferSize, new Vector2(-1, editorHeight), ImGuiInputTextFlags.AllowTabInput))
        { entry.Commands = commands; configuration.Save(); }
        ImGui.TextWrapped("用 /wait 3 或 <wait.3> 留出动作时间；子宏会保留最后一行的等待。");
    }

    private void DrawEntryActions(MacroEntry entry, MacroEntry? parent)
    {
        ImGui.BeginDisabled(macroExecutor.IsRunning || (entry.IsGroup && entry.Children.Count == 0));
        if (DrawColoredButton(entry.IsGroup ? "运行整组" : parent != null ? "单独运行此子宏" : "立即执行", SuccessColor, SuccessHoverColor)) macroExecutor.Start(entry);
        ImGui.EndDisabled();
        var siblings = parent?.Children ?? configuration.Macros;
        var index = siblings.IndexOf(entry);
        ImGui.BeginDisabled(index <= 0);
        if (ImGui.Button("上移")) configuration.Move(entry, -1);
        ImGui.EndDisabled();
        ImGui.SameLine();
        ImGui.BeginDisabled(index < 0 || index == siblings.Count - 1);
        if (ImGui.Button("下移")) configuration.Move(entry, 1);
        ImGui.EndDisabled();
        ImGui.SameLine();
        ImGui.BeginDisabled(configuration.CountEntries() + 1 + (entry.IsGroup ? entry.Children.Count : 0) > Configuration.MaxEntries ||
            (parent != null && parent.Children.Count >= Configuration.MaxChildren));
        if (ImGui.Button("复制")) selectedMacro = configuration.Duplicate(entry) ?? selectedMacro;
        ImGui.EndDisabled();
        ImGui.SameLine();
        if (DrawColoredButton("删除", DangerColor, DangerHoverColor)) { pendingDelete = entry; openDeletePopup = true; }
    }

    private static bool DrawColoredButton(string label, Vector4 color, Vector4 hoveredColor, Vector2? size = null)
    {
        ImGui.PushStyleColor(ImGuiCol.Button, color);
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, hoveredColor);
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, hoveredColor);
        var clicked = ImGui.Button(label, size ?? Vector2.Zero);
        ImGui.PopStyleColor(3);
        return clicked;
    }

    private static void PushUiTheme()
    {
        ImGui.PushStyleColor(ImGuiCol.ChildBg, new Vector4(0.035f, 0.055f, 0.085f, 0.94f));
        ImGui.PushStyleColor(ImGuiCol.Border, new Vector4(0.18f, 0.29f, 0.42f, 0.78f));
        ImGui.PushStyleColor(ImGuiCol.FrameBg, new Vector4(0.08f, 0.12f, 0.18f, 0.96f));
        ImGui.PushStyleColor(ImGuiCol.FrameBgHovered, new Vector4(0.11f, 0.18f, 0.28f, 0.98f));
        ImGui.PushStyleColor(ImGuiCol.FrameBgActive, new Vector4(0.13f, 0.25f, 0.39f, 1f));
        ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.10f, 0.17f, 0.26f, 0.96f));
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.14f, 0.29f, 0.46f, 1f));
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(0.13f, 0.38f, 0.62f, 1f));
        ImGui.PushStyleColor(ImGuiCol.Header, new Vector4(0.11f, 0.22f, 0.35f, 0.92f));
        ImGui.PushStyleColor(ImGuiCol.HeaderHovered, new Vector4(0.15f, 0.32f, 0.51f, 0.98f));
        ImGui.PushStyleColor(ImGuiCol.HeaderActive, new Vector4(0.13f, 0.39f, 0.64f, 1f));
        ImGui.PushStyleColor(ImGuiCol.CheckMark, AccentColor);
        ImGui.PushStyleColor(ImGuiCol.Tab, new Vector4(0.055f, 0.09f, 0.14f, 0.96f));
        ImGui.PushStyleColor(ImGuiCol.TabHovered, new Vector4(0.12f, 0.29f, 0.47f, 1f));
        ImGui.PushStyleColor(ImGuiCol.TabActive, new Vector4(0.14f, 0.39f, 0.64f, 1f));
    }

    private void ExportConfiguration()
    {
        try
        {
            ImGui.SetClipboardText(ConfigurationExchange.Export(configuration));
            transferStatus = $"已复制 {configuration.Macros.Count} 个入口（含子宏）";
            transferStatusIsError = false;
        }
        catch (Exception exception)
        {
            transferStatus = $"导出失败：{exception.Message}";
            transferStatusIsError = true;
        }
    }

    private void DrawImportPopup()
    {
        ImGui.SetNextWindowSize(new Vector2(680, 470) * ImGuiHelpers.GlobalScale, ImGuiCond.FirstUseEver);
        var open = true;
        if (!ImGui.BeginPopupModal("导入配置", ref open))
        {
            return;
        }

        ImGui.TextUnformatted("粘贴由 Macro Shelf-A 导出的 JSON 配置");
        ImGui.TextWrapped("追加导入仅添加内容，保留本机开关；替换导入同时应用等待与解除行数限制设置。");
        ImGui.Spacing();
        if (ImGui.Button("从剪贴板重新粘贴"))
        {
            importText = ImGui.GetClipboardText() ?? string.Empty;
            transferStatus = string.Empty;
            confirmReplaceImport = false;
        }

        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextMultiline("##ImportConfigurationJson", ref importText, ConfigurationExchange.MaximumJsonLength,
            new Vector2(-1, 285 * ImGuiHelpers.GlobalScale), ImGuiInputTextFlags.AllowTabInput);

        if (!string.IsNullOrEmpty(transferStatus))
        {
            ImGui.TextColored(transferStatusIsError ? DangerColor : SuccessColor, transferStatus);
        }
        else
        {
            ImGui.TextDisabled($"当前已有 {configuration.CountEntries()}/{ConfigurationExchange.MaximumEntries} 个条目（含宏组与子宏）");
        }

        if (DrawColoredButton("追加导入", AccentColor, AccentHoverColor, new Vector2(105 * ImGuiHelpers.GlobalScale, 0)))
        {
            ImportConfiguration(replaceExisting: false);
        }

        ImGui.SameLine();
        var replaceLabel = confirmReplaceImport ? "确认替换" : "替换现有";
        if (DrawColoredButton(replaceLabel, DangerColor, DangerHoverColor, new Vector2(105 * ImGuiHelpers.GlobalScale, 0)))
        {
            if (confirmReplaceImport)
            {
                ImportConfiguration(replaceExisting: true);
            }
            else
            {
                confirmReplaceImport = true;
                transferStatus = "再次点击“确认替换”才会覆盖全部独立宏、宏组及子宏。";
                transferStatusIsError = true;
            }
        }

        ImGui.SameLine();
        if (ImGui.Button("取消", new Vector2(90 * ImGuiHelpers.GlobalScale, 0)))
        {
            confirmReplaceImport = false;
            transferStatus = string.Empty;
            ImGui.CloseCurrentPopup();
        }

        ImGui.EndPopup();
    }

    private void ImportConfiguration(bool replaceExisting)
    {
        if (!ConfigurationExchange.TryImport(importText, out var imported, out var error))
        {
            transferStatus = error;
            transferStatusIsError = true;
            confirmReplaceImport = false;
            return;
        }

        if (!replaceExisting && configuration.CountEntries() + imported.CountEntries() > ConfigurationExchange.MaximumEntries)
        {
            transferStatus = $"追加后将有 {configuration.CountEntries() + imported.CountEntries()} 个宏，超过 {ConfigurationExchange.MaximumEntries} 个的上限。";
            transferStatusIsError = true;
            confirmReplaceImport = false;
            return;
        }

        var firstImportedIndex = replaceExisting ? 0 : configuration.Macros.Count;
        if (replaceExisting)
        {
            macroExecutor.Stop(false);
            configuration.Macros.Clear();
            configuration.BetterWaitEnabled = imported.BetterWaitEnabled;
            configuration.AllowLongMacros = imported.AllowLongMacros;
            betterWaitPatch.SetEnabled(imported.BetterWaitEnabled);
        }

        configuration.Macros.AddRange(imported.Macros);
        configuration.Save();
        selectedMacro = configuration.Macros.ElementAtOrDefault(firstImportedIndex) ?? configuration.Macros.FirstOrDefault();
        transferStatus = $"已{(replaceExisting ? "替换" : "追加")}导入 {imported.Macros.Count} 个宏";
        transferStatusIsError = false;
        confirmReplaceImport = false;
        ImGui.CloseCurrentPopup();
    }

    private void DrawDeleteConfirmation()
    {
        var open = true;
        if (!ImGui.BeginPopupModal("删除宏", ref open, ImGuiWindowFlags.AlwaysAutoResize))
        {
            return;
        }

        ImGui.TextUnformatted($"确定删除“{pendingDelete?.Name ?? string.Empty}”？");
        ImGui.TextWrapped(pendingDelete?.IsGroup == true ? $"将同时删除组内 {pendingDelete.Children.Count} 个子宏。此操作无法撤销。" : "此操作无法撤销。");
        ImGui.Spacing();
        if (DrawColoredButton("删除", DangerColor, DangerHoverColor, new Vector2(90 * ImGuiHelpers.GlobalScale, 0)))
        {
            var deleting = pendingDelete;
            var parent = deleting == null ? null : configuration.FindParent(deleting);
            pendingDelete = null;
            if (deleting != null && configuration.Remove(deleting))
            {
                selectedMacro = parent ?? configuration.Macros.FirstOrDefault();
            }

            ImGui.CloseCurrentPopup();
        }

        ImGui.SameLine();
        if (ImGui.Button("取消", new Vector2(90 * ImGuiHelpers.GlobalScale, 0)))
        {
            pendingDelete = null;
            ImGui.CloseCurrentPopup();
        }

        ImGui.EndPopup();
    }

    private bool MatchesSearch(MacroEntry macro)
    {
        var search = searchText.Trim();
        return search.Length == 0 ||
               macro.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
               macro.Group.Contains(search, StringComparison.OrdinalIgnoreCase) ||
               (macro.IsGroup && macro.Children.Any(child => child.Name.Contains(search, StringComparison.OrdinalIgnoreCase)));
    }

    private static int CountEffectiveLines(string commands)
    {
        return MacroSequence.PrepareLines(commands).Count;
    }

    private static string GetTag(MacroEntry macro)
    {
        return string.IsNullOrWhiteSpace(macro.Group) ? "未分类" : macro.Group.Trim();
    }
}


