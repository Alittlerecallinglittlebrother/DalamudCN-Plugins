using System.Runtime.InteropServices;
using MacroShelfA;
using MacroShelfA.Runtime;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;

internal static class CountdownTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool condition, string message = "countdown assertion failed") => check(condition, message);
        test("countdown API 15 event and generated agent layout are available", () =>
        {
            Check(typeof(Dalamud.Plugin.Services.IChatGui).GetEvent("LogMessage") != null);
            Check(Marshal.OffsetOf<AgentCountDownSettingDialog>("TimeRemaining") == 0x28);
            Check(Marshal.OffsetOf<AgentCountDownSettingDialog>("Active") == 0x38);
            // Compile-time field access uses the installed generated bindings; the production code has no offsets.
        });
        test("countdown defaults off and v5 migration preserves content", () =>
        {
            var c = new Configuration { Version = 5, Macros = [new() { Id = "x", Commands = "/echo saved" }],
                CountdownTriggerEnabled = true, CountdownMacroId = "x", AllowLongMacros = true };
            c.Normalize();
            Check(c.Version == 6 && !c.CountdownTriggerEnabled && c.CountdownMacroId == "" &&
                c.AllowLongMacros && c.Macros[0].Commands == "/echo saved");
        });
        test("native reader exits before touching game agent when logged out or between areas", () =>
        {
            Plugin.ClientState.IsLoggedIn = false;
            Check(!NativeCountdownReader.Read().Available);
            Plugin.ClientState.IsLoggedIn = true;
            foreach (var flag in new[] { Dalamud.Game.ClientState.Conditions.ConditionFlag.BetweenAreas,
                Dalamud.Game.ClientState.Conditions.ConditionFlag.BetweenAreas51,
                Dalamud.Game.ClientState.Conditions.ConditionFlag.LoggingOut })
            {
                Plugin.Condition.Flags.Add(flag);
                try { Check(!NativeCountdownReader.Read().Available); }
                finally { Plugin.Condition.Flags.Clear(); }
            }
        });
        test("countdown v6 migration backup created once without overwriting", () =>
        {
            var directory = Path.Combine(AppContext.BaseDirectory, "countdown-migration-fixture");
            var c = new Configuration { Version = 5, Macros = [new() { Name = "original-countdown" }] };
            ConfigurationBackup.BeforeCountdownMigration(c, directory);
            var file = Path.Combine(directory, "config-before-countdown-v6.json");
            var original = File.ReadAllText(file);
            c.Macros.Clear(); ConfigurationBackup.BeforeCountdownMigration(c, directory);
            Check(File.ReadAllText(file) == original && original.Contains("original-countdown"));
        });
        test("countdown binding persists ID across rename and reorder, copy does not rebind", () =>
        {
            using var f = new Fixture();
            var target = f.Config.Macros[0];
            target.Name = "changed"; f.Config.Duplicate(target); f.Config.Move(target, 1);
            var restored = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
            restored.Normalize();
            Check(restored.CountdownTriggerEnabled && restored.FindCountdownMacro()?.Id == target.Id);
            Check(restored.FindCountdownMacro()?.Name == "changed");
        });
        test("countdown deleting selected root or ambiguous IDs clears binding", () =>
        {
            using var f = new Fixture();
            f.Config.Remove(f.Config.Macros[0]);
            Check(!f.Config.CountdownTriggerEnabled && f.Config.CountdownMacroId == "");
            f.Config.Macros = [new() { Id = "same" }, new() { Id = "same" }];
            f.Config.CountdownMacroId = "same"; f.Config.CountdownTriggerEnabled = true; f.Config.Normalize();
            Check(!f.Config.CountdownTriggerEnabled);
        });
        test("countdown bindings not transferred or enabled by imported JSON", () =>
        {
            using var f = new Fixture();
            var exported = ConfigurationExchange.Export(f.Config);
            Check(!exported.Contains("Countdown"));
            var injected = exported.Replace("\"Format\"", "\"CountdownTriggerEnabled\":true,\"CountdownMacroId\":\"injected\",\"Format\"");
            Check(ConfigurationExchange.TryImport(injected, out var imported, out _));
            var config = new Configuration { Macros = imported.Macros }; config.Normalize();
            Check(!config.CountdownTriggerEnabled);
        });
        foreach (var id in new[] { CountdownObserver.Completed, CountdownObserver.CompletedAlternate })
            test($"countdown completion {id} runs once on framework, never inside log callback", () =>
            {
                using var f = new Fixture(); f.Begin(); f.End(id);
                Check(f.Executor.IsRunning && Plugin.CommandManager.Sent.Count == 0);
                Plugin.ChatGui.Emit(id); Plugin.ChatGui.Emit(id == 5256 ? 5264u : 5256u); f.Tick(); f.Tick();
                Check(Plugin.CommandManager.Sent.SequenceEqual(new[] { "/echo countdown" }));
            });
        test("countdown timer reaching zero alone never executes", () =>
        {
            using var f = new Fixture(); f.Begin();
            f.Sample = f.Sample with { Active = true, Remaining = 0 }; f.Tick();
            f.Sample = f.Sample with { Active = false }; f.Tick();
            for (var i = 0; i < 30; i++) f.Tick();
            Check(!f.Executor.IsRunning && Plugin.CommandManager.Sent.Count == 0);
        });
        test("countdown exact system event only; arbitrary log IDs ignored", () =>
        {
            using var f = new Fixture(); f.Begin();
            foreach (var id in new uint[] { 0, 57, 5255, 5260, 5261, 5262, 5263, 17775 }) Plugin.ChatGui.Emit(id);
            f.Tick(); Check(!f.Executor.IsRunning);
        });
        test("countdown no initial active sample or stale idle completion trigger", () =>
        {
            using var f = new Fixture(initiallyActive: true); Plugin.ChatGui.Emit(5256); f.Tick();
            Check(!f.Executor.IsRunning);
            f.Sample = f.Sample with { Active = false }; f.Tick(); Plugin.ChatGui.Emit(5264); f.Tick();
            Check(!f.Executor.IsRunning);
            f.Begin(); f.End(); Check(f.Executor.IsRunning);
        });
        foreach (var remaining in new[] { 10f, 0.01f, 0f })
            test($"countdown cancellation at {remaining}s cannot execute, even with following stale finish", () =>
            {
                using var f = new Fixture(); f.Begin();
                f.Sample = f.Sample with { Remaining = remaining }; f.Tick();
                Plugin.ChatGui.Emit(5257);
                f.Sample = f.Sample with { Active = false }; Plugin.ChatGui.Emit(5256); f.Tick();
                Check(!f.Executor.IsRunning && Plugin.CommandManager.Sent.Count == 0);
            });
        test("countdown canceled then restarted can trigger normally", () =>
        {
            using var f = new Fixture(); f.Begin(); Plugin.ChatGui.Emit(5257);
            f.Sample = f.Sample with { Active = false }; f.Tick(); f.Begin(); f.End();
            Check(f.Executor.IsRunning);
        });
        test("countdown frame ordering allows small negative remaining at exact finish", () =>
        {
            using var f = new Fixture(); f.Begin();
            f.Sample = f.Sample with { Remaining = -0.01f }; Plugin.ChatGui.Emit(5256); f.Tick();
            Check(f.Executor.IsRunning);
        });
        test("countdown canceled after pending completion clears pending before framework", () =>
        {
            using var f = new Fixture(); f.Begin();
            f.Sample = f.Sample with { Active = false }; Plugin.ChatGui.Emit(5256); Plugin.ChatGui.Emit(5257); f.Tick();
            Check(!f.Executor.IsRunning);
        });
        foreach (var reason in new[] { "logout", "zone", "invalid", "disable", "target", "delete" })
            test($"countdown {reason} invalidates pending completion", () =>
            {
                using var f = new Fixture(); f.Begin();
                f.Sample = f.Sample with { Active = false }; Plugin.ChatGui.Emit(5256);
                switch (reason)
                {
                    case "logout": f.Sample = f.Sample with { Available = false }; break;
                    case "zone": f.Sample = f.Sample with { Territory = 101 }; break;
                    case "invalid": f.Sample = f.Sample with { Active = true, Remaining = float.NaN }; break;
                    case "disable": f.Config.CountdownTriggerEnabled = false; break;
                    case "target": f.Config.CountdownMacroId = f.Config.Macros[1].Id; break;
                    case "delete": f.Config.Remove(f.Config.Macros[0]); break;
                }
                f.Tick(); Check(!f.Executor.IsRunning);
            });
        test("countdown disabled mode performs no native reads", () =>
        {
            using var f = new Fixture(); f.Config.CountdownTriggerEnabled = false;
            var count = f.Reads; f.Tick(); Plugin.ChatGui.Emit(5256); f.Tick();
            Check(f.Reads == count && !f.Executor.IsRunning);
        });
        test("countdown changed target mid-countdown waits for a fresh countdown", () =>
        {
            using var f = new Fixture(); f.Begin(); f.Config.CountdownMacroId = f.Config.Macros[1].Id;
            f.Tick(); f.End(); Check(!f.Executor.IsRunning);
            f.Begin(); f.End(); Check(f.Executor.IsRunning && f.Executor.CurrentMacroName == "other");
        });
        test("countdown busy at signal skips even if manual macro finishes before framework", () =>
        {
            using var f = new Fixture(); f.Begin(); f.Executor.Start(f.Config.Macros[1]);
            f.Sample = f.Sample with { Active = false }; Plugin.ChatGui.Emit(5256); f.Executor.Stop(false); f.Tick();
            Check(!f.Executor.IsRunning && f.Trigger.LastResult.Contains("已有宏"));
            for (var i = 0; i < 10; i++) f.Tick();
            Check(Plugin.CommandManager.Sent.Count == 0);
        });
        test("countdown manual macro started after signal is not interrupted", () =>
        {
            using var f = new Fixture(); f.Begin();
            f.Sample = f.Sample with { Active = false }; Plugin.ChatGui.Emit(5256);
            f.Config.Macros[1].Commands = "/wait 20"; f.Executor.Start(f.Config.Macros[1]); f.Tick();
            Check(f.Executor.CurrentMacroName == "other" && f.Trigger.LastResult.Contains("已有宏"));
        });
        test("countdown suspended client does not catch up", () =>
        {
            using var f = new Fixture(); f.Begin(); f.Time += 10; f.End(); Check(!f.Executor.IsRunning);
        });
        test("countdown delayed pending event is dropped", () =>
        {
            using var f = new Fixture(); f.Begin();
            f.Sample = f.Sample with { Active = false }; Plugin.ChatGui.Emit(5256); f.Time += 3; f.Tick();
            Check(!f.Executor.IsRunning && f.Trigger.LastResult.Contains("延迟"));
        });
        test("countdown invalid macro reports result and is not retried", () =>
        {
            using var f = new Fixture(); f.Config.Macros[0].Commands = ""; f.Begin(); f.End();
            Check(!f.Executor.IsRunning && f.Trigger.LastResult.Contains("跳过"));
            f.Config.Macros[0].Commands = "/echo new"; Plugin.ChatGui.Emit(5256); f.Tick(); Check(!f.Executor.IsRunning);
        });
        test("countdown group uses same complete snapshot and long-macro switch", () =>
        {
            using var f = new Fixture(); var group = f.Config.Macros[0]; group.IsGroup = true;
            group.Children = [new() { Name = "A", Commands = string.Join('\n', Enumerable.Repeat("/echo long", 30)) },
                new() { Name = "B", Commands = "/echo B" }];
            f.Begin(); f.End(); Check(!f.Executor.IsRunning && f.Trigger.LastResult.Contains("15"));
            f.Config.AllowLongMacros = true; f.Begin(); f.End();
            Check(f.Executor.TotalLines == 31 && f.Executor.TotalChildren == 2);
            group.Children.Clear(); Check(f.Executor.TotalLines == 31);
        });
        test("countdown read failure disables listener without repeated retries", () =>
        {
            using var f = new Fixture(); f.FailReads = true; f.Tick();
            Check(!f.Config.CountdownTriggerEnabled && f.Trigger.LastResult.Contains("异常"));
            var reads = f.Reads; f.Tick(); Check(f.Reads == reads);
        });
        test("countdown dispose unsubscribes events and discards pending", () =>
        {
            var framework = Plugin.Framework.Subscribers; var logs = Plugin.ChatGui.Subscribers;
            var f = new Fixture(); f.Begin(); f.Sample = f.Sample with { Active = false }; Plugin.ChatGui.Emit(5256);
            f.Dispose(); Plugin.ChatGui.Emit(5256); Plugin.Framework.Tick();
            Check(Plugin.Framework.Subscribers == framework && Plugin.ChatGui.Subscribers == logs);
            Check(Plugin.CommandManager.Sent.Count == 0);
        });
    }

    private sealed class Fixture : IDisposable
    {
        public Configuration Config = new() { Macros = [new() { Name = "countdown", Commands = "/echo countdown" },
            new() { Name = "other", Commands = "/echo other" }] };
        public CountdownSample Sample = new(true, 100, false, 0);
        public double Time;
        public int Reads;
        public bool FailReads;
        public MacroExecutor Executor;
        public CountdownTrigger Trigger;
        public Fixture(bool initiallyActive = false)
        {
            Plugin.ClientState.IsLoggedIn = true; Plugin.CommandManager.Sent.Clear();
            Config.CountdownMacroId = Config.Macros[0].Id; Config.CountdownTriggerEnabled = true;
            if (initiallyActive) Sample = Sample with { Active = true, Remaining = 10 };
            Executor = new MacroExecutor(Config);
            Trigger = new CountdownTrigger(Config, Executor, () =>
            {
                Reads++;
                if (FailReads) throw new InvalidOperationException("sample failed");
                return Sample;
            }, () => Time);
            Tick();
        }
        public void Tick() { Time += 0.1; Plugin.Framework.Tick(); }
        public void Begin() { Sample = Sample with { Active = true, Remaining = 10 }; Tick(); }
        public void End(uint id = CountdownObserver.Completed)
        {
            Sample = Sample with { Active = false, Remaining = 0 };
            Plugin.ChatGui.Emit(id); Tick();
        }
        public void Dispose() { Trigger.Dispose(); Executor.Dispose(); }
    }
}
