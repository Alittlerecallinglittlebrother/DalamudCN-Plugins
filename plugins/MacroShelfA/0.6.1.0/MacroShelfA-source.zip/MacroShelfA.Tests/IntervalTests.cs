using System.Text.Json;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Tests;

internal static class IntervalTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "interval assertion failed") => check(value, message);
        MacroEntry Leaf(string commands) => new() { Name = "test", Commands = commands };
        MacroSequence Start(string commands, double at = 0)
        {
            var s = new MacroSequence();
            Check(s.TryStart(Leaf(commands), at, out var error, true), error);
            return s;
        }
        test("both timing options and removed scheduling UI no longer exist", () =>
        {
            Check(typeof(Configuration).GetProperty("UseTimelineScheduling") == null);
            Check(typeof(Configuration).GetProperty("RemoveDefaultInterval") == null);
            Check(typeof(MacroSequence).GetProperty("UsesTimeline") == null);
            Check(typeof(MacroSequence).GetField("MaximumTimelineLateness") == null);
            Check(typeof(MacroShelfA.Windows.MainWindow).GetMethod("DrawTimingSettings",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance) == null);
        });
        foreach (var version in new[] { 6, 7 })
        foreach (var remove in new[] { false, true })
        foreach (var timeline in new[] { false, true })
            test($"v{version} upgrade ignores old flags ({remove},{timeline}) and preserves user data", () =>
            {
                var json = JsonSerializer.Serialize(new { Version = version, RemoveDefaultInterval = remove,
                    UseTimelineScheduling = timeline, AllowLongMacros = true, CountdownTriggerEnabled = true,
                    CountdownMacroId = "root", Macros = new[] { new { Id = "root", Commands = "/echo first\n/echo second" } } });
                var c = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(json)!;
                c.Normalize(); c.Save();
                Check(c.Version == 8 && c.AllowLongMacros && c.CountdownTriggerEnabled && c.CountdownMacroId == "root");
                Check(!Plugin.PluginInterface.Json.Contains("UseTimelineScheduling") && !Plugin.PluginInterface.Json.Contains("RemoveDefaultInterval"));
                var restored = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
                Check(restored.Macros[0].Commands == "/echo first\n/echo second");
                var now = 0.0; var count = Plugin.CommandManager.Sent.Count;
                using var exec = new MacroExecutor(restored, () => now);
                exec.Start(restored.Macros[0]); Plugin.Framework.Tick(); now = 0.001; Plugin.Framework.Tick();
                Check(!exec.IsRunning && Plugin.CommandManager.Sent.Count == count + 2);
            });
        test("v4 export omits retired settings and countdown bindings", () =>
        {
            var json = ConfigurationExchange.Export(new Configuration { Macros = [Leaf("/echo exported")] });
            Check(JsonDocument.Parse(json).RootElement.GetProperty("Version").GetInt32() == 4);
            Check(!json.Contains("Timeline") && !json.Contains("RemoveDefaultInterval") && !json.Contains("Countdown"));
            Check(ConfigurationExchange.TryImport(json, out var imported, out var error), error);
            Check(imported.Macros[0].Commands == "/echo exported");
        });
        foreach (var version in new[] { 1, 2, 3, 4 })
            test($"v{version} imports ignore retired options and execute without a default gap", () =>
            {
                var json = JsonSerializer.Serialize(new { Format = "MacroShelfA", Version = version,
                    UseTimelineScheduling = true, RemoveDefaultInterval = false,
                    Macros = new[] { new { Commands = "/echo first\n/echo second" } } });
                Check(ConfigurationExchange.TryImport(json, out var imported, out _));
                var s = new MacroSequence(); Check(s.TryStart(imported.Macros[0], 0, out _));
                var sent = new List<string>(); s.Tick(0, sent.Add); s.Tick(0.001, sent.Add);
                Check(sent.Count == 2 && !s.IsRunning);
            });
        test("v8 migration snapshot preserves macros without overwriting", () =>
        {
            var path = Path.Combine(AppContext.BaseDirectory, "zero-interval-migration-fixture");
            var c = new Configuration { Version = 7, Macros = [new() { Name = "original-interval" }] };
            ConfigurationBackup.BeforeZeroIntervalMigration(c, path);
            var file = Path.Combine(path, "config-before-zero-interval-v8.json"); var original = File.ReadAllText(file);
            c.Macros.Clear(); ConfigurationBackup.BeforeZeroIntervalMigration(c, path);
            Check(File.ReadAllText(file) == original && original.Contains("original-interval"));
        });
        test("no-gap dispatches exactly one row per update and ends zero-wait last row immediately", () =>
        {
            var s = Start("/echo A\n/echo B\n/echo C"); var sent = new List<string>();
            s.Tick(0, sent.Add); Check(sent.Count == 1);
            s.Tick(1.0 / 60, sent.Add); Check(sent.Count == 2);
            s.Tick(2.0 / 60, sent.Add); Check(sent.Count == 3 && !s.IsRunning);
        });
        test("no-gap waits full inline duration from actual late dispatch", () =>
        {
            var s = Start("/echo A <wait.1>\n/echo B"); var sent = new List<string>();
            s.Tick(0.2, sent.Add); s.Tick(1, sent.Add); Check(sent.Count == 1);
            s.Tick(1.2, sent.Add); Check(sent.Count == 2 && !s.IsRunning);
        });
        test("standalone decimal wait retains full duration and sends no command", () =>
        {
            var s = Start("/wait 0.5\n/echo B"); var sent = new List<string>();
            s.Tick(0.2, sent.Add); s.Tick(0.69, sent.Add); Check(sent.Count == 0 && s.IsRunning);
            s.Tick(0.7, sent.Add); Check(sent.SequenceEqual(["/echo B"]) && !s.IsRunning);
        });
        test("child and final explicit waits are retained with no-gap enabled", () =>
        {
            var group = new MacroEntry { IsGroup = true, Children = [Leaf("/echo A <wait.2>"), Leaf("/echo B <wait.3>")] };
            var s = new MacroSequence(); Check(s.TryStart(group, 0, out _, true));
            var sent = new List<string>(); s.Tick(0.1, sent.Add); s.Tick(2, sent.Add); Check(sent.Count == 1);
            s.Tick(2.1, sent.Add); Check(sent.Count == 2 && s.IsRunning && s.CurrentChildIndex == 2);
            s.Tick(5, sent.Add); Check(s.IsRunning); s.Tick(5.1, sent.Add); Check(!s.IsRunning);
        });
        test("zero-wait child boundary has no additional 0.15 delay", () =>
        {
            var group = new MacroEntry { IsGroup = true, Children = [Leaf("/echo A"), Leaf("/echo B")] };
            var s = new MacroSequence(); Check(s.TryStart(group, 0, out _, false));
            var sent = new List<string>(); s.Tick(0, sent.Add); s.Tick(0.01, sent.Add);
            Check(sent.Count == 2 && !s.IsRunning);
        });
        test("stall beyond 0.5 seconds continues one row without abort or catch-up burst", () =>
        {
            var s = Start("/echo A <wait.1>\n/echo B <wait.2>\n/echo C"); var sent = new List<string>();
            s.Tick(0, sent.Add); s.Tick(10, sent.Add); Check(sent.Count == 2 && s.IsRunning && s.ExecutionStopReason == "");
            s.Tick(11.99, sent.Add); Check(sent.Count == 2);
            s.Tick(12, sent.Add); Check(sent.Count == 3 && !s.IsRunning);
        });
        test("dense 100 zero-wait rows complete without removed late-abort behavior", () =>
        {
            var s = Start(string.Join('\n', Enumerable.Repeat("/echo dense", 100))); var sent = new List<string>();
            for (var frame = 0; frame < 100; frame++)
            {
                var before = sent.Count; s.Tick(frame / 10.0, sent.Add); Check(sent.Count - before == 1);
            }
            Check(sent.Count == 100 && !s.IsRunning && s.ExecutionStopReason == "");
        });
        test("no-gap stop removes pending rows", () =>
        {
            var s = Start("/echo A\n/echo B"); var sent = new List<string>();
            s.Tick(0, sent.Add); s.Stop(); s.Tick(100, sent.Add); Check(sent.Count == 1 && !s.IsRunning);
        });
        test("no-gap reentrant stop and restart protect replacement snapshot", () =>
        {
            var s = Start("/echo old\n/echo unwanted"); var sent = new List<string>();
            s.Tick(0, command => { sent.Add(command); s.Stop(); Check(s.TryStart(Leaf("/echo new"), 1, out _, true)); });
            s.Tick(1, sent.Add); Check(sent.SequenceEqual(["/echo old", "/echo new"]) && !s.IsRunning);
        });
        test("no-gap dispatch exception stops remaining commands", () =>
        {
            var s = Start("/echo A\n/echo B"); var threw = false;
            try { s.Tick(0, _ => throw new Exception("send failed")); } catch (InvalidOperationException) { threw = true; }
            Check(threw && !s.IsRunning); s.Tick(1, _ => throw new Exception("unexpected retry"));
        });
        test("invalid clocks still stop and reject starts", () =>
        {
            var s = new MacroSequence(); Check(!s.TryStart(Leaf("/echo A"), double.NaN, out _, true));
            s = Start("/echo A", 10); s.Tick(9, _ => throw new Exception("unexpected send"));
            Check(!s.IsRunning && s.ExecutionStopReason.Contains("时钟"));
        });
        test("executor always uses zero interval without configuration", () =>
        {
            var now = 0.0;
            using var executor = new MacroExecutor(new Configuration(), () => now);
            executor.Start(Leaf("/echo first\n/echo second\n/echo last"));
            Plugin.Framework.Tick(); Check(executor.ExecutedLines == 1);
            now = 0.001; Plugin.Framework.Tick(); Check(executor.ExecutedLines == 2);
            now = 0.002; Plugin.Framework.Tick(); Check(!executor.IsRunning);
        });
        test("countdown-started macro inherits no-gap", () =>
        {
            var macro = Leaf("/echo first\n/echo second\n/echo last");
            var c = new Configuration { CountdownTriggerEnabled = true,
                CountdownMacroId = macro.Id, Macros = [macro] };
            var now = 0.0; var sample = new CountdownSample(true, 100, false, 0);
            using var executor = new MacroExecutor(c, () => now);
            using var trigger = new CountdownTrigger(c, executor, () => sample, () => now);
            Plugin.Framework.Tick(); sample = sample with { Active = true, Remaining = 3 };
            now = 0.1; Plugin.Framework.Tick();
            sample = sample with { Remaining = 2 }; now = 1.1; Plugin.Framework.Tick();
            sample = sample with { Remaining = 1 }; now = 2.1; Plugin.Framework.Tick();
            sample = sample with { Active = false, Remaining = 0 }; now = 3.1;
            Plugin.ChatGui.Emit(CountdownObserver.Completed); Plugin.Framework.Tick();
            Check(executor.IsRunning);
            now = 3.11; Plugin.Framework.Tick(); Check(executor.ExecutedLines == 1);
            now = 3.12; Plugin.Framework.Tick(); Check(executor.ExecutedLines == 2);
            now = 3.13; Plugin.Framework.Tick(); Check(!executor.IsRunning);
        });
        foreach (var hz in new[] { 144, 60, 30, 15, 10 })
            test($"117 rows no-gap flat/group equivalence at {hz} Hz with no shortened waits", () =>
            {
                var leaf = TimingFixture.Create(); var lines = MacroSequence.PrepareLines(leaf.Commands);
                var group = new MacroEntry { IsGroup = true, Children = lines.Chunk(15).Select(chunk => Leaf(string.Join('\n', chunk))).ToList() };
                List<(string Command, double At)> Run(MacroEntry macro)
                {
                    var s = new MacroSequence(); Check(s.TryStart(macro, 0, out _, true));
                    var rows = new List<(string, double)>();
                    for (var frame = 0; frame <= hz * 300 && s.IsRunning; frame++)
                    {
                        var at = frame / (double)hz; var before = rows.Count;
                        s.Tick(at, command => rows.Add((command, at))); Check(rows.Count - before <= 1);
                    }
                    Check(!s.IsRunning && rows.Count == 117 && s.ExecutionStopReason == ""); return rows;
                }
                var flat = Run(leaf); Check(flat.SequenceEqual(Run(group)));
                for (var i = 1; i < flat.Count; i++)
                    Check(flat[i].At - flat[i - 1].At + 1e-9 >= Math.Max(0, TimingFixture.Waits[i - 1]));
            });
    }
}
