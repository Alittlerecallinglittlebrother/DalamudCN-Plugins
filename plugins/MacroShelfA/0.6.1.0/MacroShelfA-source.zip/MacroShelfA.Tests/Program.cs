using System.Text.Json;
using MacroShelfA;
using MacroShelfA.Runtime;

var passed = 0;
void Test(string name, Action action)
{
    action(); passed++; Console.WriteLine("PASS " + name);
}
void Check(bool condition, string message = "assertion failed")
{
    if (!condition) throw new InvalidOperationException(message);
}
MacroEntry Leaf(string name, string commands = "/echo test") => new() { Name = name, Commands = commands };
MacroEntry Group(params MacroEntry[] children) => new() { Name = "总宏", IsGroup = true, Children = [.. children] };
MacroSequence Start(MacroEntry entry)
{
    var s = new MacroSequence(); Check(s.TryStart(entry, 0, out var error), error); return s;
}

Test("A-B-C-D order and all children exceed 15 total lines", () =>
{
    var s = Start(Group(Enumerable.Range(0, 4).Select(i => Leaf($"宏{(char)('A'+i)}", string.Join('\n', Enumerable.Range(0, 15).Select(j => $"/echo {i}:{j}")))).ToArray()));
    Check(s.TotalLines == 60 && s.TotalChildren == 4);
    var sent = new List<string>();
    for (var i = 0; i < 61; i++) s.Tick(i, sent.Add);
    Check(sent.Count == 60 && sent[15] == "/echo 1:0" && sent[59] == "/echo 3:14" && !s.IsRunning);
});
Test("inline terminal wait holds across child boundary", () =>
{
    var s = Start(Group(Leaf("A", "/echo A <wait.3>"), Leaf("B", "/echo B <wait.1>")));
    var sent = new List<string>(); s.Tick(0, sent.Add); s.Tick(2.99, sent.Add);
    Check(sent.SequenceEqual(["/echo A"]) && s.CurrentChildIndex == 1 && s.IsRunning);
    s.Tick(3, sent.Add); Check(sent.SequenceEqual(["/echo A", "/echo B"]) && s.CurrentChildIndex == 2);
});
Test("standalone terminal decimal wait holds across boundary", () =>
{
    var s = Start(Group(Leaf("A", "/echo A\n/wait 0.5"), Leaf("B", "/echo B")));
    var sent = new List<string>(); s.Tick(0, sent.Add); s.Tick(0.15, sent.Add); s.Tick(0.64, sent.Add);
    Check(sent.Count == 1); s.Tick(0.66, sent.Add); Check(sent.Count == 2);
});
Test("final wait remains active and cancellable", () =>
{
    var s = Start(Leaf("A", "/echo A <wait.120>")); s.Tick(0, _ => { }); s.Tick(119, _ => { });
    Check(s.IsRunning && s.RemainingLines == 0 && s.RemainingWait(119) == 1); s.Stop();
    Check(!s.IsRunning); s.Tick(130, _ => throw new Exception("unexpected send"));
});
Test("natural completion occurs after final wait", () =>
{
    var s = Start(Leaf("A", "/wait 3")); s.Tick(0, _ => { }); s.Tick(2.99, _ => { }); Check(s.IsRunning);
    s.Tick(3, _ => { }); Check(!s.IsRunning);
});
Test("stop clears whole chain, not just current child", () =>
{
    var s = Start(Group(Leaf("A", "/echo A <wait.3>"), Leaf("B")));
    var sent = new List<string>(); s.Tick(0, sent.Add); s.Stop(); s.Tick(100, sent.Add); Check(sent.Count == 1);
});
Test("second start cannot replace active chain", () =>
{
    var s = Start(Leaf("original", "/echo original")); Check(!s.TryStart(Leaf("new"), 1, out _));
    var sent = new List<string>(); s.Tick(1, sent.Add); Check(sent.SequenceEqual(["/echo original"]));
});
Test("full preflight refuses invalid later child before any send", () =>
{
    var s = new MacroSequence(); Check(!s.TryStart(Group(Leaf("A"), Leaf("B", "not a command")), 0, out var e));
    Check(e.Contains("B") && !s.IsRunning && s.TotalLines == 0);
});
Test("empty groups and empty children fail clearly", () =>
{
    var s = new MacroSequence(); Check(!s.TryStart(Group(), 0, out _));
    Check(!s.TryStart(Group(Leaf("empty", "# comments\n  ")), 0, out _));
});
Test("16-line child rejected, nested groups rejected", () =>
{
    var s = new MacroSequence(); Check(!s.TryStart(Leaf("A", string.Join('\n', Enumerable.Repeat("/echo A", 16))), 0, out _));
    Check(!s.TryStart(Group(Group(Leaf("A"))), 0, out _));
});
Test("running snapshot unaffected by edits/reorder/removal", () =>
{
    var g = Group(Leaf("A", "/echo A <wait.1>"), Leaf("B", "/echo B <wait.1>")); var s = Start(g);
    g.Children[1].Name = "changed"; g.Children[1].Commands = "/echo changed"; g.Children.Clear();
    var sent = new List<string>(); s.Tick(0, sent.Add); s.Tick(1, sent.Add);
    Check(sent.SequenceEqual(["/echo A", "/echo B"]) && s.CurrentChildName == "B");
});
Test("send exception stops remaining children", () =>
{
    var s = Start(Group(Leaf("A"), Leaf("B")));
    try { s.Tick(0, _ => throw new Exception("host error")); throw new Exception("missing exception"); }
    catch (InvalidOperationException e) { Check(e.Message.Contains("A") && e.Message.Contains("host error")); }
    Check(!s.IsRunning); s.Tick(100, _ => throw new Exception("unexpected send"));
});
Test("reentrant stop from plugin command never resumes", () =>
{
    var s = Start(Group(Leaf("A"), Leaf("B"))); s.Tick(0, _ => s.Stop());
    Check(!s.IsRunning && s.ExecutedLines == 0);
});
Test("lag emits only one command and uses actual dispatch time", () =>
{
    var s = Start(Leaf("A", "/echo A <wait.3>\n/echo B\n/echo C")); var sent = new List<string>();
    s.Tick(100, sent.Add); s.Tick(101, sent.Add); Check(sent.Count == 1);
    s.Tick(103, sent.Add); Check(sent.Count == 2);
});
Test("CRLF comments and fractional waits", () =>
{
    var s = Start(Leaf("A", " # note\r\n/echo A <wait.0.25>\r/wait 0.1\n/echo B"));
    var sent = new List<string>(); s.Tick(0, sent.Add); s.Tick(0.24, sent.Add); Check(s.ExecutedLines == 1);
    s.Tick(0.25, sent.Add); s.Tick(0.36, sent.Add); Check(sent.SequenceEqual(["/echo A", "/echo B"]));
});
Test("huge wait number and double-slash commands rejected", () =>
{
    var s = new MacroSequence(); Check(!s.TryStart(Leaf("A", "/wait " + new string('9', 400)), 0, out _));
    Check(!s.TryStart(Leaf("A", "//echo test"), 0, out _));
});
Test("zero wait has floor and oversized wait is capped", () =>
{
    var s = Start(Leaf("A", "/wait 0")); s.Tick(0, _ => { }); Check(s.RemainingWait(0) == 0.01);
    s.Stop(); Check(s.TryStart(Leaf("A", "/wait 999999"), 0, out _)); s.Tick(0, _ => { }); Check(s.RemainingWait(0) == 86400);
});
Test("old v3 configuration migrates without losing originals", () =>
{
    var config = JsonSerializer.Deserialize<Configuration>("""{"Version":3,"ShowFloatingLauncher":false,"Macros":[{"Id":"old","Name":"旧宏","Group":"生产","Commands":"/echo old","Pinned":true}]}""")!;
    config.Normalize(); Check(config.Version == 8 && !config.ShowFloatingLauncher && config.Macros[0].Id == "old");
    Check(!config.Macros[0].IsGroup && config.Macros[0].Commands == "/echo old" && config.Macros[0].Pinned);
});
Test("CRUD children, sibling order and independent clone IDs", () =>
{
    var c = new Configuration(); var g = c.AddMacro(true)!; var b = c.AddChild(g)!; b.Name = "B";
    var d = c.Duplicate(b)!; Check(g.Children.Count == 3 && b.Id != d.Id);
    c.Move(d, -1); Check(g.Children[1] == d); c.Remove(d); Check(g.Children.Count == 2);
    var copy = c.Duplicate(g)!; Check(copy.Children.Count == 2 && copy.Children[0].Id != g.Children[0].Id);
    copy.Children[0].Commands = "/echo changed"; Check(g.Children[0].Commands == "");
    c.Remove(g); Check(c.Macros.Count == 1 && c.Macros[0] == copy);
});
Test("copy existing macro never changes original", () =>
{
    var c = new Configuration(); var original = c.AddMacro()!; original.Commands = "/echo original";
    var g = c.AddMacro(true)!; var child = c.AddChild(g, original)!; child.Commands = "/echo child";
    Check(original.Commands == "/echo original" && child.Id != original.Id && c.FindParent(child) == g);
});
Test("entry and per-group limits reject additions without removing data", () =>
{
    var c = new Configuration { Macros = Enumerable.Range(0, 200).Select(i => Leaf(i.ToString())).ToList() };
    Check(c.AddMacro() == null && c.AddMacro(true) == null && c.Duplicate(c.Macros[0]) == null && c.CountEntries() == 200);
    c = new Configuration(); var g = c.AddMacro(true)!;
    while (g.Children.Count < 64) Check(c.AddChild(g) != null);
    Check(c.AddChild(g) == null && c.Duplicate(g.Children[0]) == null);
});
Test("normalization repairs duplicate IDs and null children", () =>
{
    var g = Group(Leaf("A"), Leaf("B")); g.Children[0].Id = g.Id; g.Children[1].Id = g.Id;
    g.Children.Add(null!); var c = new Configuration { Macros = [g], FloatingLauncherSize = float.NaN };
    c.Normalize(); Check(c.Macros.Count == 1 && g.Children.Count == 2);
    Check(new[] {g.Id, g.Children[0].Id, g.Children[1].Id}.Distinct().Count() == 3 && c.FloatingLauncherSize == 56);
});
Test("v1 export import is backward compatible", () =>
{
    Check(ConfigurationExchange.TryImport("""{"Format":"MacroShelfA","Version":1,"BetterWaitEnabled":true,"Macros":[{"Name":"老宏","Commands":"/echo old"}]}""", out var imported, out _));
    Check(imported.Macros.Count == 1 && !imported.Macros[0].IsGroup);
});
Test("current group export round-trip preserves order names settings", () =>
{
    var g = Group(Leaf("宏A", "/echo A <wait.3>"), Leaf("宏B", "/echo B")); g.Group = "制作"; g.Pinned = true;
    var c = new Configuration { Macros = [g], BetterWaitEnabled = false };
    Check(ConfigurationExchange.TryImport(ConfigurationExchange.Export(c), out var data, out var error), error);
    Check(data.CountEntries() == 3 && data.Macros[0].IsGroup && data.Macros[0].Group == "制作" && data.Macros[0].Pinned);
    Check(data.Macros[0].Children[1].Name == "宏B" && data.Macros[0].Id != g.Id && !data.BetterWaitEnabled);
});
Test("actual Newtonsoft persistence round-trip retains hierarchy", () =>
{
    var c = new Configuration { Macros = [Group(Leaf("A"), Leaf("B"))] }; c.Save();
    var reopened = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
    reopened.Normalize(); Check(reopened.Macros[0].Children[1].Id == c.Macros[0].Children[1].Id);
    Check(reopened.Macros[0].Children[1].Commands == "/echo test");
});
Test("import rejects nested groups nulls and future format", () =>
{
    foreach (var json in new[] {
        """{"Format":"MacroShelfA","Version":2,"Macros":[null]}""",
        """{"Format":"MacroShelfA","Version":5,"Macros":[{}]}""",
        """{"Format":"MacroShelfA","Version":2,"Macros":[{"IsGroup":true,"Children":[{"IsGroup":true}]}]}""",
        """{"Format":"MacroShelfA","Version":2,"Macros":[{"Children":[{}]}]}""" })
        Check(!ConfigurationExchange.TryImport(json, out _, out _));
});
Test("executor login gate, logout cancellation and unsubscribe", () =>
{
    using (var exec = new MacroExecutor(new Configuration()))
    {
        Plugin.ClientState.IsLoggedIn = false; exec.Start(Leaf("A")); Check(!exec.IsRunning);
        Plugin.ClientState.IsLoggedIn = true; exec.Start(Group(Leaf("A", "/echo A <wait.10>"), Leaf("B")));
        Plugin.Framework.Tick(); Check(exec.IsRunning && Plugin.CommandManager.Sent.Last() == "/echo A");
        Plugin.ClientState.IsLoggedIn = false; Plugin.Framework.Tick(); Check(!exec.IsRunning);
    }
    Plugin.ClientState.IsLoggedIn = true; Check(Plugin.Framework.Subscribers == 0);
});
Test("individual child execution never starts siblings", () =>
{
    var g = Group(Leaf("A", "/echo A"), Leaf("B", "/echo B")); var s = Start(g.Children[1]);
    var sent = new List<string>(); s.Tick(0, sent.Add); s.Tick(1, sent.Add);
    Check(sent.SequenceEqual(["/echo B"]) && !s.IsRunning);
});
Test("import rejects over-total and over-child limits", () =>
{
    var c = new Configuration { Macros = Enumerable.Range(0, 201).Select(i => Leaf(i.ToString())).ToList() };
    Check(!ConfigurationExchange.TryImport(ConfigurationExchange.Export(c), out _, out _));
    c.Macros = [Group(Enumerable.Range(0, 65).Select(i => Leaf(i.ToString())).ToArray())];
    Check(!ConfigurationExchange.TryImport(ConfigurationExchange.Export(c), out _, out _));
});
Test("stopped execution can restart from first child", () =>
{
    var g = Group(Leaf("A", "/echo A"), Leaf("B", "/echo B")); var s = Start(g); var sent = new List<string>();
    s.Tick(0, sent.Add); s.Stop(); Check(s.TryStart(g, 5, out _)); s.Tick(5, sent.Add);
    Check(sent.SequenceEqual(["/echo A", "/echo A"]) && s.CurrentChildIndex == 1);
});
Test("migration snapshot is created once and never overwritten", () =>
{
    var directory = Path.Combine(args.LastOrDefault() ?? AppContext.BaseDirectory, "migration-fixture");
    directory = Path.GetFullPath(directory);
    var c = new Configuration { Version = 3, Macros = [Leaf("original")] };
    ConfigurationBackup.BeforeGroupMigration(c, directory);
    var file = Path.Combine(directory, "config-before-groups-v4.json");
    var original = File.ReadAllText(file); c.Macros[0].Name = "changed";
    ConfigurationBackup.BeforeGroupMigration(c, directory);
    Check(File.ReadAllText(file) == original && original.Contains("original"));
});
Test("long macro switch defaults off and 16-line error names setting", () =>
{
    Check(!new Configuration().AllowLongMacros);
    var s = new MacroSequence();
    Check(!s.TryStart(Leaf("16行", string.Join('\n', Enumerable.Repeat("/echo A", 16))), 0, out var error));
    Check(error.Contains("解除 15 行限制"));
});
Test("enabled switch runs 1000 lines in one standalone macro", () =>
{
    var macro = Leaf("1000行", string.Join('\n', Enumerable.Range(1, 1000).Select(i => $"/echo {i} 中文长宏测试")));
    Check(macro.Commands.Length > 8000);
    var s = new MacroSequence(); Check(s.TryStart(macro, 0, out var error, true), error);
    var sent = new List<string>(); for (var i = 0; i <= 1000; i++) s.Tick(i, sent.Add);
    Check(sent.Count == 1000 && sent[999].Contains("1000") && !s.IsRunning);
});
Test("enabled groups chain 30-line children and honor final waits", () =>
{
    var a = Leaf("A", string.Join('\n', Enumerable.Range(0, 29).Select(i => "/echo A")) + "\n/echo A-end <wait.3>");
    var b = Leaf("B", string.Join('\n', Enumerable.Repeat("/echo B", 30)));
    var s = new MacroSequence(); Check(s.TryStart(Group(a, b), 0, out _, true));
    var sent = new List<string>(); for (var i = 0; i < 30; i++) s.Tick(i, sent.Add);
    s.Tick(31.99, sent.Add); Check(sent.Count == 30 && s.CurrentChildIndex == 1);
    s.Tick(32, sent.Add); Check(sent.Count == 31 && s.CurrentChildName == "B");
    for (var i = 33; i <= 62; i++) s.Tick(i, sent.Add);
    Check(sent.Count == 60 && !s.IsRunning);
});
Test("switch off keeps long text intact through save and reload", () =>
{
    var text = string.Join('\n', Enumerable.Range(0, 1000).Select(i => $"/echo 完整内容第{i}行"));
    var c = new Configuration { AllowLongMacros = true, Macros = [Leaf("长宏", text)] }; c.Save();
    c.AllowLongMacros = false; c.Save();
    var restored = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
    restored.Normalize(); Check(!restored.AllowLongMacros && restored.Macros[0].Commands == text);
    var s = new MacroSequence(); Check(!s.TryStart(restored.Macros[0], 0, out _));
});
Test("persistent switch survives reload", () =>
{
    var c = new Configuration { AllowLongMacros = true }; c.Save();
    Check(Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!.AllowLongMacros);
});
Test("old v4 config migrates with switch off and content unchanged", () =>
{
    var c = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>("""{"Version":4,"Macros":[{"Name":"old","Commands":"/echo old"}]}""")!;
    c.Normalize(); Check(c.Version == 8 && !c.AllowLongMacros && c.Macros[0].Commands == "/echo old");
});
Test("current export preserves enabled switch and long text exactly", () =>
{
    var text = string.Join('\n', Enumerable.Repeat("/echo 中文长宏 <wait.0.1>", 1000));
    var c = new Configuration { AllowLongMacros = true, Macros = [Group(Leaf("长子宏", text))] };
    Check(ConfigurationExchange.TryImport(ConfigurationExchange.Export(c), out var imported, out var error), error);
    Check(imported.AllowLongMacros && imported.Macros[0].Children[0].Commands == text);
});
Test("old v1 and v2 imports never enable long macros", () =>
{
    foreach (var version in new[] { 1, 2 })
    {
        var json = "{\"Format\":\"MacroShelfA\",\"Version\":" + version + ",\"AllowLongMacros\":true,\"Macros\":[{\"Commands\":\"/echo old\"}]}";
        Check(ConfigurationExchange.TryImport(json, out var imported, out _)); Check(!imported.AllowLongMacros);
    }
});
Test("64000-character boundary accepted, 64001 refused without truncation", () =>
{
    var macro = Leaf("容量边界", "/echo " + new string('中', Configuration.MaxCommandLength - 6));
    var s = new MacroSequence(); Check(s.TryStart(macro, 0, out _, true)); s.Stop();
    macro.Commands += "文"; Check(!s.TryStart(macro, 0, out var error, true) && error.Contains("字符"));
    var c = new Configuration { Macros = [macro] }; c.Normalize(); Check(macro.Commands.Length == 64001);
});
Test("oversized import rejected instead of silently cutting content", () =>
{
    var c = new Configuration { AllowLongMacros = true, Macros = [Leaf("过长", "/echo " + new string('x', Configuration.MaxCommandLength))] };
    Check(!ConfigurationExchange.TryImport(ConfigurationExchange.Export(c), out var imported, out var error));
    Check(error.Contains("字符") && imported.Macros.Count == 0);
});
Test("enabled mode still rejects empty invalid and nested macros", () =>
{
    var s = new MacroSequence();
    Check(!s.TryStart(Leaf("空", ""), 0, out _, true));
    Check(!s.TryStart(Leaf("无效", "bad"), 0, out _, true));
    Check(!s.TryStart(Group(Group(Leaf("嵌套"))), 0, out _, true));
});
Test("adapter uses setting at start and keeps active snapshot after disabling", () =>
{
    var c = new Configuration(); var macro = Leaf("60行", string.Join('\n', Enumerable.Repeat("/echo long", 60)));
    using var exec = new MacroExecutor(c); exec.Start(macro); Check(!exec.IsRunning);
    c.AllowLongMacros = true; exec.Start(macro); Check(exec.IsRunning && exec.TotalLines == 60);
    c.AllowLongMacros = false; Plugin.Framework.Tick(); Check(exec.IsRunning && exec.TotalLines == 60);
    exec.Stop(false); exec.Start(macro); Check(!exec.IsRunning);
});
Test("long-chain stop removes all remaining lines", () =>
{
    var s = new MacroSequence(); var macro = Leaf("长宏", string.Join('\n', Enumerable.Repeat("/echo long", 1000)));
    Check(s.TryStart(macro, 0, out _, true)); var sent = new List<string>();
    s.Tick(0, sent.Add); s.Stop(); s.Tick(10000, sent.Add); Check(sent.Count == 1 && !s.IsRunning);
});
Test("v5 migration backup preserves old group config without overwrite", () =>
{
    var directory = Path.GetFullPath(Path.Combine(args.LastOrDefault() ?? AppContext.BaseDirectory, "long-migration-fixture"));
    var c = new Configuration { Version = 4, Macros = [Group(Leaf("original-long"))] };
    ConfigurationBackup.BeforeLongMacroMigration(c, directory);
    var file = Path.Combine(directory, "config-before-long-macros-v5.json");
    var original = File.ReadAllText(file); c.Macros.Clear();
    ConfigurationBackup.BeforeLongMacroMigration(c, directory); Check(File.ReadAllText(file) == original && original.Contains("original-long"));
});
CountdownTests.Run(Test, Check);
IntervalTests.Run(Test, Check);
Console.WriteLine($"RESULT {passed}/{passed} checks passed; native game dispatch is mocked, not in-game verification.");
if (args.Contains("--ui")) RuntimeUi.Run(args.Last());






