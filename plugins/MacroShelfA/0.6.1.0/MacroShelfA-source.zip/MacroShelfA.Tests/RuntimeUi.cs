using System.Numerics;
using System.Reflection;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;

internal static unsafe class RuntimeUi
{
    public static void Run(string output)
    {
        Directory.CreateDirectory(output);
        using var native = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory, "cimgui.dll"));
        ImGui.InitApi(native);
        var context = ImGui.CreateContext();
        try
        {
            var io = ImGui.GetIO(); io.IniFilename = null; io.DeltaTime = 1f / 60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 17, default, io.Fonts.GetGlyphRangesChineseFull());
            if (!io.Fonts.Build()) throw new Exception("font atlas failed");
            ImGui.StyleColorsDark();
            var c = new Configuration { Macros = [new MacroEntry
            {
                Name = "生产流程 · 完整制作", IsGroup = true, Group = "生产制作", Pinned = true,
                Children = [new() { Name = "宏A · 准备", Commands = "/echo 准备开始 <wait.3>" },
                    new() { Name = "宏B · 加工", Commands = "/echo 开始加工 <wait.3>" },
                    new() { Name = "宏C · 收尾", Commands = "/echo 开始收尾 <wait.3>" },
                    new() { Name = "宏D · 完成", Commands = "/echo 全部完成" }],
            }, new MacroEntry { Name = "打招呼", Group = "日常", Commands = "/echo 大家好" }] };
            var executionTime = 0.0;
            using var executor = new MacroExecutor(c, () => executionTime);
            var countdownSample = new CountdownSample(true, 100, false, 0);
            var countdownTime = 0.0;
            using var countdown = new CountdownTrigger(c, executor, () => countdownSample, () => countdownTime);
            using var window = new MainWindow(c, executor, new BetterWaitPatch(), countdown);
            Frame(window, 940, 760); Frame(window, 940, 760);
            SoftwareRenderer.Save(Path.Combine(output, "run-panel-940.png"));
            Frame(window, 720, 500); Frame(window, 720, 500);
            SoftwareRenderer.Save(Path.Combine(output, "run-panel-720.png"));
            Frame(window, 1200, 900); Frame(window, 1200, 900);
            SoftwareRenderer.Save(Path.Combine(output, "run-panel-1200.png"));
            // Native mouse interaction, not a reconstructed HTML mockup.
            Frame(window, 940, 760); Frame(window, 940, 760);
            Click(window, 132, 159);
            SoftwareRenderer.Save(Path.Combine(output, "editor-click.png"));
            Click(window, 90, 456);
            CheckSelected(window, c.Macros[0].Children[1]);
            io.AddMousePosEvent(-100, -100); Frame(window);
            SoftwareRenderer.Save(Path.Combine(output, "child-editor-940.png"));
            var moving = c.Macros[0].Children[1];
            Click(window, 320, 685);
            if (c.Macros[0].Children[2] != moving) throw new Exception("native move down failed");
            Click(window, 270, 685);
            if (c.Macros[0].Children[1] != moving) throw new Exception("native move up failed");
            Console.WriteLine("PASS native child reorder controls preserve identity");
            Frame(window, 720, 500); Frame(window, 720, 500);
            SoftwareRenderer.Save(Path.Combine(output, "child-editor-720.png"));
            Frame(window, 940, 760); Frame(window, 940, 760);
            Click(window, 100, 406);
            CheckSelected(window, c.Macros[0]);
            Click(window, 108, 231);
            if (c.Macros.Count != 3 || !c.Macros[2].IsGroup || c.Macros[2].Children.Count != 1)
                throw new Exception("native new group failed");
            CheckSelected(window, c.Macros[2]);
            Click(window, 400, 256);
            io.AddKeyEvent(ImGuiKey.ModCtrl, true); io.AddKeyEvent(ImGuiKey.A, true); Frame(window);
            io.AddKeyEvent(ImGuiKey.A, false); io.AddKeyEvent(ImGuiKey.ModCtrl, false); Frame(window);
            foreach (var ch in "自定义总按钮") io.AddInputCharacter(ch); Frame(window);
            Click(window, 460, 194);
            if (c.Macros[2].Name != "自定义总按钮") throw new Exception("native rename failed");
            var reopened = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
            if (reopened.Macros[2].Name != "自定义总按钮") throw new Exception("native rename not persisted");
            Click(window, 280, 425);
            if (c.Macros[2].Children.Count != 2) throw new Exception("native add child failed");
            CheckSelected(window, c.Macros[2].Children[1]);
            Console.WriteLine("PASS native mouse selects child, creates group, renames with keyboard, persists and adds child");
            // Preview the active-chain state. Dispatch is mocked, and no game process is used.
            executor.Start(c.Macros[0]); Plugin.Framework.Tick();
            Click(window, 42, 234);
            Frame(window); Frame(window);
            SoftwareRenderer.Save(Path.Combine(output, "running-chain-940.png"));
            Click(window, 196, 42);
            if (executor.IsRunning) throw new Exception("native stop entire chain failed");
            Console.WriteLine("PASS native stop entire chain button");
            ImGuiHelpers.GlobalScale = 1.5f;
            Frame(window, 1080, 750); Frame(window, 1080, 750);
            SoftwareRenderer.Save(Path.Combine(output, "run-panel-scale150.png"));
            ImGuiHelpers.GlobalScale = 1;
            Frame(window); Frame(window);
            ClickRaw(window, 20, 152);
            if (!c.AllowLongMacros) throw new Exception("native long macro toggle did not enable");
            var saved = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
            if (!saved.AllowLongMacros) throw new Exception("native long macro toggle was not persisted");
            Click(window, 132, 159);
            Click(window, 108, 268);
            var longMacro = c.Macros.Last();
            CheckSelected(window, longMacro);
            if (longMacro.IsGroup) throw new Exception("native standalone creation failed");
            longMacro.Name = "长宏测试 · 400 行";
            var longText = string.Join('\n', Enumerable.Range(1, 400).Select(i => $"/echo 第{i:000}行 中文长宏编辑器测试 <wait.0.1>"));
            if (longText.Length <= 8000) throw new Exception("test text not long enough");
            ClickRaw(window, 460, 530);
            foreach (var ch in longText) io.AddInputCharacter(ch);
            Frame(window); Frame(window);
            if (longMacro.Commands != longText) throw new Exception($"native text input truncated: {longMacro.Commands.Length}/{longText.Length}");
            io.AddMousePosEvent(-100, -100); Frame(window);
            SoftwareRenderer.Save(Path.Combine(output, "long-macro-enabled-940.png"));
            Frame(window, 720, 500); Frame(window, 720, 500);
            SoftwareRenderer.Save(Path.Combine(output, "long-macro-enabled-720.png"));
            Frame(window); Frame(window);
            ClickRaw(window, 289, 650);
            if (!executor.IsRunning || executor.TotalLines != 400) throw new Exception("native run button did not start all 400 lines");
            ClickRaw(window, 20, 226);
            if (c.AllowLongMacros || !executor.IsRunning || longMacro.Commands != longText)
                throw new Exception("native toggle-off changed active snapshot or discarded text");
            ClickRaw(window, 196, 42);
            if (executor.IsRunning) throw new Exception("native stop failed for long macro");
            executor.Start(longMacro);
            if (executor.IsRunning || !Plugin.ChatGui.Errors.Last().Contains("解除 15 行限制"))
                throw new Exception("disabled switch did not enforce limit on next start");
            io.AddMousePosEvent(-100, -100); Frame(window);
            SoftwareRenderer.Save(Path.Combine(output, "long-macro-disabled-940.png"));
            Console.WriteLine("PASS native toggle persisted, 400-line Chinese input >8000 chars retained, run button starts full macro, toggle-off preserves active run and text, stop and next-run limit enforced");
            ClickRaw(window, 180, 196);
            Frame(window); Frame(window);
            SoftwareRenderer.Save(Path.Combine(output, "countdown-disabled-940.png"));
            Frame(window, 720, 500); Frame(window, 720, 500);
            SoftwareRenderer.Save(Path.Combine(output, "countdown-disabled-720.png"));
            Frame(window); Frame(window);
            ClickRaw(window, 300, 316);
            SoftwareRenderer.Save(Path.Combine(output, "countdown-target-options-940.png"));
            ClickRaw(window, 120, 377);
            if (c.CountdownMacroId != c.Macros[0].Id) throw new Exception("native countdown target selection failed");
            ClickRaw(window, 20, 354);
            if (!c.CountdownTriggerEnabled) throw new Exception("native countdown enable failed");
            var countdownSaved = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
            if (!countdownSaved.CountdownTriggerEnabled || countdownSaved.CountdownMacroId != c.Macros[0].Id)
                throw new Exception("native countdown binding not persisted");
            Plugin.Framework.Tick(); // Observe idle after enabling, then a fresh countdown.
            countdownSample = countdownSample with { Active = true, Remaining = 5 };
            countdownTime += 0.1; Plugin.Framework.Tick();
            io.AddMousePosEvent(-100, -100); Frame(window); Frame(window);
            SoftwareRenderer.Save(Path.Combine(output, "countdown-armed-940.png"));
            Frame(window, 720, 500); Frame(window, 720, 500);
            SoftwareRenderer.Save(Path.Combine(output, "countdown-armed-720.png"));
            ImGuiHelpers.GlobalScale = 1.5f;
            Frame(window, 1080, 750); Frame(window, 1080, 750);
            SoftwareRenderer.Save(Path.Combine(output, "countdown-scale150.png"));
            ImGuiHelpers.GlobalScale = 1;
            Frame(window); Frame(window);
            countdownSample = countdownSample with { Active = false, Remaining = 0 };
            Plugin.ChatGui.Emit(CountdownObserver.Completed);
            countdownTime += 0.1; Plugin.Framework.Tick();
            if (!executor.IsRunning || executor.TotalChildren != 4) throw new Exception("bound countdown group did not start");
            Frame(window); Frame(window);
            SoftwareRenderer.Save(Path.Combine(output, "countdown-triggered-940.png"));
            ClickRaw(window, 196, 42);
            if (executor.IsRunning) throw new Exception("native stop failed for countdown-started macro");
            ClickRaw(window, 20, 354);
            if (c.CountdownTriggerEnabled) throw new Exception("native countdown disable failed");
            Console.WriteLine("PASS native event tab, target dropdown, persisted enable, countdown status, exact-event group start and stop/disable");

            // Real import UI path must preserve a local binding on append and clear it on replacement.
            c.CountdownTriggerEnabled = true; c.Save();
            var importField = typeof(MainWindow).GetField("importText", BindingFlags.NonPublic | BindingFlags.Instance)!;
            var importMethod = typeof(MainWindow).GetMethod("ImportConfiguration", BindingFlags.NonPublic | BindingFlags.Instance)!;
            importField.SetValue(window, ConfigurationExchange.Export(new Configuration { Macros = [new() { Name = "导入宏", Commands = "/echo imported" }] }));
            var boundId = c.CountdownMacroId;
            importMethod.Invoke(window, [false]);
            if (!c.CountdownTriggerEnabled || c.CountdownMacroId != boundId) throw new Exception("append import changed local binding");
            importMethod.Invoke(window, [true]);
            if (c.CountdownTriggerEnabled || c.CountdownMacroId != "") throw new Exception("replace import did not clear trigger");
            Console.WriteLine("PASS actual import path preserves binding on append and clears it on replacement");
            var immediateMacro = c.Macros[0];
            immediateMacro.Name = "默认零间隔测试";
            immediateMacro.Commands = "/echo first\n/echo second <wait.2>\n/echo last";
            c.AllowLongMacros = true; c.Save();
            ClickRaw(window, 40, 196);
            io.AddMousePosEvent(-100, -100); Frame(window); Frame(window);
            SoftwareRenderer.Save(Path.Combine(output, "zero-interval-default-940.png"));
            Frame(window, 720, 500); Frame(window, 720, 500);
            SoftwareRenderer.Save(Path.Combine(output, "zero-interval-default-720.png"));
            Frame(window, 1200, 900); Frame(window, 1200, 900);
            SoftwareRenderer.Save(Path.Combine(output, "zero-interval-default-1200.png"));
            ImGuiHelpers.GlobalScale = 1.5f;
            Frame(window, 1080, 750); Frame(window, 1080, 750);
            SoftwareRenderer.Save(Path.Combine(output, "zero-interval-scale150.png"));
            ImGuiHelpers.GlobalScale = 1;
            Frame(window); Frame(window);
            var errorCount = Plugin.ChatGui.Errors.Count;
            executor.Start(immediateMacro); Plugin.Framework.Tick();
            executionTime = 0.001; Plugin.Framework.Tick();
            if (!executor.IsRunning || executor.ExecutedLines != 2)
                throw new Exception("default zero gap did not reach production executor");
            executionTime = 2; Plugin.Framework.Tick();
            if (executor.ExecutedLines != 2) throw new Exception("explicit wait was shortened");
            executionTime = 5; Plugin.Framework.Tick();
            if (executor.IsRunning || Plugin.ChatGui.Errors.Count != errorCount)
                throw new Exception("retired late-abort behavior remains active");
            var savedJson = Plugin.PluginInterface.Json;
            if (savedJson.Contains("UseTimelineScheduling") || savedJson.Contains("RemoveDefaultInterval"))
                throw new Exception("retired settings still persisted");
            importField.SetValue(window, "{\"Format\":\"MacroShelfA\",\"Version\":4,\"UseTimelineScheduling\":true,\"RemoveDefaultInterval\":false,\"Macros\":[{\"Name\":\"旧配置\",\"Commands\":\"/echo old-first\\n/echo old-second\"}]}");
            importMethod.Invoke(window, [true]);
            executionTime = 6; executor.Start(c.Macros[0]); Plugin.Framework.Tick();
            executionTime = 6.001; Plugin.Framework.Tick();
            if (executor.IsRunning) throw new Exception("old imported option restored a default gap");
            Console.WriteLine("PASS no timing tab or switches; default zero interval, explicit waits, no late-abort and inert legacy flags in real import path");
            Console.WriteLine("PASS native ImGui frame rendering at 720x500, 940x760 and 1200x900 (game boundary mocked)");
        }
        catch { SoftwareRenderer.Save(Path.Combine(output, "ui-failure.png")); throw; }
        finally { ImGui.DestroyContext(context); }
    }
    private static void CheckSelected(MainWindow window, MacroEntry expected)
    {
        var actual = typeof(MainWindow).GetField("selectedMacro", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(window);
        if (!ReferenceEquals(actual, expected)) throw new Exception("native selection failed: " + expected.Name);
    }
    internal static void Frame(MainWindow window, int width = 940, int height = 760)
    {
        var io = ImGui.GetIO(); io.DisplaySize = new Vector2(width, height); io.DeltaTime = 1f / 60;
        ImGui.NewFrame();
        ImGui.SetNextWindowPos(Vector2.Zero, ImGuiCond.Always);
        ImGui.SetNextWindowSize(new Vector2(width, height), ImGuiCond.Always);
        ImGui.Begin("Macro Shelf-A###TestHost", ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoCollapse);
        window.Draw();
        ImGui.End(); ImGui.Render();
        if (ImGui.GetDrawData().TotalVtxCount < 100) throw new Exception("empty render");
    }
    internal static void Click(MainWindow window, float x, float y)
    {
        if (y >= 150 && y < 650) y += 37;
        ClickRaw(window, x, y);
    }
    internal static void ClickRaw(MainWindow window, float x, float y)
    {
        var io = ImGui.GetIO(); io.AddMousePosEvent(x, y); Frame(window);
        io.AddMouseButtonEvent(0, true); Frame(window);
        io.AddMouseButtonEvent(0, false); Frame(window); Frame(window);
    }
}






