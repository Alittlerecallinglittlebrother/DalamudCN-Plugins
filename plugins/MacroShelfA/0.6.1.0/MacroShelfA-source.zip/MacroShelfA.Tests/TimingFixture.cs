namespace MacroShelfA.Tests;

// Timing-only fixture: 117 lines / 77 explicit waits / 180 seconds. No user lyrics or commands.
internal static class TimingFixture
{
    internal static readonly double[] Waits = [-1, 4, -1, 2, 2, -1, 2, 2, 2, 6, 6, 1, 2, -1, 4, -1, 2, 2, -1, 2, 2, -1, 1, 1, -1, 1, -1, 2, -1, 2, -1, 2, -1, 1, -1, 2, 1, 1, -1, 2, -1, 5, -1, 1, 3, 2, 1, -1, 4, 1, -1, 3, -1, 4, -1, 4, 2, -1, 2, -1, 2, 4, 1, 1, -1, 3, 3, 3, 1, -1, 2, -1, 2, -1, 2, -1, 2, 2, -1, 2, -1, 2, -1, 4, 1, 2, -1, 1, 3, -1, 4, 2, 2, -1, 2, 3, -1, 2, 1, -1, 4, 2, -1, 4, -1, 2, 2, -1, 2, -1, 2, 4, 2, 2, 4, 2, -1];
    internal static MacroEntry Create() => new()
    {
        Name = "117 行演出节奏测试",
        Commands = string.Join('\n', Waits.Select((wait, i) => wait < 0
            ? $"/echo timing-{i + 1}" : $"/echo timing-{i + 1} <wait.{wait}>")),
    };
}
