using System;
using System.Collections.Generic;
using System.Linq;
using Dalamud.Configuration;

namespace MacroShelfA;

[Serializable]
public sealed class Configuration : IPluginConfiguration
{
    public const int MaxEntries = 200;
    public const int MaxChildren = 64;
    public const int MaxNameLength = 32;
    public const int MaxGroupLength = 24;
    public const int MaxCommandLength = 64_000;

    public int Version { get; set; } = 8;
    public bool BetterWaitEnabled { get; set; } = true;
    public bool AllowLongMacros { get; set; }
    public bool CountdownTriggerEnabled { get; set; }
    public string CountdownMacroId { get; set; } = string.Empty;
    public bool ShowFloatingLauncher { get; set; } = true;
    public bool LockFloatingLauncher { get; set; }
    public float FloatingLauncherSize { get; set; } = 56f;
    public List<MacroEntry> Macros { get; set; } = [];

    public int CountEntries() => Macros.Sum(m => 1 + (m.IsGroup ? m.Children.Count : 0));

    public MacroEntry? FindCountdownMacro() => Macros.FirstOrDefault(m => m.Id == CountdownMacroId);

    public void ClearCountdownBinding()
    {
        CountdownTriggerEnabled = false;
        CountdownMacroId = string.Empty;
    }

    internal static Configuration CreateDefault() => new()
    {
        Macros = [new MacroEntry
        {
            Name = "示例宏", Group = "示例",
            Commands = "/echo Macro Shelf-A 已就绪 <wait.1>\n/echo 请在编辑宏页面修改内容",
        }],
    };

    public void Normalize()
    {
        if (Version < 6) ClearCountdownBinding();
        if (Version < 3)
        {
            ShowFloatingLauncher = true;
            FloatingLauncherSize = 56f;
        }
        Macros ??= [];
        Macros.RemoveAll(m => m == null);
        if (Macros.Count(m => m.Id == CountdownMacroId) != 1) ClearCountdownBinding();
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var macro in Macros)
        {
            NormalizeEntry(macro, ids);
            macro.Children ??= [];
            macro.Children.RemoveAll(c => c == null);
            foreach (var child in macro.Children) NormalizeEntry(child, ids);
        }
        FloatingLauncherSize = float.IsFinite(FloatingLauncherSize)
            ? Math.Clamp(FloatingLauncherSize, 32f, 96f) : 56f;
        // A deleted target or ambiguous duplicate ID must never bind to a different macro by name.
        if (string.IsNullOrEmpty(CountdownMacroId) || FindCountdownMacro() == null) ClearCountdownBinding();
        Version = 8;
    }

    private static void NormalizeEntry(MacroEntry macro, HashSet<string> ids)
    {
        if (string.IsNullOrWhiteSpace(macro.Id) || !ids.Add(macro.Id))
        {
            do { macro.Id = Guid.NewGuid().ToString("N"); } while (!ids.Add(macro.Id));
        }
        macro.Name = Limit(macro.Name, MaxNameLength, macro.IsGroup ? "未命名宏组" : "未命名宏");
        macro.Group = Limit(macro.Group, MaxGroupLength, string.Empty);
        var commands = (macro.Commands ?? string.Empty).Replace("\r\n", "\n").Replace('\r', '\n');
        // Never silently discard saved commands, especially when the line-limit toggle is off.
        // Execution and import validate the size; oversized existing text remains editable.
        macro.Commands = commands;
    }

    public MacroEntry? AddMacro(bool isGroup = false)
    {
        if (CountEntries() + (isGroup ? 2 : 1) > MaxEntries) return null;
        var macro = new MacroEntry { IsGroup = isGroup, Name = isGroup ? "新宏组" : "新宏" };
        if (isGroup) macro.Children.Add(new MacroEntry { Name = "宏A" });
        Macros.Add(macro);
        Save();
        return macro;
    }

    public MacroEntry? AddChild(MacroEntry parent, MacroEntry? source = null)
    {
        if (!Macros.Contains(parent) || !parent.IsGroup || source?.IsGroup == true ||
            CountEntries() >= MaxEntries || parent.Children.Count >= MaxChildren) return null;
        var child = source?.Copy() ?? new MacroEntry
        {
            Name = parent.Children.Count < 26 ? $"宏{(char)('A' + parent.Children.Count)}" : $"子宏 {parent.Children.Count + 1}",
        };
        parent.Children.Add(child);
        Save();
        return child;
    }

    public MacroEntry? FindParent(MacroEntry entry) => Macros.FirstOrDefault(m => m.IsGroup && m.Children.Contains(entry));
    private List<MacroEntry>? FindSiblings(MacroEntry entry) => Macros.Contains(entry) ? Macros : FindParent(entry)?.Children;

    public MacroEntry? Duplicate(MacroEntry source)
    {
        var siblings = FindSiblings(source);
        var cost = 1 + (source.IsGroup ? source.Children.Count : 0);
        if (siblings == null || CountEntries() + cost > MaxEntries ||
            (siblings != Macros && siblings.Count >= MaxChildren)) return null;
        var copy = source.Clone();
        siblings.Insert(siblings.IndexOf(source) + 1, copy);
        Save();
        return copy;
    }

    public bool Remove(MacroEntry entry)
    {
        var removed = FindSiblings(entry)?.Remove(entry) == true;
        if (removed) Save();
        return removed;
    }

    public void Move(MacroEntry entry, int offset)
    {
        var siblings = FindSiblings(entry);
        if (siblings == null) return;
        var index = siblings.IndexOf(entry);
        var destination = index + offset;
        if (destination < 0 || destination >= siblings.Count) return;
        siblings.RemoveAt(index);
        siblings.Insert(destination, entry);
        Save();
    }

    public void Save()
    {
        Normalize();
        Plugin.PluginInterface.SavePluginConfig(this);
    }

    private static string Limit(string? value, int maxLength, string fallback)
    {
        var normalized = value?.Trim() ?? string.Empty;
        return normalized.Length == 0 ? fallback : normalized.Length <= maxLength ? normalized : normalized[..maxLength];
    }
}
