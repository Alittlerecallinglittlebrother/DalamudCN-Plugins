using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace MacroShelfA;

internal static class ConfigurationExchange
{
    internal const int MaximumEntries = Configuration.MaxEntries;
    internal const int MaximumJsonLength = 16_000_000;
    private const string FormatName = "MacroShelfA";
    private const int FormatVersion = 4;
    private static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true, WriteIndented = true, MaxDepth = 16,
    };

    public static string Export(Configuration configuration)
    {
        var json = JsonSerializer.Serialize(new ExchangeDocument
        {
            Format = FormatName, Version = FormatVersion,
            BetterWaitEnabled = configuration.BetterWaitEnabled,
            AllowLongMacros = configuration.AllowLongMacros,
            Macros = configuration.Macros.Select(ToExchange).ToList(),
        }, Options);
        if (json.Length > MaximumJsonLength) throw new InvalidOperationException("配置过大，无法导出。");
        return json;
    }

    private static ExchangeMacro ToExchange(MacroEntry macro) => new()
    {
        Name = macro.Name, Group = macro.Group, Commands = macro.Commands,
        Pinned = macro.Pinned, IsGroup = macro.IsGroup,
        Children = macro.Children.Select(ToExchange).ToList(),
    };

    public static bool TryImport(string json, out ImportedConfiguration imported, out string error)
    {
        imported = new(); error = string.Empty;
        if (string.IsNullOrWhiteSpace(json)) { error = "没有可导入的配置内容。"; return false; }
        if (json.Length > MaximumJsonLength) { error = "配置内容过大，已拒绝导入。"; return false; }
        try
        {
            var doc = JsonSerializer.Deserialize<ExchangeDocument>(json, Options);
            if (doc == null || doc.Format != FormatName) { error = "这不是 Macro Shelf-A 导出的配置。"; return false; }
            if (doc.Version is not (1 or 2 or 3 or FormatVersion))
            { error = $"不支持配置版本 {doc.Version}。支持版本 1、2、3、4。"; return false; }
            if (doc.Macros == null || doc.Macros.Count == 0)
            { error = "配置中没有可导入的宏。"; return false; }
            var count = 0;
            foreach (var macro in doc.Macros)
            {
                if (macro == null) { error = "配置包含无效条目。"; return false; }
                var children = macro.Children ?? [];
                if ((!macro.IsGroup && children.Count > 0) || children.Any(c => c == null || c.IsGroup || c.Children?.Count > 0))
                { error = "宏组只允许一层子宏，普通宏不能包含子宏。"; return false; }
                if (children.Count > Configuration.MaxChildren)
                { error = $"“{macro.Name}”超过每组 {Configuration.MaxChildren} 个子宏的上限。"; return false; }
                if ((macro.Commands?.Length ?? 0) > Configuration.MaxCommandLength ||
                    children.Any(c => (c.Commands?.Length ?? 0) > Configuration.MaxCommandLength))
                { error = $"“{macro.Name}”或其子宏超过 {Configuration.MaxCommandLength:N0} 字符；请先拆分，未导入任何内容。"; return false; }
                count += 1 + children.Count;
            }
            if (count > MaximumEntries)
            { error = $"配置共 {count} 个条目，超过 {MaximumEntries} 个上限（含宏组与子宏）。"; return false; }
            var normalized = new Configuration
            {
                BetterWaitEnabled = doc.BetterWaitEnabled,
                AllowLongMacros = doc.Version >= 3 && doc.AllowLongMacros,
                Macros = doc.Macros.Select(FromExchange).ToList(),
            };
            normalized.Normalize();
            imported = new ImportedConfiguration
            {
                BetterWaitEnabled = normalized.BetterWaitEnabled, AllowLongMacros = normalized.AllowLongMacros, Macros = normalized.Macros,
            };
            return true;
        }
        catch (Exception ex) when (ex is JsonException or NotSupportedException)
        { error = $"JSON 配置格式错误：{ex.Message}"; return false; }
    }

    private static MacroEntry FromExchange(ExchangeMacro macro) => new()
    {
        Name = macro.Name ?? string.Empty, Group = macro.Group ?? string.Empty,
        Commands = macro.Commands ?? string.Empty, Pinned = macro.Pinned,
        IsGroup = macro.IsGroup, Children = (macro.Children ?? []).Select(FromExchange).ToList(),
    };

    internal sealed class ImportedConfiguration
    {
        public bool BetterWaitEnabled { get; init; }
        public bool AllowLongMacros { get; init; }
        public List<MacroEntry> Macros { get; init; } = [];
        public int CountEntries() => Macros.Sum(m => 1 + m.Children.Count);
    }
    private sealed class ExchangeDocument
    {
        public string Format { get; set; } = string.Empty;
        public int Version { get; set; }
        public bool BetterWaitEnabled { get; set; }
        public bool AllowLongMacros { get; set; }
        public List<ExchangeMacro>? Macros { get; set; }
    }
    private sealed class ExchangeMacro
    {
        public string? Name { get; set; }
        public string? Group { get; set; }
        public string? Commands { get; set; }
        public bool Pinned { get; set; }
        public bool IsGroup { get; set; }
        public List<ExchangeMacro>? Children { get; set; }
    }
}
