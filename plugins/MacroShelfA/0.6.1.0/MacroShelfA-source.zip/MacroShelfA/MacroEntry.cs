using System;
using System.Collections.Generic;
using System.Linq;

namespace MacroShelfA;

[Serializable]
public sealed class MacroEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");

    public string Name { get; set; } = "新宏";

    public string Group { get; set; } = string.Empty;

    public string Commands { get; set; } = string.Empty;

    public bool Pinned { get; set; }

    // A group owns ordered copies, not references to entries elsewhere.
    public bool IsGroup { get; set; }
    public List<MacroEntry> Children { get; set; } = [];

    public MacroEntry Clone()
    {
        return new MacroEntry
        {
            Name = $"{Name} 副本",
            Group = Group,
            Commands = Commands,
            Pinned = Pinned,
            IsGroup = IsGroup,
            Children = Children.Select(child => child.Copy()).ToList(),
        };
    }

    public MacroEntry Copy()
    {
        var copy = Clone();
        copy.Name = Name;
        return copy;
    }
}
