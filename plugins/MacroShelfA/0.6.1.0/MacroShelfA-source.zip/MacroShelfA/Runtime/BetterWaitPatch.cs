using System;
using System.Collections.Generic;
using Dalamud;
using Dalamud.Plugin.Services;

namespace MacroShelfA.Runtime;

/// <summary>
/// The same two client-side wait patches used by DailyRoutines' Better Wait
/// module. The patch is optional and restores the original bytes on dispose.
/// </summary>
internal sealed class BetterWaitPatch : IDisposable
{
    private const string WaitSyntaxSignature = "F3 0F 58 05 ?? ?? ?? ?? F3 48 0F 2C C0 69 C8";
    private const string WaitCommandSignature = "F3 0F 58 0D ?? ?? ?? ?? F3 48 0F 2C C1 69 C8";

    private static readonly byte?[] WaitSyntaxBytes =
    [
        0xB8, 0x00, 0x00, 0x7A, 0x44,
        0x66, 0x0F, 0x6E, 0xC8,
        0xF3, 0x0F, 0x59, 0xC1,
        0xF3, 0x48, 0x0F, 0x2C, 0xC8,
        0x90,
        0x90, 0x90, 0x90, 0x90, 0x90,
    ];

    private static readonly byte?[] WaitCommandBytes =
    [
        0xB8, 0x00, 0x00, 0x7A, 0x44,
        0x66, 0x0F, 0x6E, 0xC0,
        0xF3, 0x0F, 0x59, 0xC8,
        0xF3, 0x48, 0x0F, 0x2C, 0xC9,
        0x90,
        0x89, 0x4B, 0x58,
        0x90, 0x90, 0x90, 0x90, 0x90, 0x90,
        0xEB,
    ];

    private readonly ISigScanner scanner;
    private readonly IPluginLog log;
    private BytePatch? syntaxPatch;
    private BytePatch? commandPatch;

    public BetterWaitPatch(ISigScanner scanner, IPluginLog log)
    {
        this.scanner = scanner;
        this.log = log;
    }

    public bool IsEnabled => syntaxPatch?.IsEnabled == true && commandPatch?.IsEnabled == true;

    public string StatusText { get; private set; } = "未启用";

    public void SetEnabled(bool enabled)
    {
        if (!enabled)
        {
            Disable();
            StatusText = "已关闭";
            return;
        }

        try
        {
            syntaxPatch ??= CreatePatch(WaitSyntaxSignature, WaitSyntaxBytes);
            commandPatch ??= CreatePatch(WaitCommandSignature, WaitCommandBytes);
            if (syntaxPatch == null || commandPatch == null)
            {
                StatusText = "当前客户端未找到匹配签名，已安全停用";
                log.Warning("Macro Shelf-A 更好的等待未启用：当前客户端未找到 DailyRoutines 兼容签名。");
                return;
            }

            syntaxPatch.Enable();
            commandPatch.Enable();
            StatusText = IsEnabled ? "已启用（小数等待/解除上限）" : "启用失败，已恢复原始字节";
        }
        catch (Exception exception)
        {
            Disable();
            StatusText = "启用失败，已恢复原始字节";
            log.Error(exception, "Macro Shelf-A 更好的等待补丁启用失败。");
        }
    }

    public void Dispose()
    {
        Disable();
        syntaxPatch?.Dispose();
        commandPatch?.Dispose();
        syntaxPatch = null;
        commandPatch = null;
    }

    private BytePatch? CreatePatch(string signature, IReadOnlyList<byte?> bytes)
    {
        if (!scanner.TryScanText(signature, out var address) || address == nint.Zero)
        {
            return null;
        }

        return new BytePatch(address, bytes);
    }

    private void Disable()
    {
        syntaxPatch?.Disable();
        commandPatch?.Disable();
    }

    private sealed class BytePatch : IDisposable
    {
        private readonly nint address;
        private readonly byte[] originalBytes;
        private readonly byte[] replacementBytes;

        public BytePatch(nint address, IReadOnlyList<byte?> bytes)
        {
            this.address = address;
            replacementBytes = new byte[bytes.Count];
            for (var index = 0; index < bytes.Count; index++)
            {
                replacementBytes[index] = bytes[index] ?? throw new InvalidOperationException("等待补丁不允许使用未知字节。");
            }

            if (!SafeMemory.ReadBytes(address, replacementBytes.Length, out originalBytes))
            {
                throw new InvalidOperationException("无法读取等待指令的原始字节。");
            }
        }

        public bool IsEnabled { get; private set; }

        public void Enable()
        {
            if (IsEnabled || !SafeMemory.WriteBytes(address, replacementBytes))
            {
                if (!IsEnabled)
                    throw new InvalidOperationException("无法写入等待指令补丁。");
                return;
            }

            IsEnabled = true;
        }

        public void Disable()
        {
            if (IsEnabled && SafeMemory.WriteBytes(address, originalBytes))
                IsEnabled = false;
        }

        public void Dispose() => Disable();
    }
}
