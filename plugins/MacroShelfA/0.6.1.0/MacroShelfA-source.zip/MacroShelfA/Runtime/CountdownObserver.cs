using System;

namespace MacroShelfA.Runtime;

internal readonly record struct CountdownSample(bool Available, uint Territory, bool Active, float Remaining)
{
    public bool Usable => Available && (!Active || (float.IsFinite(Remaining) && Remaining is >= -1 and <= 600));
}

// Timer samples only arm a fresh countdown. Only the game's explicit completion event can fire it.
internal sealed class CountdownObserver
{
    public const uint Completed = 5256;
    public const uint CompletedAlternate = 5264;
    public const uint Canceled = 5257;
    private bool sawIdle;
    private double lastSample = double.NaN;
    private double lastActive;
    public bool Armed { get; private set; }
    public float? Remaining { get; private set; }

    public void Reset()
    {
        Armed = false;
        sawIdle = false;
        Remaining = null;
        lastSample = double.NaN;
    }

    public void Observe(CountdownSample sample, double now)
    {
        if (!sample.Usable || !double.IsFinite(now))
        {
            Reset();
            return;
        }
        // Never execute a late event after a loading stall, suspended client, or stale observation.
        if (double.IsFinite(lastSample) && (now < lastSample || now - lastSample > 2)) Reset();
        lastSample = now;
        Remaining = sample.Active ? sample.Remaining : null;
        if (sample.Active && sample.Remaining > 0)
        {
            if (sawIdle) Armed = true;
            sawIdle = false;
            lastActive = now;
        }
        else
        {
            if (!sample.Active) sawIdle = true;
            // A small delivery window handles native Update / LogMessage ordering, not timer extrapolation.
            if (Armed && now - lastActive > 2) Armed = false;
        }
    }

    public bool OnLogMessage(uint id)
    {
        if (id == Canceled)
        {
            Reset();
            return false;
        }
        if (id is not (Completed or CompletedAlternate) || !Armed) return false;
        Reset(); // Consume before executing, including busy / missing-target failures.
        return true;
    }
}

