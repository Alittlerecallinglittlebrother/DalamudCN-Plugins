using System;
using System.Diagnostics;
using Dalamud.Game.Chat;
using Dalamud.Plugin.Services;

namespace MacroShelfA.Runtime;

internal sealed class CountdownTrigger : IDisposable
{
    private readonly Configuration configuration;
    private readonly MacroExecutor executor;
    private readonly Func<CountdownSample> readSample;
    private readonly Func<double> now;
    private readonly CountdownObserver observer = new();
    private (bool Enabled, string Id, bool Available, uint Territory)? context;
    private (double At, bool WasBusy)? pending;
    private bool disposed;
    public string StatusText { get; private set; } = "已关闭";
    public string LastResult { get; private set; } = "尚未触发";

    public CountdownTrigger(Configuration configuration, MacroExecutor executor,
        Func<CountdownSample>? readSample = null, Func<double>? now = null)
    {
        this.configuration = configuration;
        this.executor = executor;
        this.readSample = readSample ?? NativeCountdownReader.Read;
        var start = Stopwatch.GetTimestamp();
        this.now = now ?? (() => Stopwatch.GetElapsedTime(start).TotalSeconds);
        Plugin.Framework.Update += OnFrameworkUpdate;
        Plugin.ChatGui.LogMessage += OnLogMessage;
    }

    public void ResetForSettingsChange()
    {
        context = null;
        pending = null;
        observer.Reset();
        StatusText = configuration.CountdownTriggerEnabled ? "等待下一次倒计时" : "已关闭";
    }

    private bool Synchronize(CountdownSample sample)
    {
        var next = (configuration.CountdownTriggerEnabled, configuration.CountdownMacroId,
            sample.Usable, sample.Territory);
        if (context != next)
        {
            observer.Reset();
            pending = null;
            context = next;
        }
        if (!configuration.CountdownTriggerEnabled) { StatusText = "已关闭"; return false; }
        if (configuration.FindCountdownMacro() == null) { StatusText = "请先选择执行目标"; return false; }
        if (!sample.Usable) { StatusText = "等待角色就绪 · 登出 / 切图时不触发"; return false; }
        return true;
    }

    private void OnLogMessage(ILogMessage message)
    {
        // ILogMessage is callback-scoped. Never retain it, render its text, suppress it, or send commands here.
        var id = message.LogMessageId;
        if (disposed || !configuration.CountdownTriggerEnabled ||
            id is not (CountdownObserver.Completed or CountdownObserver.CompletedAlternate or CountdownObserver.Canceled)) return;
        try
        {
            var sample = readSample();
            var time = now();
            if (!Synchronize(sample)) return;
            observer.Observe(sample, time);
            if (id == CountdownObserver.Canceled)
            {
                pending = null;
                LastResult = "倒计时已取消 · 未执行宏";
            }
            if (observer.OnLogMessage(id)) pending = (time, executor.IsRunning);
        }
        catch (Exception exception) { HandleFailure(exception); }
    }

    private void OnFrameworkUpdate(IFramework framework)
    {
        if (disposed) return;
        try
        {
            // Disabled really is dormant: no native timer reads, hooks, or command dispatch.
            var sample = configuration.CountdownTriggerEnabled ? readSample() : default;
            if (!Synchronize(sample)) return;
            var time = now();
            observer.Observe(sample, time);
            StatusText = observer.Armed && observer.Remaining is { } remaining
                ? $"倒计时中 · 剩余 {remaining:F1} 秒"
                : observer.Armed ? "等待游戏确认“战斗开始”"
                : "等待下一次完整倒计时";
            if (pending is not { } completion) return;
            pending = null;
            if (time < completion.At || time - completion.At > 1)
                LastResult = "已跳过：游戏更新延迟，不补执行";
            else if (completion.WasBusy || executor.IsRunning)
                LastResult = "已跳过：已有宏正在执行，不打断、不排队";
            else if (configuration.FindCountdownMacro() is not { } target)
                LastResult = "已跳过：绑定目标不存在";
            else if (executor.TryStart(target, out var error))
                LastResult = $"{DateTime.Now:HH:mm:ss} 已启动：{target.Name}";
            else
                LastResult = $"已跳过：{error}";
        }
        catch (Exception exception) { HandleFailure(exception); }
    }

    private void HandleFailure(Exception exception)
    {
        observer.Reset();
        pending = null;
        // Disable this session after an unexpected native/API error, rather than retrying every frame.
        configuration.CountdownTriggerEnabled = false;
        StatusText = "监听异常，已关闭；详情见插件日志";
        LastResult = StatusText;
        Plugin.Log.Error(exception, "战斗倒计时监听失败，已关闭自动触发。");
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        Plugin.ChatGui.LogMessage -= OnLogMessage;
        Plugin.Framework.Update -= OnFrameworkUpdate;
        ResetForSettingsChange();
    }
}

