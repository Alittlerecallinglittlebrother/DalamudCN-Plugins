using System;
using System.Diagnostics;
using Dalamud.Plugin.Services;

namespace MacroShelfA.Runtime;

internal sealed class MacroExecutor : IDisposable
{
    public const int MaximumLines = MacroSequence.MaximumLines;
    private readonly Configuration configuration;
    private readonly MacroSequence sequence = new();
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private readonly Func<double> now;
    public MacroExecutor(Configuration configuration, Func<double>? now = null)
    {
        this.configuration = configuration;
        this.now = now ?? (() => clock.Elapsed.TotalSeconds);
        Plugin.Framework.Update += OnFrameworkUpdate;
    }
    public bool IsRunning => sequence.IsRunning;
    public string CurrentMacroName => sequence.CurrentMacroName;
    public string CurrentChildName => sequence.CurrentChildName;
    public int CurrentChildIndex => sequence.CurrentChildIndex;
    public int TotalChildren => sequence.TotalChildren;
    public int TotalLines => sequence.TotalLines;
    public int ExecutedLines => sequence.ExecutedLines;
    public int RemainingLines => sequence.RemainingLines;
    public double RemainingWait => sequence.RemainingWait(now());

    public void Start(MacroEntry macro)
    {
        if (!TryStart(macro, out var error)) Plugin.ChatGui.PrintError($"[Macro Shelf-A] {error}");
    }

    public bool TryStart(MacroEntry macro, out string error)
    {
        if (!Plugin.ClientState.IsLoggedIn)
        {
            error = "请先登录角色，再执行宏。";
            return false;
        }
        return sequence.TryStart(macro, now(), out error, configuration.AllowLongMacros);
    }

    public void Stop(bool notify = true)
    {
        var name = CurrentMacroName;
        var wasRunning = IsRunning;
        sequence.Stop();
        if (notify && wasRunning) Plugin.ChatGui.Print($"[Macro Shelf-A] 已中止：{name}");
    }

    public void Dispose()
    {
        Plugin.Framework.Update -= OnFrameworkUpdate;
        Stop(false);
        clock.Stop();
    }

    private void OnFrameworkUpdate(IFramework framework)
    {
        if (!IsRunning) return;
        if (!Plugin.ClientState.IsLoggedIn) { Stop(false); return; }
        try
        {
            sequence.Tick(now(), line =>
            {
                if (!Plugin.CommandManager.ProcessCommand(line)) NativeCommandSender.Send(line);
            });
            if (!string.IsNullOrEmpty(sequence.ExecutionStopReason))
                Plugin.ChatGui.PrintError($"[Macro Shelf-A] {sequence.ExecutionStopReason}");
        }
        catch (Exception exception)
        {
            Plugin.Log.Error(exception, "宏组执行失败，已中止后续全部命令。");
            Plugin.ChatGui.PrintError($"[Macro Shelf-A] {exception.Message}");
        }
    }
}
