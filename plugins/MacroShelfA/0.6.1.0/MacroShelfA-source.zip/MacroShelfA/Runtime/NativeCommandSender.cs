using System;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Client.UI.Shell;

namespace MacroShelfA.Runtime;

internal static unsafe class NativeCommandSender
{
    public static void Send(string command)
    {
        var uiModule = UIModule.Instance();
        var shellModule = RaptureShellModule.Instance();
        if (uiModule == null || shellModule == null)
        {
            throw new InvalidOperationException("游戏命令模块尚未就绪。");
        }

        var input = Utf8String.FromString(command);
        if (input == null)
        {
            throw new InvalidOperationException("无法创建游戏命令文本。");
        }

        try
        {
            shellModule->ExecuteCommandInner(input, uiModule);
        }
        finally
        {
            input->Dtor(true);
        }
    }
}

