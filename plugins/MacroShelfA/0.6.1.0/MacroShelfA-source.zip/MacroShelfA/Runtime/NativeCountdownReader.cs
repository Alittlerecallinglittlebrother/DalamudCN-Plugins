using Dalamud.Game.ClientState.Conditions;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;

namespace MacroShelfA.Runtime;

internal static class NativeCountdownReader
{
    public static unsafe CountdownSample Read()
    {
        var territory = Plugin.ClientState.TerritoryType;
        if (!Plugin.ClientState.IsLoggedIn || Plugin.Condition[ConditionFlag.BetweenAreas] ||
            Plugin.Condition[ConditionFlag.BetweenAreas51] || Plugin.Condition[ConditionFlag.LoggingOut])
            return new(false, territory, false, 0);
        var agent = AgentCountDownSettingDialog.Instance();
        return agent == null ? new(false, territory, false, 0)
            : new(true, territory, agent->Active, agent->TimeRemaining);
    }
}
