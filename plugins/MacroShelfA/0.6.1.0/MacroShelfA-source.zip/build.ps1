param(
    [ValidateSet('Debug', 'Release')][string]$Configuration = 'Release',
    [switch]$Test
)
$ErrorActionPreference = 'Stop'
$dotnet = (Get-Command dotnet -ErrorAction Stop).Source
if (-not $env:DALAMUD_HOME) {
    $env:DALAMUD_HOME = Join-Path $env:APPDATA 'XIVLauncherCN\addon\Hooks\dev'
}
if (-not (Test-Path -LiteralPath (Join-Path $env:DALAMUD_HOME 'Dalamud.dll'))) {
    throw "未找到 Dalamud 开发程序集，请设置 DALAMUD_HOME：$env:DALAMUD_HOME"
}
& $dotnet build (Join-Path $PSScriptRoot 'MacroShelfA.slnx') -c $Configuration
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if ($Test) {
    & $dotnet run --project (Join-Path $PSScriptRoot 'MacroShelfA.Tests\MacroShelfA.Tests.csproj') -c Release -- --ui (Join-Path $PSScriptRoot 'verification')
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
exit 0
