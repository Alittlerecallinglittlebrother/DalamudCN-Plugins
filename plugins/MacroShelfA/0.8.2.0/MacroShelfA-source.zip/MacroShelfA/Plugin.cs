using System;
using Dalamud.Game.Command;
using Dalamud.Interface.Textures;
using Dalamud.Interface.Windowing;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

namespace MacroShelfA;

public sealed class Plugin : IDalamudPlugin
{
    private const string CommandName = "/aklmacro";

    [PluginService]
    internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;

    [PluginService]
    internal static ICommandManager CommandManager { get; private set; } = null!;

    [PluginService]
    internal static IFramework Framework { get; private set; } = null!;

    [PluginService]
    internal static IClientState ClientState { get; private set; } = null!;

    [PluginService]
    internal static ICondition Condition { get; private set; } = null!;

    [PluginService]
    internal static ISigScanner SigScanner { get; private set; } = null!;

    [PluginService]
    internal static IChatGui ChatGui { get; private set; } = null!;

    [PluginService]
    internal static IPluginLog Log { get; private set; } = null!;

    [PluginService]
    internal static ITextureProvider TextureProvider { get; private set; } = null!;

    private readonly WindowSystem windowSystem = new("MacroShelfA");
    private readonly MacroExecutor macroExecutor;
    private readonly CountdownTrigger countdownTrigger;
    private readonly BetterWaitPatch betterWaitPatch;
    private readonly MainWindow mainWindow;
    private readonly FloatingLauncherWindow floatingLauncherWindow;
    private readonly QuickBarWindow quickBarWindow;

    internal Configuration Configuration { get; }

    public Plugin()
    {
        Configuration = PluginInterface.GetPluginConfig() as Configuration ?? Configuration.CreateDefault();
        try
        {
            ConfigurationBackup.BeforeGroupMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
            ConfigurationBackup.BeforeLongMacroMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
            ConfigurationBackup.BeforeCountdownMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
            ConfigurationBackup.BeforeZeroIntervalMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
        }
        catch (Exception exception)
        {
            Log.Error(exception, "无法备份升级前配置；请通过导出配置保留副本。");
            ChatGui.PrintError("[Macro Shelf-A] 升级前配置备份失败，请先导出配置保留副本。");
        }
        Configuration.Normalize();

        macroExecutor = new MacroExecutor(Configuration);
        countdownTrigger = new CountdownTrigger(Configuration, macroExecutor);
        betterWaitPatch = new BetterWaitPatch(SigScanner, Log);
        betterWaitPatch.SetEnabled(Configuration.BetterWaitEnabled);
        mainWindow = new MainWindow(Configuration, macroExecutor, betterWaitPatch, countdownTrigger);
        floatingLauncherWindow = new FloatingLauncherWindow(Configuration, mainWindow);
        quickBarWindow = new QuickBarWindow(Configuration, macroExecutor, mainWindow);
        windowSystem.AddWindow(mainWindow);
        windowSystem.AddWindow(floatingLauncherWindow);
        windowSystem.AddWindow(quickBarWindow);

        CommandManager.AddHandler(CommandName, new CommandInfo(OnCommand)
        {
            HelpMessage = "打开或关闭 Macro Shelf-A。/aklmacro bar 切换常用宏栏；/aklmacro stop 中止运行。",
        });

        PluginInterface.UiBuilder.Draw += windowSystem.Draw;
        PluginInterface.UiBuilder.OpenMainUi += OpenMainUi;
        PluginInterface.UiBuilder.OpenConfigUi += OpenMainUi;
        Log.Information("Macro Shelf-A 已加载。使用 {Command} 打开窗口。", CommandName);
    }

    public void Dispose()
    {
        PluginInterface.UiBuilder.Draw -= windowSystem.Draw;
        PluginInterface.UiBuilder.OpenMainUi -= OpenMainUi;
        PluginInterface.UiBuilder.OpenConfigUi -= OpenMainUi;
        CommandManager.RemoveHandler(CommandName);

        Configuration.Save();
        windowSystem.RemoveAllWindows();
        mainWindow.Dispose();
        countdownTrigger.Dispose();
        macroExecutor.Dispose();
        betterWaitPatch.Dispose();
    }

    private void OnCommand(string command, string arguments)
    {
        if (string.Equals(arguments.Trim(), "bar", StringComparison.OrdinalIgnoreCase))
        {
            Configuration.ShowQuickBar = !Configuration.ShowQuickBar;
            Configuration.Save();
            return;
        }
        if (string.Equals(arguments.Trim(), "stop", StringComparison.OrdinalIgnoreCase))
        {
            macroExecutor.Stop();
            return;
        }
        mainWindow.Toggle();
    }

    private void OpenMainUi()
    {
        mainWindow.IsOpen = true;
    }
}
