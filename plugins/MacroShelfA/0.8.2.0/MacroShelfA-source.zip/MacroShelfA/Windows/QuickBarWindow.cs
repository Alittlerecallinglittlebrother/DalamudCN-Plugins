using System;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Windowing;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class QuickBarWindow : Window
{
    private readonly Configuration configuration;
    private readonly MacroExecutor executor;
    private readonly MainWindow mainWindow;
    private string pickerSearch = string.Empty;
    private string lastError = string.Empty;
    private MacroEntry? failedMacro;
    private string failedCommands = string.Empty;
    private string failedName = string.Empty;
    private bool failedLongSetting;
    private float gridHeight;
    private float gridTop, statusTop, headerHeight, actionsWidth, buttonHeight;
    private int gridColumns;
    private bool secondHeaderRow, gridScrolls;
    private const string UsageHint = "左键运行，右键编辑或删除";
    private const string EmptyHint = "还没有常用宏。点击“添加”选择，或在资料库中点击收藏星标。";
    private static float S(float value) => value * ImGuiHelpers.GlobalScale;
    partial void RecordItem(string key);
    partial void RecordRegion(string key, Vector2 minimum, Vector2 maximum);

    public QuickBarWindow(Configuration configuration, MacroExecutor executor, MainWindow mainWindow)
        : base("Macro Shelf-A 常用宏###MacroShelfAQuickBar")
    {
        this.configuration = configuration; this.executor = executor; this.mainWindow = mainWindow;
        Flags = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove |
            ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse | ImGuiWindowFlags.NoCollapse |
            ImGuiWindowFlags.NoDocking | ImGuiWindowFlags.NoFocusOnAppearing;
        Position = new Vector2(24, 300) * ImGuiHelpers.GlobalScale;
        PositionCondition = ImGuiCond.FirstUseEver;
        IsOpen = true; ShowCloseButton = false; RespectCloseHotkey = false; DisableWindowSounds = true; ForceMainWindow = true;
    }
    public override bool DrawConditions() => configuration.ShowQuickBar && Plugin.ClientState.IsLoggedIn;
    public override void PreDraw()
    {
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(S(10)));
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(S(8), S(6)));
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(S(6)));
        ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, S(6));
        ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, S(4));
        ImGui.PushStyleColor(ImGuiCol.WindowBg, new Vector4(.075f,.115f,.165f,1));
        ImGui.PushStyleColor(ImGuiCol.Border, new Vector4(.20f,.29f,.38f,1));
        ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(.92f,.95f,.99f,1));
        ImGui.PushStyleColor(ImGuiCol.TextDisabled, new Vector4(.66f,.76f,.86f,1));
        ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(.11f,.18f,.26f,1));
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(.16f,.30f,.44f,1));
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(.11f,.38f,.72f,1));
        ImGui.PushStyleColor(ImGuiCol.FrameBg, new Vector4(.055f,.085f,.125f,1));
        ImGui.PushStyleColor(ImGuiCol.Header, new Vector4(.13f,.30f,.51f,1));
        ImGui.PushStyleColor(ImGuiCol.HeaderHovered, new Vector4(.16f,.32f,.50f,1));
        ImGui.PushStyleColor(ImGuiCol.CheckMark, new Vector4(.18f,.53f,.94f,1));

        var pinned = QuickBarModel.Pinned(configuration);
        ClearStaleError(pinned);
        var count = pinned.Count;
        var frameHeight = ImGui.GetFrameHeight();
        actionsWidth = new[] { "添加", "管理", "更多", configuration.QuickBarCollapsed ? "展开" : "收起" }
            .Sum(label => ImGui.CalcTextSize(label).X + ImGui.GetStyle().FramePadding.X * 2) + S(18);
        var textWidth = ImGui.CalcTextSize($"常用宏 · {count}").X + S(12) + ImGui.CalcTextSize(UsageHint).X;
        var preferredWidth = MathF.Max(S(360), S(configuration.QuickBarColumns * (configuration.QuickBarButtonWidth + 6) + 14));
        // Keep the requested hint intact. Only the action buttons wrap on narrow bars.
        preferredWidth = MathF.Max(preferredWidth, textWidth + S(20));
        if (configuration.QuickBarColumns > 1) preferredWidth = MathF.Max(preferredWidth, textWidth + actionsWidth + S(32));
        var available = MathF.Max(1, ImGui.GetMainViewport().WorkSize.X - S(16));
        var width = MathF.Min(available, preferredWidth);
        var contentWidth = width - S(20);
        secondHeaderRow = contentWidth < textWidth + actionsWidth + S(12);
        headerHeight = secondHeaderRow ? frameHeight * 2 + S(6) : frameHeight;
        buttonHeight = MathF.Max(S(38), frameHeight);
        gridColumns = QuickBarModel.EffectiveColumns(configuration.QuickBarColumns, contentWidth, S(configuration.QuickBarButtonWidth), S(6));
        gridScrolls = count > gridColumns * 4;
        if (gridScrolls) gridColumns = QuickBarModel.EffectiveColumns(configuration.QuickBarColumns, contentWidth - ImGui.GetStyle().ScrollbarSize, S(configuration.QuickBarButtonWidth), S(6));
        var rows = Math.Clamp((count + gridColumns - 1) / gridColumns, 1, 4);
        gridHeight = count == 0 ? ImGui.CalcTextSize(EmptyHint, false, contentWidth).Y : rows * buttonHeight + (rows - 1) * S(6);
        gridTop = S(10) + headerHeight + S(7);
        var lastContentBottom = configuration.QuickBarCollapsed ? S(10) + headerHeight : gridTop + gridHeight;
        statusTop = lastContentBottom + S(7);
        var statusHeight = executor.IsRunning ? frameHeight : lastError.Length > 0 ? ImGui.GetTextLineHeight() : 0;
        var height = lastContentBottom + S(10) + (statusHeight > 0 ? S(7) + statusHeight : 0);
        // WindowHost applies GlobalScale AFTER PreDraw. Size is logical, not already-scaled pixels.
        Size = new Vector2(width, height) / ImGuiHelpers.GlobalScale;
        SizeCondition = ImGuiCond.Always;
    }
    public override void PostDraw() { ImGui.PopStyleColor(11); ImGui.PopStyleVar(5); }
    public override void Draw()
    {
        ClampToViewport();
        var pinned = QuickBarModel.Pinned(configuration);
        var headerWidth = ImGui.GetContentRegionAvail().X - (secondHeaderRow ? 0 : actionsWidth + S(12));
        ImGui.InvisibleButton("##DragQuickBar", new Vector2(headerWidth, ImGui.GetFrameHeight())); RecordItem("drag");
        var title = $"常用宏 · {pinned.Count}";
        var textPosition = ImGui.GetItemRectMin() + new Vector2(0, ImGui.GetStyle().FramePadding.Y);
        ImGui.GetWindowDrawList().AddText(textPosition, ImGui.GetColorU32(ImGuiCol.Text), title);
        var hintPosition = textPosition + new Vector2(ImGui.CalcTextSize(title).X + S(12), 0);
        ImGui.GetWindowDrawList().AddText(hintPosition, ImGui.GetColorU32(ImGuiCol.TextDisabled), UsageHint);
        RecordRegion("header-hint", hintPosition, hintPosition + ImGui.CalcTextSize(UsageHint));
        if (ImGui.IsItemActive() && !configuration.LockQuickBar && ImGui.IsMouseDragging(ImGuiMouseButton.Left, 3))
        {
            ImGui.SetWindowPos(ImGui.GetWindowPos() + ImGui.GetIO().MouseDelta, ImGuiCond.Always);
            ClampToViewport();
        }
        if (ImGui.IsItemHovered()) ImGui.SetTooltip(configuration.LockQuickBar ? "位置已锁定；在“更多”中解锁" : "拖动此处移动常用栏");
        ImGui.SetCursorPos(secondHeaderRow ? new Vector2(S(10), S(10) + ImGui.GetFrameHeight() + S(6))
            : new Vector2(ImGui.GetWindowSize().X - S(10) - actionsWidth, S(10)));
        if (ImGui.Button("添加")) { pickerSearch = string.Empty; ImGui.OpenPopup("##QuickPicker"); } RecordItem("add");
        ImGui.SameLine(); if (ImGui.Button("管理")) mainWindow.IsOpen = true; RecordItem("manage");
        ImGui.SameLine(); if (ImGui.Button("更多")) ImGui.OpenPopup("##QuickOptions"); RecordItem("options");
        ImGui.SameLine();
        if (ImGui.Button(configuration.QuickBarCollapsed ? "展开" : "收起")) { configuration.QuickBarCollapsed = !configuration.QuickBarCollapsed; configuration.Save(); }
        RecordItem("collapse");
        DrawPicker(); DrawOptions();
        if (!configuration.QuickBarCollapsed)
        {
            DrawDivider(gridTop - S(4));
            ImGui.SetCursorPos(new Vector2(S(10), gridTop));
            ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, Vector2.Zero);
            ImGui.BeginChild("##QuickGrid", new Vector2(0, gridHeight), false,
                gridScrolls ? ImGuiWindowFlags.AlwaysVerticalScrollbar : ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);
            RecordRegion("grid", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
            if (pinned.Count == 0) ImGui.TextWrapped(EmptyHint);
            else
            {
                var contentWidth = ImGui.GetContentRegionAvail().X;
                var columns = gridColumns;
                var buttonWidth = (contentWidth - (columns - 1) * S(6)) / columns;
                for (var i = 0; i < pinned.Count; i++)
                {
                    if (i % columns != 0) ImGui.SameLine();
                    DrawMacro(pinned[i], buttonWidth);
                }
            }
            ImGui.EndChild(); ImGui.PopStyleVar();
        }
        if (executor.IsRunning || lastError.Length > 0) DrawStatus();
    }
    private void ClearStaleError(System.Collections.Generic.List<QuickBarEntry> pinned)
    {
        if (lastError.Length > 0 && (failedMacro == null || !pinned.Any(e => ReferenceEquals(e.Macro, failedMacro)) ||
            failedMacro.Commands != failedCommands || failedMacro.Name != failedName || configuration.AllowLongMacros != failedLongSetting))
            lastError = string.Empty;
    }
    private static void DrawDivider(float y)
    {
        var origin = ImGui.GetWindowPos();
        ImGui.GetWindowDrawList().AddLine(origin + new Vector2(S(10), y), origin + new Vector2(ImGui.GetWindowSize().X - S(10), y), ImGui.GetColorU32(ImGuiCol.Border));
    }
    private void DrawMacro(QuickBarEntry entry, float width)
    {
        var macro = entry.Macro;
        ImGui.PushID(macro.Id);
        ImGui.BeginDisabled(executor.IsRunning);
        var clicked = ImGui.Button("##Run", new Vector2(width, buttonHeight)); RecordItem("run-" + macro.Id);
        var prefix = entry.Parent != null ? "子 · " : macro.IsGroup ? "组 · " : string.Empty;
        var color = ImGui.GetColorU32(ImGuiCol.Text);
        ImGui.GetWindowDrawList().AddText(ImGui.GetItemRectMin() + new Vector2(S(8), (buttonHeight - ImGui.GetFontSize()) / 2), color, MainWindow.Fit(prefix + macro.Name, width - S(16)));
        if (clicked)
        {
            lastError = executor.TryStart(macro, out var error) ? string.Empty : error;
            failedMacro = macro; failedCommands = macro.Commands; failedName = macro.Name; failedLongSetting = configuration.AllowLongMacros;
        }
        ImGui.EndDisabled();
        if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
            ImGui.SetTooltip($"{entry.Label}\n{entry.Kind} · {MacroLibrary.Tag(entry.Parent ?? macro)}\n{(executor.IsRunning ? "已有宏运行，先中止再切换" : "左键运行；右键编辑或移出常用栏")}");
        if (ImGui.BeginPopupContextItem("##QuickEntry"))
        {
            ImGui.TextUnformatted(entry.Label); ImGui.Separator();
            if (ImGui.MenuItem("编辑此宏")) mainWindow.EditEntry(macro); RecordItem("edit-" + macro.Id);
            if (ImGui.MenuItem("移出常用栏")) SetPinned(macro, false); RecordItem("remove-" + macro.Id);
            ImGui.EndPopup();
        }
        ImGui.PopID();
    }
    private void SetPinned(MacroEntry macro, bool value)
    {
        if (QuickBarModel.SetPinned(configuration, macro, value)) mainWindow.RefreshLibrary();
    }
    private void DrawPicker()
    {
        if (!ImGui.IsPopupOpen("##QuickPicker")) return;
        var viewport = ImGui.GetMainViewport();
        var popupSize = new Vector2(MathF.Min(S(430), viewport.WorkSize.X - S(24)), MathF.Min(S(340), viewport.WorkSize.Y - S(24)));
        ImGui.SetNextWindowSize(popupSize, ImGuiCond.Always);
        // Explicit flags replace BeginPopup's default AlwaysAutoResize; child cannot grow its parent.
        if (!ImGui.BeginPopup("##QuickPicker", ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse)) return;
        RecordRegion("picker-window", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
        ImGui.TextUnformatted("选择常用宏"); ImGui.SameLine(); ImGui.TextDisabled("勾选即添加");
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##PickerSearch", "搜索名称或分类…", ref pickerSearch, 256); RecordItem("picker-search");
        ImGui.Separator();
        var all = QuickBarModel.All(configuration).Where(e => QuickBarModel.Matches(e, pickerSearch)).ToList();
        var footerY = ImGui.GetWindowSize().Y - ImGui.GetStyle().WindowPadding.Y - ImGui.GetFrameHeight();
        var listTop = ImGui.GetCursorPosY();
        ImGui.BeginChild("##PickerEntries", new Vector2(0, MathF.Max(1, footerY - S(8) - listTop)), false);
        RecordRegion("picker-list", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
        if (all.Count == 0) ImGui.TextWrapped(configuration.Macros.Count == 0 ? "还没有宏。点击底部“打开管理”创建。" : "没有匹配的宏。");
        foreach (var entry in all)
        {
            var macro = entry.Macro; var value = macro.Pinned; ImGui.PushID(macro.Id);
            if (ImGui.Checkbox("##Pin", ref value)) SetPinned(macro, value); RecordItem("pin-" + macro.Id);
            ImGui.SameLine();
            ImGui.TextUnformatted(MainWindow.Fit($"{entry.Kind} · {entry.Label}", ImGui.GetContentRegionAvail().X));
            if (ImGui.IsItemHovered()) ImGui.SetTooltip(entry.Label);
            ImGui.PopID();
        }
        ImGui.EndChild();
        DrawDivider(footerY - S(4));
        ImGui.SetCursorPos(new Vector2(ImGui.GetStyle().WindowPadding.X, footerY));
        if (ImGui.Button("完成")) ImGui.CloseCurrentPopup(); RecordItem("picker-done"); ImGui.SameLine();
        if (ImGui.Button("打开管理")) { mainWindow.IsOpen = true; ImGui.CloseCurrentPopup(); } RecordItem("picker-manage");
        ImGui.EndPopup();
    }
    private void DrawOptions()
    {
        if (!ImGui.BeginPopup("##QuickOptions")) return;
        var locked = configuration.LockQuickBar;
        if (ImGui.Checkbox("锁定位置", ref locked)) { configuration.LockQuickBar = locked; configuration.Save(); } RecordItem("lock");
        var columns = configuration.QuickBarColumns;
        ImGui.SetNextItemWidth(S(160));
        if (ImGui.SliderInt("每行按钮数", ref columns, 1, 8)) { configuration.QuickBarColumns = columns; configuration.Save(); }
        var width = configuration.QuickBarButtonWidth;
        ImGui.SetNextItemWidth(S(160));
        if (ImGui.SliderFloat("按钮宽度", ref width, 80, 200, "%.0f px")) { configuration.QuickBarButtonWidth = width; configuration.Save(); }
        ImGui.Separator();
        if (ImGui.MenuItem("隐藏常用栏")) { configuration.ShowQuickBar = false; configuration.Save(); } RecordItem("hide");
        ImGui.TextDisabled("/aklmacro bar 恢复显示");
        ImGui.EndPopup();
    }
    private void DrawStatus()
    {
        DrawDivider(statusTop - S(4));
        ImGui.SetCursorPos(new Vector2(S(10), statusTop));
        if (executor.IsRunning)
        {
            ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(.60f,.20f,.25f,1));
            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(.68f,.24f,.28f,1));
            ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(.60f,.20f,.25f,1));
            if (ImGui.Button("中止", new Vector2(S(62), 0))) executor.Stop(); RecordItem("stop");
            ImGui.PopStyleColor(3); ImGui.SameLine();
            var status = $"{executor.CurrentMacroName} · {executor.ExecutedLines}/{executor.TotalLines} 行 · {executor.RemainingWait:F1}s";
            ImGui.TextUnformatted(MainWindow.Fit(status, ImGui.GetContentRegionAvail().X));
            if (ImGui.IsItemHovered()) ImGui.SetTooltip(status);
        }
        else
        {
            var text = lastError;
            if (lastError.Length > 0) ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(1,.65f,.67f,1));
            ImGui.TextUnformatted(MainWindow.Fit(text, ImGui.GetContentRegionAvail().X));
            if (lastError.Length > 0) ImGui.PopStyleColor();
            if (ImGui.IsItemHovered()) ImGui.SetTooltip(text);
        }
    }
    private static void ClampToViewport()
    {
        var viewport = ImGui.GetMainViewport(); var minimum = viewport.WorkPos + new Vector2(S(8));
        var maximum = Vector2.Max(minimum, viewport.WorkPos + viewport.WorkSize - ImGui.GetWindowSize() - new Vector2(S(8)));
        var position = ImGui.GetWindowPos(); var clamped = Vector2.Clamp(position, minimum, maximum);
        if (Vector2.DistanceSquared(position, clamped) > .01f) ImGui.SetWindowPos(clamped, ImGuiCond.Always);
    }
}
