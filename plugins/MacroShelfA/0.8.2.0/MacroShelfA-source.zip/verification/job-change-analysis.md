# 0.8.2.0 job-change consistency guard — scope and evidence

## User reproduction and evidence

The user reports gearset 6 is Astrologian. Manually changing first and then running the two plugin `/ac` lines works. A plugin `/gs change 6<wait.3>` followed by those actions works, while the original 0.2-second version fails with invalid action-name arguments. This supports a timing-dependent transition problem, not a proven particular cache mechanism.

Directly linked 0.8.1 MacroSequence tests at 60 Hz produce gearset dispatch at 3.000s, the intervening chat at 3.200s, Swiftcast at 3.216667s, and Helios Conjunction at 4.716667s. Decimal waits are parsed and stripped correctly, and apply AFTER the corresponding dispatch. There is no default 0.15-second interval.

The 0.8.1 native sender's ExecuteCommandInner signature agrees with the installed ClientStructs binding. No evidence supports replacing that sender to refresh an action-name cache. It is unchanged in 0.8.2.

## Candidate intervention

Read-only snapshots on the Framework thread compare LocalPlayer.ClassJob, PlayerState.CurrentClassJobId, RaptureHotbarModule.ActiveHotbarClassJobId and CurrentGearsetIndex with the requested existing numeric gearset. ContentId/EntityId association is checked. The host reads Entries and Exists without invoking EquipGearset or any ActionManager method; pointers are reacquired each time, never retained.

Only the first `/ac` or `/action` after a tracked cross-job change is held when these fields disagree. Prior chat/emotes/waits proceed in original order. Once that action is dispatched, its explicit wait begins in full, and no action is automatically retried. A first-blocked timestamp imposes a 10-second hard deadline, including a frame stall that jumps beyond it. Stop, logout, dispose and a fresh successful start clear the guard.

An obsolete synchronous callback's exception must not cancel a replacement run. The scheduler now checks its generation on the exception path as it already did on the normal return path.

## Explicit non-claims

- Four matching observations are NOT a proven native action-name parsing ready flag. They prevent an observable mismatch but could fail to cover deeper delayed state; game verification remains required.
- Hotbar ModuleReady only describes data-file initialization, not a per-job action-name refresh. Unknown high bits are not masked away to manufacture a match.
- ActionManager.GetActionStatus == 0 is not used: cooldown, target, resources and combat conditions are unrelated and must not become a generic action-wait loop.
- The installed Dalamud ChatGui.LogMessage callback reads a queued log-message buffer during RaptureLogModule.Update, not synchronously inside our command sender. Error 3803 therefore cannot be uniquely assigned to a dispatched plugin line for retry. No delayed-error retry exists.
- RaptureShellModule.ErrorData has undocumented bit semantics; it is not used as a success or retry signal.
- Numeric English commands and ASCII spaces/tabs are the supported recognition scope. No wholesale whitespace/backslash normalization or lyric editing is performed. Named/unsupported change commands do not inherit an obsolete target.
- Missing initial character identity means no guessed tracking; missing later modules defer under the same bounded deadline. Incorrect/missing gearset or same-job commands retain their previous native behavior.

## Source provenance

Bindings checked against the currently installed API-15 FFXIVClientStructs.dll and the successful production compilation. Public source references for the corresponding structures:

- [ShellCommandModule](https://github.com/aers/FFXIVClientStructs/blob/main/FFXIVClientStructs/FFXIV/Component/Shell/ShellCommandModule.cs)
- [RaptureGearsetModule](https://github.com/aers/FFXIVClientStructs/blob/main/FFXIVClientStructs/FFXIV/Client/UI/Misc/RaptureGearsetModule.cs)
- [RaptureHotbarModule](https://github.com/aers/FFXIVClientStructs/blob/main/FFXIVClientStructs/FFXIV/Client/UI/Misc/RaptureHotbarModule.cs)
- [PlayerState](https://github.com/aers/FFXIVClientStructs/blob/main/FFXIVClientStructs/FFXIV/Client/Game/UI/PlayerState.cs)

## Verification boundary

Production-linked state-machine, scheduler and adapter tests simulate the changing fields. Native dispatch is a test boundary; a passing build or these tests does not establish actual in-game skill execution. UI and asset regressions are checked independently. No install, hot reload, live macro execution or GitHub publication is part of this delivery.

Use the README's 0.2-second reproduction after loading 0.8.2.0. Inspect `[切职保护]` records; if all fields match but the error remains, retain those records and investigate further instead of inventing a hidden fixed buffer.
