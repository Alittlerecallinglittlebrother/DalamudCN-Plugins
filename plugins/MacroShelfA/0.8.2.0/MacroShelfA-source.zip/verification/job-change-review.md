# Job-change guard independent review — 0.8.2.0

Reviewer: job_gate_review. Scope: JobChangeGuard, NativeJobChangeHost, MacroSequence, MacroExecutor, and candidate-scope documentation. Read-only code review; not an in-game test.

## Findings and final recheck

1. **Resolved — obsolete callback exception.** The exception path now checks the scheduler generation before stopping or rethrowing. If a synchronous plugin callback replaces the run and then throws, its obsolete exception no longer stops the replacement or reaches executor cleanup for the new guard.
2. **Resolved — hard timeout.** A previously blocked action checks the 10-second deadline before evaluating a now-matching snapshot. A long stalled frame cannot emit a stale action beyond that deadline.
3. **Scope reminder addressed.** README explicitly uses supported English commands and ASCII spaces/tabs, calls the guard a candidate consistency barrier, and does not equate observations with native action-name-cache readiness.

## Other reviewed properties

- A deferred action does not consume the row or start its post-dispatch wait.
- Gearset commands dispatch once; already-dispatched actions are never retried.
- Ordinary commands and preceding chat have no new global delay; later chat does not skip past a held action.
- The pending guard is cleared before the first released action is sent; synchronous replacement cannot be cleared by an old post-send operation.
- Named/unsupported changes discard obsolete targets. Missing modules, identity changes and valid/invalid numeric targets have explicit behavior.
- State observations are read-only through current bindings; the native sender and all UI source remain unchanged.

Final disposition: **no remaining blocking issue in the reviewed scope; local candidate only**. Production-linked regression results are recorded separately in build-test.log. This review does not establish actual native action-name readiness, skill execution, installation, hot reload or publication.
