# 已确认的因果路径

1. 0.8.0 DrawPicker 只在 Appearing 设置大小，BeginPopup 的默认 AlwaysAutoResize 与按 GetContentRegionAvail 伸展的子区形成反馈。原代码在本机原生 ImGui 重现：430×352 开始，100 帧后变为444×494，接近720×500测试视口的高度上限。不是凭截图猜测。见 baseline/baseline-growth.json。
2. 本机 API15 Dalamud.dll 的 WindowHost.DrawInternal 先调用 Window.PreDraw() 再调用 ApplyConditionals()；后者对 Window.Size.Value 乘 ImGuiHelpers.GlobalScale。旧代码已经把 Size 算成物理像素，造成双重缩放。将真实宿主顺序纳入测试后，旧栏在150%变为1093×429，超过1080宽的测试视口。旧离线测试只执行 PreDraw 的 SetNextWindowSize，因此漏检此问题。
3. 本机 PluginImageCache.TryLoadImage 对图标检查宽高不超过512，且 requireSquare=true。因此不直接把828×804原图作为列表图标：内嵌资源保留原始字节，列表图标仅等比缩小到512正方形并补透明边，不裁切人物、不生成。

修正：固定弹窗尺寸与明确列表/底部区域；Window.Size只接收逻辑尺寸；空闲 footer 删除，运行或错误才分配状态行。新增真实宿主顺序模拟与600帧/10次重开测试。仍未在用户游戏进程中验收。
