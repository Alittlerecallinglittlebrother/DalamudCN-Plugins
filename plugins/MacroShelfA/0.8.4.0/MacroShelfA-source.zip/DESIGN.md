---
name: "Macro Shelf-A"
description: "Windows 原生宏资料库与树状编辑台的已实现视觉规范"
colors:
  primary: "rgb(11% 38% 72%)"
  primary-hover: "rgb(12% 41% 77%)"
  checkmark: "rgb(18% 53% 94%)"
  success: "rgb(35% 82% 54%)"
  danger: "rgb(93% 40% 43%)"
  danger-deep: "rgb(70% 24% 29%)"
  favorite: "rgb(100% 78% 32%)"
  text: "rgb(92% 95% 99%)"
  text-muted: "rgb(66% 76% 86%)"
  canvas: "rgb(4.5% 6.8% 9.5%)"
  surface: "rgb(7.5% 11.5% 16.5%)"
  border: "rgb(20% 29% 38%)"
  field: "rgb(5.5% 8.5% 12.5%)"
  field-hover: "rgb(10% 17% 25%)"
  field-active: "rgb(13% 25% 39%)"
  button-secondary: "rgb(11% 18% 26%)"
  button-secondary-hover: "rgb(16% 30% 44%)"
  selection: "rgb(13% 30% 51%)"
  selection-hover: "rgb(16% 32% 50%)"
  table-header: "rgb(6.5% 10% 14.5%)"
typography:
  title:
    fontSize: "150%"
  body:
    fontSize: "100%"
  label:
    fontSize: "100%"
rounded:
  control: "5px"
  icon-hover: "4px"
  icon-outline: "1px"
spacing:
  item-gap: "8px"
  frame-x: "10px"
  frame-y: "7px"
  panel-padding: "12px"
  tree-category-indent: "10px"
  tree-child-indent: "19px"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.text}"
    rounded: "{rounded.control}"
    padding: "7px 10px"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
    textColor: "{colors.text}"
  button-primary-active:
    backgroundColor: "{colors.primary-hover}"
    textColor: "{colors.text}"
  button-secondary:
    backgroundColor: "{colors.button-secondary}"
    textColor: "{colors.text}"
    rounded: "{rounded.control}"
    padding: "7px 10px"
  button-secondary-hover:
    backgroundColor: "{colors.button-secondary-hover}"
  button-secondary-active:
    backgroundColor: "{colors.primary}"
  button-danger:
    backgroundColor: "{colors.danger}"
    textColor: "{colors.text}"
    rounded: "{rounded.control}"
    padding: "7px 10px"
  button-danger-hover:
    backgroundColor: "{colors.danger-deep}"
  button-stop:
    backgroundColor: "{colors.danger-deep}"
    textColor: "{colors.text}"
    rounded: "{rounded.control}"
    width: "100px"
    height: "31px"
  field-text:
    backgroundColor: "{colors.field}"
    textColor: "{colors.text}"
    rounded: "{rounded.control}"
    padding: "7px 10px"
  field-text-hover:
    backgroundColor: "{colors.field-hover}"
  field-text-active:
    backgroundColor: "{colors.field-active}"
  category-selected:
    backgroundColor: "{colors.selection}"
    textColor: "{colors.text}"
    height: "35px"
  library-row-selected:
    backgroundColor: "{colors.selection}"
    textColor: "{colors.text}"
    height: "43px"
  panel:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    rounded: "{rounded.control}"
    padding: "12px"
  command-editor:
    backgroundColor: "{colors.field}"
    textColor: "{colors.text}"
    rounded: "{rounded.control}"
    padding: "7px 10px"
---

# Design System: Macro Shelf-A

## Overview

**Creative North Star: "深蓝原生资料柜"**

深海军蓝与炭黑组成紧凑的原生资料柜：较浅面板、细分隔、克制蓝色选择与执行入口，以及清楚的中文文本。沿用已批准 A/B 概念的气质，不将概念图里的装饰、语法着色或大标题误认成实现。

本规范记录 0.7.0.0 当前 C# / ImGui 界面，不是网站或下一版需求。产品约束见 PRODUCT.md；本次 A 主资料库、B 树编辑台的组合见 design/surface-brief.md。实际视觉以 MainWindow 三个分文件为准，窗口外壳和字体仍由 Dalamud 宿主管理。

**Key Characteristics:**
- 深蓝分层、细边界、小圆角。
- 蓝色定位与执行，绿色状态，红色中止和破坏性确认。
- 宿主中文字体，标题相对放大。
- 局部滚动、选择不执行、明确自动保存。

**平台与来源。** Windows / DalamudCN API 15 / C# / ImGui。源头为 MacroShelfA/Windows/MainWindow.cs、MainWindow.Editor.cs、MainWindow.Settings.cs。没有 Web 运行时。

**token 单位。** CSS rgb 百分比忠实表达 C# 归一化 RGB 浮点值，全部不透明；不另做有损 hex 取整。长度 px 是 GlobalScale=1 时 ImGui 基准布局单位的可移植表达，生产多数长度使用 S(n)=n×ImGuiHelpers.GlobalScale。字体百分比表达原生相对缩放；不是 CSS 实现。未覆写的宿主样式不从此规范推导。

## Colors

冷调深色背景托住冷白正文，功能色只承担识别与反馈。

### Primary
- **执行蓝**（primary）：运行、追加导入、当前页面按钮底色。**提亮执行蓝**（primary-hover）用于封装主按钮的 hover 和 active。
- **清亮勾选蓝**（checkmark）：保留原亮蓝 checkbox 勾，与执行底色分开。
- **选中钢蓝 / 悬停钢蓝**（selection / selection-hover）：分类、树和对象选择。HeaderActive 使用执行蓝；选中列表行另显式设 selection。

### Secondary
以下是功能状态色，不是第二组品牌主题。
- **状态绿**（success）：就绪、运行状态、导入成功。
- **警示红 / 深警示红**（danger / danger-deep）：超限、错误、删除与替换确认。删除/替换为红常态、深红 hover/active；页脚中止反向使用深红常态、红 hover/active。
- **收藏金**（favorite）：已收藏填充星；未收藏是浅蓝轮廓星。

### Neutral
- text / text-muted：冷白正文 / 浅蓝说明；TextDisabled 也用 text-muted，最终禁用透明度继承宿主。
- canvas / surface / border：炭黑底幕 / 深蓝面板 / 冷钢边界。
- field / field-hover / field-active：搜索与编辑暗槽及其状态。
- button-secondary / button-secondary-hover：普通按钮；active 为执行蓝。
- table-header：宏表表头暗层。窗口标题色和滚动条等未覆写样式由宿主控制。

**The State Is Not Execution Rule.** 选中高亮只表示当前对象；执行必须通过显式运行操作。

contrast-check.json 仅验证冷白文本对执行蓝常态约 5.42:1、hover/active 约 4.83:1，达到该检查的 4.5:1 阈值；不覆盖红色按钮、全部禁用态或整套可访问性。源码还覆写 ImGui Tab 色，但当前没有 TabBar，故不将它们扩写成现用组件。

## Typography

**Display Font:** 无独立字体。  
**Body Font:** 继承 Dalamud 当前 ImGui 字体图集与中文覆盖。  
**Label/Mono Font:** 标签与命令编辑没有另设字体或等宽声明。

- **Title**：Heading 临时 SetWindowFontScale(1.5f)，输出后复位到 1；没有自定义字重。
- **Body / Label**：继承基础字号，依赖颜色与空间分层，不承诺固定像素字号。
- Fit 按 ImGui 测量与组合字符边界补省略号，标题/条目 hover 显示完整 tooltip；帮助段落通常 TextWrapped。并非所有文本都走 Fit。

**The Host Owns Type Rule.** 测试宿主的字体、字号和光栅效果不是插件字体承诺。

RuntimeUi.cs 测试宿主加载 Windows msyh.ttc，基准字号 17；150% 样本同时设置 FontGlobalScale 和 GlobalScale。生产 MainWindow 未固定该字体和字号。面板示例的浏览器系统字体只是转译。

## Layout

### 原生外壳与缩放
- 首次窗口建议 1120×760；WindowSizeConstraints 声明最小 720×500、最大 1920×1400，最终宿主缩放由 Dalamud 管理。测试宿主强制 ImGui 尺寸，不覆盖真实 Window 类全部外壳行为。
- ItemSpacing 为 item-gap；FramePadding 为 frame-x / frame-y；WindowPadding 为 panel-padding。
- 顶部“资料库 / 编辑台 / 事件触发”、搜索、“新建”、“设置”持续显示。搜索宽 max(S(80),余宽−S(140))。
- 根页面不滚动；内容高 max(S(180),可用高−S(54))，之后绘制共享页脚。各长内容区独立滚动。

### 资料库
令 W 为页面可用宽度：分类宽 clamp(W×0.18,S(150),S(260))；详情预算 clamp(W×0.30,S(220),S(430))；列表宽 max(S(200),W−分类宽−详情预算−S(16))；最后详情 Child 实际占余宽。不是固定 18/50/32 网格。

- 列表内部宽 **大于 S(400)** 才显示类型列；收藏宽 S(26)、类型 S(54)、内容 S(86)，名称拉伸，表头冻结，表格纵向滚动。
- 分类行高 S(35)，表格行最小高 S(43)，名称 Selectable 高 S(35)。图标命中区 S(26)×S(30)，图形边长 S(16)。
- 分类内滚动保留底部 S(95)；详情内滚动保留 S(128)。底部编辑高 S(34)、运行高 S(38)，不随详情长内容滚走。

### 编辑台
- 树宽 clamp(W×0.30,S(185),S(360))，编辑区占余宽；没有拖拽分栏或手机抽屉。
- 树分类缩进 tree-category-indent，子宏追加 tree-child-indent；树条目高 S(31)，分类高 S(30)。树内滚动保留底部 S(45) 给导入/导出。
- 编辑头部为路径、标题、对象信息和自动保存；属性默认收起。EditScroll 高 max(S(70),余高−S(96))，其下保留重排/复制/删除及运行操作。
- 多行框高 max(S(140),内区余高−S(33))，自身可滚动、支持 Tab；运行主按钮高 S(35)。

### 适配与证据
保持三栏资料库、双栏编辑台，用 clamp、隐藏类型列、截断和局部滚动适配；没有 CSS 断点或单栏移动版。现有截图矩阵是 720×500、940×760、1200×900、1536×1024，以及 1080×750 / 150%。

本次文档目视核对 design/approved-library.png、approved-editor.png 与 verification/library-940.png、editor-940.png；其他矩阵文件已存在并有源码定义，未在本轮重新逐张复验。批准图是生成概念，截图是同一 MainWindow 源码经 cimgui 和软件光栅器生成，内容是合成 fixture。

verification/build-test.log 记录 120/120 逻辑检查与 87 个原生 UI 断言，含筛选、树、改名、重排、400 行中文输入、设置、创建、倒计时、导入、200 条目和空状态。服务及游戏派发为测试替身；截图/断言不等于游戏内实测，也不证明全部 DPI、字体、输入法或真实游戏事件兼容性。

## Elevation & Depth

面板依靠深浅层次、边界和选择条分区。源码没有自定义阴影、模糊、渐变、玻璃或装饰光；弹窗、部分分隔与滚动条反馈继承宿主。没有自定义 transition、缓动或过场，状态随 ImGui 帧更新。

**The Tonal, Not Floating Rule.** 靠明度与边界分层，不把概念氛围光写成实现中的阴影或玻璃效果。

## Shapes

- 控件和 Child 使用 control 圆角；图标 hover 背景为 icon-hover；文件/宏组图形拐角为 icon-outline。不是大圆角卡片系统。
- 带边框 Child 分区；Border 只定义颜色，边框厚度和导航焦点并未全部覆写。
- 文件、四格宏组、星形、播放三角由 DrawList 向量绘制，线宽 max(1,S(1.4))；不使用 icon-font 或生成截图。
- 收藏星有填充/轮廓状态与 tooltip。没有独立 chip/tag 组件；分类是文本和过滤项。

## Components

### Buttons & Navigation
紧凑、明确，按动作分色。
- DrawColoredButton 的 hover/active 共用传入色。普通按钮有独立常态/hover/active；顶部当前页面仅覆盖常态，hover 仍是普通按钮色。
- 禁用 alpha、键盘/导航焦点继承宿主，无自定义 focus ring。执行中禁用运行，空宏组也禁用；页脚“中止整组”仅执行中出现，独立宏也沿用该现有标签。
- 单击宏行只选择，双击进入编辑；星形独立改变持久化 Pinned。宏组详情的子宏名进入编辑，播放图标单独运行子宏。
- 搜索匹配根/子宏名称、分类和命令，资料库返回根入口。保存顺序/名称/宏组优先是视图排序，不改保存及执行顺序。树搜索展开命中分支，打开对象可 SetScrollHereY(0.3) 定位。

### Inputs & Command Editor
- 搜索是带 hint 单行输入；属性是名称、分类和收藏。正文为真实 InputTextMultiline，无语法着色、行号或手动保存按钮。
- 命令修改立即保存；名称/分类编辑失焦或无激活项时保存。运行时提示使用启动快照，修改下次生效。
- 行计数来自执行准备后的行，不是视觉折行。超 15 行且限制未解除时提示去设置；超 64,000 字符提示拆分，已有内容不截断；超限计数为警示色。
- 现有数据上限：名称 32、分类 24 字符，总条目 200、组内子宏 64；新增/复制/添加按容量禁用。

### Panels & Inspector
- 标题、类型、分类、子宏/行数先于正文；只在所选组详情展开其子宏列表。独立宏预览只取原文前 16 行，更多内容进入编辑台。
- 无宏指向顶部“新建”；无结果可清除筛选；无选择、空宏组、空命令分别显示现有引导，不填假内容。
- 类别右侧是根入口数，左下容量包含宏组和子宏；二者口径不同。

### Shared Footer & Global Controls
- 就绪为绿色“就绪”与浅蓝“未执行宏”。运行时先显示中止，再显示宏/子宏、行进度和剩余等待；长状态截断并给 tooltip。
- 设置独立滚动：解除 15 行、更好的等待、悬浮入口（尺寸 32–96）、配置管理，不塞回每条列表。
- 事件触发为全宽目标 Combo、启用 checkbox、监听与结果文本；无目标禁用开关。空目标说明指向顶部“新建”；停止已运行宏说明指向底部“中止整组”。

### Confirmation & Transfer
- 原生模态弹窗。导入首次大小取 min(680×Scale,DisplaySize.X−32) 与 min(520×Scale,DisplaySize.Y−32)。
- 追加为主按钮；替换首次切换“确认替换”，再次才覆盖。删除确认显示名称及组内数量；取消关闭。
- 导入失败在弹窗显示错误色；替换完成回资料库、清筛选、选择新对象并清除倒计时绑定，避免旧选择残留。

**面板边界。** .impeccable/design.json 为 schemaVersion 2 扩展；HTML/CSS 仅为 shadow DOM 设计面板转译，不实现 C# 数据绑定、自动保存或宏执行。合成 OKLCH 八阶色条、浏览器字体/焦点仅供展示，不是新增产品 token。

## Do's and Don'ts

### Do:
- **Do** 延续批准的深蓝原生界面；用源代码和本文件 token 核对具体数值。
- **Do** 保持选择、编辑、运行、中止不同语义，保留跨页状态栏。
- **Do** 按宿主字体与 S(n) 缩放检查窄窗口；长名称截断后仍保留完整 tooltip。
- **Do** 保留自动保存、真实多行缓冲区、查看排序与保存顺序的区别。
- **Do** 分开标注生成概念、测试宿主截图、自动断言与游戏内验证。

### Don't:
- **Don't** 用生成截图代替交互界面，或承诺与概念逐像素一致。
- **Don't** 将亮蓝勾选标记合并为主按钮底色。
- **Don't** 新增未实现的网页断点、移动抽屉、语法高亮、行号、手动保存、队列、BPM 或时间线。
- **Don't** 把面板 HTML/CSS、合成色阶或浏览器焦点示意当作生产实现。
- **Don't** 用测试宿主或局部对比度结果声称游戏内、全部可访问性或用户验收已通过。

