using Dalamud.Plugin.Services;

// Host boundary only: all scheduling, CRUD, migration, exchange and UI code is production source.
namespace MacroShelfA
{
    internal static class Plugin
    {
        public static FakeConfigStore PluginInterface { get; } = new();
        public static FakeFramework Framework { get; } = new();
        public static FakeClientState ClientState { get; } = new();
        public static FakeCondition Condition { get; } = new();
        public static FakeCommands CommandManager { get; } = new();
        public static FakeChat ChatGui { get; } = new();
        public static FakeLog Log { get; } = new();
    }
    internal sealed class FakeConfigStore
    {
        public string Json = "";
        public void SavePluginConfig(object value) => Json = Newtonsoft.Json.JsonConvert.SerializeObject(value);
    }
    internal sealed class FakeFramework
    {
        public event Action<IFramework>? Update;
        public void Tick() => Update?.Invoke(null!);
        public int Subscribers => Update?.GetInvocationList().Length ?? 0;
    }
    internal sealed class FakeClientState
    {
        public bool IsLoggedIn { get; set; } = true;
        public uint TerritoryType { get; set; } = 100;
    }
    internal sealed class FakeCondition
    {
        public HashSet<Dalamud.Game.ClientState.Conditions.ConditionFlag> Flags { get; } = [];
        public bool this[Dalamud.Game.ClientState.Conditions.ConditionFlag flag] => Flags.Contains(flag);
    }
    internal sealed class FakeCommands
    {
        public readonly List<string> Sent = [];
        public bool ProcessCommand(string command) { Sent.Add(command); return true; }
    }
    internal sealed class FakeChat
    {
        public event IChatGui.OnLogMessageDelegate? LogMessage;
        public int Subscribers => LogMessage?.GetInvocationList().Length ?? 0;
        public void Emit(uint id)
        {
            var message = System.Reflection.DispatchProxy.Create<Dalamud.Game.Chat.ILogMessage, FakeLogMessage>();
            ((FakeLogMessage)(object)message).Id = id;
            LogMessage?.Invoke(message);
        }
        public readonly List<string> Errors = [];
        public void PrintError(string text) => Errors.Add(text);
        public void Print(string text) { }
    }
    public class FakeLogMessage : System.Reflection.DispatchProxy
    {
        public uint Id;
        protected override object? Invoke(System.Reflection.MethodInfo? method, object?[]? arguments) =>
            method?.Name == "get_LogMessageId" ? Id : throw new Exception("Unexpected log message access: " + method?.Name);
    }
    internal sealed class FakeLog
    {
        public readonly List<string> Messages = [];
        public void Error(Exception error, string message) { }
        public void Information(string template, params object[] arguments) =>
            Messages.Add(arguments.Length == 0 ? template : string.Join(" | ", arguments.Select(x => x?.ToString() ?? "null")));
    }
}
namespace MacroShelfA.Runtime
{
    internal sealed class NativeJobChangeHost : IJobChangeHost
    {
        public JobChangeSnapshot ReadState() => default;
        public byte? GetGearsetJob(int zeroBasedIndex) => null;
        public bool SendCommand(string command)
        {
            if (Plugin.CommandManager.ProcessCommand(command)) return false;
            NativeCommandSender.Send(command);
            return true;
        }
    }
    internal sealed class BetterWaitPatch
    {
        public string StatusText => "测试宿主 · 未应用内存补丁";
        public void SetEnabled(bool enabled) { }
    }
}
namespace Dalamud.Interface.Utility
{
    internal static class ImGuiHelpers { public static float GlobalScale { get; set; } = 1; }
}

