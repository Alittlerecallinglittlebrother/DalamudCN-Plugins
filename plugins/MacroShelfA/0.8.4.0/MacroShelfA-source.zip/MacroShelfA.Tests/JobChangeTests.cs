using MacroShelfA;
using MacroShelfA.Runtime;

// Exercise production scheduling and guard logic; the game/native boundary is always mocked.
internal static class JobChangeTests
{
    private const byte Astrologian = 33;
    private const byte OtherJob = 24;
    private static MacroEntry Leaf(string text, string name = "切职测试") => new() { Name = name, Commands = text };
    private static MacroEntry Group(params MacroEntry[] entries) => new() { Name = "跨子宏切职", IsGroup = true, Children = [.. entries] };
    private static JobChangeSnapshot State(byte job = OtherJob, int set = 0) =>
        new(true, 123456789, 0x10203040, job, job, job, set);

    private sealed class Host : IJobChangeHost
    {
        internal JobChangeSnapshot Current = State();
        internal readonly Dictionary<int, byte?> Jobs = new() { [5] = Astrologian, [13] = OtherJob };
        internal readonly List<(double At, string Command)> Sent = [];
        internal readonly List<int> Lookups = [];
        internal readonly List<string> Calls = [];
        internal double Now;
        internal bool NativeDispatch = true;
        internal Action<string>? OnSend;
        public JobChangeSnapshot ReadState() { Calls.Add("read"); return Current; }
        public byte? GetGearsetJob(int index)
        {
            Calls.Add("lookup:" + index); Lookups.Add(index);
            return Jobs.GetValueOrDefault(index);
        }
        public bool SendCommand(string command)
        {
            Calls.Add("send:" + command); Sent.Add((Now, command)); OnSend?.Invoke(command);
            return NativeDispatch;
        }
    }

    private sealed class Harness : IDisposable
    {
        internal readonly Host Host;
        internal readonly MacroExecutor Executor;
        internal double Now;
        internal Harness(MacroEntry macro, Host? host = null)
        {
            Host = host ?? new();
            Plugin.ClientState.IsLoggedIn = true;
            Executor = new MacroExecutor(new Configuration { AllowLongMacros = true }, () => Now, Host);
            if (!Executor.TryStart(macro, out var error)) throw new InvalidOperationException(error);
        }
        internal void Tick(double time)
        {
            Now = time; Host.Now = time; Plugin.Framework.Tick();
        }
        internal string[] Commands => Host.Sent.Select(x => x.Command).ToArray();
        public void Dispose()
        {
            Executor.Dispose(); Plugin.ClientState.IsLoggedIn = true;
        }
    }

    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "job-change assertion failed") => check(value, message);
        void Test(string name, Action body) => test("job-change: " + name, body);
        void Close(double actual, double expected) => Check(Math.Abs(actual - expected) < 0.000001, $"{actual} != {expected}");

        foreach (var (text, index) in new (string, int)[] {
            ("/gs change 1", 0), ("/gs change 6", 5), ("/gs change 100", 99),
            ("/gearset change 6", 5), ("/GEARSET CHANGE 6", 5),
            ("/gs\tchange\t6", 5), ("/gs change 6 1", 5), ("/gs change 006 20  ", 5) })
            Test("numeric parser maps one-based gearset: " + text, () =>
            {
                Check(JobChangeGuard.TryParseGearsetChange(text, out var actual) && actual == index);
                var host = new Host(); host.Jobs[index] = Astrologian;
                var guard = new JobChangeGuard(host);
                Check(guard.TryDispatch(text, 0)); Check(host.Lookups.SequenceEqual([index]));
                Check(host.Calls.SequenceEqual(["lookup:" + index, "read", "send:" + text]), "mapping and snapshot must precede dispatch");
            });
        foreach (var text in new[] { "/gs change 0", "/gs change 101", "/gs change 1000", "/gs change -1",
            "/gs change +1", "/gs change 占星", "/gs change \"占星套装\"", "/gs change", "/gschanger change 6",
            "/gs change 6 garbage", "/echo /gs change 6", "/gs change 6 1 2" })
            Test("unsupported parser does not resolve a guessed target: " + text, () =>
            {
                Check(!JobChangeGuard.TryParseGearsetChange(text, out _));
                var host = new Host(); var guard = new JobChangeGuard(host);
                Check(guard.TryDispatch(text, 0) && host.Lookups.Count == 0 && host.Sent.Count == 1);
            });
        Test("ordinary actions retain zero default delay and one line per frame", () =>
        {
            using var run = new Harness(Leaf("/y before\n/ac 即刻咏唱\n/action 阳星合相\n/y after"));
            for (var i = 0; i < 4; i++) { run.Tick(i * 0.001); Check(run.Host.Sent.Count == i + 1); }
            Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange);
            Check(run.Host.Calls.All(x => x.StartsWith("send:")), "normal macros must not poll native state");
            Close(run.Host.Sent[3].At, 0.003);
        });
        Test("exact user 0.2 case blocks lyrics and all later commands until all sources match", () =>
        {
            using var run = new Harness(Leaf("/songbird<wait.3>\n/gs change 6<wait.0.2>\n/y 独一无二\n/ac 即刻咏唱<wait.1.5>\n/ac 阳星合相<wait.1.8>\n/sh 想被注意\n/victorypose<wait.4>"));
            run.Tick(0); run.Tick(2.99); Check(run.Host.Sent.Count == 1);
            run.Tick(3); Check(run.Host.Lookups.SequenceEqual([5]));
            run.Tick(3.199); Check(run.Host.Sent.Count == 2);
            run.Tick(3.2); Check(run.Commands.Last() == "/gs change 6");
            run.Tick(3.22); Check(run.Executor.IsWaitingForJobChange && run.Executor.ExecutedLines == 2 && run.Host.Sent.Count == 2);
            run.Host.Current = State() with { LocalJob = Astrologian };
            run.Tick(3.3); Check(run.Host.Sent.Count == 2);
            run.Host.Current = run.Host.Current with { PlayerJob = Astrologian };
            run.Tick(3.4); Check(run.Host.Sent.Count == 2);
            run.Host.Current = run.Host.Current with { HotbarJob = Astrologian };
            run.Tick(3.5); Check(run.Host.Sent.Count == 2, "matching jobs alone must not ignore the gearset");
            run.Host.Current = run.Host.Current with { GearsetIndex = 5 };
            run.Tick(3.6); Check(run.Commands.Last() == "/y 独一无二" && run.Executor.ExecutedLines == 3);
            run.Tick(3.601); Check(run.Commands.Last() == "/ac 即刻咏唱" && run.Executor.ExecutedLines == 4);
            Check(!run.Executor.IsWaitingForJobChange); Close(run.Executor.RemainingWait, 1.5);
            run.Tick(5.100); Check(run.Host.Sent.Count == 4);
            run.Tick(5.102); Check(run.Commands.Last() == "/ac 阳星合相");
            run.Tick(6.901); Check(run.Host.Sent.Count == 5);
            run.Tick(6.903); Check(run.Commands.Last() == "/sh 想被注意");
            run.Tick(6.904); Check(run.Commands.Last() == "/victorypose");
            run.Tick(10.905); Check(!run.Executor.IsRunning && run.Host.Sent.Count == 7);
        });
        foreach (var (label, observed) in new (string, JobChangeSnapshot)[] {
            ("local", State(Astrologian, 5) with { LocalJob = OtherJob }),
            ("player", State(Astrologian, 5) with { PlayerJob = OtherJob }),
            ("hotbar", State(Astrologian, 5) with { HotbarJob = OtherJob }),
            ("gearset", State(Astrologian, 4)),
            ("module availability", State(Astrologian, 5) with { Available = false }) })
            Test("inconsistent " + label + " alone defers action without consuming line", () =>
            {
                using var run = new Harness(Leaf("/gs change 6\n/ac 即刻咏唱\n/y must-not-overtake"));
                run.Tick(0); run.Host.Current = observed;
                for (var i = 1; i <= 100; i++) run.Tick(i * 0.01);
                Check(run.Host.Sent.Count == 1 && run.Executor.ExecutedLines == 1 && run.Executor.RemainingLines == 2);
                Check(run.Executor.IsWaitingForJobChange && run.Executor.CurrentMacroName == "切职测试");
                run.Host.Current = State(Astrologian, 5); run.Tick(1.01); run.Tick(1.011);
                Check(run.Commands.SequenceEqual(["/gs change 6", "/ac 即刻咏唱", "/y must-not-overtake"]));
            });
        Test("ready observations dispatch immediately, with no added settling delay", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac 即刻咏唱\n/y after"));
            run.Tick(0); run.Host.Current = State(Astrologian, 5); run.Tick(0.001); run.Tick(0.002);
            Check(run.Host.Sent.Count == 3 && !run.Executor.IsRunning); Close(run.Host.Sent[1].At, 0.001);
        });
        Test("completed transition clears the barrier; dispatched actions are not retried or ACK-polled", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac 即刻咏唱<wait.1.5>\n/ac 阳星合相"));
            run.Tick(0); run.Tick(0.1); run.Host.Current = State(Astrologian, 5); run.Tick(0.5);
            var readsAfterAction = run.Host.Calls.Count(x => x == "read");
            run.Host.Current = State();
            for (var i = 1; i < 100; i++) run.Tick(0.5 + i * 0.01);
            run.Tick(2); run.Tick(9);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/ac 即刻咏唱", "/ac 阳星合相"]));
            Check(run.Host.Calls.Count(x => x == "read") == readsAfterAction, "no post-dispatch ACK or readiness polling");
            Check(!run.Executor.IsRunning);
        });
        Test("timeout counts ten seconds from first blocked action, not gearset dispatch", () =>
        {
            var errors = Plugin.ChatGui.Errors.Count;
            using var run = new Harness(Leaf("/gs change 6<wait.20>\n/ac 即刻咏唱\n/y forbidden"));
            run.Tick(0); run.Tick(19.99); Check(!run.Executor.IsWaitingForJobChange);
            run.Tick(20); run.Tick(29.999); Check(run.Executor.IsRunning && run.Executor.IsWaitingForJobChange);
            run.Tick(30); Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange);
            Check(run.Host.Sent.Count == 1 && Plugin.ChatGui.Errors.Count == errors + 1);
            Check(Plugin.ChatGui.Errors.Last().Contains("10 秒") && Plugin.ChatGui.Errors.Last().Contains("第 2 行"));
            run.Tick(40); Check(run.Host.Sent.Count == 1);
        });
        Test("missing modules after dispatch time out without action or later chat", () =>
        {
            var errors = Plugin.ChatGui.Errors.Count;
            using var run = new Harness(Leaf("/gs change 6\n/ac 即刻咏唱\n/y forbidden"));
            run.Tick(0); run.Host.Current = default;
            run.Tick(1); run.Tick(10.999); Check(run.Executor.IsRunning);
            run.Tick(11); Check(!run.Executor.IsRunning && run.Host.Sent.Count == 1);
            Check(Plugin.ChatGui.Errors.Count == errors + 1 && Plugin.ChatGui.Errors.Last().Contains("available=False"));
        });
        Test("stalled frame after hard deadline aborts even when next snapshot matches", () =>
        {
            var errors = Plugin.ChatGui.Errors.Count;
            using var run = new Harness(Leaf("/gs change 6\n/ac too-late\n/y forbidden"));
            run.Tick(0); run.Tick(0.2); Check(run.Executor.IsWaitingForJobChange);
            run.Host.Current = State(Astrologian, 5); run.Tick(11);
            Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange && run.Host.Sent.Count == 1);
            Check(Plugin.ChatGui.Errors.Count == errors + 1 && Plugin.ChatGui.Errors.Last().Contains("10 秒"));
        });
        Test("missing initial module with stable identity aborts before gearset dispatch", () =>
        {
            var errors = Plugin.ChatGui.Errors.Count;
            var host = new Host { Current = State() with { Available = false } };
            using var run = new Harness(Leaf("/gs change 6\n/ac 即刻咏唱"), host);
            run.Tick(0); run.Tick(0.1);
            Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange && run.Host.Sent.Count == 0);
            Check(Plugin.ChatGui.Errors.Count == errors + 1 && Plugin.ChatGui.Errors.Last().Contains("未发送切职命令"));
            host.Current = State(Astrologian, 5); run.Tick(0.2);
            Check(!run.Executor.IsRunning && run.Host.Sent.Count == 0);
        });
        Test("same-job different-set equipment switch waits for the target gearset", () =>
        {
            var host = new Host { Current = State(Astrologian, 0) };
            using var run = new Harness(Leaf("/gs change 6\n/ac 即刻咏唱"), host);
            run.Tick(0); run.Tick(0.001);
            Check(run.Executor.IsRunning && run.Host.Sent.Count == 1 && run.Executor.IsWaitingForJobChange);
            host.Current = State(Astrologian, 5); run.Tick(0.002);
            Check(!run.Executor.IsRunning && run.Host.Sent.Count == 2 && !run.Executor.IsWaitingForJobChange);
        });
        Test("same-job same-set request does not add a transition barrier", () =>
        {
            var host = new Host { Current = State(Astrologian, 5) };
            using var run = new Harness(Leaf("/gs change 6\n/divinearm"), host);
            run.Tick(0); run.Tick(0.001);
            Check(!run.Executor.IsRunning && run.Host.Sent.Count == 2 && !run.Executor.IsWaitingForJobChange);
            Check(host.Calls.Count(x => x == "read") == 1, "already-matching request needs only its pre-dispatch snapshot");
        });
        foreach (var target in new byte?[] { null, 0 })
            Test("invalid or missing gearset job is never guessed: " + (target?.ToString() ?? "null"), () =>
            {
                var host = new Host(); host.Jobs[5] = target;
                using var run = new Harness(Leaf("/gs change 6\n/ac 即刻咏唱"), host);
                run.Tick(0); run.Tick(0.001);
                Check(run.Host.Sent.Count == 2 && !run.Host.Calls.Contains("read") && !run.Executor.IsRunning);
            });
        foreach (var unsupported in new[] { "/gs change \"占星套装\"", "/gs change +1", "/gearset change 101" })
            Test("unsupported new change cannot overtake an older pending numeric target: " + unsupported, () =>
            {
                using var run = new Harness(Leaf("/gs change 6\n" + unsupported + "\n/ac 即刻咏唱"));
                run.Tick(0); run.Tick(0.001); Check(run.Host.Sent.Count == 1 && run.Executor.IsWaitingForJobChange);
                run.Host.Current = State(Astrologian, 5); run.Tick(0.002); run.Tick(0.003);
                Check(run.Commands.SequenceEqual(["/gs change 6", unsupported, "/ac 即刻咏唱"]));
                Check(!run.Executor.IsRunning && run.Host.Lookups.SequenceEqual([5]));
            });
        Test("another plugin consuming gearset command never arms guard", () =>
        {
            var host = new Host { NativeDispatch = false };
            using var run = new Harness(Leaf("/gs change 6\n/ac 即刻咏唱"), host);
            run.Tick(0); run.Tick(0.001); Check(run.Host.Sent.Count == 2 && !run.Executor.IsRunning);
        });
        Test("guard reset discards blocked state without sending stale command", () =>
        {
            var host = new Host(); var guard = new JobChangeGuard(host);
            Check(guard.TryDispatch("/gs change 6", 0)); Check(!guard.TryDispatch("/ac 即刻咏唱", 0.1));
            Check(guard.IsWaiting); guard.Reset(); Check(!guard.IsWaiting);
            Check(guard.TryDispatch("/ac next", 0.2) && host.Sent.Select(x => x.Command).SequenceEqual(["/gs change 6", "/ac next"]));
        });
        Test("stop cancels pending action and restart begins cleanly", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac stale\n/y stale"));
            run.Tick(0); run.Tick(0.1); Check(run.Executor.IsWaitingForJobChange);
            run.Executor.Stop(false); run.Host.Current = State(Astrologian, 5); run.Tick(10);
            Check(run.Host.Sent.Count == 1 && !run.Executor.IsWaitingForJobChange);
            Check(run.Executor.TryStart(Leaf("/ac fresh"), out _)); run.Tick(10.001);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/ac fresh"]));
        });
        Test("busy rejected start does not reset active guard", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac original"));
            run.Tick(0); run.Tick(0.1); Check(!run.Executor.TryStart(Leaf("/ac replacement"), out var error));
            Check(error.Contains("已有宏") && run.Executor.IsWaitingForJobChange);
            run.Tick(0.2); Check(run.Host.Sent.Count == 1);
            run.Host.Current = State(Astrologian, 5); run.Tick(0.3);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/ac original"]));
        });
        Test("logout cancels guard and prevents resuming action after relogin", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac stale"));
            run.Tick(0); run.Tick(0.1); Plugin.ClientState.IsLoggedIn = false; run.Tick(0.2);
            Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange);
            Plugin.ClientState.IsLoggedIn = true; run.Host.Current = State(Astrologian, 5); run.Tick(0.3);
            Check(run.Host.Sent.Count == 1);
        });
        Test("dispose unsubscribes and clears waiting action", () =>
        {
            var count = Plugin.Framework.Subscribers;
            using var run = new Harness(Leaf("/gs change 6\n/ac stale"));
            Check(Plugin.Framework.Subscribers == count + 1);
            run.Tick(0); run.Tick(0.1); run.Executor.Dispose();
            Check(Plugin.Framework.Subscribers == count && !run.Executor.IsWaitingForJobChange && !run.Executor.IsRunning);
            run.Host.Current = State(Astrologian, 5); run.Tick(0.2); Check(run.Host.Sent.Count == 1);
        });
        Test("gearset send callback stopping macro cannot rearm its guard", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac stale"));
            run.Host.OnSend = _ => run.Executor.Stop(false);
            run.Tick(0); Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange);
            run.Host.OnSend = null; Check(run.Executor.TryStart(Leaf("/ac fresh"), out _)); run.Tick(0.001);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/ac fresh"]));
        });
        Test("gearset send callback stop-restart preserves replacement first line", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac stale"));
            run.Host.OnSend = command =>
            {
                if (command != "/gs change 6") return;
                run.Executor.Stop(false); Check(run.Executor.TryStart(Leaf("/ac replacement\n/y next"), out _));
            };
            run.Tick(0); Check(run.Executor.ExecutedLines == 0 && run.Executor.TotalLines == 2);
            run.Tick(0.001); run.Tick(0.002);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/ac replacement", "/y next"]));
        });
        Test("action send callback stopping prevents later row and no action resend", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac once\n/y stale"));
            run.Tick(0); run.Tick(0.1); run.Host.Current = State(Astrologian, 5);
            run.Host.OnSend = command => { if (command == "/ac once") run.Executor.Stop(false); };
            run.Tick(0.2); run.Tick(0.3);
            Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/ac once"]));
        });
        Test("send callback stop-start-throw cannot cancel newly started macro", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac stale"));
            var errors = Plugin.ChatGui.Errors.Count;
            run.Host.OnSend = command =>
            {
                if (command != "/gs change 6") return;
                run.Executor.Stop(false); Check(run.Executor.TryStart(Leaf("/ac replacement\n/y next"), out _));
                throw new InvalidOperationException("previous command callback failed after replacement");
            };
            run.Tick(0);
            Check(run.Executor.IsRunning && run.Executor.ExecutedLines == 0 && run.Executor.TotalLines == 2);
            Check(!run.Executor.IsWaitingForJobChange && Plugin.ChatGui.Errors.Count == errors);
            run.Tick(0.001); run.Tick(0.002);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/ac replacement", "/y next"]));
        });
        Test("deferred callback stop-restart preserves replacement even when callback returns false", () =>
        {
            var sequence = new MacroSequence(); Check(sequence.TryStart(Leaf("/ac old"), 0, out _));
            sequence.TickDeferred(0, _ =>
            {
                sequence.Stop(); Check(sequence.TryStart(Leaf("/echo replacement"), 0, out _)); return false;
            });
            Check(sequence.IsRunning && sequence.ExecutedLines == 0 && sequence.TotalLines == 1);
            var sent = new List<string>(); sequence.TickDeferred(0.001, command => { sent.Add(command); return true; });
            Check(sent.SequenceEqual(["/echo replacement"]) && !sequence.IsRunning);
        });
        Test("pending guard survives group boundary and does not skip later children", () =>
        {
            using var run = new Harness(Group(Leaf("/gs change 6<wait.0.2>", "A"),
                Leaf("/y after-ready\n/ac 即刻咏唱<wait.1.5>", "B"), Leaf("/ac 阳星合相", "C")));
            run.Tick(0); run.Tick(0.2); run.Tick(0.201);
            Check(run.Executor.CurrentChildIndex == 2 && run.Executor.CurrentChildName == "B" && run.Host.Sent.Count == 1);
            run.Host.Current = State(Astrologian, 5); run.Tick(0.5); run.Tick(0.501); run.Tick(2.000); Check(run.Host.Sent.Count == 3);
            run.Tick(2.002); Check(run.Commands.SequenceEqual(["/gs change 6", "/y after-ready", "/ac 即刻咏唱", "/ac 阳星合相"]));
        });
        Test("second numeric change waits for the first target then arms its own barrier", () =>
        {
            var host = new Host(); host.Jobs[13] = 23;
            using var run = new Harness(Leaf("/gs change 6\n/gs change 14\n/ac latest"), host);
            run.Tick(0); run.Tick(0.001);
            Check(run.Host.Sent.Count == 1 && run.Host.Lookups.SequenceEqual([5]), "second gearset must not be resolved or dispatched early");
            host.Current = State(Astrologian, 5); run.Tick(0.002); run.Tick(0.003);
            Check(run.Executor.IsWaitingForJobChange && run.Host.Sent.Count == 2);
            host.Current = State(23, 13); run.Tick(0.004);
            Check(run.Host.Lookups.SequenceEqual([5, 13]) && run.Commands.Last() == "/ac latest" && !run.Executor.IsRunning);
        });
        Test("later invalid gearset waits for the earlier target then passes without guessing another target", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/gs change 7\n/ac passthrough"));
            run.Tick(0); run.Tick(0.001); Check(run.Host.Sent.Count == 1);
            run.Host.Current = State(Astrologian, 5); run.Tick(0.002); run.Tick(0.003);
            Check(run.Host.Lookups.SequenceEqual([5, 6]) && run.Host.Sent.Count == 3 && !run.Executor.IsRunning);
        });
        foreach (var (label, changed) in new (string, JobChangeSnapshot)[] {
            ("content id", State(Astrologian, 5) with { ContentId = 999 }),
            ("entity id", State(Astrologian, 5) with { EntityId = 0x10203041 }) })
            Test("changed " + label + " aborts without dispatching pending action", () =>
            {
                var errors = Plugin.ChatGui.Errors.Count;
                using var run = new Harness(Leaf("/gs change 6\n/ac stale\n/y stale"));
                run.Tick(0); run.Tick(0.1); run.Host.Current = changed; run.Tick(0.2);
                Check(!run.Executor.IsRunning && run.Host.Sent.Count == 1 && !run.Executor.IsWaitingForJobChange);
                Check(Plugin.ChatGui.Errors.Count == errors + 1 && Plugin.ChatGui.Errors.Last().Contains("角色已变化"));
            });
        foreach (var (label, unavailable) in new (string, JobChangeSnapshot)[] {
            ("all unavailable", default), ("content id zero", State() with { ContentId = 0 }),
            ("entity id zero", State() with { EntityId = 0 }),
            ("invalid entity sentinel", State() with { EntityId = 0xE0000000 }) })
            Test("unavailable initial " + label + " aborts the whole macro before any dispatch", () =>
            {
                var errors = Plugin.ChatGui.Errors.Count;
                var host = new Host { Current = unavailable };
                using var run = new Harness(Leaf("/gs change 6\n/ac passthrough"), host);
                run.Tick(0); run.Tick(0.001);
                Check(run.Host.Sent.Count == 0 && !run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange);
                Check(host.Calls.SequenceEqual(["lookup:5", "read"]));
                Check(Plugin.ChatGui.Errors.Count == errors + 1 && Plugin.ChatGui.Errors.Last().Contains("第 1 行") &&
                    Plugin.ChatGui.Errors.Last().Contains("未发送切职命令"));
            });
        Test("temporarily absent identity cannot release blocked action", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac once"));
            run.Tick(0); run.Host.Current = State(Astrologian, 5) with { Available = false, ContentId = 0, EntityId = 0 };
            run.Tick(0.1); Check(run.Executor.IsWaitingForJobChange && run.Host.Sent.Count == 1);
            run.Host.Current = State(Astrologian, 5); run.Tick(0.2);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/ac once"]));
        });
        Test("snapshot and target job are captured before send callback mutates host", () =>
        {
            var host = new Host(); host.OnSend = command =>
            {
                if (command != "/gs change 6") return;
                host.Jobs[5] = 23; host.Current = State(Astrologian, 5);
            };
            using var run = new Harness(Leaf("/gs change 6\n/ac captured-target"), host);
            run.Tick(0); run.Tick(0.001);
            Check(run.Host.Lookups.SequenceEqual([5]) && run.Host.Sent.Count == 2 && !run.Executor.IsRunning);
        });
        Test("trace logs state transitions once, not every blocked frame", () =>
        {
            var host = new Host(); var messages = new List<string>(); var guard = new JobChangeGuard(host, messages.Add);
            guard.TryDispatch("/gs change 6", 0);
            for (var i = 1; i <= 100; i++) Check(!guard.TryDispatch("/ac test", i * 0.01));
            Check(messages.Count == 2);
            host.Current = State() with { LocalJob = Astrologian };
            Check(!guard.TryDispatch("/ac test", 1.1) && messages.Count == 3);
            host.Current = State(Astrologian, 5); Check(guard.TryDispatch("/ac test", 1.2));
            Check(messages.Count == 4 && messages.Last().Contains("不重发动作"));
        });
        Test("nonfinite scheduler clock aborts waiting without dispatch", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/ac stale"));
            run.Tick(0); run.Tick(0.1); run.Tick(double.NaN);
            Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange && run.Host.Sent.Count == 1);
        });
        Test("guard rejects a clock earlier than gearset issue time", () =>
        {
            var host = new Host(); var guard = new JobChangeGuard(host); guard.TryDispatch("/gs change 6", 5);
            var threw = false;
            try { guard.TryDispatch("/ac test", 4); } catch (InvalidOperationException error) { threw = error.Message.Contains("倒退"); }
            Check(threw && host.Sent.Count == 1);
        });
        Test("final gearset-only macro completion cannot leak guard into next run", () =>
        {
            using var run = new Harness(Leaf("/gs change 6")); run.Tick(0);
            Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange);
            Check(run.Executor.TryStart(Leaf("/ac independent"), out _)); run.Tick(0.001);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/ac independent"]));
        });
        foreach (var command in new[] { "/divinearm", "/欢呼胜利", "/跳舞", "/ac 即刻咏唱", "/action 阳星合相", "/sh 不要提前发送", "/customplugin argument" })
            Test("universal pending barrier applies without a command whitelist: " + command, () =>
            {
                using var run = new Harness(Leaf("/gs change 6\n" + command + "\n/echo after"));
                run.Tick(0); run.Tick(0.016); run.Tick(0.032);
                Check(run.Host.Sent.Count == 1 && run.Executor.ExecutedLines == 1 && run.Executor.IsWaitingForJobChange);
                run.Host.Current = State(Astrologian, 5); run.Tick(0.1);
                Check(run.Commands.SequenceEqual(["/gs change 6", command]) && run.Executor.ExecutedLines == 2);
                run.Tick(0.101); run.Tick(0.2);
                Check(run.Commands.SequenceEqual(["/gs change 6", command, "/echo after"]) && !run.Executor.IsRunning);
            });
        Test("standalone wait is not consumed while a gearset transition is pending", () =>
        {
            using var run = new Harness(Leaf("/gs change 6\n/wait 2\n/divinearm"));
            run.Tick(0); run.Tick(0.016); run.Tick(0.2);
            Check(run.Executor.ExecutedLines == 1 && run.Executor.RemainingLines == 2 && run.Host.Sent.Count == 1);
            Check(run.Executor.IsWaitingForJobChange); Close(run.Executor.RemainingWait, 0);
            run.Host.Current = State(Astrologian, 5); run.Tick(0.5);
            Check(run.Executor.ExecutedLines == 2 && run.Host.Sent.Count == 1 && !run.Executor.IsWaitingForJobChange);
            Close(run.Executor.RemainingWait, 2);
            run.Tick(2.499); Check(run.Host.Sent.Count == 1);
            run.Tick(2.501); Check(run.Commands.SequenceEqual(["/gs change 6", "/divinearm"]) && !run.Executor.IsRunning);
        });
        Test("standalone wait at next child boundary remains behind the transition", () =>
        {
            using var run = new Harness(Group(Leaf("/gs change 6", "切职"), Leaf("/wait 0.5\n/欢呼胜利", "动作")));
            run.Tick(0); run.Tick(0.1);
            Check(run.Executor.ExecutedLines == 1 && run.Executor.CurrentChildIndex == 2 && run.Host.Sent.Count == 1);
            run.Host.Current = State(Astrologian, 5); run.Tick(0.2);
            Close(run.Executor.RemainingWait, 0.5);
            run.Tick(0.699); Check(run.Host.Sent.Count == 1);
            run.Tick(0.701); Check(run.Commands.SequenceEqual(["/gs change 6", "/欢呼胜利"]) && !run.Executor.IsRunning);
        });
        Test("gearset explicit wait starts at dispatch and does not poll the barrier before a row is due", () =>
        {
            using var run = new Harness(Leaf("/gs change 6<wait.0.2>\n/divinearm<wait.4>"));
            run.Tick(0); Close(run.Executor.RemainingWait, 0.2);
            run.Tick(0.1); run.Tick(0.199);
            Check(run.Host.Calls.Count(x => x == "read") == 1 && !run.Executor.IsWaitingForJobChange);
            run.Tick(0.2); Check(run.Host.Sent.Count == 1 && run.Executor.ExecutedLines == 1 && run.Executor.IsWaitingForJobChange);
            run.Host.Current = State(Astrologian, 5); run.Tick(0.6);
            Check(run.Commands.SequenceEqual(["/gs change 6", "/divinearm"])); Close(run.Executor.RemainingWait, 4);
            run.Tick(4.599); Check(run.Executor.IsRunning); run.Tick(4.601); Check(!run.Executor.IsRunning);
        });
        Test("direct TryDispatch also blocks a later gearset before resolving or sending it", () =>
        {
            var host = new Host(); host.Jobs[13] = 23;
            var guard = new JobChangeGuard(host);
            Check(guard.TryDispatch("/gs change 6", 0));
            Check(!guard.TryDispatch("/gs change 14", 0.1));
            Check(host.Lookups.SequenceEqual([5]) && host.Sent.Count == 1 && guard.IsWaiting);
            host.Current = State(Astrologian, 5);
            Check(guard.TryDispatch("/gs change 14", 0.2));
            Check(!guard.TryContinue(0.3) && host.Lookups.SequenceEqual([5, 13]) && host.Sent.Count == 2);
            host.Current = State(23, 13);
            Check(guard.TryContinue(0.4) && !guard.IsWaiting);
            Check(guard.TryDispatch("/divinearm", 0.401) && host.Sent.Select(x => x.Command).SequenceEqual(["/gs change 6", "/gs change 14", "/divinearm"]));
        });
        foreach (var logout in new[] { false, true })
            Test((logout ? "logout" : "stop") + " cancels pending chat emote and a second gearset together", () =>
            {
                using var run = new Harness(Leaf("/gs change 6\n/sh stale\n/divinearm\n/gs change 14"));
                run.Tick(0); run.Tick(0.1); Check(run.Executor.IsWaitingForJobChange);
                if (logout) { Plugin.ClientState.IsLoggedIn = false; run.Tick(0.2); }
                else run.Executor.Stop(false);
                Plugin.ClientState.IsLoggedIn = true; run.Host.Current = State(Astrologian, 5); run.Tick(0.3);
                Check(!run.Executor.IsRunning && !run.Executor.IsWaitingForJobChange && run.Host.Sent.Count == 1);
                Check(run.Host.Lookups.SequenceEqual([5]), "the unexecuted second gearset must not even be resolved");
            });
        Test("rejected gearset that leaves the old state hard-times out before chat or emote", () =>
        {
            var errors = Plugin.ChatGui.Errors.Count;
            using var run = new Harness(Leaf("/gs change 6\n/sh must-not-pass\n/divinearm"));
            run.Tick(0); run.Tick(0.25); run.Tick(10.249);
            Check(run.Executor.IsRunning && run.Host.Sent.Count == 1 && run.Executor.ExecutedLines == 1);
            run.Tick(10.25);
            Check(!run.Executor.IsRunning && run.Host.Sent.Count == 1 && Plugin.ChatGui.Errors.Count == errors + 1);
            Check(Plugin.ChatGui.Errors.Last().Contains("10 秒"));
            run.Host.Current = State(Astrologian, 5); run.Tick(11); Check(run.Host.Sent.Count == 1);
        });
        foreach (var returns in new[] { false, true })
            Test("canAdvance reentrant stop and restart cannot dispatch the obsolete row when returning " + returns, () =>
            {
                var sequence = new MacroSequence(); Check(sequence.TryStart(Leaf("/echo obsolete"), 0, out _));
                var sent = new List<string>();
                sequence.TickDeferred(0, command => { sent.Add(command); return true; }, () =>
                {
                    sequence.Stop(); Check(sequence.TryStart(Leaf("/echo replacement"), 0, out _)); return returns;
                });
                Check(sent.Count == 0 && sequence.IsRunning && sequence.ExecutedLines == 0);
                sequence.TickDeferred(0.01, command => { sent.Add(command); return true; }, () => true);
                Check(sent.SequenceEqual(["/echo replacement"]) && !sequence.IsRunning);
            });
        Test("canAdvance exception stops the pending row and preserves its source line", () =>
        {
            var sequence = new MacroSequence(); Check(sequence.TryStart(Leaf("/wait 0.5\n/divinearm", "等待行"), 0, out _));
            var sent = new List<string>();
            Exception? failure = null;
            try { sequence.TickDeferred(0, command => { sent.Add(command); return true; }, () => throw new InvalidOperationException("barrier failed")); }
            catch (Exception ex) { failure = ex; }
            Check(failure is InvalidOperationException && failure.Message.Contains("第 1 行") && failure.Message.Contains("barrier failed"));
            Check(!sequence.IsRunning && sent.Count == 0);
        });
        Test("canAdvance stop-restart-throw preserves replacement and does not consume its wait", () =>
        {
            var sequence = new MacroSequence(); Check(sequence.TryStart(Leaf("/echo obsolete"), 0, out _));
            var sent = new List<string>();
            sequence.TickDeferred(0, command => { sent.Add(command); return true; }, () =>
            {
                sequence.Stop(); Check(sequence.TryStart(Leaf("/wait 0.5\n/echo replacement"), 0, out _));
                throw new InvalidOperationException("obsolete barrier callback");
            });
            Check(sent.Count == 0 && sequence.IsRunning && sequence.ExecutedLines == 0 && sequence.TotalLines == 2);
            sequence.TickDeferred(0.01, command => { sent.Add(command); return true; }, () => true);
            Close(sequence.RemainingWait(0.01), 0.5);
            sequence.TickDeferred(0.509, command => { sent.Add(command); return true; }, () => true);
            Check(sent.Count == 0 && sequence.ExecutedLines == 1);
            sequence.TickDeferred(0.511, command => { sent.Add(command); return true; }, () => true);
            Check(sent.SequenceEqual(["/echo replacement"]) && !sequence.IsRunning);
        });
    }
}
