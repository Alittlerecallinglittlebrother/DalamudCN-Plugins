using MacroShelfA;
using System.Text.Json;

internal static class LibraryTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "library assertion failed") => check(value, message);
        Configuration Fixture() => new() { Macros = [
            new() { Name = "Z macro", Group = "演出", Pinned = true, IsGroup = true,
                Children = [new() { Name = "子宏甲", Commands = "/echo UNIQUE-CHILD" }, new() { Name = "子宏乙", Commands = "/echo second" }] },
            new() { Name = "A macro", Group = "制作", Commands = "/echo HELLO" },
            new() { Name = "B macro", Commands = "/echo world" }] };
        test("library name sort never changes root or child execution order", () =>
        {
            var c = Fixture(); var before = JsonSerializer.Serialize(c);
            var rows = MacroLibrary.Query(c.Macros, LibraryFilter.All, "", "", LibrarySort.Name);
            Check(rows.Select(m => m.Name).SequenceEqual(["A macro", "B macro", "Z macro"]));
            Check(JsonSerializer.Serialize(c) == before);
        });
        test("library stored-order view and category filter use root tags", () =>
        {
            var c = Fixture(); Check(MacroLibrary.Query(c.Macros, LibraryFilter.All, "", "", LibrarySort.SavedOrder).SequenceEqual(c.Macros));
            Check(MacroLibrary.Query(c.Macros, LibraryFilter.Category, "演出", "", LibrarySort.Name).Single() == c.Macros[0]);
        });
        test("favorites reuse persisted Pinned without adding duplicate entries", () =>
        {
            var c = Fixture(); var rows = MacroLibrary.Query(c.Macros, LibraryFilter.Favorites, "", "", LibrarySort.Name);
            Check(rows.Count == 1 && ReferenceEquals(rows[0], c.Macros[0]) && c.CountEntries() == 5);
        });
        test("search finds child commands and parent remains group result", () =>
        {
            var c = Fixture(); var rows = MacroLibrary.Query(c.Macros, LibraryFilter.All, "", " unique-child ", LibrarySort.Name);
            Check(rows.Single() == c.Macros[0]);
        });
        test("search finds child names case-insensitive root names and root commands", () =>
        {
            var c = Fixture(); Check(MacroLibrary.Matches(c.Macros[0], "子宏乙"));
            Check(MacroLibrary.Matches(c.Macros[1], "a MACRO") && MacroLibrary.Matches(c.Macros[1], "hello"));
        });
        test("unclassified tag and category search intersect correctly", () =>
        {
            var c = Fixture(); Check(MacroLibrary.Tag(c.Macros[2]) == "未分类");
            Check(MacroLibrary.Query(c.Macros, LibraryFilter.Category, "未分类", "world", LibrarySort.Name).Single() == c.Macros[2]);
            Check(MacroLibrary.Query(c.Macros, LibraryFilter.Favorites, "", "hello", LibrarySort.Name).Count == 0);
        });
        test("group-first view is separate from saved order", () =>
        {
            var c = Fixture(); c.Macros.Reverse(); var first = c.Macros[0];
            Check(MacroLibrary.Query(c.Macros, LibraryFilter.All, "", "", LibrarySort.Type)[0].IsGroup);
            Check(c.Macros[0] == first);
        });
        test("200-entry library remains complete and query is non-mutating", () =>
        {
            var c = new Configuration { Macros = Enumerable.Range(0, 200).Select(i => new MacroEntry { Name = $"宏{i:000}", Group = $"分类{i % 8}", Commands = $"/echo {i}" }).ToList() };
            var before = JsonSerializer.Serialize(c);
            Check(MacroLibrary.Query(c.Macros, LibraryFilter.All, "", "", LibrarySort.Name).Count == 200);
            Check(MacroLibrary.Query(c.Macros, LibraryFilter.Category, "分类3", "", LibrarySort.Name).Count == 25);
            Check(JsonSerializer.Serialize(c) == before);
        });
    }
}
