using System.Runtime.InteropServices;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI;
using MacroShelfA.Runtime;

// Link and exercise the actual production adapter. Only its generated binding is replaced.
// No game process, game allocator, UIModule.Instance, Utf8String.FromString or native handler runs.
internal static unsafe class NativeCommandDispatchTests
{
    private static int calls;
    private static nint observedModule;
    private static nint observedInput;
    private static nint observedUnused;
    private static byte observedHistory;

    // Native C++ bool occupies a byte. Use byte rather than a non-blittable managed bool
    // in this UnmanagedCallersOnly callback, while the production binding keeps its bool ABI.
    [UnmanagedCallersOnly]
    private static void Receive(UIModule* module, Utf8String* input, nint unused, byte history)
    {
        calls++;
        observedModule = (nint)module;
        observedInput = (nint)input;
        observedUnused = unused;
        observedHistory = history;
    }

    private static void ResetObservations()
    {
        calls = 0;
        observedModule = observedInput = observedUnused = -1;
        observedHistory = byte.MaxValue;
    }

    private static void WithBinding(Action<nint, nint> body, bool unresolved = false)
    {
        var original = UIModule.Addresses.ProcessChatBoxEntry.Value;
        var module = NativeMemory.AllocZeroed((nuint)sizeof(UIModule));
        var input = NativeMemory.AllocZeroed((nuint)sizeof(Utf8String));
        try
        {
            UIModule.Addresses.ProcessChatBoxEntry.Value = unresolved ? 0 :
                (nint)(delegate* unmanaged<UIModule*, Utf8String*, nint, byte, void>)&Receive;
            ResetObservations();
            body((nint)module, (nint)input);
        }
        finally
        {
            UIModule.Addresses.ProcessChatBoxEntry.Value = original;
            NativeMemory.Free(input);
            NativeMemory.Free(module);
        }
    }

    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "native-adapter assertion failed") => check(value, message);
        void Test(string name, Action body) => test("native-adapter: " + name, body);

        Test("full chat entry receives module then input exactly once", () => WithBinding((module, input) =>
        {
            NativeCommandSender.DispatchToGame((UIModule*)module, (Utf8String*)input);
            Check(calls == 1, "exactly one entry invocation is required");
            Check(observedModule == module && observedInput == input, "module/input parameter order must not be reversed");
        }));
        Test("unused argument is zero and chat history is disabled", () => WithBinding((module, input) =>
        {
            NativeCommandSender.DispatchToGame((UIModule*)module, (Utf8String*)input);
            Check(calls == 1 && observedUnused == 0 && observedHistory == 0, "must forward (input, 0, false)");
        }));
        Test("successive dispatches each use their supplied input without reuse", () => WithBinding((module, input) =>
        {
            var second = (Utf8String*)NativeMemory.AllocZeroed((nuint)sizeof(Utf8String));
            try
            {
                NativeCommandSender.DispatchToGame((UIModule*)module, (Utf8String*)input);
                Check(calls == 1 && observedInput == input);
                NativeCommandSender.DispatchToGame((UIModule*)module, second);
                Check(calls == 2 && observedInput == (nint)second && observedModule == module);
            }
            finally { NativeMemory.Free(second); }
        }));
        foreach (var missing in new[] { "module", "input", "both" })
            Test("null " + missing + " fails before entering handler", () => WithBinding((module, input) =>
            {
                Exception? failure = null;
                try
                {
                    NativeCommandSender.DispatchToGame(missing is "module" or "both" ? null : (UIModule*)module,
                        missing is "input" or "both" ? null : (Utf8String*)input);
                }
                catch (Exception ex) { failure = ex; }
                Check(failure is InvalidOperationException && calls == 0, "null input/module must fail without a native call");
            }));
        Test("unresolved binding throws instead of falling back to inner command", () => WithBinding((module, input) =>
        {
            Exception? failure = null;
            try { NativeCommandSender.DispatchToGame((UIModule*)module, (Utf8String*)input); }
            catch (Exception ex) { failure = ex; }
            Check(failure != null && calls == 0, "an unresolved generated binding must not silently succeed");
        }, unresolved: true));
        Test("temporary binding is restored even when test callback throws", () =>
        {
            var original = UIModule.Addresses.ProcessChatBoxEntry.Value;
            var marker = new InvalidOperationException("offline test marker");
            Exception? failure = null;
            try { WithBinding((_, _) => throw marker); }
            catch (Exception ex) { failure = ex; }
            Check(ReferenceEquals(failure, marker) && UIModule.Addresses.ProcessChatBoxEntry.Value == original);
        });
    }
}
