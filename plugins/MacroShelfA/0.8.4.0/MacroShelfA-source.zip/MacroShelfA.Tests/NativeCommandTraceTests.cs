using System.Runtime.InteropServices;
using FFXIVClientStructs.FFXIV.Client.UI.Shell;
using MacroShelfA;
using MacroShelfA.Runtime;

// All snapshots below read zeroed, privately allocated test memory. No live game
// objects, bindings, process-image verification, or native game functions are used.
internal static unsafe class NativeCommandTraceTests
{
    private static void WithShell(Action<nint> body)
    {
        var shell = NativeMemory.AllocZeroed((nuint)sizeof(RaptureShellModule));
        try { body((nint)shell); }
        finally { NativeMemory.Free(shell); }
    }

    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "native-trace assertion failed") => check(value, message);
        void Test(string name, Action body) => test("native-trace: " + name, () =>
        {
            NativeCommandTrace.End();
            Plugin.Log.Messages.Clear();
            try { body(); }
            finally { NativeCommandTrace.End(); Plugin.Log.Messages.Clear(); }
        });
        int Records() => Plugin.Log.Messages.Count(x => x.StartsWith('#'));

        Test("default disabled capture never enters the game instance accessor", () =>
        {
            Check(!NativeCommandTrace.Enabled && !NativeCommandTrace.RawLayoutVerified);
            Check(NativeCommandTrace.Capture() == null);
            Check(Plugin.Log.Messages.Count == 0);
        });
        Test("disabled dispatch scope does not mutate source, session or logs", () =>
        {
            var source = NativeCommandTrace.CurrentSource;
            var session = NativeCommandTrace.SessionGeneration;
            using (NativeCommandTrace.EnterDispatch("/sh PRIVATE_DISABLED_BODY"))
            {
                Check(NativeCommandTrace.CurrentSource == source && NativeCommandTrace.SessionGeneration == session);
                Check(!NativeCommandTrace.Enabled && Plugin.Log.Messages.Count == 0);
            }
            Check(NativeCommandTrace.CurrentSource == source && NativeCommandTrace.SessionGeneration == session);
            Check(source == "external(manual/native-macro/other-plugin)");
        });
        Test("enabled dispatch scope labels plugin route with sanitized verb only", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var external = NativeCommandTrace.CurrentSource;
            var session = NativeCommandTrace.SessionGeneration;
            var count = Plugin.Log.Messages.Count;
            foreach (var (input, verb) in new (string, string)[] {
                ("/sh\u00A0PRIVATE_LYRIC", "/sh"), ("/ac\tPRIVATE_TARGET", "/ac"),
                ("/gs change PRIVATE_GEARSET", "/gs"), ("/divinearm<wait.4>", "/divinearm"),
                ("/echo!PRIVATE_SUFFIX", "/echo"), ("PRIVATE_INVALID", "(invalid)") })
            {
                using (NativeCommandTrace.EnterDispatch(input))
                {
                    var source = NativeCommandTrace.CurrentSource;
                    Check(source.StartsWith("plugin#") && source.EndsWith(":" + verb), "unexpected dispatch source: " + source);
                    Check(!source.Contains("PRIVATE_") && !source.Contains("<wait") && !source.Contains("change"));
                    Check(NativeCommandTrace.SessionGeneration == session && Plugin.Log.Messages.Count == count,
                        "entering a correlation scope must not change sessions, log, or spend the record budget");
                }
                Check(NativeCommandTrace.CurrentSource == external);
            }
        });
        Test("nested dispatch scopes restore outer source after exceptions", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var external = NativeCommandTrace.CurrentSource;
            var marker = new InvalidOperationException("test marker");
            string outer;
            using (NativeCommandTrace.EnterDispatch("/gs change PRIVATE_SET"))
            {
                outer = NativeCommandTrace.CurrentSource;
                try
                {
                    using var inner = NativeCommandTrace.EnterDispatch("/divinearm PRIVATE_NESTED");
                    Check(NativeCommandTrace.CurrentSource != outer && NativeCommandTrace.CurrentSource.EndsWith(":/divinearm"));
                    throw marker;
                }
                catch (InvalidOperationException ex) { Check(ReferenceEquals(ex, marker)); }
                Check(NativeCommandTrace.CurrentSource == outer, "an inner failure must not erase the outer route");
                using (NativeCommandTrace.EnterDispatch("/sh PRIVATE_NEXT"))
                    Check(NativeCommandTrace.CurrentSource.EndsWith(":/sh"));
                Check(NativeCommandTrace.CurrentSource == outer);
            }
            Check(NativeCommandTrace.CurrentSource == external, "leaving the outer scope must restore external classification");
            Check(!Plugin.Log.Messages.Any(x => x.Contains("PRIVATE_")));
        });
        Test("default disabled scope cannot erase a later enabled scope", () =>
        {
            var disabledScope = NativeCommandTrace.EnterDispatch("/sh PRIVATE_BEFORE_BEGIN");
            NativeCommandTrace.Begin(validateRawLayout: false);
            using (NativeCommandTrace.EnterDispatch("/divinearm PRIVATE_ACTIVE"))
            {
                var active = NativeCommandTrace.CurrentSource;
                disabledScope.Dispose();
                Check(NativeCommandTrace.CurrentSource == active);
            }
            Check(NativeCommandTrace.CurrentSource == "external(manual/native-macro/other-plugin)");
        });
        Test("external record stays external and scoped record stays plugin without chat body", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var snapshot = NativeCommandTrace.CaptureShell(null, false);
            NativeCommandTrace.Record("/divinearm PRIVATE_EXTERNAL", snapshot, snapshot, true);
            Check(Plugin.Log.Messages.Last().Contains("source=external(manual/native-macro/other-plugin)"));
            using (NativeCommandTrace.EnterDispatch("/sh PRIVATE_SCOPE_BODY"))
            {
                var source = NativeCommandTrace.CurrentSource;
                NativeCommandTrace.Record("/sh PRIVATE_RECORD_BODY", snapshot, snapshot, true);
                Check(Plugin.Log.Messages.Last().Contains("source=" + source));
            }
            NativeCommandTrace.Record("/divinearm PRIVATE_AFTER_SCOPE", snapshot, snapshot, true);
            Check(Records() == 3 && Plugin.Log.Messages.Last().Contains("source=external(manual/native-macro/other-plugin)"));
            Check(!Plugin.Log.Messages.Any(x => x.Contains("PRIVATE_")));
        });
        Test("dispatch correlation is thread local rather than leaking to unrelated native activity", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            using (NativeCommandTrace.EnterDispatch("/divinearm PRIVATE_FRAMEWORK_THREAD"))
            {
                var current = NativeCommandTrace.CurrentSource;
                string? otherThread = null;
                Exception? failure = null;
                var worker = new System.Threading.Thread(() =>
                {
                    try { otherThread = NativeCommandTrace.CurrentSource; }
                    catch (Exception ex) { failure = ex; }
                });
                worker.Start();
                Check(worker.Join(TimeSpan.FromSeconds(5)), "correlation-only worker did not finish");
                Check(failure == null && otherThread == "external(manual/native-macro/other-plugin)");
                Check(NativeCommandTrace.CurrentSource == current);
            }
        });
        Test("session token changes only on Begin or End and fresh sessions reject old snapshots", () =>
        {
            var disabled = NativeCommandTrace.SessionGeneration;
            NativeCommandTrace.Begin(validateRawLayout: false);
            var first = NativeCommandTrace.SessionGeneration;
            Check(first != disabled);
            var stale = NativeCommandTrace.CaptureShell(null, false);
            Check(stale.Generation == first);
            using (NativeCommandTrace.EnterDispatch("/sh PRIVATE_FIRST_SESSION"))
                Check(NativeCommandTrace.SessionGeneration == first);
            Check(NativeCommandTrace.SessionGeneration == first);
            NativeCommandTrace.End();
            var ended = NativeCommandTrace.SessionGeneration;
            Check(ended != first && !NativeCommandTrace.Enabled);
            NativeCommandTrace.Begin(validateRawLayout: false);
            var second = NativeCommandTrace.SessionGeneration;
            Check(second != first && second != ended);
            var fresh = NativeCommandTrace.CaptureShell(null, false);
            Check(fresh.Generation == second);
            using (NativeCommandTrace.EnterDispatch("/divinearm PRIVATE_SECOND_SESSION"))
            {
                NativeCommandTrace.Record("/sh PRIVATE_STALE", stale, fresh, true);
                Check(Records() == 0);
                NativeCommandTrace.Record("/divinearm PRIVATE_FRESH", fresh, fresh, true);
                Check(Records() == 1 && NativeCommandTrace.SessionGeneration == second);
            }
            Check(NativeCommandTrace.CurrentSource == "external(manual/native-macro/other-plugin)");
            Check(!Plugin.Log.Messages.Any(x => x.Contains("PRIVATE_")));
        });
        Test("compiled installed bindings match the audited named layout", () =>
            Check(NativeCommandTrace.BindingLayoutMatches()));
        Test("named fields are copied by value from private shell memory", () => WithShell(address =>
        {
            var shell = (RaptureShellModule*)address;
            shell->ShowCommandErrors = true;
            shell->ErrorData = 0xA1B2C3D4;
            shell->Flags = 0x56789ABC;
            shell->MacroCurrentLine = 11;
            shell->MacroLocked = true;
            shell->WaitTimeMs = 12345;
            var snapshot = NativeCommandTrace.CaptureShell(shell, false);
            Check(snapshot.Available && snapshot.ShowErrors && snapshot.ErrorData == 0xA1B2C3D4 &&
                snapshot.Flags == 0x56789ABC && snapshot.MacroLine == 11 && snapshot.MacroLocked && snapshot.WaitMs == 12345);
            shell->ErrorData = 0; shell->MacroCurrentLine = -1;
            Check(snapshot.ErrorData == 0xA1B2C3D4 && snapshot.MacroLine == 11, "snapshot must not retain a pointer into mutable shell memory");
            Check(snapshot.Raw2AF == null && snapshot.Raw2B0 == null && snapshot.Raw2B8 == null);
        }));
        Test("unknown raw fields are absent unless the caller explicitly permits them", () => WithShell(address =>
        {
            var shell = (RaptureShellModule*)address;
            var raw = (byte*)shell;
            raw[0x2AF] = 0xA7;
            raw[0x2B0] = 0xC9;
            *(float*)(raw + 0x2B8) = 12.25f;
            var disabled = NativeCommandTrace.CaptureShell(shell, false);
            Check(disabled.Raw2AF == null && disabled.Raw2B0 == null && disabled.Raw2B8 == null);
            Check(disabled.ToString().Contains("rawUnknown=disabled"));
            var allowed = NativeCommandTrace.CaptureShell(shell, true);
            Check(allowed.Raw2AF == 0xA7 && allowed.Raw2B0 == 0xC9 && allowed.Raw2B8 == 12.25f);
            Check(allowed.ToString().Contains("rawUnknown[2AF=167,2B0=201,2B8=12.25]"));
            Check(!NativeCommandTrace.RawLayoutVerified, "private test allowance must not enable global raw reads");
        }));
        Test("null shell is unavailable with no named or raw observations", () =>
        {
            foreach (var allowRaw in new[] { false, true })
            {
                var snapshot = NativeCommandTrace.CaptureShell(null, allowRaw);
                Check(!snapshot.Available && !snapshot.ShowErrors && snapshot.ErrorData == 0 && snapshot.Flags == 0 &&
                    snapshot.MacroLine == -1 && !snapshot.MacroLocked && snapshot.WaitMs == 0);
                Check(snapshot.Raw2AF == null && snapshot.Raw2B0 == null && snapshot.Raw2B8 == null && snapshot.ToString() == "unavailable");
            }
        });
        Test("Begin false enables a fresh 64-line named-only session and End does not log", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            Check(NativeCommandTrace.Enabled && !NativeCommandTrace.RawLayoutVerified && NativeCommandTrace.LineLimit == 64);
            Check(Plugin.Log.Messages.Count == 1 && Plugin.Log.Messages[0].Contains("limit=64"));
            Check(!Plugin.Log.Messages.Any(x => x.Contains("raw-layout-exact-image-verified")));
            NativeCommandTrace.End();
            Check(!NativeCommandTrace.Enabled && !NativeCommandTrace.RawLayoutVerified && Plugin.Log.Messages.Count == 1);
            Check(NativeCommandTrace.Capture() == null);
        });
        Test("budget allows 64 records and suppresses the 65th without another footer", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var snapshot = NativeCommandTrace.CaptureShell(null, false);
            for (var i = 0; i < 64; i++) NativeCommandTrace.Record("/ac private argument", snapshot, snapshot, true);
            Check(Records() == 64 && !NativeCommandTrace.Enabled);
            Check(Plugin.Log.Messages.Count(x => x == "limit reached; disabled") == 1);
            Check(Plugin.Log.Messages.Any(x => x.StartsWith("#64 ")));
            var logCount = Plugin.Log.Messages.Count;
            NativeCommandTrace.Record("/ac hidden 65th", snapshot, snapshot, true);
            Check(Records() == 64 && Plugin.Log.Messages.Count == logCount && !Plugin.Log.Messages.Any(x => x.StartsWith("#65 ")));
            Check(!Plugin.Log.Messages.Any(x => x.Contains("private argument") || x.Contains("hidden 65th")));
        });
        Test("new Begin resets budget after exhaustion and starts numbering at one", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var first = NativeCommandTrace.CaptureShell(null, false);
            for (var i = 0; i < 64; i++) NativeCommandTrace.Record("/echo first", first, first, true);
            NativeCommandTrace.Begin(validateRawLayout: false);
            var second = NativeCommandTrace.CaptureShell(null, false);
            Check(first.Generation != second.Generation && NativeCommandTrace.Enabled);
            var offset = Plugin.Log.Messages.Count;
            for (var i = 0; i < 64; i++) NativeCommandTrace.Record("/echo second", second, second, true);
            var session = Plugin.Log.Messages.Skip(offset).ToArray();
            Check(session.Count(x => x.StartsWith('#')) == 64 && session[0].StartsWith("#1 ") &&
                session.Any(x => x.StartsWith("#64 ")) && !NativeCommandTrace.Enabled);
        });
        Test("stale generation and null before snapshot cannot consume a new session budget", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var stale = NativeCommandTrace.CaptureShell(null, false);
            NativeCommandTrace.Begin(validateRawLayout: false);
            var fresh = NativeCommandTrace.CaptureShell(null, false);
            for (var i = 0; i < 100; i++)
            {
                NativeCommandTrace.Record("/ac stale", stale, fresh, true);
                NativeCommandTrace.Record("/ac absent", null, fresh, true);
            }
            Check(Records() == 0 && NativeCommandTrace.Enabled);
            for (var i = 0; i < 64; i++) NativeCommandTrace.Record("/ac fresh", fresh, null, false);
            Check(Records() == 64 && !NativeCommandTrace.Enabled);
            Check(Plugin.Log.Messages.First(x => x.StartsWith('#')).Contains("returned=False") &&
                Plugin.Log.Messages.First(x => x.StartsWith('#')).Contains("after[unavailable]"));
        });
        Test("records after End are ignored", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var snapshot = NativeCommandTrace.CaptureShell(null, false);
            NativeCommandTrace.End();
            var count = Plugin.Log.Messages.Count;
            NativeCommandTrace.Record("/ac must not log", snapshot, snapshot, true);
            Check(Records() == 0 && Plugin.Log.Messages.Count == count);
        });
        Test("verb sanitizer excludes whitespace arguments, Unicode separators and symbols", () =>
        {
            foreach (var (input, expected) in new (string, string)[] {
                ("/ac secret target", "/ac"), ("/ac\tsecret", "/ac"), ("/ac\u00A0secret", "/ac"),
                ("/ac\r\nsecret", "/ac"), ("/欢呼胜利\tsecret", "/欢呼胜利"), ("/gs change 4", "/gs"),
                ("/a!secret", "/a"), ("/" + new string('!', 500) + "secret", "/?"), ("/😀secret", "/?"),
                ("", "(invalid)"), ("/", "(invalid)"), ("plain secret", "(invalid)"), (" /ac secret", "(invalid)"),
                ("/" + new string('x', 500) + " secret", "/" + new string('x', 32)) })
            {
                var result = NativeCommandTrace.CommandVerb(input);
                Check(result == expected && !result.Contains("secret") && result.Length <= 33, "unexpected sanitized verb: " + result);
            }
        });
        Test("formatted record includes only sanitized verb, not lyrics, target or escaped suffix", () => WithShell(address =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var snapshot = NativeCommandTrace.CaptureShell((RaptureShellModule*)address, false);
            foreach (var text in new[] { "/sh\u00A0PRIVATE_LYRIC", "/ac\tPRIVATE_TARGET", "/gs change PRIVATE_SET", "/echo!PRIVATE_SUFFIX" })
                NativeCommandTrace.Record(text, snapshot, snapshot, true);
            Check(Records() == 4 && !Plugin.Log.Messages.Any(x => x.Contains("PRIVATE_")));
            Check(Plugin.Log.Messages.Any(x => x.Contains("verb=/sh entry=ProcessChatBoxEntry")) &&
                Plugin.Log.Messages.Any(x => x.Contains("verb=/ac entry=ProcessChatBoxEntry")));
        }));
        Test("consumed plugin commands share the same 64-command budget as native records", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var snapshot = NativeCommandTrace.CaptureShell(null, false);
            for (var i = 0; i < 32; i++)
            {
                NativeCommandTrace.RecordConsumed("/custom\tPRIVATE_PLUGIN_ARGUMENT");
                NativeCommandTrace.Record("/ac PRIVATE_ACTION_TARGET", snapshot, snapshot, true);
            }
            Check(Records() == 64 && !NativeCommandTrace.Enabled);
            Check(Plugin.Log.Messages.Count(x => x.Contains("route=DalamudCommandManager consumed=true; nativeNotCalled")) == 32);
            Check(Plugin.Log.Messages.Count(x => x.Contains("entry=ProcessChatBoxEntry")) == 32);
            Check(!Plugin.Log.Messages.Any(x => x.Contains("PRIVATE_")));
            var count = Plugin.Log.Messages.Count;
            NativeCommandTrace.RecordConsumed("/custom PRIVATE_65");
            NativeCommandTrace.Record("/ac PRIVATE_66", snapshot, snapshot, true);
            Check(Plugin.Log.Messages.Count == count && Plugin.Log.Messages.Count(x => x == "limit reached; disabled") == 1);
        });
        Test("consumed records stay silent while disabled and redact NBSP-separated lyrics", () =>
        {
            NativeCommandTrace.RecordConsumed("/sh\u00A0PRIVATE_DISABLED");
            Check(Plugin.Log.Messages.Count == 0);
            NativeCommandTrace.Begin(validateRawLayout: false);
            NativeCommandTrace.RecordConsumed("/sh\u00A0PRIVATE_LYRIC");
            Check(Records() == 1 && Plugin.Log.Messages.Last().Contains("verb=/sh route=DalamudCommandManager"));
            Check(!Plugin.Log.Messages.Any(x => x.Contains("PRIVATE_")));
            NativeCommandTrace.End();
            var count = Plugin.Log.Messages.Count;
            NativeCommandTrace.RecordConsumed("/custom PRIVATE_ENDED");
            Check(Plugin.Log.Messages.Count == count);
        });
        Test("mismatched after-generation is recorded as unavailable instead of mixed-run state", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var oldAfter = NativeCommandTrace.CaptureShell(null, false) with { Available = true, ErrorData = 0x1234ABCD };
            NativeCommandTrace.Begin(validateRawLayout: false);
            var freshBefore = NativeCommandTrace.CaptureShell(null, false);
            NativeCommandTrace.Record("/ac PRIVATE_TARGET", freshBefore, oldAfter, true);
            Check(Records() == 1 && Plugin.Log.Messages.Last().Contains("after[unavailable]"));
            Check(!Plugin.Log.Messages.Last().Contains("1234ABCD"));
        });
        Test("malformed snapshot formatting cannot escape and abort macro execution", () =>
        {
            NativeCommandTrace.Begin(validateRawLayout: false);
            var snapshot = NativeCommandTrace.CaptureShell(null, false);
            // An impossible production snapshot intentionally exercises the diagnostic catch:
            // ToString reads Raw2B8.Value when Raw2AF is populated, so it must throw here.
            var malformed = snapshot with { Available = true, Raw2AF = 1, Raw2B0 = 2, Raw2B8 = null };
            Exception? directFailure = null;
            try { _ = malformed.ToString(); } catch (Exception ex) { directFailure = ex; }
            Check(directFailure is InvalidOperationException, "fixture must actually fail during formatting");
            NativeCommandTrace.Record("/ac PRIVATE_MALFORMED", malformed, snapshot, true);
            Check(Records() == 0 && NativeCommandTrace.Enabled);
            NativeCommandTrace.Record("/ac PRIVATE_VALID", snapshot, snapshot, true);
            Check(Records() == 1 && Plugin.Log.Messages.Last().StartsWith("#2 "), "failure may consume budget but must not stop subsequent dispatch diagnostics");
        });
    }
}
