global using Control = FFXIVClientStructs.FFXIV.Client.Game.Control.Control;
using System.Reflection;
using Dalamud.Plugin.Services;
using MacroShelfA.Runtime;

// Only the managed lifecycle and pure address predicate are exercised here.
// Interop, conditions and log services are null, and raw verification never passes:
// no hook installation, detour, native snapshot, game function or live process access.
internal static class NativeEmoteTraceTests
{
    private static FieldInfo Field(string name) => typeof(NativeEmoteTrace).GetField(name,
        BindingFlags.Instance | BindingFlags.NonPublic) ?? throw new InvalidOperationException("Missing diagnostic field: " + name);
    private static T Read<T>(NativeEmoteTrace trace, string name) => (T)Field(name).GetValue(trace)!;
    private static void Set<T>(NativeEmoteTrace trace, string name, T value) => Field(name).SetValue(trace, value);

    private sealed class Fixture : IDisposable
    {
        public bool Enabled;
        public int Generation = 1, EnabledReads, RawReads, ReadyNotifications;
        public bool ThrowEnabled, ThrowRaw;
        public readonly IFramework Framework;
        public readonly NativeEmoteFrameworkProxy Proxy;
        public readonly NativeEmoteTrace Trace;
        public Fixture()
        {
            Framework = DispatchProxy.Create<IFramework, NativeEmoteFrameworkProxy>();
            Proxy = (NativeEmoteFrameworkProxy)(object)Framework;
            Trace = new NativeEmoteTrace(null!, Framework, null!, null!,
                () => { EnabledReads++; return ThrowEnabled ? throw new InvalidOperationException("enabled fixture") : Enabled; },
                () => { RawReads++; return ThrowRaw ? throw new InvalidOperationException("raw fixture") : false; },
                () => throw new InvalidOperationException("Offline lifecycle must not capture source or native observations"),
                () => Generation, _ => ReadyNotifications++);
        }
        public void Tick() => Proxy.Tick(Framework);
        public void Dispose()
        {
            // Keep assertion failures in the deferred-dispose fixture from leaving a subscriber.
            Set(Trace, "activeCalls", 0);
            Trace.Dispose();
            Tick();
        }
    }

    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "native-emote lifecycle assertion failed") => check(value, message);
        void Test(string name, Action body) => test("native-emote: " + name, body);
        void NoHooks(Fixture f)
        {
            Check(Field("agentHook").GetValue(f.Trace) == null && Field("canHook").GetValue(f.Trace) == null &&
                Field("executeHook").GetValue(f.Trace) == null, "offline lifecycle must never install hooks");
            Check(f.ReadyNotifications == 0 && !f.Trace.IsReady);
        }

        Test("constructor is default off and only subscribes without reading gates or installing", () =>
        {
            using var f = new Fixture();
            Check(f.Proxy.Subscribers == 1 && f.Proxy.AddCalls == 1 && f.Proxy.RemoveCalls == 0);
            Check(f.EnabledReads == 0 && f.RawReads == 0 && f.Trace.StatusText == "已关闭");
            Check(!Read<bool>(f.Trace, "sessionActive"));
            NoHooks(f);
        });
        Test("disabled updates do not read raw verification or start a diagnostic session", () =>
        {
            using var f = new Fixture { ThrowRaw = true };
            f.Tick(); f.Tick();
            Check(f.EnabledReads == 2 && f.RawReads == 0 && f.Trace.StatusText == "已关闭");
            Check(!Read<bool>(f.Trace, "sessionActive") && f.Proxy.Subscribers == 1);
            NoHooks(f);
        });
        Test("enabled session waits for exact client verification and never installs when false", () =>
        {
            using var f = new Fixture { Enabled = true, Generation = 8 };
            f.Tick();
            Check(Read<bool>(f.Trace, "sessionActive") && Read<int>(f.Trace, "observedGeneration") == 8);
            Check(f.RawReads == 1 && f.Trace.StatusText == "等待客户端精确校验（未通过时不安装）");
            f.Tick();
            Check(f.RawReads == 2 && Read<int>(f.Trace, "events") == 0);
            NoHooks(f);
        });
        Test("turning off clears the active session and readiness without changing scheduling", () =>
        {
            using var f = new Fixture { Enabled = true };
            f.Tick();
            var rawReads = f.RawReads;
            f.Enabled = false;
            f.Tick();
            Check(!Read<bool>(f.Trace, "sessionActive") && f.Trace.StatusText == "已关闭");
            Check(f.RawReads == rawReads && f.Proxy.Subscribers == 1 && f.Proxy.RemoveCalls == 0);
            NoHooks(f);
        });
        Test("new generation resets exhausted budget even without an intervening off frame", () =>
        {
            using var f = new Fixture { Enabled = true, Generation = 13 };
            f.Tick();
            Set(f.Trace, "events", NativeEmoteTrace.EventLimit);
            Set(f.Trace, "exhausted", true);
            Set(f.Trace, "installFailed", true);
            f.Generation = 14; // Simulate trace off/on between two Framework updates.
            f.Tick();
            Check(Read<int>(f.Trace, "observedGeneration") == 14 && Read<int>(f.Trace, "events") == 0);
            Check(!Read<bool>(f.Trace, "exhausted") && !Read<bool>(f.Trace, "installFailed"));
            Check(Read<bool>(f.Trace, "sessionActive") && f.Trace.StatusText == "等待客户端精确校验（未通过时不安装）");
            NoHooks(f);
        });
        Test("event limit has a distinct status and does not query or install native hooks", () =>
        {
            using var f = new Fixture { Enabled = true };
            f.Tick();
            var rawReads = f.RawReads;
            Set(f.Trace, "events", NativeEmoteTrace.EventLimit);
            f.Tick();
            Check(Read<bool>(f.Trace, "exhausted") && f.Trace.StatusText == "已达到事件或时间上限");
            Check(f.RawReads == rawReads && f.Proxy.Subscribers == 1);
            NoHooks(f);
        });
        Test("throwing enabled or raw gate remains fail closed without native services", () =>
        {
            using var f = new Fixture { Enabled = true, ThrowEnabled = true };
            f.Tick();
            Check(f.Trace.StatusText == "已关闭" && f.RawReads == 0 && !Read<bool>(f.Trace, "sessionActive"));
            f.ThrowEnabled = false; f.ThrowRaw = true;
            f.Tick();
            Check(f.Trace.StatusText == "等待客户端精确校验（未通过时不安装）" && f.RawReads == 1);
            NoHooks(f);
        });
        Test("dispose without in flight callbacks unsubscribes once and is idempotent", () =>
        {
            using var f = new Fixture { Enabled = true };
            f.Tick();
            f.Trace.Dispose();
            Check(f.Proxy.Subscribers == 0 && f.Proxy.RemoveCalls == 1 && f.Trace.StatusText == "已卸载");
            var reads = f.EnabledReads;
            f.Trace.Dispose(); f.Tick();
            Check(f.Proxy.RemoveCalls == 1 && f.EnabledReads == reads);
            NoHooks(f);
        });
        Test("reentrant dispose retains subscription until the in flight native stack has returned", () =>
        {
            using var f = new Fixture { Enabled = true };
            f.Tick();
            Set(f.Trace, "activeCalls", 1); // Managed-only simulation; no hook or detour is invoked.
            f.Trace.Dispose();
            Check(f.Trace.StatusText == "已卸载" && f.Proxy.Subscribers == 1 && f.Proxy.RemoveCalls == 0);
            var reads = f.EnabledReads;
            f.Tick(); f.Trace.Dispose();
            Check(f.Proxy.Subscribers == 1 && f.Proxy.RemoveCalls == 0 && f.EnabledReads == reads);
            Set(f.Trace, "activeCalls", 0);
            f.Tick();
            Check(f.Proxy.Subscribers == 0 && f.Proxy.RemoveCalls == 1);
            f.Tick(); f.Trace.Dispose();
            Check(f.Proxy.RemoveCalls == 1 && f.EnabledReads == reads);
            NoHooks(f);
        });
        Test("audited address predicate accepts only the matching nonzero base and exact three RVAs", () =>
        {
            nint imageBase = unchecked((nint)0x140000000L);
            nint agent = imageBase + 0xF3AF20, can = imageBase + 0x1967670, execute = imageBase + 0x1966DB0;
            Check(NativeEmoteTrace.AuditedAddressesMatch(imageBase, agent, can, execute));
            Check(!NativeEmoteTrace.AuditedAddressesMatch(0, 0xF3AF20, 0x1967670, 0x1966DB0));
            Check(!NativeEmoteTrace.AuditedAddressesMatch(imageBase, agent + 1, can, execute));
            Check(!NativeEmoteTrace.AuditedAddressesMatch(imageBase, agent, can + 1, execute));
            Check(!NativeEmoteTrace.AuditedAddressesMatch(imageBase, agent, can, execute + 1));
            Check(!NativeEmoteTrace.AuditedAddressesMatch(imageBase, agent, execute, can));
            Check(!NativeEmoteTrace.AuditedAddressesMatch(imageBase + 0x10000, agent, can, execute));
            nint relocatedBase = imageBase + 0x200000;
            Check(NativeEmoteTrace.AuditedAddressesMatch(relocatedBase,
                relocatedBase + 0xF3AF20, relocatedBase + 0x1967670, relocatedBase + 0x1966DB0),
                "comparison is relocation-aware; it does not resolve or call native code");
        });
    }
}

public class NativeEmoteFrameworkProxy : DispatchProxy
{
    private IFramework.OnUpdateDelegate? updates;
    public int AddCalls { get; private set; }
    public int RemoveCalls { get; private set; }
    public int Subscribers => updates?.GetInvocationList().Length ?? 0;
    public void Tick(IFramework framework) => updates?.Invoke(framework);

    protected override object? Invoke(MethodInfo? method, object?[]? arguments)
    {
        switch (method?.Name)
        {
            case "add_Update":
                updates += (IFramework.OnUpdateDelegate)arguments![0]!;
                AddCalls++;
                return null;
            case "remove_Update":
                updates -= (IFramework.OnUpdateDelegate)arguments![0]!;
                RemoveCalls++;
                return null;
            default:
                throw new InvalidOperationException("Unexpected Framework access in offline lifecycle test: " + method?.Name);
        }
    }
}
