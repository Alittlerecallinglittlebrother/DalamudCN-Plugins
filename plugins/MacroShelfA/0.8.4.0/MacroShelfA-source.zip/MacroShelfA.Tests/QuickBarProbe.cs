using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

internal sealed partial class QuickBarWindow
{
    internal readonly Dictionary<string, (Vector2 Min, Vector2 Max)> UiItems = [];
    internal string TestLastError => lastError;
    internal Vector2? TestPickerSize;
    internal Vector2 TestPickerPosition;
    internal readonly Dictionary<string, (Vector2 Min, Vector2 Max)> Regions = [];
    partial void RecordRegion(string key, Vector2 minimum, Vector2 maximum) => Regions[key] = (minimum, maximum);
    partial void RecordItem(string key)
    {
        if (key == "picker-done") { TestPickerSize = ImGui.GetWindowSize(); TestPickerPosition = ImGui.GetWindowPos(); }
        if (ImGui.IsItemVisible()) UiItems[key] = (ImGui.GetItemRectMin(), ImGui.GetItemRectMax());
    }
}
