using MacroShelfA;
using System.Text.Json;

internal static class QuickBarTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "quick bar assertion failed") => check(value, message);
        Configuration Fixture() => new() { Macros = [new() { Name = "组", IsGroup = true, Pinned = true,
            Children = [new() { Name = "开场", Commands = "/echo A", Pinned = true }, new() { Name = "结尾", Commands = "/echo B" }] },
            new() { Name = "招呼", Group = "交互", Commands = "/echo HI", Pinned = true }] };
        test("quickbar old v8 config loads additive defaults without changing data", () =>
        {
            var c = JsonSerializer.Deserialize<Configuration>("{\"Version\":8,\"Macros\":[{\"Name\":\"old\",\"Commands\":\"/echo old\",\"Pinned\":true}]}")!;
            c.Normalize(); Check(c.Version == 8 && c.ShowQuickBar && c.QuickBarColumns == 4 && c.Macros[0].Commands == "/echo old");
        });
        test("quickbar exposes independent groups children and roots in saved order", () =>
        {
            var c = Fixture(); var list = QuickBarModel.Pinned(c);
            Check(list.Count == 3 && list[0].Macro == c.Macros[0] && list[1].Parent == c.Macros[0] && list[2].Macro == c.Macros[1]);
        });
        test("quickbar queries and layout never mutate macro data", () =>
        {
            var c = Fixture(); var before = JsonSerializer.Serialize(c); _ = QuickBarModel.Pinned(c); _ = QuickBarModel.All(c); _ = QuickBarModel.EffectiveColumns(8,320,112,6);
            Check(JsonSerializer.Serialize(c) == before);
        });
        test("quickbar removal only unpins not deletes or rewrites commands", () =>
        {
            var c = Fixture(); var child = c.Macros[0].Children[0]; Check(QuickBarModel.SetPinned(c,child,false));
            Check(c.CountEntries() == 4 && child.Commands == "/echo A" && !child.Pinned && c.Macros[0].Pinned);
        });
        test("quickbar deleted or replaced references cannot be repinned", () =>
        {
            var c = Fixture(); var old = c.Macros[0]; c.Macros.Clear(); Check(QuickBarModel.Pinned(c).Count == 0 && !QuickBarModel.SetPinned(c,old,true));
        });
        test("quickbar root deletion removes pinned child shortcuts", () =>
        {
            var c = Fixture(); c.Remove(c.Macros[0]); Check(QuickBarModel.Pinned(c).Count == 1);
        });
        test("quickbar updates names and labels from current objects", () =>
        {
            var c = Fixture(); c.Macros[0].Name = "改名"; Check(QuickBarModel.Pinned(c)[1].Label == "改名 / 开场");
        });
        test("quickbar child favorites roundtrip in unchanged export format4", () =>
        {
            var c = Fixture(); Check(ConfigurationExchange.TryImport(ConfigurationExchange.Export(c),out var imported,out _));
            var restored = new Configuration { Macros = imported.Macros }; Check(QuickBarModel.Pinned(restored).Count == 3);
        });
        test("quickbar view settings persist and clamp invalid numbers", () =>
        {
            var c = new Configuration { QuickBarColumns = 100, QuickBarButtonWidth = float.NaN, ShowQuickBar = false, LockQuickBar = true, QuickBarCollapsed = true };
            c.Normalize(); Check(c.QuickBarColumns == 8 && c.QuickBarButtonWidth == 112); c.Save();
            var restored = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
            Check(!restored.ShowQuickBar && restored.LockQuickBar && restored.QuickBarCollapsed);
        });
        test("quickbar columns fit narrow and scaled viewports", () =>
        {
            Check(QuickBarModel.EffectiveColumns(4,466,112,6) == 4);
            Check(QuickBarModel.EffectiveColumns(8,320,112,6) == 2);
            Check(QuickBarModel.EffectiveColumns(8,480,168,9) == 2);
            Check(QuickBarModel.EffectiveColumns(0,0,112,6) == 1);
        });
        test("quickbar picker searches parent labels and categories", () =>
        {
            var c = Fixture(); var all = QuickBarModel.All(c);
            Check(QuickBarModel.Matches(all[1],"组 / 开场") && QuickBarModel.Matches(all[^1],"交互") && !QuickBarModel.Matches(all[^1],"missing"));
        });
        test("quickbar 200 entries remain reachable without truncating favorites", () =>
        {
            var c = new Configuration { Macros = Enumerable.Range(0,200).Select(i=>new MacroEntry { Name = i.ToString(), Pinned=true }).ToList() };
            Check(QuickBarModel.Pinned(c).Count == 200);
        });
    }
}
