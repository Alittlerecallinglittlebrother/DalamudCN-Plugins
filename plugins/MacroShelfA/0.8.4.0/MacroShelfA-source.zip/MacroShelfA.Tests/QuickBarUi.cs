using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

internal static unsafe class QuickBarUi
{
    private static int width=720,height=500,checks;
    private static Vector2 position,size;
    private static readonly List<object> geometrySamples = [];
    private static void Check(bool b,string reason){if(!b)throw new Exception(reason); checks++;}
    public static void Run(string output)
    {
        using var native = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory,"cimgui.dll"));
        ImGui.InitApi(native); var context=ImGui.CreateContext();
        try
        {
            var io=ImGui.GetIO();io.IniFilename=null;io.DeltaTime=1f/60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc",17,default,io.Fonts.GetGlyphRangesChineseFull());io.Fonts.Build();ImGui.StyleColorsDark();
            var c=new Configuration();
            foreach(var name in new[]{"开场招呼","花间序曲","传送提醒","装备方案","合奏提示","谢幕致意"})
                c.Macros.Add(new MacroEntry{Name=name,Group="常用",Pinned=true,Commands="/echo "+name+" <wait.2>"});
            var group=c.Macros[1];group.IsGroup=true;group.Children=[new(){Name="开场",Commands="/echo childA <wait.2>"},new(){Name="谢幕",Commands="/echo childB <wait.2>"}];
            c.Normalize(); var time=0d;using var executor=new MacroExecutor(c,()=>time);using var main=new MainWindow(c,executor,new BetterWaitPatch());
            main.IsOpen=false;Plugin.ClientState.IsLoggedIn=true;var bar=new QuickBarWindow(c,executor,main);
            Frame(bar);Capture(bar,output,"quickbar-720.png",720,500);Check(bar.DrawConditions()&&!main.IsOpen,"bar depends on main being open");
            Click(bar,"run-"+c.Macros[0].Id); Check(executor.IsRunning&&!main.IsOpen,"quick run opened main or failed");
            Plugin.Framework.Tick();var sent=Plugin.CommandManager.Sent.Count;
            Click(bar,"run-"+group.Id);Check(executor.TotalChildren==1&&Plugin.CommandManager.Sent.Count==sent,"busy bar restarted group");
            Capture(bar,output,"quickbar-running.png",720,500);
            Click(bar,"collapse");Check(c.QuickBarCollapsed&&bar.UiItems.ContainsKey("stop"),"collapsed bar lost stop");
            Capture(bar,output,"quickbar-collapsed-running.png",720,500);Click(bar,"stop");Check(!executor.IsRunning,"stop failed");
            Click(bar,"collapse");Click(bar,"run-"+group.Id);Check(executor.TotalChildren==2,"group shortcut did not start complete group");Click(bar,"stop");
            Click(bar,"add");Capture(bar,output,"quickbar-picker.png",720,500);
            AssertStablePicker(bar,"normal-open");
            for(var cycle=0;cycle<10;cycle++) {Click(bar,"picker-done");Click(bar,"add");Frame(bar);Check(MathF.Abs(bar.TestPickerSize!.Value.Y-340)<1.1f,"picker drifts after reopen");}
            Type(bar,"picker-search","不存在的检索结果");AssertStablePicker(bar,"zero-search");
            Capture(bar,output,"quickbar-picker-no-results.png",720,500);Type(bar,"picker-search","");
            Click(bar,"pin-"+group.Children[0].Id);Click(bar,"picker-done");Check(group.Children[0].Pinned&&!main.IsOpen,"picker failed independent child");
            Click(bar,"run-"+group.Children[0].Id);Check(executor.TotalChildren==1&&executor.CurrentMacroName=="开场","child shortcut ran siblings");Click(bar,"stop");
            Click(bar,"run-"+group.Children[0].Id,1);Click(bar,"remove-"+group.Children[0].Id);Check(!group.Children[0].Pinned&&group.Children.Count==2,"remove deleted child");
            Click(bar,"run-"+c.Macros[0].Id,1);Click(bar,"edit-"+c.Macros[0].Id);Check(main.IsOpen&&main.TestSelected==c.Macros[0],"context edit selected wrong macro");main.IsOpen=false;
            var before=position;Drag(bar,"drag",new Vector2(55,35));Check(Vector2.Distance(before,position)>20,"header drag failed");
            Click(bar,"options");Click(bar,"lock");Dismiss(bar);before=position;Drag(bar,"drag",new Vector2(55,35));Check(Vector2.Distance(before,position)<1,"locked bar moved");
            c.QuickBarColumns=1;Capture(bar,output,"quickbar-one-column.png",720,500);Check(position.X+size.X<=720&&position.Y+size.Y<=500,"bar outside viewport");
            c.QuickBarColumns=8;ImGuiHelpers.GlobalScale=1.5f;io.FontGlobalScale=1.5f;Capture(bar,output,"quickbar-scale150.png",1080,750);Check(position.X+size.X<=1080&&position.Y+size.Y<=750,"scaled bar outside viewport");
            ImGuiHelpers.GlobalScale=1;io.FontGlobalScale=1;c.QuickBarColumns=4;
            Click(bar,"options");Click(bar,"hide");Check(!bar.DrawConditions()&&!main.IsOpen,"hide failed");c.ShowQuickBar=true;
            Plugin.ClientState.IsLoggedIn=false;Check(!bar.DrawConditions(),"logout bar visible");Plugin.ClientState.IsLoggedIn=true;
            c.Macros[0].Commands=string.Join('\n',Enumerable.Repeat("/echo long",16));Frame(bar);Click(bar,"run-"+c.Macros[0].Id);Check(!executor.IsRunning,"quickbar bypassed 15-line rule");Capture(bar,output,"quickbar-error.png",720,500);
            c.AllowLongMacros=true;Frame(bar);Check(bar.TestLastError.Length==0,"fixed settings retained old error");
            Click(bar,"run-"+c.Macros[0].Id);Check(executor.TotalLines==16&&executor.IsRunning,"long switch not shared by bar");Click(bar,"stop");
            c.AllowLongMacros=false;Click(bar,"run-"+c.Macros[0].Id);Check(bar.TestLastError.Length>0,"missing long-limit failure");
            c.Macros.Clear();Capture(bar,output,"quickbar-empty.png",720,500);Check(!bar.UiItems.Keys.Any(k=>k.StartsWith("run-")),"stale entries after replacement");
            Check(bar.TestLastError.Length==0,"removed macro retained stale error");
            Click(bar,"add");Capture(bar,output,"quickbar-empty-picker.png",720,500);Click(bar,"picker-done");
            for(var i=0;i<200;i++)c.Macros.Add(new MacroEntry{Name=$"{i:000} 很长的中文宏名称用于验证截断",Commands="/echo test",Pinned=true});
            c.Normalize();c.QuickBarColumns=8;Capture(bar,output,"quickbar-200.png",720,500);
            Check(size.X<=704&&size.Y<400,"200-entry bar grows beyond viewport");
            // Scrolling reaches the final pinned entry without growing the window.
            var point=bar.UiItems.First(k=>k.Key.StartsWith("run-")).Value;io.AddMousePosEvent(point.Min.X+15,point.Min.Y+15);Frame(bar);
            for(var i=0;i<30;i++){io.AddMouseWheelEvent(0,-20);Frame(bar);} Check(bar.UiItems.ContainsKey("run-"+c.Macros[^1].Id),"last pinned macro unreachable");
            Click(bar,"add");AssertStablePicker(bar,"200-entries");Capture(bar,output,"quickbar-picker-200.png",720,500);Click(bar,"picker-done");
            c.QuickBarColumns=4;foreach(var macro in c.Macros)macro.Pinned=false;c.Macros[0].Pinned=true;c.Save();
            Capture(bar,output,"quickbar-one-macro.png",720,500);AssertCompactIdle(bar);
            foreach(var macro in c.Macros.Take(7))macro.Pinned=true;c.Save();
            Capture(bar,output,"quickbar-seven-macros.png",720,500);AssertCompactIdle(bar);
            ImGuiHelpers.GlobalScale=1.5f;io.FontGlobalScale=1.5f;
            Capture(bar,output,"quickbar-seven-scale150-min.png",720,500);AssertCompactIdle(bar);
            Click(bar,"add");AssertStablePicker(bar,"scale150-min");Capture(bar,output,"quickbar-picker-scale150-min.png",720,500);
            foreach(var macro in c.Macros)macro.Pinned=false;c.Save();AssertStablePicker(bar,"clear-favorites-150");Click(bar,"picker-done");
            Capture(bar,output,"quickbar-empty-scale150.png",720,500);AssertCompactIdle(bar);
            c.Macros[0].Pinned=true;c.Save();c.QuickBarColumns=1;Capture(bar,output,"quickbar-one-column-scale150-min.png",720,500);AssertCompactIdle(bar);
            File.WriteAllText(Path.Combine(output,"picker-stability.json"),System.Text.Json.JsonSerializer.Serialize(geometrySamples,new System.Text.Json.JsonSerializerOptions{WriteIndented=true}));
            VerifyJobChangeBarrier(output);
            Console.WriteLine($"PASS native quickbar UI: {checks} assertions; closed-main execution, root/group/child, busy stop, collapse, picker, remove/edit, move/lock, visibility, limits, empty, 200 entries and job-change barrier stop");
        }
        catch{SoftwareRenderer.Save(Path.Combine(output,"quickbar-failure.png"));throw;}
        finally{ImGuiHelpers.GlobalScale=1;Plugin.ClientState.IsLoggedIn=true;ImGui.DestroyContext(context);}
    }
    private static void VerifyJobChangeBarrier(string output)
    {
        var io=ImGui.GetIO();ImGuiHelpers.GlobalScale=1;io.FontGlobalScale=1;
        using var scenario=new UiJobChangeScenario();
        using var main=new MainWindow(scenario.Configuration,scenario.Executor,new BetterWaitPatch());
        main.IsOpen=false;var bar=new QuickBarWindow(scenario.Configuration,scenario.Executor,main);
        width=720;height=500;Frame(bar);Click(bar,"run-"+scenario.Macro.Id);
        Check(scenario.Executor.IsRunning&&!main.IsOpen,"quickbar did not independently start the job-change fixture");
        scenario.Tick(0);scenario.Tick(0.2);
        Check(scenario.Executor.IsWaitingForJobChange&&scenario.Executor.ExecutedLines==1&&
            scenario.Commands.SequenceEqual(["/gs change 6"]),"quickbar fixture did not block the emote");
        Capture(bar,output,"quickbar-job-change-waiting-720.png",720,500);
        Capture(bar,output,"quickbar-job-change-waiting-420.png",420,360);
        Check(position.X>=0&&position.Y>=0&&position.X+size.X<=420&&position.Y+size.Y<=360,
            "blocked quickbar escaped the narrow viewport");
        ImGuiHelpers.GlobalScale=1.5f;io.FontGlobalScale=1.5f;
        try
        {
            Capture(bar,output,"quickbar-job-change-waiting-scale150.png",1080,750);
            Check(position.X+size.X<=1080&&position.Y+size.Y<=750,"scaled blocked quickbar escaped the viewport");
            Click(bar,"collapse");
            Capture(bar,output,"quickbar-job-change-waiting-collapsed-scale150.png",1080,750);
            Check(scenario.Executor.IsWaitingForJobChange&&bar.UiItems.ContainsKey("stop"),"collapsed quickbar lost the blocked stop control");
            Click(bar,"stop");
            Check(!scenario.Executor.IsRunning&&!scenario.Executor.IsWaitingForJobChange,
                "quickbar stop did not cancel the job-change barrier");
            scenario.MakeReady();scenario.Tick(0.5);scenario.Tick(1);
            Check(scenario.Commands.SequenceEqual(["/gs change 6"]),"quickbar stop let the deferred emote escape");
        }
        finally{ImGuiHelpers.GlobalScale=1;io.FontGlobalScale=1;}
    }
    private static void Frame(QuickBarWindow bar)
    {
        var io=ImGui.GetIO();io.DisplaySize=new Vector2(width,height);io.DeltaTime=1f/60;bar.UiItems.Clear();bar.Regions.Clear();bar.TestPickerSize=null;ImGui.NewFrame();
        ImGui.GetBackgroundDrawList().AddRectFilled(Vector2.Zero,io.DisplaySize,ImGui.GetColorU32(new Vector4(.035f,.05f,.075f,1)));
        if(bar.DrawConditions()){
            bar.PreDraw();
            // WindowHost.ApplyConditionals runs AFTER PreDraw and scales Window.Size once.
            if(bar.Size.HasValue)ImGui.SetNextWindowSize(bar.Size.Value*ImGuiHelpers.GlobalScale,bar.SizeCondition);
            ImGui.SetNextWindowPos(new Vector2(24,48),ImGuiCond.FirstUseEver);ImGui.Begin("Macro Shelf-A 常用宏###QuickBarTestHost",bar.Flags);
            bar.Draw();position=ImGui.GetWindowPos();size=ImGui.GetWindowSize();ImGui.End();bar.PostDraw();
        }
        ImGui.Render();
    }
    private static void Capture(QuickBarWindow bar,string output,string name,int w,int h)
    {width=w;height=h;ImGui.GetIO().AddMousePosEvent(-100,-100);Frame(bar);Frame(bar);SoftwareRenderer.Save(Path.Combine(output,name));}
    private static void Click(QuickBarWindow bar,string key,int button=0)
    {
        Frame(bar);if(!bar.UiItems.TryGetValue(key,out var r))throw new Exception("quickbar native control unavailable: "+key);
        var p=(r.Min+r.Max)/2;Check(p.X>=0&&p.X<width&&p.Y>=0&&p.Y<height,"quickbar control off screen: "+key);
        var io=ImGui.GetIO();io.AddMousePosEvent(p.X,p.Y);Frame(bar);io.AddMouseButtonEvent(button,true);Frame(bar);io.AddMouseButtonEvent(button,false);Frame(bar);Frame(bar);
    }
    private static void Drag(QuickBarWindow bar,string key,Vector2 delta)
    {
        Frame(bar);var r=bar.UiItems[key];var p=(r.Min+r.Max)/2;var io=ImGui.GetIO();io.AddMousePosEvent(p.X,p.Y);Frame(bar);io.AddMouseButtonEvent(0,true);Frame(bar);
        io.AddMousePosEvent(p.X+delta.X,p.Y+delta.Y);Frame(bar);io.AddMouseButtonEvent(0,false);Frame(bar);Frame(bar);
    }
    private static void Dismiss(QuickBarWindow bar){var io=ImGui.GetIO();io.AddKeyEvent(ImGuiKey.Escape,true);Frame(bar);io.AddKeyEvent(ImGuiKey.Escape,false);Frame(bar);}
    private static void Type(QuickBarWindow bar,string key,string value)
    {
        Click(bar,key);var io=ImGui.GetIO();io.AddKeyEvent(ImGuiKey.ModCtrl,true);io.AddKeyEvent(ImGuiKey.A,true);Frame(bar);
        io.AddKeyEvent(ImGuiKey.A,false);io.AddKeyEvent(ImGuiKey.ModCtrl,false);Frame(bar);
        if(value.Length==0){io.AddKeyEvent(ImGuiKey.Backspace,true);Frame(bar);io.AddKeyEvent(ImGuiKey.Backspace,false);}
        else foreach(var c in value)io.AddInputCharacter(c);
        Frame(bar);Frame(bar);
    }
    private static void AssertStablePicker(QuickBarWindow bar,string scenario)
    {
        var scale=ImGuiHelpers.GlobalScale;
        var expected=new Vector2(MathF.Min(430*scale,width-24*scale),MathF.Min(340*scale,height-24*scale));
        Vector2? firstList=null;
        for(var f=1;f<=600;f++)
        {
            Frame(bar);if(f!=1&&f!=30&&f!=120&&f!=600)continue;
            var actual=bar.TestPickerSize??throw new Exception("picker closed unexpectedly");
            var list=bar.Regions["picker-list"];var listSize=list.Max-list.Min;
            firstList??=listSize;
            Check(Vector2.Distance(actual,expected)<1.5f,"picker grows: "+scenario);
            Check(Vector2.Distance(listSize,firstList.Value)<1.5f,"list grows: "+scenario);
            var done=bar.UiItems["picker-done"];var manage=bar.UiItems["picker-manage"];
            Check(done.Min.Y>=list.Max.Y&&manage.Max.Y<=bar.TestPickerPosition.Y+actual.Y,"picker footer overlaps or escapes");
            Check(bar.TestPickerPosition.X>=0&&bar.TestPickerPosition.Y>=0&&bar.TestPickerPosition.X+actual.X<=width&&bar.TestPickerPosition.Y+actual.Y<=height,"picker outside viewport");
            geometrySamples.Add(new{scenario,frame=f,scale,popup=new{width=actual.X,height=actual.Y},list=new{width=listSize.X,height=listSize.Y},footerBottom=manage.Max.Y,screenWidth=width,screenHeight=height});
        }
    }
    private static void AssertCompactIdle(QuickBarWindow bar)
    {
        var scale=ImGuiHelpers.GlobalScale;var hint=bar.Regions["header-hint"];var grid=bar.Regions["grid"];var add=bar.UiItems["add"];
        Check(hint.Max.X<=position.X+size.X-9*scale&&hint.Min.X>=position.X,"hint clipped");
        Check(hint.Max.Y<=add.Min.Y||hint.Max.X<add.Min.X,"hint overlaps action buttons");
        Check(MathF.Abs(position.Y+size.Y-grid.Max.Y-10*scale)<=1.5f,"idle footer blank space remains");
        Check(position.X+size.X<=width&&position.Y+size.Y<=height,"bar applies scale twice");
    }
}

