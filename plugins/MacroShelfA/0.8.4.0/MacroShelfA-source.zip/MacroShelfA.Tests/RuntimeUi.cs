using System.Numerics;
using System.Text.Json;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;

internal static unsafe class RuntimeUi
{
    private static int width = 940, height = 760;
    private static int checks;
    private static void Check(bool value, string message) { if (!value) throw new Exception(message); checks++; }
    private static Configuration Fixture()
    {
        var config = new Configuration { AllowLongMacros = true };
        var titles = new[] { "花间序曲", "舞台开场", "落幕谢礼", "月下独舞", "花雨谢幕", "夜色圆舞", "暖场问候", "双人谢礼", "彩灯开场", "晨光舞步" };
        foreach (var (tag, count) in new[] { ("演出舞蹈", 18), ("生产制作", 32), ("战斗辅助", 14), ("日常便利", 12), ("表情互动", 8) })
        for (var i = 0; i < count; i++)
        {
            var root = new MacroEntry { Name = tag == "演出舞蹈" && i < titles.Length ? titles[i] : $"{tag} · {i + 1:00}", Group = tag,
                Commands = $"/echo {tag} 第 {i + 1} 项 <wait.2>", Pinned = i < 2 };
            if (tag == "演出舞蹈" && new[] { 0, 1, 2, 5, 8 }.Contains(i))
            {
                root.IsGroup = true;
                var names = new[] { "宏 A · 开场", "宏 B · 主段", "宏 C · 间奏", "宏 D · 谢幕" };
                var counts = new[] { 30, 24, 48, 15 };
                for (var j = 0; j < 4; j++) root.Children.Add(new MacroEntry { Name = names[j], Commands = string.Join('\n', Enumerable.Range(1, counts[j]).Select(n => $"/echo {names[j]} 第 {n} 行 <wait.1>")) });
            }
            config.Macros.Add(root);
        }
        config.Normalize(); return config;
    }
    public static void Run(string output)
    {
        Directory.CreateDirectory(output);
        using var native = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory, "cimgui.dll"));
        ImGui.InitApi(native); var context = ImGui.CreateContext();
        try
        {
            var io = ImGui.GetIO(); io.IniFilename = null; io.DeltaTime = 1f / 60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 17, default, io.Fonts.GetGlyphRangesChineseFull());
            Check(io.Fonts.Build(), "font atlas failed"); ImGui.StyleColorsDark();
            var config = Fixture(); var original = JsonSerializer.Serialize(config); var group = config.Macros[0];
            var time = 0.0; using var executor = new MacroExecutor(config, () => time);
            var sample = new CountdownSample(true, 100, false, 0); var countdownTime = 0.0;
            using var countdown = new CountdownTrigger(config, executor, () => sample, () => countdownTime);
            using var window = new MainWindow(config, executor, new BetterWaitPatch(), countdown);
            Frame(window); Frame(window);
            Check(!window.UiItems.ContainsKey("setting-long"), "global settings still clutter main page");
            Click(window, "category-演出舞蹈");
            Check(window.TestVisibleCount == 18, "category does not filter roots");
            Click(window, "root-" + group.Id); Check(window.TestSelected == group && !executor.IsRunning, "selection should not execute");
            foreach (var size in new[] { (940,760), (720,500), (1200,900), (1536,1024) })
                Capture(window, output, $"library-{size.Item1}.png", size.Item1, size.Item2);
            Capture(window, Path.Combine(output, "..", ".impeccable", "review"), "hero-repro.png", 1536, 1024);
            ImGuiHelpers.GlobalScale = 1.5f; io.FontGlobalScale = 1.5f;
            Capture(window, output, "library-scale150.png", 1080, 750);
            ImGuiHelpers.GlobalScale = 1; io.FontGlobalScale = 1; Resize(window, 940, 760);
            Check(JsonSerializer.Serialize(config) == original, "view navigation changed config");
            Click(window, "favorite-" + group.Id); Check(!group.Pinned, "favorite did not toggle");
            Click(window, "favorite-" + group.Id); Check(group.Pinned, "favorite did not restore");
            Click(window, "filter-favorites"); Check(window.TestVisibleCount == 10, "favorite filter count wrong");
            var restored = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
            Check(restored.Macros[0].Pinned, "favorite did not persist");
            Click(window, "filter-all");
            Type(window, "search", "完全不存在的检索内容"); Check(window.TestVisibleCount == 0 && window.TestSelected == null, "empty search leaves stale runnable selection");
            Capture(window, output, "library-no-results.png", 940, 760);
            Type(window, "search", "宏 C · 间奏"); Check(window.TestVisibleCount == 5, "child command/name search failed");
            Type(window, "search", ""); Click(window, "category-演出舞蹈"); Click(window, "root-" + group.Id);
            Click(window, "inspect-child-" + group.Children[1].Id);
            var child = group.Children[1]; Check(window.TestSelected == child, "inspector did not open child editor");
            foreach (var size in new[] { (940,760), (720,500), (1200,900), (1536,1024) })
                Capture(window, output, $"editor-{size.Item1}.png", size.Item1, size.Item2);
            ImGuiHelpers.GlobalScale = 1.5f; io.FontGlobalScale = 1.5f;
            Capture(window, output, "editor-scale150.png", 1080, 750);
            ImGuiHelpers.GlobalScale = 1; io.FontGlobalScale = 1; Resize(window, 940, 760);
            Click(window, "move-down"); Check(group.Children[2] == child, "reorder down lost identity");
            Click(window, "move-up"); Check(group.Children[1] == child, "reorder up lost identity");
            Click(window, "tree-" + group.Id); Check(window.TestSelected == group, "tree group not selectable");
            Click(window, "tree-expand-" + group.Id); Check(!window.UiItems.ContainsKey("tree-" + child.Id), "group did not collapse");
            Click(window, "tree-expand-" + group.Id); Click(window, "tree-" + child.Id); Check(window.TestSelected == child, "tree child selection failed");
            Click(window, "edit-properties"); Type(window, "edit-name", "中文子宏重命名"); Click(window, "edit-properties");
            Check(child.Name == "中文子宏重命名" && Plugin.PluginInterface.Json.Contains("中文子宏重命名"), "rename not persisted on panel close");
            Click(window, "edit-run"); Check(executor.IsRunning && executor.TotalLines == 24 && executor.TotalChildren == 1, "child run started siblings");
            Plugin.Framework.Tick();
            Click(window, "nav-library"); Capture(window, output, "library-running-940.png", 940, 760);
            Click(window, "stop"); Check(!executor.IsRunning, "persistent stop control failed");
            Click(window, "nav-settings"); Check(window.UiItems.ContainsKey("setting-long"), "long macro option missing from settings");
            Click(window, "setting-quickbar"); Check(!config.ShowQuickBar, "quickbar visibility setting did not disable");
            Click(window, "setting-quickbar"); Check(config.ShowQuickBar, "quickbar visibility setting did not enable");
            Click(window, "setting-long"); Check(!config.AllowLongMacros, "long setting did not disable");
            executor.Start(child); Check(!executor.IsRunning && Plugin.ChatGui.Errors.Last().Contains("15"), "long setting not enforced");
            Click(window, "setting-long"); Check(config.AllowLongMacros, "long setting did not re-enable");
            Capture(window, output, "settings-940.png", 940, 760); Capture(window, output, "settings-720.png", 720, 500); Resize(window, 940, 760);
            Click(window, "new-menu"); Click(window, "new-macro"); var created = window.TestSelected!;
            Check(config.Macros.Contains(created) && !created.IsGroup, "new standalone creation failed");
            Type(window, "edit-name", "长宏测试 · 400 行"); Type(window, "edit-category", "压力测试"); Click(window, "edit-properties");
            var longText = string.Join('\n', Enumerable.Range(1,400).Select(i => $"/echo 第{i:000}行 中文长宏编辑器测试 <wait.0.1>"));
            Type(window, "edit-commands", longText);
            Check(created.Commands == longText && created.Commands.Length > 8000, "CJK multiline input was truncated");
            Capture(window, output, "editor-long-940.png", 940, 760);
            Click(window, "edit-run"); Check(executor.IsRunning && executor.TotalLines == 400, "400-line run did not start");
            Click(window, "nav-settings"); Click(window, "setting-long"); Check(executor.IsRunning && executor.TotalLines == 400, "setting changed active snapshot");
            Click(window, "stop"); Click(window, "setting-long");
            Click(window, "new-menu"); Click(window, "new-group"); var addedGroup = window.TestSelected!;
            Check(addedGroup.IsGroup && addedGroup.Children.Count == 1, "new group failed");
            Click(window, "edit-properties"); Click(window, "add-child"); Check(addedGroup.Children.Count == 2 && window.TestSelected == addedGroup.Children[1], "add child failed");
            Click(window, "nav-countdown"); Capture(window, output, "countdown-940.png", 940, 760);
            Click(window, "countdown-target"); Click(window, "countdown-option-" + group.Id); Click(window, "countdown-enabled");
            Check(config.CountdownTriggerEnabled && config.CountdownMacroId == group.Id, "countdown binding did not persist");
            Plugin.Framework.Tick(); sample = sample with { Active = true, Remaining = 5 }; countdownTime += .1; Plugin.Framework.Tick();
            sample = sample with { Active = false, Remaining = 0 }; Plugin.ChatGui.Emit(CountdownObserver.Completed); countdownTime += .1; Plugin.Framework.Tick();
            Check(executor.IsRunning && executor.TotalChildren == 4, "countdown did not start selected group"); Click(window, "stop");
            var json = ConfigurationExchange.Export(new Configuration { Macros = [new() { Name = "导入示例", Commands = "/echo imported" }] });
            window.TestImport(json, false); Frame(window); Check(config.CountdownTriggerEnabled && config.CountdownMacroId == group.Id, "append changed countdown binding");
            window.TestImport(json, true); Frame(window); Check(!config.CountdownTriggerEnabled && config.Macros.Count == 1 && window.TestSelected == config.Macros[0], "replacement left stale selection or binding");
            config.Macros.Clear(); config.Save(); window.TestRefresh(); Capture(window, output, "library-empty-720.png", 720, 500);
            Check(window.TestSelected == null, "empty library retains stale selection");
            Click(window, "nav-countdown"); Capture(window, output, "countdown-empty-720.png", 720, 500);
            Click(window, "nav-library");
            for (var i=0;i<200;i++) config.Macros.Add(new MacroEntry { Name = $"{i:000} 很长的中文宏名称用于验证截断与提示显示", Group = "超长分类标签用于验证窄窗口显示", Commands = "/echo test" });
            config.Normalize(); window.TestRefresh(); Capture(window, output, "library-200-long-names-720.png", 720, 500); Resize(window, 940, 760);
            Click(window, "new-menu"); Click(window, "new-macro"); Check(config.Macros.Count == 200, "entry limit not enforced by menu");
            VerifyJobChangeBarrier(output);
            Console.WriteLine($"PASS native A+B UI: {checks} assertions; category/favorite/search, tree, rename, order, child execution, 400-line CJK editing, settings, creation, countdown, import, 200 entries, empty states and job-change barrier stop");
        }
        catch { SoftwareRenderer.Save(Path.Combine(output, "ui-failure.png")); throw; }
        finally { ImGui.DestroyContext(context); }
    }
    private static void VerifyJobChangeBarrier(string output)
    {
        using var scenario = new UiJobChangeScenario();
        using var window = new MainWindow(scenario.Configuration, scenario.Executor, new BetterWaitPatch());
        Resize(window, 940, 760);
        var io = ImGui.GetIO(); io.AddKeyEvent(ImGuiKey.Escape, true); Frame(window);
        io.AddKeyEvent(ImGuiKey.Escape, false); Frame(window);
        Click(window, "root-" + scenario.Macro.Id); Click(window, "inspect-run");
        Check(scenario.Executor.IsRunning, "main window did not start the job-change fixture");
        scenario.Tick(0); scenario.Tick(0.2);
        Check(scenario.Executor.IsWaitingForJobChange && scenario.Executor.ExecutedLines == 1 &&
            scenario.Commands.SequenceEqual(["/gs change 6"]), "main window fixture did not block the emote");
        Capture(window, output, "library-job-change-waiting-940.png", 940, 760);
        Capture(window, output, "library-job-change-waiting-720.png", 720, 500);
        ImGuiHelpers.GlobalScale = 1.5f; io.FontGlobalScale = 1.5f;
        try
        {
            Capture(window, output, "library-job-change-waiting-scale150.png", 1080, 750);
            Click(window, "stop");
            Check(!scenario.Executor.IsRunning && !scenario.Executor.IsWaitingForJobChange,
                "main window stop did not cancel the job-change barrier");
            scenario.MakeReady(); scenario.Tick(0.5); scenario.Tick(1);
            Check(scenario.Commands.SequenceEqual(["/gs change 6"]), "main window stop let the deferred emote escape");
        }
        finally { ImGuiHelpers.GlobalScale = 1; io.FontGlobalScale = 1; }
    }
    private static void Capture(MainWindow window, string output, string name, int w, int h)
    {
        Directory.CreateDirectory(output); Resize(window,w,h); ImGui.GetIO().AddMousePosEvent(-100,-100); Frame(window); Frame(window);
        SoftwareRenderer.Save(Path.Combine(output,name));
    }
    private static void Resize(MainWindow window,int w,int h) { width=w;height=h;Frame(window);Frame(window); }
    internal static void Frame(MainWindow window)
    {
        var io=ImGui.GetIO();io.DisplaySize=new Vector2(width,height);io.DeltaTime=1f/60;
        window.UiItems.Clear(); ImGui.NewFrame(); ImGui.SetNextWindowPos(Vector2.Zero,ImGuiCond.Always); ImGui.SetNextWindowSize(new Vector2(width,height),ImGuiCond.Always);
        ImGui.Begin("Macro Shelf-A###TestHost",ImGuiWindowFlags.NoResize|ImGuiWindowFlags.NoMove|ImGuiWindowFlags.NoCollapse|ImGuiWindowFlags.NoScrollbar|ImGuiWindowFlags.NoScrollWithMouse);
        window.Draw();ImGui.End();ImGui.Render();
        if(ImGui.GetDrawData().TotalVtxCount<100)throw new Exception("empty native render");
    }
    private static void Click(MainWindow window,string key)
    {
        Frame(window);
        if(!window.UiItems.TryGetValue(key,out var rect))throw new Exception("native control unavailable: "+key);
        var point=(rect.Min+rect.Max)/2;Check(point.X>=0&&point.X<width&&point.Y>=0&&point.Y<height,"control outside viewport: "+key);
        var io=ImGui.GetIO();io.AddMousePosEvent(point.X,point.Y);Frame(window);
        io.AddMouseButtonEvent(0,true);Frame(window);io.AddMouseButtonEvent(0,false);Frame(window);Frame(window);
    }
    private static void Type(MainWindow window,string key,string value)
    {
        Click(window,key);var io=ImGui.GetIO();io.AddKeyEvent(ImGuiKey.ModCtrl,true);io.AddKeyEvent(ImGuiKey.A,true);Frame(window);
        io.AddKeyEvent(ImGuiKey.A,false);io.AddKeyEvent(ImGuiKey.ModCtrl,false);Frame(window);
        if(value.Length==0) { io.AddKeyEvent(ImGuiKey.Backspace,true);Frame(window);io.AddKeyEvent(ImGuiKey.Backspace,false); }
        else foreach(var c in value)io.AddInputCharacter(c);
        Frame(window);Frame(window);
    }
}
