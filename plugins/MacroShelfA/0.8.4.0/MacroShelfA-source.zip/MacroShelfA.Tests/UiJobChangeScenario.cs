using MacroShelfA;
using MacroShelfA.Runtime;

// Render the real executor's blocked state without calling the game command handler.
internal sealed class UiJobChangeScenario : IDisposable
{
    private sealed class Host : IJobChangeHost
    {
        internal JobChangeSnapshot Current = new(true, 123456789, 0x10203040, 24, 24, 24, 0);
        internal readonly List<string> Commands = [];
        public JobChangeSnapshot ReadState() => Current;
        public byte? GetGearsetJob(int zeroBasedIndex) => zeroBasedIndex == 5 ? (byte)33 : null;
        public bool SendCommand(string command) { Commands.Add(command); return true; }
    }

    private readonly Host host = new();
    private double time;
    internal Configuration Configuration { get; } = new()
    {
        Macros = [new() { Name = "切职", Group = "演出", Pinned = true, Commands = "/gs change 6\n/divinearm" }]
    };
    internal MacroEntry Macro => Configuration.Macros[0];
    internal MacroExecutor Executor { get; }
    internal IReadOnlyList<string> Commands => host.Commands;

    internal UiJobChangeScenario()
    {
        Configuration.Normalize();
        Plugin.ClientState.IsLoggedIn = true;
        Executor = new MacroExecutor(Configuration, () => time, host);
    }

    internal void Tick(double now) { time = now; Plugin.Framework.Tick(); }
    internal void MakeReady() => host.Current = host.Current with
    {
        LocalJob = 33, PlayerJob = 33, HotbarJob = 33, GearsetIndex = 5
    };
    public void Dispose() => Executor.Dispose();
}
