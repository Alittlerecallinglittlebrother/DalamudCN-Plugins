using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

// Compiled only by the test host, never shipped in MacroShelfA.dll.
internal sealed partial class MainWindow
{
    internal readonly Dictionary<string, (Vector2 Min, Vector2 Max)> UiItems = [];
    partial void RecordItem(string key)
    {
        if (ImGui.IsItemVisible()) UiItems[key] = (ImGui.GetItemRectMin(), ImGui.GetItemRectMax());
    }
    internal MacroEntry? TestSelected => selectedMacro;
    internal int TestVisibleCount => VisibleRoots().Count;
    internal void TestRefresh() => InvalidateLibrary();
    internal void TestOpen(MacroEntry entry) => OpenEditor(entry);
    internal void TestImport(string json, bool replace) { importText = json; ImportConfiguration(replace); }
}
