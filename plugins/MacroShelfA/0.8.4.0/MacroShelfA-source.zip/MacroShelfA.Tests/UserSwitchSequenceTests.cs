using MacroShelfA;
using MacroShelfA.Runtime;

// These tests prove ordered scheduling into a mocked host, NOT that the game executed an action.
internal static class UserSwitchSequenceTests
{
    private sealed class Host : IJobChangeHost
    {
        public readonly List<(double At, string Text)> Sent = [];
        public double Now;
        public int StateReads;
        public JobChangeSnapshot State = new(true, 123, 0x12345, 24, 24, 24, 0);
        public JobChangeSnapshot ReadState() { StateReads++; return State; }
        public byte? GetGearsetJob(int index) => index is 3 or 5 or 31 ? (byte)33 : null;
        public bool SendCommand(string command) { Sent.Add((Now, command)); return true; }
    }

    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "user-switch assertion failed") => check(value, message);
        void Test(string name, Action body) => test("user-switch: " + name, body);
        Test("minimal gs32 shout divinearm example blocks lyrics and emote until all state matches", () =>
        {
            string[] expected = ["/gs change 32", "/sh 虽然上了岁数 但还是会真心相待", "/divinearm"];
            var macro = new MacroEntry { Name = "用户三行最小复现", Commands = string.Join('\n', [
                expected[0], expected[1], expected[2] + "<wait.4>"]) };
            var host = new Host();
            var sequence = new MacroSequence();
            var guard = new JobChangeGuard(host);
            Check(JobChangeGuard.TryParseGearsetChange(expected[0], out var index) && index == 31 && host.GetGearsetJob(index) == 33);
            Check(!host.State.JobsMatch(33), "fixture must start on a different job so the pending guard is armed");
            Check(sequence.TryStart(macro, 0, out var error), error);
            void Tick(double at) { host.Now = at; sequence.TickDeferred(at, line => guard.TryDispatch(line, at), () => guard.TryContinue(at)); }
            Tick(0);
            Check(host.Sent.Count == 1 && host.StateReads == 1 && sequence.ExecutedLines == 1);
            Tick(0.016);
            Check(host.Sent.Count == 1 && sequence.ExecutedLines == 1 && guard.IsWaiting);
            host.State = host.State with { LocalJob = 33 };
            Tick(0.032);
            Check(host.Sent.Count == 1 && sequence.ExecutedLines == 1);
            host.State = host.State with { PlayerJob = 33 };
            Tick(0.048);
            Check(host.Sent.Count == 1 && sequence.ExecutedLines == 1);
            host.State = host.State with { HotbarJob = 33 };
            Tick(0.064);
            Check(host.Sent.Count == 1 && sequence.ExecutedLines == 1,
                "matching job observations must not release a different gearset");
            host.State = host.State with { GearsetIndex = 31 };
            Tick(0.2);
            Check(host.Sent.Count == 2 && sequence.ExecutedLines == 2 && !guard.IsWaiting);
            var readsAtRelease = host.StateReads;
            Tick(0.216);
            Check(host.Sent.Count == 3 && sequence.ExecutedLines == 3 && sequence.IsRunning);
            Check(host.Sent.Select(x => x.Text).SequenceEqual(expected));
            Check(Math.Abs(host.Sent[1].At - 0.2) < 0.000001,
                "the first matching observation releases the next row without a fixed extra delay");
            Check(Math.Abs(sequence.RemainingWait(0.216) - 4) < 0.000001,
                "the full suffix wait starts after the actual emote dispatch");
            Tick(4.215);
            Check(sequence.IsRunning && host.Sent.Count == 3);
            Tick(4.217);
            Check(!sequence.IsRunning && host.Sent.Count == 3 && host.StateReads == readsAtRelease,
                "released commands must not be retried or poll for an action acknowledgement");
            // Sender invocation is the tested outcome, not successful in-game animation.
        });
        Test("nine-line emote example retains every command and full explicit waits", () =>
        {
            string[] expected = [
                "/sh Ah～有时候也会心灰意冷", "/popotostep", "/y Ah～就算这样也没关系吗？",
                "/gs change 4", "/sh 虽然上了岁数 但还是会真心相待", "/divinearm",
                "/y 即使狂.风.暴.雨袭来", "/easternstretch", "/sh 【咱一起...挺过去呗？】"];
            var macro = new MacroEntry { Name = "用户九行", Commands = string.Join('\n', [
                expected[0], expected[1] + "<wait.3>", expected[2] + "<wait.2>", expected[3],
                expected[4], expected[5] + "<wait.4>", expected[6], expected[7] + "<wait.2>", expected[8] + "<wait.1>"]) };
            var host = new Host();
            var sequence = new MacroSequence();
            var guard = new JobChangeGuard(host);
            Check(sequence.TryStart(macro, 0, out var error), error);
            void Tick(double at) { host.Now = at; sequence.TickDeferred(at, line => guard.TryDispatch(line, at), () => guard.TryContinue(at)); }
            Tick(0); Tick(0.01); Tick(3.009); Check(host.Sent.Count == 2);
            Tick(3.011); Tick(5.010); Check(host.Sent.Count == 3);
            Tick(5.012); Tick(5.013); Tick(5.014);
            Check(host.Sent.Count == 4 && sequence.ExecutedLines == 4 && guard.IsWaiting);
            host.State = new(true, 123, 0x12345, 33, 33, 33, 3);
            Tick(5.25); Tick(5.26); Check(host.Sent.Count == 6 && !guard.IsWaiting);
            var readsAtRelease = host.StateReads;
            Tick(9.259); Check(host.Sent.Count == 6);
            Tick(9.261); Tick(9.262); Check(host.Sent.Count == 8);
            Tick(11.261); Check(host.Sent.Count == 8);
            Tick(11.263); Check(sequence.IsRunning && host.Sent.Count == 9);
            Tick(12.262); Check(sequence.IsRunning); Tick(12.264); Check(!sequence.IsRunning);
            Check(host.Sent.Select(x => x.Text).SequenceEqual(expected));
            Check(host.Sent[6].At - host.Sent[5].At >= 4 && host.Sent[7].At - host.Sent[5].At >= 4,
                "second post-switch emote must not overtake the first emote's four-second wait");
            Check(host.StateReads == readsAtRelease && !guard.IsWaiting,
                "finished transition must not keep polling during explicit emote waits");
        });
        Test("four-line skill example preserves 0.2, 1.5 and final 1.8 second waits", () =>
        {
            string[] expected = ["/gs change 6", "/y ♡ 独一无二，信号满格~ ♡", "/ac 即刻咏唱", "/ac 阳星合相"];
            var macro = new MacroEntry { Name = "用户四行", Commands = string.Join('\n', [
                expected[0] + "<wait.0.2>", expected[1], expected[2] + "<wait.1.5>", expected[3] + "<wait.1.8>"]) };
            var host = new Host();
            var sequence = new MacroSequence();
            var guard = new JobChangeGuard(host);
            Check(sequence.TryStart(macro, 0, out var error), error);
            void Tick(double at) { host.Now = at; sequence.TickDeferred(at, line => guard.TryDispatch(line, at), () => guard.TryContinue(at)); }
            Tick(0); Tick(0.199); Check(host.Sent.Count == 1);
            Tick(0.2); Check(host.Sent.Count == 1 && sequence.ExecutedLines == 1 && guard.IsWaiting);
            host.State = new(true, 123, 0x12345, 33, 33, 33, 5);
            Tick(0.21); Check(host.Sent.Count == 2 && !guard.IsWaiting);
            Tick(0.22); Check(host.Sent.Count == 3);
            Tick(1.719); Check(host.Sent.Count == 3);
            Tick(1.721); Check(host.Sent.Count == 4 && sequence.IsRunning);
            Tick(3.520); Check(sequence.IsRunning); Tick(3.522); Check(!sequence.IsRunning);
            Check(host.Sent.Select(x => x.Text).SequenceEqual(expected));
            Check(host.Sent[1].At - host.Sent[0].At >= 0.2 && host.Sent[3].At - host.Sent[2].At >= 1.5);
        });
    }
}
