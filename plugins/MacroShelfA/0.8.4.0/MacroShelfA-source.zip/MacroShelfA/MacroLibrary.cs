using System;
using System.Collections.Generic;
using System.Linq;

namespace MacroShelfA;

internal enum LibraryFilter { All, Favorites, Category }
internal enum LibrarySort { SavedOrder, Name, Type }

// View-only operations: never reorder saved roots/children or rewrite macro text.
internal static class MacroLibrary
{
    public static string Tag(MacroEntry entry) => string.IsNullOrWhiteSpace(entry.Group) ? "未分类" : entry.Group.Trim();
    public static bool MatchesSelf(MacroEntry entry, string query) => string.IsNullOrWhiteSpace(query) ||
        entry.Name.Contains(query.Trim(), StringComparison.OrdinalIgnoreCase) ||
        entry.Group.Contains(query.Trim(), StringComparison.OrdinalIgnoreCase) ||
        entry.Commands.Contains(query.Trim(), StringComparison.OrdinalIgnoreCase);
    public static bool Matches(MacroEntry entry, string query) => MatchesSelf(entry, query) ||
        (entry.IsGroup && entry.Children.Any(child => MatchesSelf(child, query)));

    public static List<MacroEntry> Query(IEnumerable<MacroEntry> roots, LibraryFilter filter,
        string category, string query, LibrarySort sort)
    {
        var selected = roots.Where(m => filter != LibraryFilter.Favorites || m.Pinned)
            .Where(m => filter != LibraryFilter.Category || Tag(m) == category)
            .Where(m => Matches(m, query));
        return (sort switch
        {
            LibrarySort.Name => selected.OrderBy(m => m.Name, StringComparer.OrdinalIgnoreCase),
            LibrarySort.Type => selected.OrderByDescending(m => m.IsGroup).ThenBy(m => m.Name, StringComparer.OrdinalIgnoreCase),
            _ => selected,
        }).ToList();
    }
}
