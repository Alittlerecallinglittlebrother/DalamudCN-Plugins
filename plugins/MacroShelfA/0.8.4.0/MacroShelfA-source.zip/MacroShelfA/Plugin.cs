using System;
using Dalamud.Game.Command;
using Dalamud.Interface.Textures;
using Dalamud.Interface.Windowing;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

namespace MacroShelfA;

public sealed class Plugin : IDalamudPlugin
{
    private const string CommandName = "/aklmacro";

    [PluginService]
    internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;

    [PluginService]
    internal static ICommandManager CommandManager { get; private set; } = null!;

    [PluginService]
    internal static IFramework Framework { get; private set; } = null!;

    [PluginService]
    internal static IClientState ClientState { get; private set; } = null!;

    [PluginService]
    internal static ICondition Condition { get; private set; } = null!;

    [PluginService]
    internal static ISigScanner SigScanner { get; private set; } = null!;

    [PluginService]
    internal static IGameInteropProvider GameInteropProvider { get; private set; } = null!;

    [PluginService]
    internal static IChatGui ChatGui { get; private set; } = null!;

    [PluginService]
    internal static IPluginLog Log { get; private set; } = null!;

    [PluginService]
    internal static ITextureProvider TextureProvider { get; private set; } = null!;

    private readonly WindowSystem windowSystem = new("MacroShelfA");
    private readonly MacroExecutor macroExecutor;
    private readonly CountdownTrigger countdownTrigger;
    private readonly BetterWaitPatch betterWaitPatch;
    private readonly MainWindow mainWindow;
    private readonly FloatingLauncherWindow floatingLauncherWindow;
    private readonly QuickBarWindow quickBarWindow;
    private readonly NativeEmoteTrace nativeEmoteTrace;

    internal Configuration Configuration { get; }

    public Plugin()
    {
        Configuration = PluginInterface.GetPluginConfig() as Configuration ?? Configuration.CreateDefault();
        try
        {
            ConfigurationBackup.BeforeGroupMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
            ConfigurationBackup.BeforeLongMacroMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
            ConfigurationBackup.BeforeCountdownMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
            ConfigurationBackup.BeforeZeroIntervalMigration(Configuration, PluginInterface.GetPluginConfigDirectory());
        }
        catch (Exception exception)
        {
            Log.Error(exception, "无法备份升级前配置；请通过导出配置保留副本。");
            ChatGui.PrintError("[Macro Shelf-A] 升级前配置备份失败，请先导出配置保留副本。");
        }
        Configuration.Normalize();

        nativeEmoteTrace = new NativeEmoteTrace(GameInteropProvider, Framework, Condition, Log,
            () => NativeCommandTrace.Enabled, () => NativeCommandTrace.RawLayoutVerified,
            () => NativeCommandTrace.CurrentSource, () => NativeCommandTrace.SessionGeneration,
            message => ChatGui.Print($"[Macro Shelf-A] {message}"));
        macroExecutor = new MacroExecutor(Configuration);
        countdownTrigger = new CountdownTrigger(Configuration, macroExecutor);
        betterWaitPatch = new BetterWaitPatch(SigScanner, Log);
        betterWaitPatch.SetEnabled(Configuration.BetterWaitEnabled);
        mainWindow = new MainWindow(Configuration, macroExecutor, betterWaitPatch, countdownTrigger);
        floatingLauncherWindow = new FloatingLauncherWindow(Configuration, mainWindow);
        quickBarWindow = new QuickBarWindow(Configuration, macroExecutor, mainWindow);
        windowSystem.AddWindow(mainWindow);
        windowSystem.AddWindow(floatingLauncherWindow);
        windowSystem.AddWindow(quickBarWindow);

        CommandManager.AddHandler(CommandName, new CommandInfo(OnCommand)
        {
            HelpMessage = "打开或关闭 Macro Shelf-A。/aklmacro bar 切换常用宏栏；/aklmacro stop 中止运行；/aklmacro version 查看当前实际加载版本。",
        });

        PluginInterface.UiBuilder.Draw += windowSystem.Draw;
        PluginInterface.UiBuilder.OpenMainUi += OpenMainUi;
        PluginInterface.UiBuilder.OpenConfigUi += OpenMainUi;
        Log.Information("Macro Shelf-A {Version} 已加载。原生命令入口：ProcessChatBoxEntry。使用 {Command} 打开窗口。",
            typeof(Plugin).Assembly.GetName().Version?.ToString() ?? "未知", CommandName);
    }

    public void Dispose()
    {
        NativeCommandTrace.End();
        nativeEmoteTrace.Dispose();
        PluginInterface.UiBuilder.Draw -= windowSystem.Draw;
        PluginInterface.UiBuilder.OpenMainUi -= OpenMainUi;
        PluginInterface.UiBuilder.OpenConfigUi -= OpenMainUi;
        CommandManager.RemoveHandler(CommandName);

        Configuration.Save();
        windowSystem.RemoveAllWindows();
        mainWindow.Dispose();
        countdownTrigger.Dispose();
        macroExecutor.Dispose();
        betterWaitPatch.Dispose();
    }

    private void OnCommand(string command, string arguments)
    {
        if (string.Equals(arguments.Trim(), "trace on", StringComparison.OrdinalIgnoreCase))
        {
            NativeCommandTrace.Begin();
            ChatGui.Print("[Macro Shelf-A] 本地动作诊断已开启；请等到“动作诊断已就绪”再运行三行复现宏。只记录命令名、动作编号、实际调用结果与状态，不记录聊天正文；/aklmacro trace status 查看状态，trace off 关闭。");
            return;
        }
        if (string.Equals(arguments.Trim(), "trace status", StringComparison.OrdinalIgnoreCase))
        {
            ChatGui.Print($"[Macro Shelf-A] 诊断开启={NativeCommandTrace.Enabled}，客户端校验={NativeCommandTrace.RawLayoutVerified}；{nativeEmoteTrace.StatusText}。");
            return;
        }
        if (string.Equals(arguments.Trim(), "trace off", StringComparison.OrdinalIgnoreCase))
        {
            NativeCommandTrace.End();
            ChatGui.Print("[Macro Shelf-A] 命令链路诊断已关闭。");
            return;
        }
        if (string.Equals(arguments.Trim(), "version", StringComparison.OrdinalIgnoreCase))
        {
            ChatGui.Print($"[Macro Shelf-A] 当前加载版本：{typeof(Plugin).Assembly.GetName().Version}（切职顺序修正候选版，待游戏内验证）；原生命令入口：ProcessChatBoxEntry。");
            return;
        }
        if (string.Equals(arguments.Trim(), "bar", StringComparison.OrdinalIgnoreCase))
        {
            Configuration.ShowQuickBar = !Configuration.ShowQuickBar;
            Configuration.Save();
            return;
        }
        if (string.Equals(arguments.Trim(), "stop", StringComparison.OrdinalIgnoreCase))
        {
            macroExecutor.Stop();
            return;
        }
        mainWindow.Toggle();
    }

    private void OpenMainUi()
    {
        mainWindow.IsOpen = true;
    }
}
