using System;
using System.Collections.Generic;
using System.Linq;

namespace MacroShelfA;

internal readonly record struct QuickBarEntry(MacroEntry Macro, MacroEntry? Parent)
{
    public string Label => Parent == null ? Macro.Name : $"{Parent.Name} / {Macro.Name}";
    public string Kind => Parent != null ? "子宏" : Macro.IsGroup ? "宏组" : "独立宏";
}

internal static class QuickBarModel
{
    // Live references only: renames, deletes and replacement imports cannot leave saved shortcuts stale.
    internal static List<QuickBarEntry> All(Configuration configuration)
    {
        var result = new List<QuickBarEntry>();
        foreach (var root in configuration.Macros)
        {
            result.Add(new QuickBarEntry(root, null));
            if (root.IsGroup) result.AddRange(root.Children.Select(child => new QuickBarEntry(child, root)));
        }
        return result;
    }
    internal static List<QuickBarEntry> Pinned(Configuration configuration) => All(configuration).Where(e => e.Macro.Pinned).ToList();
    internal static bool Matches(QuickBarEntry entry, string search) => string.IsNullOrWhiteSpace(search) ||
        entry.Label.Contains(search.Trim(), StringComparison.OrdinalIgnoreCase) ||
        MacroLibrary.Tag(entry.Parent ?? entry.Macro).Contains(search.Trim(), StringComparison.OrdinalIgnoreCase);
    internal static bool SetPinned(Configuration configuration, MacroEntry entry, bool pinned)
    {
        if (!All(configuration).Any(e => ReferenceEquals(e.Macro, entry))) return false;
        entry.Pinned = pinned;
        configuration.Save();
        return true;
    }
    internal static int EffectiveColumns(int requested, float contentWidth, float buttonWidth, float gap) =>
        Math.Clamp((int)MathF.Floor((MathF.Max(1, contentWidth) + gap) / MathF.Max(1, buttonWidth + gap)), 1, Math.Clamp(requested, 1, 8));
}
