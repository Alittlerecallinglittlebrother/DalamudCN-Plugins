using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MacroShelfA.Runtime;

// Observation only: these fields cannot prove that an action or animation is ready.
// No cooldown polling, ActionManager calls, delayed-error correlation or action retries.
internal readonly record struct JobChangeSnapshot(
    bool Available, ulong ContentId, uint EntityId, byte LocalJob, byte PlayerJob,
    byte HotbarJob, int GearsetIndex)
{
    public bool JobsMatch(byte job) => Available && job != 0 &&
        LocalJob == job && PlayerJob == job && HotbarJob == job;

    public override string ToString() =>
        $"available={Available}, local={LocalJob}, player={PlayerJob}, hotbar={HotbarJob}, gearset={GearsetIndex + 1}";
}

internal interface IJobChangeHost
{
    JobChangeSnapshot ReadState();
    byte? GetGearsetJob(int zeroBasedIndex);
    // true: dispatched to the game's text-command handler; false: consumed by another plugin.
    bool SendCommand(string command);
}

internal sealed class JobChangeGuard
{
    public const double MaximumWaitSeconds = 10;
    private static readonly Regex GearsetChange = new(
        @"^/(?:gs|gearset)[ \t]+change[ \t]+(?<set>[0-9]{1,3})(?:[ \t]+[0-9]{1,3})?[ \t]*$",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    private static readonly Regex AnyGearsetChange = new(
        @"^/(?:gs|gearset)[ \t]+change(?:[ \t]|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    private readonly IJobChangeHost host;
    private readonly Action<string> trace;
    private PendingChange? pending;
    private int generation;

    private sealed class PendingChange(int index, byte job, JobChangeSnapshot before, double issuedAt)
    {
        public readonly int Index = index;
        public readonly byte Job = job;
        public readonly JobChangeSnapshot Before = before;
        public readonly double IssuedAt = issuedAt;
        public double? BlockedAt;
        public JobChangeSnapshot? LastObserved;
    }

    public JobChangeGuard(IJobChangeHost host, Action<string>? trace = null)
    {
        this.host = host;
        this.trace = trace ?? (_ => { });
    }

    public bool IsWaiting => pending?.BlockedAt != null;

    public void Reset()
    {
        generation++;
        pending = null;
    }

    public static bool TryParseGearsetChange(string command, out int zeroBasedIndex)
    {
        zeroBasedIndex = -1;
        var match = GearsetChange.Match(command);
        if (!match.Success || !int.TryParse(match.Groups["set"].Value,
                NumberStyles.None, CultureInfo.InvariantCulture, out var number) || number is < 1 or > 100)
            return false;
        zeroBasedIndex = number - 1;
        return true;
    }

    // A sequence barrier, not an action-name filter. Called before every due row,
    // including chat, a standalone /wait, another gearset change and child boundaries.
    // No row or its wait is consumed while this returns false.
    public bool TryContinue(double now)
    {
        if (!double.IsFinite(now)) throw new InvalidOperationException("切职保护时钟无效。");
        if (pending is not { } change) return true;
        if (now < change.IssuedAt) throw new InvalidOperationException("切职保护时钟倒退，已停止。");
        var current = host.ReadState();
        if ((change.Before.ContentId != 0 && current.ContentId != 0 && change.Before.ContentId != current.ContentId) ||
            (change.Before.EntityId != 0 && current.EntityId != 0 && change.Before.EntityId != current.EntityId))
            throw new InvalidOperationException("等待切职时角色已变化，已中止整段宏。");

        // Once blocked, a long frame stall must not release an already stale row.
        if (change.BlockedAt.HasValue && now - change.BlockedAt.Value >= MaximumWaitSeconds)
            throw new InvalidOperationException($"等待套装 {change.Index + 1} / 职业 {change.Job} 状态同步达到 {MaximumWaitSeconds:0} 秒上限，未发送后续宏行，已中止整段宏。{current}");

        if (!current.JobsMatch(change.Job) || current.GearsetIndex != change.Index)
        {
            change.BlockedAt ??= now;
            if (change.LastObserved != current)
            {
                trace($"[切职保护] 暂停后续宏行；切装后 {now - change.IssuedAt:F3}s；{current}。");
                change.LastObserved = current;
            }
            return false;
        }

        pending = null;
        var activeGeneration = generation;
        trace($"[切职保护] 三处职业与套装一致，继续后续宏行；切装后 {now - change.IssuedAt:F3}s，额外等待 {(change.BlockedAt.HasValue ? now - change.BlockedAt.Value : 0):F3}s；{current}。仅确认状态同步，不重发动作。");
        return generation == activeGeneration;
    }

    public bool TryDispatch(string command, double now)
    {
        // Protect direct callers as well as MacroExecutor. A second /gs may not
        // replace an outstanding transition and overtake the first one.
        if (!TryContinue(now)) return false;
        if (TryParseGearsetChange(command, out var index))
        {
            // Resolve and snapshot BEFORE dispatch; never keep native pointers between frames.
            var targetJob = host.GetGearsetJob(index);
            var before = targetJob is > 0 ? host.ReadState() : default;
            if (targetJob is > 0 && (!before.Available || before.ContentId == 0 ||
                before.EntityId is 0 or >= 0xE0000000))
                throw new InvalidOperationException("切职前角色状态不可用，未发送切职命令，已中止整段宏。");
            Reset();
            var activeGeneration = generation;
            var nativeDispatched = host.SendCommand(command);
            if (generation != activeGeneration) return true;
            if (nativeDispatched && targetJob is > 0 &&
                (!before.JobsMatch(targetJob.Value) || before.GearsetIndex != index))
            {
                pending = new PendingChange(index, targetJob.Value, before, now);
                trace($"[切职保护] 请求套装 {index + 1}，目标职业 {targetJob.Value}；{before}。后续宏行将在职业与套装同步后继续。");
            }
            return true;
        }

        // An unsupported named/relative/invalid change must not leave an older target armed.
        if (AnyGearsetChange.IsMatch(command)) Reset();

        host.SendCommand(command);
        return true;
    }
}
