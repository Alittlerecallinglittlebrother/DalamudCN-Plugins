using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace MacroShelfA.Runtime;

// No game dependency: tests exercise the exact scheduler used by the plugin.
internal sealed class MacroSequence
{
    public const int MaximumLines = 15;
    private static readonly Regex WaitLine = new(@"^/wait\s+(?<seconds>\d+(?:\.\d+)?)\s*$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    private static readonly Regex InlineWait = new(@"<wait\.(?<seconds>\d+(?:\.\d+)?)>", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    private sealed record Step(string ChildName, int ChildIndex, int LineNumber, string Command, double Delay);
    private readonly List<Step> steps = [];
    private double dueAt;
    private double startedAt;
    private int generation;
    public bool IsRunning { get; private set; }
    public string CurrentMacroName { get; private set; } = string.Empty;
    public string CurrentChildName { get; private set; } = string.Empty;
    public int CurrentChildIndex { get; private set; }
    public int TotalChildren { get; private set; }
    public int ExecutedLines { get; private set; }
    public int TotalLines => steps.Count;
    public int RemainingLines => TotalLines - ExecutedLines;
    public string ExecutionStopReason { get; private set; } = string.Empty;
    public double RemainingWait(double now) => IsRunning ? Math.Max(0, dueAt - now) : 0;

    public static List<string> PrepareLines(string commands) => commands.Replace("\r\n", "\n").Replace('\r', '\n')
        .Split('\n').Select(l => l.Trim()).Where(l => l.Length > 0 && !l.StartsWith('#')).ToList();

    public bool TryStart(MacroEntry macro, double now, out string error, bool allowLongMacros = false)
    {
        error = string.Empty;
        if (IsRunning) { error = "已有宏正在执行，请先中止，再启动其他宏。"; return false; }
        if (!double.IsFinite(now)) { error = "执行时钟无效，未启动宏。"; return false; }
        var children = macro.IsGroup ? macro.Children : new List<MacroEntry> { macro };
        if (children.Count == 0) { error = $"宏组“{macro.Name}”没有子宏，请先添加。"; return false; }
        if (macro.IsGroup && children.Count > Configuration.MaxChildren)
        { error = $"每组最多 {Configuration.MaxChildren} 个子宏。"; return false; }
        var prepared = new List<Step>();
        for (var i = 0; i < children.Count; i++)
        {
            var child = children[i];
            if (child.IsGroup) { error = "宏组内不能再嵌套宏组。"; return false; }
            if (child.Commands.Length > Configuration.MaxCommandLength)
            { error = $"“{child.Name}”超过 {Configuration.MaxCommandLength:N0} 字符，请拆分为多个子宏。"; return false; }
            var lines = PrepareLines(child.Commands);
            if (lines.Count == 0)
            { error = $"“{child.Name}”没有有效命令，请先填写内容。"; return false; }
            if (!allowLongMacros && lines.Count > MaximumLines)
            { error = $"“{child.Name}”有 {lines.Count} 行有效命令，超过 {MaximumLines} 行；请开启“解除 15 行限制”后再执行。"; return false; }
            for (var j = 0; j < lines.Count; j++)
            {
                var command = lines[j];
                var delay = 0.0; // No artificial inter-line delay; explicit waits below are preserved.
                var wait = WaitLine.Match(command);
                var inline = InlineWait.Match(command);
                if (wait.Success || inline.Success)
                {
                    var value = (wait.Success ? wait : inline).Groups["seconds"].Value;
                    if (!double.TryParse(value, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var seconds) || !double.IsFinite(seconds))
                    { error = $"“{child.Name}”第 {j + 1} 行的等待时间无效。"; return false; }
                    delay = Math.Clamp(seconds, 0.01, 86400);
                    command = wait.Success ? string.Empty : InlineWait.Replace(command, string.Empty).TrimEnd();
                }
                if (command.Length > 0 && (!command.StartsWith('/') || command.StartsWith("//", StringComparison.Ordinal)))
                { error = $"“{child.Name}”第 {j + 1} 行必须以单个 / 开头。"; return false; }
                prepared.Add(new Step(child.Name, i + 1, j + 1, command, delay));
            }
        }

        // Snapshot the whole chain before sending anything; editing cannot mutate this run.
        steps.Clear();
        steps.AddRange(prepared);
        ExecutedLines = 0;
        TotalChildren = children.Count;
        CurrentMacroName = macro.Name;
        CurrentChildName = children[0].Name;
        CurrentChildIndex = 1;
        ExecutionStopReason = string.Empty;
        startedAt = now;
        dueAt = now;
        IsRunning = true;
        generation++;
        return true;
    }

    public void Tick(double now, Action<string> send)
        => TickDeferred(now, command => { send(command); return true; });

    // false means not dispatched yet, not success: preserve the row and its wait.
    public void TickDeferred(double now, Func<string, bool> trySend, Func<bool>? canAdvance = null)
    {
        if (!IsRunning) return;
        if (!double.IsFinite(now) || now < startedAt)
        {
            Stop();
            ExecutionStopReason = "执行时钟异常，已中止整段宏。";
            return;
        }
        if (now < dueAt) return;
        if (ExecutedLines == steps.Count) { Stop(); return; }
        var step = steps[ExecutedLines];
        CurrentChildName = step.ChildName;
        CurrentChildIndex = step.ChildIndex;
        var activeGeneration = generation;
        try
        {
            if (canAdvance != null && !canAdvance()) return;
            // The gate can synchronously stop/replace the run, just like a command.
            if (generation != activeGeneration || !IsRunning) return;
            if (step.Command.Length > 0 && !trySend(step.Command)) return;
        }
        catch (Exception ex)
        {
            // A plugin command can synchronously stop this run and start another.
            // An exception from the obsolete callback must not stop the replacement.
            if (generation != activeGeneration) return;
            Stop();
            throw new InvalidOperationException($"“{step.ChildName}”第 {step.LineNumber} 行发送失败：{ex.Message}", ex);
        }
        if (generation != activeGeneration || !IsRunning) return;
        ExecutedLines++;
        // Explicit waits always start at actual dispatch, including after a frame stall.
        dueAt = now + step.Delay;
        // Still at most one step per Framework.Update. Zero-delay commands continue on later frames.
        if (ExecutedLines == steps.Count && dueAt <= now) Stop();
    }

    public void Stop()
    {
        generation++;
        IsRunning = false;
        CurrentMacroName = string.Empty;
        CurrentChildName = string.Empty;
        CurrentChildIndex = 0;
        TotalChildren = 0;
        steps.Clear();
        ExecutedLines = 0;
        dueAt = 0;
        ExecutionStopReason = string.Empty;
    }
}
