using System;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI;

namespace MacroShelfA.Runtime;

internal static unsafe class NativeCommandSender
{
    public static void Send(string command)
    {
        var uiModule = UIModule.Instance();
        if (uiModule == null)
        {
            throw new InvalidOperationException("游戏命令模块尚未就绪。");
        }

        var input = Utf8String.FromString(command);
        if (input == null)
        {
            throw new InvalidOperationException("无法创建游戏命令文本。");
        }

        using var traceScope = NativeCommandTrace.EnterDispatch(command);
        var before = NativeCommandTrace.Capture();
        var returned = false;
        try
        {
            DispatchToGame(uiModule, input);
            returned = true;
        }
        finally
        {
            try { NativeCommandTrace.Record(command, before, NativeCommandTrace.Capture(), returned); }
            finally { input->Dtor(true); }
        }
    }

    // Use the complete chat-command entry point, not ShellCommandModule's inner
    // parser. The native outer entry prepares per-command error state and runs
    // native outer cleanup. Do not reproduce those steps by writing shell flags.
    // This seam also permits an offline ABI test against the actual binding; it
    // does not make a successful dispatch equivalent to a successful game action.
    internal static void DispatchToGame(UIModule* uiModule, Utf8String* input)
    {
        if (uiModule == null || input == null)
            throw new InvalidOperationException("游戏命令模块或命令文本尚未就绪。");

        uiModule->ProcessChatBoxEntry(input, 0, false);
    }
}
