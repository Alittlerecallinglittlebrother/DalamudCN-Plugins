using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using FFXIVClientStructs.FFXIV.Client.UI.Shell;

namespace MacroShelfA.Runtime;

// Explicit, session-only diagnostics. Never infer success, retry, or write game state.
internal static class NativeCommandTrace
{
    internal const int LineLimit = 64;
    internal const string AuditedImageSha256 = "7BA28760BC53CBBBF66B63105FEA6C1BFE09CB6B1C6353FC8FB0FF03CC1A30F4";
    private static readonly object Sync = new();
    private static int generation;
    private static int remaining;
    private static long started;
    private static volatile bool rawLayoutVerified;
    private static long dispatchNumber;
    [ThreadStatic] private static string? dispatchSource;

    public static bool Enabled => Volatile.Read(ref remaining) > 0;
    public static bool RawLayoutVerified => rawLayoutVerified;
    internal static int SessionGeneration => Volatile.Read(ref generation);
    internal static string CurrentSource => dispatchSource ?? "external(manual/native-macro/other-plugin)";

    // Correlation only: never retain command arguments, native pointers or player identities.
    internal static DispatchScope EnterDispatch(string command)
    {
        if (!Enabled) return default;
        var previous = dispatchSource;
        dispatchSource = $"plugin#{Interlocked.Increment(ref dispatchNumber)}:{CommandVerb(command)}";
        return new DispatchScope(previous, true);
    }

    internal readonly struct DispatchScope(string? previous, bool active) : IDisposable
    {
        public void Dispose() { if (active) dispatchSource = previous; }
    }

    internal sealed record Snapshot(int Generation, bool Available, bool ShowErrors, uint ErrorData,
        uint Flags, int MacroLine, bool MacroLocked, uint WaitMs, byte? Raw2AF, byte? Raw2B0, float? Raw2B8)
    {
        public override string ToString() => !Available ? "unavailable" :
            $"showErrors={ShowErrors},error=0x{ErrorData:X8},flags=0x{Flags:X8},nativeLine={MacroLine},locked={MacroLocked},waitMs={WaitMs}," +
            (Raw2AF.HasValue ? $"rawUnknown[2AF={Raw2AF},2B0={Raw2B0},2B8={Raw2B8!.Value.ToString("R", CultureInfo.InvariantCulture)}]" : "rawUnknown=disabled");
    }

    // false is also useful for binding-only offline tests; it never enables raw reads.
    public static void Begin(bool validateRawLayout = true)
    {
        int token;
        lock (Sync)
        {
            token = Interlocked.Increment(ref generation);
            rawLayoutVerified = false;
            started = Stopwatch.GetTimestamp();
            Volatile.Write(ref remaining, LineLimit);
        }
        Write("enabled; limit=64; records command verb and read-only shell state, not action success or chat body");
        if (validateRawLayout) _ = Task.Run(() => VerifyCurrentImage(token));
    }

    public static void End()
    {
        lock (Sync)
        {
            Interlocked.Increment(ref generation);
            Volatile.Write(ref remaining, 0);
            rawLayoutVerified = false;
        }
    }

    private static void VerifyCurrentImage(int token)
    {
        var verified = false;
        try
        {
            // Raw fields are not documented bindings. Only the exact locally audited
            // executable AND matching installed struct layout may enable their reads.
            using var process = Process.GetCurrentProcess();
            var path = process.MainModule?.FileName;
            if (path != null && string.Equals(Path.GetFileName(path), "ffxiv_dx11.exe", StringComparison.OrdinalIgnoreCase) && BindingLayoutMatches())
            {
                using var stream = File.OpenRead(path);
                verified = Convert.ToHexString(SHA256.HashData(stream)) == AuditedImageSha256;
            }
        }
        catch (Exception) { /* Diagnostics fall back to named binding fields. */ }
        lock (Sync)
        {
            if (token != Volatile.Read(ref generation) || !Enabled) return;
            rawLayoutVerified = verified;
            Write($"raw-layout-exact-image-verified={verified}; raw offsets are observations, not a readiness API");
        }
    }

    internal static unsafe bool BindingLayoutMatches() =>
        sizeof(RaptureShellModule) == 0x1250 &&
        Marshal.OffsetOf<RaptureShellModule>(nameof(RaptureShellModule.ShowCommandErrors)) == 0x2AD &&
        Marshal.OffsetOf<RaptureShellModule>(nameof(RaptureShellModule.MacroCurrentLine)) == 0x2C0 &&
        Marshal.OffsetOf<RaptureShellModule>(nameof(RaptureShellModule.Flags)) == 0x1248 &&
        Marshal.OffsetOf<RaptureShellModule>(nameof(RaptureShellModule.ErrorData)) == 0x124C;

    public static unsafe Snapshot? Capture()
    {
        if (!Enabled) return null;
        try { return CaptureShell(RaptureShellModule.Instance(), rawLayoutVerified && BindingLayoutMatches()); }
        catch (Exception) { return CaptureShell(null, false); }
    }

    internal static unsafe Snapshot CaptureShell(RaptureShellModule* shell, bool allowAuditedRawFields)
    {
        var token = Volatile.Read(ref generation);
        if (shell == null) return new(token, false, false, 0, 0, -1, false, 0, null, null, null);
        var raw = (byte*)shell;
        return new(token, true, shell->ShowCommandErrors, shell->ErrorData, shell->Flags,
            shell->MacroCurrentLine, shell->MacroLocked, shell->WaitTimeMs,
            allowAuditedRawFields ? raw[0x2AF] : null,
            allowAuditedRawFields ? raw[0x2B0] : null,
            allowAuditedRawFields ? *(float*)(raw + 0x2B8) : null);
    }

    internal static string CommandVerb(string command)
    {
        // Whitelist the command token; never log arguments, targets, lyrics or suffixes.
        if (command.Length < 2 || command[0] != '/') return "(invalid)";
        var end = 1;
        while (end < command.Length && end <= 32 && char.IsLetterOrDigit(command[end])) end++;
        return end == 1 ? "/?" : command[..end];
    }

    public static void Record(string command, Snapshot? before, Snapshot? after, bool returned)
    {
        try
        {
            lock (Sync)
            {
                if (!Enabled || before == null || before.Generation != Volatile.Read(ref generation)) return;
                if (after?.Generation != before.Generation) after = null;
                var left = Interlocked.Decrement(ref remaining);
                var index = LineLimit - left;
                var elapsed = Stopwatch.GetElapsedTime(started).TotalSeconds.ToString("F3", CultureInfo.InvariantCulture);
                Write($"#{index} +{elapsed}s verb={CommandVerb(command)} entry=ProcessChatBoxEntry returned={returned}; source={CurrentSource}; before[{before}]; after[{after?.ToString() ?? "unavailable"}]");
                if (left == 0) Write("limit reached; disabled");
            }
        }
        catch (Exception) { /* Formatting failures must not interrupt the macro. */ }
    }

    public static void RecordConsumed(string command)
    {
        try
        {
            lock (Sync)
            {
                if (!Enabled) return;
                var left = Interlocked.Decrement(ref remaining);
                var elapsed = Stopwatch.GetElapsedTime(started).TotalSeconds.ToString("F3", CultureInfo.InvariantCulture);
                Write($"#{LineLimit - left} +{elapsed}s verb={CommandVerb(command)} route=DalamudCommandManager consumed=true; nativeNotCalled");
                if (left == 0) Write("limit reached; disabled");
            }
        }
        catch (Exception) { /* Diagnostics must not affect plugin command routing. */ }
    }

    private static void Write(string message)
    {
        try { Plugin.Log.Information("[命令链路诊断] {Message}", message); }
        catch (Exception) { /* Diagnostic logging must never interrupt a macro. */ }
    }
}
