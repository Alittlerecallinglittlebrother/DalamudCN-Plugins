using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading;
using Dalamud.Hooking;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;
using FFXIVClientStructs.FFXIV.Client.UI.Shell;

namespace MacroShelfA.Runtime;

// Diagnostic observer only. Never calls an action in addition to the original native call,
// never changes its arguments/return, and never writes native game fields.
// Constructor does not install hooks. enabled/rawLayoutVerified must be session-only flags.
internal sealed unsafe class NativeEmoteTrace : IDisposable
{
    internal const int EventLimit = 192;
    internal const int SessionSeconds = 120;
    private readonly IGameInteropProvider interop;
    private readonly IFramework framework;
    private readonly ICondition conditions;
    private readonly IPluginLog log;
    private readonly Func<bool> enabled;
    private readonly Func<bool> rawLayoutVerified;
    // Contract: a fixed source label and command verb only; never pass command arguments.
    private readonly Func<string?> sourceContext;
    private readonly Func<int> sessionGeneration;
    private readonly Action<string>? readyCallback;
    private int observedGeneration;
    private volatile bool isReady;
    private string statusText = "已关闭";
    public bool IsReady => isReady;
    public string StatusText => statusText;
    private Hook<AgentEmote.Delegates.ExecuteEmote>? agentHook;
    private Hook<EmoteManager.Delegates.CanExecuteEmote>? canHook;
    private Hook<EmoteManager.Delegates.ExecuteEmote>? executeHook;
    private bool disposed, sessionActive, installFailed, exhausted;
    private long started;
    private int events, activeCalls;
    [ThreadStatic] private static int agentDepth;
    [ThreadStatic] private static bool insideTelemetry;

    public NativeEmoteTrace(IGameInteropProvider interop, IFramework framework, ICondition conditions,
        IPluginLog log, Func<bool> enabled, Func<bool> rawLayoutVerified, Func<string?> sourceContext,
        Func<int> sessionGeneration, Action<string>? readyCallback = null)
    {
        this.interop = interop;
        this.framework = framework;
        this.conditions = conditions;
        this.log = log;
        this.enabled = enabled;
        this.rawLayoutVerified = rawLayoutVerified;
        this.sourceContext = sourceContext;
        this.sessionGeneration = sessionGeneration;
        this.readyCallback = readyCallback;
        framework.Update += OnUpdate;
    }

    private bool Flag(Func<bool> get) { try { return get(); } catch { return false; } }
    private void OnUpdate(IFramework _)
    {
        if (disposed)
        {
            // Reentrant unload must not free a trampoline that Original is still using.
            // These emote entry points run on the Framework thread; retain this final
            // update subscription until the in-flight native stack has returned.
            if (Volatile.Read(ref activeCalls) == 0)
            {
                framework.Update -= OnUpdate;
                DisposeHooks();
            }
            return;
        }
        var on = Flag(enabled);
        if (!on)
        {
            sessionActive = false;
            isReady = false;
            statusText = "已关闭";
            // Do not dispose a native hook while a detour is using its Original trampoline.
            if (Volatile.Read(ref activeCalls) == 0) DisposeHooks();
            return;
        }
        int nextGeneration;
        try { nextGeneration = sessionGeneration(); } catch { nextGeneration = observedGeneration; }
        if (!sessionActive || nextGeneration != observedGeneration)
        {
            if (Volatile.Read(ref activeCalls) != 0) return;
            DisposeHooks();
            observedGeneration = nextGeneration;
            isReady = false;
            statusText = "等待客户端精确校验（未通过时不安装）";
            sessionActive = true;
            installFailed = exhausted = false;
            events = 0;
            started = Stopwatch.GetTimestamp();
        }
        if (Stopwatch.GetElapsedTime(started).TotalSeconds >= SessionSeconds || Volatile.Read(ref events) >= EventLimit)
            exhausted = true;
        if (exhausted || !Flag(rawLayoutVerified))
        {
            isReady = false;
            statusText = exhausted ? "已达到事件或时间上限" : "等待客户端精确校验（未通过时不安装）";
            if (Volatile.Read(ref activeCalls) == 0) DisposeHooks();
            return;
        }
        if (agentHook != null || installFailed) return;
        try
        {
            // Installed ClientStructs delegates preserve the native U1 boolean ABI.
            var agentAddress = (nint)AgentEmote.MemberFunctionPointers.ExecuteEmote;
            var canAddress = (nint)EmoteManager.MemberFunctionPointers.CanExecuteEmote;
            var executeAddress = (nint)EmoteManager.MemberFunctionPointers.ExecuteEmote;
            if (agentAddress == 0 || canAddress == 0 || executeAddress == 0)
                throw new InvalidOperationException("Emote binding unavailable");
            using (var process = Process.GetCurrentProcess())
            {
                var imageBase = process.MainModule?.BaseAddress ?? 0;
                if (!AuditedAddressesMatch(imageBase, agentAddress, canAddress, executeAddress) ||
                    sizeof(AgentEmote) != 0x110 || sizeof(EmoteManager) != 0x40)
                    throw new InvalidOperationException("Emote bindings do not match audited client");
            }
            agentHook = interop.HookFromAddress<AgentEmote.Delegates.ExecuteEmote>(agentAddress, OnAgent);
            canHook = interop.HookFromAddress<EmoteManager.Delegates.CanExecuteEmote>(canAddress, OnCanExecute);
            executeHook = interop.HookFromAddress<EmoteManager.Delegates.ExecuteEmote>(executeAddress, OnExecute);
            canHook.Enable();
            executeHook.Enable();
            agentHook.Enable();
            isReady = true;
            statusText = "动作诊断已就绪";
            Ready("动作诊断已就绪：开始记录实际原生动作调用。");
            SafeWrite("enabled; actual native calls only; cap=192 events/120s; no success inference from outer command return");
        }
        catch (Exception ex)
        {
            installFailed = true;
            isReady = false;
            statusText = "动作观察器安装失败（见日志）";
            DisposeHooks();
            Ready("动作诊断未能启动，请查看卫月日志；宏执行逻辑没有改变。");
            SafeWrite($"hooks unavailable; type={ex.GetType().Name}; no native call substituted");
        }
    }

    // Only evaluated after the exact current-process image hash gate. Addresses are
    // compared with audited RVAs, never used to call an unbound native function.
    internal static bool AuditedAddressesMatch(nint imageBase, nint agent, nint can, nint execute) =>
        imageBase != 0 && agent == imageBase + 0xF3AF20 &&
        can == imageBase + 0x1967670 && execute == imageBase + 0x1966DB0;

    private bool Observe()
    {
        if (insideTelemetry || disposed || exhausted || !isReady || !sessionActive || !Flag(enabled) || !Flag(rawLayoutVerified)) return false;
        try { if (sessionGeneration() != observedGeneration) return false; }
        catch { return false; }
        if (Volatile.Read(ref events) >= EventLimit || Stopwatch.GetElapsedTime(started).TotalSeconds >= SessionSeconds) return false;
        return true;
    }

    private void OnAgent(AgentEmote* self, ushort id, EmoteController.PlayEmoteOption* option, bool history, bool liveHistory)
    {
        Interlocked.Increment(ref activeCalls);
        var original = agentHook!.Original;
        agentDepth++;
        var record = Observe();
        var before = record ? Capture() : null;
        var returned = false;
        try
        {
            original(self, id, option, history, liveHistory); // Exactly once.
            returned = true;
        }
        finally
        {
            if (record) Record("Agent.Execute", id, returned ? "returned-void" : "original-threw", before);
            agentDepth--;
            Interlocked.Decrement(ref activeCalls);
        }
    }

    private bool OnCanExecute(EmoteManager* self, ushort id)
    {
        Interlocked.Increment(ref activeCalls);
        var original = canHook!.Original;
        // Ignore availability polling by an open emote UI; Agent's real execution check is in scope.
        var record = agentDepth > 0 && Observe();
        var before = record ? Capture() : null;
        var returned = false;
        var result = false;
        try
        {
            result = original(self, id); // Exactly once; no extra readiness query.
            returned = true;
            return result;
        }
        finally
        {
            if (record) Record("Manager.CanExecute", id, returned ? result.ToString() : "original-threw", before);
            Interlocked.Decrement(ref activeCalls);
        }
    }

    private bool OnExecute(EmoteManager* self, ushort id, EmoteController.PlayEmoteOption* option)
    {
        Interlocked.Increment(ref activeCalls);
        var original = executeHook!.Original;
        var record = Observe();
        var before = record ? Capture() : null;
        var returned = false;
        var result = false;
        try
        {
            result = original(self, id, option); // Exactly once; no retries.
            returned = true;
            return result;
        }
        finally
        {
            if (record) Record("Manager.Execute", id, returned ? result.ToString() : "original-threw", before);
            Interlocked.Decrement(ref activeCalls);
        }
    }

    private string? Capture()
    {
        if (insideTelemetry) return null;
        insideTelemetry = true;
        try
        {
            var flags = new List<int>();
            for (var i = 0; i < Math.Min(112, Math.Max(0, conditions.MaxEntries)); i++)
                if (conditions[i]) flags.Add(i);
            var actor = Control.GetLocalPlayer();
            var state = PlayerState.Instance();
            var gearsets = RaptureGearsetModule.Instance();
            var hotbars = RaptureHotbarModule.Instance();
            var shell = RaptureShellModule.Instance();
            var shared = $"nativeLine={(shell == null ? -1 : shell->MacroCurrentLine)},nativeLocked={(shell != null && shell->MacroLocked)},active=[{string.Join(',', flags)}],stateJob={(state == null ? -1 : state->CurrentClassJobId)}," +
                $"hotbarJob={(hotbars == null ? -1 : hotbars->ActiveHotbarClassJobId)},gs={(gearsets == null ? -1 : gearsets->CurrentGearsetIndex)}";
            if (actor == null) return $"actor=null,{shared}";
            // Pointer is diagnostic object identity only; no name, account/content ID, target, or lyrics.
            return $"actor=0x{(nuint)actor:X},job={actor->ClassJob},mode={(byte)actor->Mode},modeParam={actor->ModeParam}," +
                $"emote={actor->EmoteController.EmoteId},pose={(byte)actor->EmoteController.CurrentPoseType},cpose={actor->EmoteController.CPoseState},{shared}";
        }
        catch (Exception ex) { return $"snapshot-unavailable:{ex.GetType().Name}"; }
        finally { insideTelemetry = false; }
    }

    private void Record(string stage, ushort id, string result, string? before)
    {
        // All diagnostics are isolated from Original. Logging errors never retry or change the native result.
        try
        {
            if (!Observe()) return;
            var index = Interlocked.Increment(ref events);
            if (index > EventLimit) return;
            var source = Source();
            var after = Capture();
            var elapsed = Stopwatch.GetElapsedTime(started).TotalSeconds.ToString("F3", CultureInfo.InvariantCulture);
            SafeWrite($"#{index} +{elapsed}s source={source} stage={stage} id={id} result={result}; before[{before ?? "unavailable"}]; after[{after ?? "unavailable"}]");
            if (index == EventLimit) SafeWrite("event limit reached; observers will be disabled on next Framework update");
        }
        catch { /* Observation must not affect execution. */ }
    }

    private string Source()
    {
        try
        {
            var value = sourceContext();
            if (string.IsNullOrWhiteSpace(value)) return "external-native/manual-or-macro";
            // Additional defense only: caller must already return source/verb, not the original text.
            return new string(value.Take(80).Where(c => char.IsLetterOrDigit(c) || c is '/' or ':' or '-' or '_' or '#' or '.').ToArray());
        }
        catch { return "source-unavailable"; }
    }

    private void Ready(string text)
    {
        try { readyCallback?.Invoke(text); } catch { }
    }

    private void SafeWrite(string text)
    {
        try { log.Information("[动作链路诊断] {Message}", text); }
        catch { /* No effect on native execution. */ }
    }

    private void DisposeHooks()
    {
        // Reverse installation order. No game state fields are reset or written.
        Release(ref agentHook);
        Release(ref executeHook);
        Release(ref canHook);
    }
    private static void Release<T>(ref Hook<T>? field) where T : Delegate
    {
        var hook = field;
        field = null;
        if (hook == null) return;
        try { hook.Disable(); } catch { }
        try { hook.Dispose(); } catch { }
    }
    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        isReady = false;
        statusText = "已卸载";
        if (Volatile.Read(ref activeCalls) == 0)
        {
            framework.Update -= OnUpdate;
            DisposeHooks();
        }
    }
}


