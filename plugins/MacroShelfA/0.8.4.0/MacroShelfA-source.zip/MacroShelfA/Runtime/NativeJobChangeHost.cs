using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;

namespace MacroShelfA.Runtime;

// Framework-thread, read-only observations through the installed ClientStructs bindings.
// Never bypass the game's text-command dispatcher or write job/action state.
internal sealed unsafe class NativeJobChangeHost : IJobChangeHost
{
    public byte? GetGearsetJob(int zeroBasedIndex)
    {
        var module = RaptureGearsetModule.Instance();
        if (module == null || zeroBasedIndex < 0 || zeroBasedIndex >= module->Entries.Length) return null;
        ref var entry = ref module->Entries[zeroBasedIndex];
        return (entry.Flags & RaptureGearsetModule.GearsetFlag.Exists) != 0 && entry.ClassJob != 0
            ? entry.ClassJob : null;
    }

    public JobChangeSnapshot ReadState()
    {
        var local = Control.GetLocalPlayer();
        var state = PlayerState.Instance();
        var gearsets = RaptureGearsetModule.Instance();
        var hotbars = RaptureHotbarModule.Instance();
        var available = local != null && state != null && gearsets != null && hotbars != null &&
            state->IsLoaded && state->ContentId != 0 && local->EntityId == state->EntityId && hotbars->ModuleReady;
        // ModuleReady is file initialization, NOT a per-job action-readiness signal.
        return new JobChangeSnapshot(available,
            state == null ? 0 : state->ContentId, local == null ? 0 : local->EntityId,
            local == null ? (byte)0 : local->ClassJob, state == null ? (byte)0 : state->CurrentClassJobId,
            hotbars == null ? (byte)0 : hotbars->ActiveHotbarClassJobId,
            gearsets == null ? -1 : gearsets->CurrentGearsetIndex);
    }

    public bool SendCommand(string command)
    {
        if (Plugin.CommandManager.ProcessCommand(command))
        {
            NativeCommandTrace.RecordConsumed(command);
            return false;
        }
        NativeCommandSender.Send(command);
        return true;
    }
}
