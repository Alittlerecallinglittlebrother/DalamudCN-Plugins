using System;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Textures;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Windowing;

namespace MacroShelfA.Windows;

internal sealed class FloatingLauncherWindow : Window
{
    private const float MinimumIconSize = 32f;
    private const float MaximumIconSize = 96f;
    private const float DefaultOpacity = 0.58f;

    private readonly Configuration configuration;
    private readonly MainWindow mainWindow;
    private readonly ISharedImmediateTexture iconTexture;
    private float opacity = DefaultOpacity;

    public FloatingLauncherWindow(Configuration configuration, MainWindow mainWindow)
        : base("Macro Shelf-A 启动器###MacroShelfAFloatingLauncher")
    {
        this.configuration = configuration;
        this.mainWindow = mainWindow;
        iconTexture = Plugin.TextureProvider.GetFromManifestResource(
            typeof(Plugin).Assembly,
            "MacroShelfA.Resources.FloatingLauncher.png");

        Flags = ImGuiWindowFlags.NoTitleBar |
                ImGuiWindowFlags.NoResize |
                ImGuiWindowFlags.NoMove |
                ImGuiWindowFlags.NoScrollbar |
                ImGuiWindowFlags.NoScrollWithMouse |
                ImGuiWindowFlags.NoCollapse |
                ImGuiWindowFlags.NoBackground |
                ImGuiWindowFlags.NoDocking |
                ImGuiWindowFlags.NoFocusOnAppearing |
                ImGuiWindowFlags.NoNav;
        Position = new Vector2(24f, 210f) * ImGuiHelpers.GlobalScale;
        PositionCondition = ImGuiCond.FirstUseEver;
        IsOpen = true;
        ShowCloseButton = false;
        RespectCloseHotkey = false;
        DisableWindowSounds = true;
        ForceMainWindow = true;
    }

    public override bool DrawConditions() => configuration.ShowFloatingLauncher && !mainWindow.IsOpen;

    public override void PreDraw()
    {
        var scale = ImGuiHelpers.GlobalScale;
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(5f, 5f) * scale);
        ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, 14f * scale);
        ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0f);
    }

    public override void PostDraw()
    {
        ImGui.PopStyleVar(3);
    }

    public override void Draw()
    {
        var scale = ImGuiHelpers.GlobalScale;
        var iconSize = new Vector2(Math.Clamp(configuration.FloatingLauncherSize, MinimumIconSize, MaximumIconSize) * scale);
        ClampToViewport();

        ImGui.InvisibleButton(
            "##FloatingLauncherButton",
            iconSize,
            ImGuiButtonFlags.MouseButtonLeft |
            ImGuiButtonFlags.MouseButtonMiddle |
            ImGuiButtonFlags.MouseButtonRight);

        var hovered = ImGui.IsItemHovered();
        var dragging = hovered && !configuration.LockFloatingLauncher &&
            ImGui.IsMouseDragging(ImGuiMouseButton.Middle, 1f);
        if (dragging)
        {
            MoveWithMouse();
        }

        if (hovered && !dragging && ImGui.IsItemClicked(ImGuiMouseButton.Left))
        {
            mainWindow.IsOpen = true;
        }

        UpdateOpacity(hovered);
        DrawIcon(iconSize, hovered);
        DrawContextMenu();

        if (hovered)
        {
            var dragHint = configuration.LockFloatingLauncher ? "位置已锁定" : "按住中键：拖动悬浮图标";
            ImGui.SetTooltip($"左键：打开 Macro Shelf-A\n{dragHint}\n右键：悬浮入口设置");
        }
    }

    private void DrawIcon(Vector2 iconSize, bool hovered)
    {
        var iconMin = ImGui.GetItemRectMin();
        var iconMax = iconMin + iconSize;
        var scale = ImGuiHelpers.GlobalScale;
        var rounding = MathF.Min(18f * scale, iconSize.X * 0.24f);
        var drawList = ImGui.GetWindowDrawList();
        var shadowOffset = new Vector2(0f, 2f) * scale;

        drawList.AddRectFilled(
            iconMin + shadowOffset,
            iconMax + shadowOffset,
            ImGui.GetColorU32(new Vector4(0.005f, 0.015f, 0.03f, opacity * 0.78f)),
            rounding + (2f * scale));

        var wrap = iconTexture.GetWrapOrEmpty();
        // Keep the supplied original's aspect ratio; do not crop or stretch its portrait.
        var fit = MathF.Min(iconSize.X / Math.Max(1, wrap.Width), iconSize.Y / Math.Max(1, wrap.Height));
        var imageSize = new Vector2(wrap.Width, wrap.Height) * fit;
        var imageMin = iconMin + (iconSize - imageSize) / 2;
        drawList.AddImageRounded(
            wrap.Handle,
            imageMin,
            imageMin + imageSize,
            Vector2.Zero,
            Vector2.One,
            ImGui.GetColorU32(new Vector4(1f, 1f, 1f, opacity)),
            rounding);

        var border = hovered
            ? new Vector4(0.30f, 0.72f, 1f, opacity)
            : new Vector4(0.19f, 0.36f, 0.55f, opacity * 0.78f);
        drawList.AddRect(iconMin, iconMax, ImGui.GetColorU32(border), rounding, 1.25f * scale);
    }

    private void DrawContextMenu()
    {
        if (!ImGui.BeginPopupContextItem("##FloatingLauncherContext"))
        {
            return;
        }

        ImGui.TextUnformatted("Macro Shelf-A");
        ImGui.TextDisabled("悬浮入口");
        ImGui.Separator();

        if (ImGui.MenuItem("打开 Macro Shelf-A"))
        {
            mainWindow.IsOpen = true;
        }

        if (ImGui.MenuItem(configuration.LockFloatingLauncher ? "解锁位置" : "锁定位置"))
        {
            configuration.LockFloatingLauncher = !configuration.LockFloatingLauncher;
            configuration.Save();
        }

        if (ImGui.MenuItem("图标缩小", string.Empty, false, configuration.FloatingLauncherSize > MinimumIconSize))
        {
            SetIconSize(configuration.FloatingLauncherSize - 8f);
        }

        if (ImGui.MenuItem("图标放大", string.Empty, false, configuration.FloatingLauncherSize < MaximumIconSize))
        {
            SetIconSize(configuration.FloatingLauncherSize + 8f);
        }

        ImGui.Separator();
        if (ImGui.MenuItem("显示常用宏栏", string.Empty, configuration.ShowQuickBar))
        {
            configuration.ShowQuickBar = !configuration.ShowQuickBar;
            configuration.Save();
        }
        if (ImGui.MenuItem("隐藏悬浮入口"))
        {
            configuration.ShowFloatingLauncher = false;
            configuration.Save();
        }

        ImGui.EndPopup();
    }

    private void UpdateOpacity(bool hovered)
    {
        var target = hovered ? 1f : DefaultOpacity;
        var speed = hovered ? 14f : 7f;
        var deltaTime = MathF.Max(0f, ImGui.GetIO().DeltaTime);
        var progress = 1f - MathF.Exp(-speed * deltaTime);
        opacity += (target - opacity) * progress;
    }

    private void MoveWithMouse()
    {
        var viewport = ImGui.GetMainViewport();
        var margin = new Vector2(8f * ImGuiHelpers.GlobalScale);
        var windowSize = ImGui.GetWindowSize();
        var minimum = viewport.WorkPos + margin;
        var maximum = viewport.WorkPos + viewport.WorkSize - windowSize - margin;
        var desired = ImGui.GetWindowPos() + ImGui.GetIO().MouseDelta;
        ImGui.SetWindowPos(ClampToBounds(desired, minimum, maximum), ImGuiCond.Always);
    }

    private void ClampToViewport()
    {
        var viewport = ImGui.GetMainViewport();
        var margin = new Vector2(8f * ImGuiHelpers.GlobalScale);
        var windowSize = ImGui.GetWindowSize();
        if (windowSize.X <= 0f || windowSize.Y <= 0f)
        {
            return;
        }

        var minimum = viewport.WorkPos + margin;
        var maximum = viewport.WorkPos + viewport.WorkSize - windowSize - margin;
        var current = ImGui.GetWindowPos();
        var clamped = ClampToBounds(current, minimum, maximum);
        if (Vector2.DistanceSquared(current, clamped) > 0.01f)
        {
            ImGui.SetWindowPos(clamped, ImGuiCond.Always);
        }
    }

    private static Vector2 ClampToBounds(Vector2 value, Vector2 minimum, Vector2 maximum)
    {
        maximum = Vector2.Max(minimum, maximum);
        return Vector2.Clamp(value, minimum, maximum);
    }

    private void SetIconSize(float size)
    {
        configuration.FloatingLauncherSize = Math.Clamp(size, MinimumIconSize, MaximumIconSize);
        configuration.Save();
    }
}
