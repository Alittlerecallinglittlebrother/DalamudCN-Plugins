using System;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow
{
    private void DrawEditor()
    {
        var width = ImGui.GetContentRegionAvail().X;
        BeginPanel("##MacroTree", Math.Clamp(width * .30f, S(185), S(360)));
        Heading("宏库"); ImGui.TextColored(MutedColor, $"{configuration.Macros.Count} 个入口 · 按保存顺序"); ImGui.Separator();
        ImGui.BeginChild("##TreeScroll", new Vector2(0, MathF.Max(S(80), ImGui.GetContentRegionAvail().Y - S(45))), false);
        foreach (var tag in configuration.Macros.Where(m => MacroLibrary.Matches(m, searchText)).GroupBy(MacroLibrary.Tag)
            .OrderBy(g => g.Key == "未分类").ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase).ToArray())
        {
            var isOpen = !collapsedCategories.Contains(tag.Key) || searchText.Length > 0;
            if (ImGui.Selectable($"{(isOpen ? "v" : ">")}   {Fit(tag.Key, ImGui.GetContentRegionAvail().X - S(30))}##treecat-{tag.Key}", false, ImGuiSelectableFlags.None, new Vector2(0, S(30))))
            { if (isOpen) collapsedCategories.Add(tag.Key); else collapsedCategories.Remove(tag.Key); }
            RecordItem("tree-category-" + tag.Key);
            if (!isOpen) continue;
            ImGui.Indent(S(10));
            foreach (var root in tag.ToArray())
            {
                ImGui.PushID(root.Id);
                if (root.IsGroup)
                {
                    var expanded = expandedGroups.Contains(root.Id) || searchText.Length > 0;
                    if (ImGui.SmallButton(expanded ? "v" : ">")) { if (expanded) expandedGroups.Remove(root.Id); else expandedGroups.Add(root.Id); }
                    RecordItem("tree-expand-" + root.Id); ImGui.SameLine();
                    if (EntryRow(root, "tree-" + root.Id, ReferenceEquals(selectedMacro, root), S(31))) { selectedMacro = root; showEntryProperties = false; }
                    if (expanded)
                    {
                        ImGui.Indent(S(19));
                        foreach (var child in root.Children.ToArray())
                        {
                            if (!MacroLibrary.MatchesSelf(root, searchText) && !MacroLibrary.MatchesSelf(child, searchText)) continue;
                            if (EntryRow(child, "tree-" + child.Id, ReferenceEquals(selectedMacro, child), S(31))) { selectedMacro = child; showEntryProperties = false; }
                        }
                        ImGui.Unindent(S(19));
                    }
                }
                else if (EntryRow(root, "tree-" + root.Id, ReferenceEquals(selectedMacro, root), S(31))) { selectedMacro = root; showEntryProperties = false; }
                ImGui.PopID();
            }
            ImGui.Unindent(S(10)); ImGui.Spacing();
        }
        if (!configuration.Macros.Any(m => MacroLibrary.Matches(m, searchText))) ImGui.TextWrapped("没有匹配的宏。清除搜索或创建新宏。");
        ImGui.EndChild(); ImGui.Separator();
        if (ImGui.Button("导入")) BeginImport(); RecordItem("tree-import"); ImGui.SameLine();
        if (ImGui.Button("导出")) ExportConfiguration(); RecordItem("tree-export");
        ImGui.EndChild(); ImGui.SameLine();
        BeginPanel("##MacroEditor", 0); DrawSelectedMacroEditor(); ImGui.EndChild();
    }
    private void DrawSelectedMacroEditor()
    {
        if (selectedMacro == null || RootOf(selectedMacro) == null)
        {
            selectedMacro = null; Heading("编辑台"); ImGui.TextWrapped("从左侧选择宏或子宏。也可以点击顶部“新建”开始。"); return;
        }
        var entry = selectedMacro; var parent = configuration.FindParent(entry);
        ImGui.TextColored(MutedColor, Fit(parent == null ? MacroLibrary.Tag(entry) : $"{MacroLibrary.Tag(parent)} / {parent.Name}", ImGui.GetContentRegionAvail().X));
        Heading(entry.Name);
        ImGui.TextColored(MutedColor, parent == null ? (entry.IsGroup ? $"宏组 · {entry.Children.Count} 个子宏" : "独立宏") : $"子宏 {parent.Children.IndexOf(entry) + 1} / {parent.Children.Count}");
        ImGui.SameLine(); ImGui.TextColored(MutedColor, "· 自动保存");
        if (ImGui.Button(showEntryProperties ? "收起属性" : "名称与分类")) showEntryProperties = !showEntryProperties; RecordItem("edit-properties");
        if (parent != null)
        {
            ImGui.SameLine(); if (ImGui.Button("宏组顺序")) OpenEditor(parent); RecordItem("edit-parent");
        }
        if (macroExecutor.IsRunning) ImGui.TextWrapped("当前执行使用启动时快照；编辑内容在下次运行生效。");
        ImGui.Separator();
        var available = ImGui.GetContentRegionAvail().Y;
        ImGui.BeginChild("##EditScroll", new Vector2(0, MathF.Max(S(70), available - S(96))), false);
        if (showEntryProperties) DrawProperties(entry, parent);
        if (entry.IsGroup) DrawGroupEditor(entry); else DrawCommandEditor(entry);
        ImGui.EndChild();
        DrawEntryActions(entry, parent);
    }
    private void DrawProperties(MacroEntry entry, MacroEntry? parent)
    {
        ImGui.TextColored(MutedColor, entry.IsGroup ? "总按钮名称" : "宏名称"); var name = entry.Name;
        ImGui.SetNextItemWidth(-1);
        if (ImGui.InputText("##MacroName", ref name, Configuration.MaxNameLength * 4 + 1)) { entry.Name = name; metadataDirty = true; InvalidateLibrary(); }
        RecordItem("edit-name"); if (ImGui.IsItemDeactivatedAfterEdit()) SaveConfiguration();
        if (parent == null)
        {
            ImGui.TextColored(MutedColor, "分类标签"); var group = entry.Group; ImGui.SetNextItemWidth(-1);
            if (ImGui.InputText("##MacroTag", ref group, Configuration.MaxGroupLength * 4 + 1)) { entry.Group = group; metadataDirty = true; InvalidateLibrary(); }
            RecordItem("edit-category"); if (ImGui.IsItemDeactivatedAfterEdit()) SaveConfiguration();
        }
        var pinned = entry.Pinned;
        if (ImGui.Checkbox(parent == null ? "收藏并加入常用栏" : "加入常用栏（仅此子宏）", ref pinned)) { entry.Pinned = pinned; SaveConfiguration(); }
        RecordItem("edit-favorite");
        ImGui.Spacing(); ImGui.Separator();
    }
    private void DrawGroupEditor(MacroEntry group)
    {
        ImGui.TextUnformatted("子宏顺序"); ImGui.TextColored(MutedColor, "先执行上一段，再进入下一段；保留末行等待。");
        ImGui.BeginDisabled(group.Children.Count >= Configuration.MaxChildren || configuration.CountEntries() >= Configuration.MaxEntries);
        if (ImGui.Button("添加子宏"))
        {
            var child = configuration.AddChild(group); if (child != null) { OpenEditor(child); showEntryProperties = true; InvalidateLibrary(); }
        }
        RecordItem("add-child"); ImGui.SameLine();
        ImGui.SetNextItemWidth(MathF.Max(S(100), ImGui.GetContentRegionAvail().X));
        if (ImGui.BeginCombo("##CopyExisting", "添加已有宏的副本…"))
        {
            foreach (var original in configuration.Macros.Where(m => !m.IsGroup).ToArray())
            {
                if (ImGui.Selectable($"{original.Name}##{original.Id}"))
                {
                    var child = configuration.AddChild(group, original); if (child != null) { OpenEditor(child); InvalidateLibrary(); }
                }
                RecordItem("copy-existing-" + original.Id);
            }
            ImGui.EndCombo();
        }
        RecordItem("copy-existing"); ImGui.EndDisabled(); ImGui.Spacing();
        for (var i = 0; i < group.Children.Count; i++)
        {
            var child = group.Children[i]; ImGui.PushID(child.Id);
            if (ImGui.Selectable($"{i + 1:00}  {child.Name}##edit-child", false, ImGuiSelectableFlags.None, new Vector2(0, S(30)))) OpenEditor(child);
            RecordItem("group-child-" + child.Id); ImGui.TextColored(MutedColor, $"     {Lines(child)} 行"); ImGui.Separator(); ImGui.PopID();
        }
        if (group.Children.Count == 0) ImGui.TextWrapped("添加第一个子宏后即可编辑命令。");
    }
    private void DrawCommandEditor(MacroEntry entry)
    {
        var count = Lines(entry); var overLines = !configuration.AllowLongMacros && count > MacroExecutor.MaximumLines;
        var overText = entry.Commands.Length > Configuration.MaxCommandLength;
        ImGui.TextUnformatted("命令编辑"); ImGui.SameLine();
        ImGui.TextColored(overLines || overText ? DangerColor : MutedColor, $"{count} 行 · {entry.Commands.Length:N0} 字符");
        if (overLines)
        {
            ImGui.TextWrapped("超过 15 行，请在“设置”中解除行数限制。");
            if (ImGui.Button("打开设置")) page = Page.Settings; RecordItem("edit-open-settings");
        }
        if (overText) ImGui.TextWrapped("超过 64,000 字符，请拆分；已有内容不会截断。");
        var commands = entry.Commands;
        var height = MathF.Max(S(140), ImGui.GetContentRegionAvail().Y - S(33));
        var bytes = Math.Max(Configuration.MaxCommandLength * 3 + 1, System.Text.Encoding.UTF8.GetByteCount(commands) + 1);
        if (ImGui.InputTextMultiline("##MacroCommands", ref commands, bytes, new Vector2(-1, height), ImGuiInputTextFlags.AllowTabInput))
        { entry.Commands = commands; SaveConfiguration(); }
        RecordItem("edit-commands");
        ImGui.TextColored(MutedColor, "支持 /wait 3、<wait.0.5> · 内容自动保存");
    }
    private void DrawEntryActions(MacroEntry entry, MacroEntry? parent)
    {
        ImGui.Separator();
        var siblings = parent?.Children ?? configuration.Macros; var index = siblings.IndexOf(entry);
        ImGui.BeginDisabled(index <= 0);
        if (ImGui.Button("上移")) { configuration.Move(entry, -1); InvalidateLibrary(); } RecordItem("move-up"); ImGui.EndDisabled(); ImGui.SameLine();
        ImGui.BeginDisabled(index < 0 || index >= siblings.Count - 1);
        if (ImGui.Button("下移")) { configuration.Move(entry, 1); InvalidateLibrary(); } RecordItem("move-down"); ImGui.EndDisabled(); ImGui.SameLine();
        ImGui.BeginDisabled(configuration.CountEntries() + 1 + (entry.IsGroup ? entry.Children.Count : 0) > Configuration.MaxEntries ||
            (parent != null && parent.Children.Count >= Configuration.MaxChildren));
        if (ImGui.Button("复制")) { var copy = configuration.Duplicate(entry); if (copy != null) OpenEditor(copy); InvalidateLibrary(); } RecordItem("duplicate"); ImGui.EndDisabled(); ImGui.SameLine();
        if (ImGui.Button("删除")) { pendingDelete = entry; openDeletePopup = true; } RecordItem("delete");
        ImGui.BeginDisabled(macroExecutor.IsRunning || (entry.IsGroup && entry.Children.Count == 0));
        if (parent != null)
        {
            if (ImGui.Button("运行整组")) macroExecutor.Start(parent); RecordItem("edit-run-group"); ImGui.SameLine();
        }
        if (DrawColoredButton(entry.IsGroup ? "运行整组" : parent == null ? "运行此宏" : "运行此子宏", AccentColor, AccentHoverColor,
            new Vector2(MathF.Max(S(100), ImGui.GetContentRegionAvail().X), S(35)))) macroExecutor.Start(entry);
        RecordItem("edit-run"); ImGui.EndDisabled();
    }
}
