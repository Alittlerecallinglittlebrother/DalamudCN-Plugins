using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow
{
    private void DrawQuickBarSettings()
    {
        Heading("常用宏栏");
        var visible = configuration.ShowQuickBar;
        if (ImGui.Checkbox("显示常用宏栏", ref visible)) { configuration.ShowQuickBar = visible; SaveConfiguration(); }
        RecordItem("setting-quickbar");
        ImGui.TextWrapped("收藏的宏会出现在独立悬浮栏；点击即可运行，无需打开主窗口。也可在栏中添加独立宏、宏组或单个子宏。");
        var locked = configuration.LockQuickBar;
        if (ImGui.Checkbox("锁定常用栏位置", ref locked)) { configuration.LockQuickBar = locked; SaveConfiguration(); }
        RecordItem("setting-quickbar-lock");
        var columns = configuration.QuickBarColumns;
        ImGui.SetNextItemWidth(S(180));
        if (ImGui.SliderInt("每行按钮数", ref columns, 1, 8)) { configuration.QuickBarColumns = columns; SaveConfiguration(); }
        var width = configuration.QuickBarButtonWidth;
        ImGui.SetNextItemWidth(S(180));
        if (ImGui.SliderFloat("按钮宽度", ref width, 80, 200, "%.0f px")) { configuration.QuickBarButtonWidth = width; SaveConfiguration(); }
        ImGui.TextWrapped("拖动栏头移动位置；支持收起、移除和右键编辑。隐藏后可用 /aklmacro bar 恢复；/aklmacro stop 中止执行。隐藏收纳栏不会中止宏。");
    }
}
