using System;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow
{
    private void DrawCountdownTrigger()
    {
        if (ImGui.BeginChild("##CountdownSettings", new Vector2(0, 0), false))
        {
            ImGui.TextUnformatted("战斗倒计时结束后执行指定宏");
            ImGui.TextWrapped("小队战斗倒计时结束、游戏发出“战斗开始！”时，自动启动一次所选宏。宏组会依次执行所有子宏。");
            ImGui.Spacing();
            ImGui.TextUnformatted("执行目标");
            var target = configuration.FindCountdownMacro();
            ImGui.SetNextItemWidth(-1);
            if (ImGui.BeginCombo("##CountdownTarget", target == null ? "请选择独立宏或宏组" : CountdownTargetLabel(target)))
            {
                if (ImGui.Selectable("不绑定", target == null))
                {
                    configuration.ClearCountdownBinding();
                    SaveConfiguration();
                    countdownTrigger?.ResetForSettingsChange();
                }
                foreach (var macro in configuration.Macros.ToArray())
                {
                    var choose = ImGui.Selectable($"{CountdownTargetLabel(macro)}##{macro.Id}", target?.Id == macro.Id);
                    RecordItem("countdown-option-" + macro.Id);
                    if (!choose) continue;
                    configuration.CountdownMacroId = macro.Id;
                    SaveConfiguration();
                    countdownTrigger?.ResetForSettingsChange();
                }
                ImGui.EndCombo();
            }
            RecordItem("countdown-target");
            if (configuration.Macros.Count == 0) ImGui.TextWrapped("还没有可选目标，请使用顶部“新建”创建独立宏或宏组。");
            target = configuration.FindCountdownMacro();
            var enabled = configuration.CountdownTriggerEnabled;
            ImGui.BeginDisabled(target == null);
            if (ImGui.Checkbox("战斗倒计时结束后执行宏", ref enabled))
            {
                configuration.CountdownTriggerEnabled = enabled;
                SaveConfiguration();
                countdownTrigger?.ResetForSettingsChange();
            }
            RecordItem("countdown-enabled");
            ImGui.EndDisabled();
            ImGui.Spacing();
            ImGui.Separator();
            ImGui.TextWrapped($"监听状态：{countdownTrigger?.StatusText ?? "测试宿主未连接监听器"}");
            ImGui.TextWrapped($"最近结果：{countdownTrigger?.LastResult ?? "尚未触发"}");
            ImGui.Spacing();
            ImGui.TextWrapped("启用或更换目标后，从下一次完整倒计时生效；自己或队友发起均可。取消、登出、切图不会触发，普通聊天文字也不会触发。");
            ImGui.TextWrapped("已有宏正在执行时跳过本次，不打断、不排队。仍遵循“解除 15 行限制”和宏中 /wait 的设置。");
            ImGui.TextWrapped("删除绑定目标或覆盖导入配置会关闭本功能。关闭此开关可停止监听；已启动的宏请使用底部状态栏的“中止整组”。");
        }
        ImGui.EndChild();
    }

    private static string CountdownTargetLabel(MacroEntry macro) =>
        $"{(macro.IsGroup ? "[宏组]" : "[独立宏]")} {macro.Name}{(string.IsNullOrEmpty(macro.Group) ? "" : $" · {macro.Group}")}";

    private void DrawLineLimitSetting()
    {
        var enabled = configuration.AllowLongMacros;
        if (ImGui.Checkbox("解除 15 行限制", ref enabled))
        {
            configuration.AllowLongMacros = enabled;
            SaveConfiguration();
        }
        if (ImGui.IsItemHovered())
            ImGui.SetTooltip("对独立宏和所有子宏生效。关闭不会删除长宏内容。\n修改只影响下次启动，不改变正在执行的流程。");
        RecordItem("setting-long");
        ImGui.SameLine();
        ImGui.TextDisabled(enabled ? "已解除 · 每宏最多 64,000 字符" : "未解除 · 每个独立宏 / 子宏最多 15 行");
    }

    private void DrawBetterWaitSetting()
    {
        var enabled = configuration.BetterWaitEnabled;
        if (ImGui.Checkbox("启用更好的等待", ref enabled))
        {
            configuration.BetterWaitEnabled = enabled;
            SaveConfiguration();
            betterWaitPatch.SetEnabled(enabled);
        }

        RecordItem("setting-wait");
        ImGui.SameLine();
        ImGui.TextDisabled(betterWaitPatch.StatusText);
        ImGui.SameLine();
        ImGui.TextDisabled("支持小数等待与长时间 /wait");
        if (ImGui.IsItemHovered())
        {
            ImGui.SetTooltip("宏中可使用 /wait 0.1、/wait 120 或 <wait.0.1>。\n若 Daily Routines 的同类功能仍启用，请先关闭，避免两个内存补丁冲突。");
        }
    }

    private void DrawFloatingLauncherSetting()
    {
        ImGui.Spacing();
        var visible = configuration.ShowFloatingLauncher;
        if (ImGui.Checkbox("显示悬浮入口", ref visible))
        {
            configuration.ShowFloatingLauncher = visible;
            SaveConfiguration();
        }

        RecordItem("setting-floating");
        ImGui.SameLine();
        ImGui.TextDisabled(visible ? "关闭主窗口后显示" : "已隐藏");
        if (!visible)
        {
            return;
        }

        ImGui.SameLine();
        var locked = configuration.LockFloatingLauncher;
        if (ImGui.Checkbox("锁定位置", ref locked))
        {
            configuration.LockFloatingLauncher = locked;
            SaveConfiguration();
        }

        ImGui.SameLine();
        ImGui.SetNextItemWidth(150 * ImGuiHelpers.GlobalScale);
        var size = configuration.FloatingLauncherSize;
        if (ImGui.SliderFloat("图标尺寸", ref size, 32f, 96f, "%.0f px"))
        {
            configuration.FloatingLauncherSize = size;
            SaveConfiguration();
        }
    }

    private void ExportConfiguration()
    {
        try
        {
            ImGui.SetClipboardText(ConfigurationExchange.Export(configuration));
            transferStatus = $"已复制 {configuration.Macros.Count} 个入口（含子宏）";
            transferStatusIsError = false;
        }
        catch (Exception exception)
        {
            transferStatus = $"导出失败：{exception.Message}";
            transferStatusIsError = true;
        }
    }

    private void DrawImportPopup()
    {
        ImGui.SetNextWindowSize(new Vector2(MathF.Min(680 * Scale, ImGui.GetIO().DisplaySize.X - 32), MathF.Min(520 * Scale, ImGui.GetIO().DisplaySize.Y - 32)), ImGuiCond.FirstUseEver);
        var open = true;
        if (!ImGui.BeginPopupModal("导入配置", ref open))
        {
            return;
        }

        ImGui.TextUnformatted("粘贴由 Macro Shelf-A 导出的 JSON 配置");
        ImGui.TextWrapped("追加导入仅添加内容，保留本机开关；替换导入同时应用等待与解除行数限制设置。");
        ImGui.Spacing();
        if (ImGui.Button("从剪贴板重新粘贴"))
        {
            importText = ImGui.GetClipboardText() ?? string.Empty;
            transferStatus = string.Empty;
            confirmReplaceImport = false;
        }

        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextMultiline("##ImportConfigurationJson", ref importText, ConfigurationExchange.MaximumJsonLength,
            new Vector2(-1, MathF.Max(80, ImGui.GetContentRegionAvail().Y - 112 * Scale)), ImGuiInputTextFlags.AllowTabInput);

        if (!string.IsNullOrEmpty(transferStatus))
        {
            ImGui.TextColored(transferStatusIsError ? DangerColor : SuccessColor, transferStatus);
        }
        else
        {
            ImGui.TextDisabled($"当前已有 {configuration.CountEntries()}/{ConfigurationExchange.MaximumEntries} 个条目（含宏组与子宏）");
        }

        if (DrawColoredButton("追加导入", AccentColor, AccentHoverColor, new Vector2(105 * ImGuiHelpers.GlobalScale, 0)))
        {
            ImportConfiguration(replaceExisting: false);
        }

        ImGui.SameLine();
        var replaceLabel = confirmReplaceImport ? "确认替换" : "替换现有";
        if (DrawColoredButton(replaceLabel, DangerColor, DangerHoverColor, new Vector2(105 * ImGuiHelpers.GlobalScale, 0)))
        {
            if (confirmReplaceImport)
            {
                ImportConfiguration(replaceExisting: true);
            }
            else
            {
                confirmReplaceImport = true;
                transferStatus = "再次点击“确认替换”才会覆盖全部独立宏、宏组及子宏。";
                transferStatusIsError = true;
            }
        }

        ImGui.SameLine();
        if (ImGui.Button("取消", new Vector2(90 * ImGuiHelpers.GlobalScale, 0)))
        {
            confirmReplaceImport = false;
            transferStatus = string.Empty;
            ImGui.CloseCurrentPopup();
        }

        ImGui.EndPopup();
    }

    private void ImportConfiguration(bool replaceExisting)
    {
        if (!ConfigurationExchange.TryImport(importText, out var imported, out var error))
        {
            transferStatus = error;
            transferStatusIsError = true;
            confirmReplaceImport = false;
            return;
        }

        if (!replaceExisting && configuration.CountEntries() + imported.CountEntries() > ConfigurationExchange.MaximumEntries)
        {
            transferStatus = $"追加后将有 {configuration.CountEntries() + imported.CountEntries()} 个宏，超过 {ConfigurationExchange.MaximumEntries} 个的上限。";
            transferStatusIsError = true;
            confirmReplaceImport = false;
            return;
        }

        var firstImportedIndex = replaceExisting ? 0 : configuration.Macros.Count;
        if (replaceExisting)
        {
            macroExecutor.Stop(false);
            configuration.Macros.Clear();
            configuration.ClearCountdownBinding();
            countdownTrigger?.ResetForSettingsChange();
            configuration.BetterWaitEnabled = imported.BetterWaitEnabled;
            configuration.AllowLongMacros = imported.AllowLongMacros;
            betterWaitPatch.SetEnabled(imported.BetterWaitEnabled);
        }

        configuration.Macros.AddRange(imported.Macros);
        SaveConfiguration();
        selectedMacro = configuration.Macros.ElementAtOrDefault(firstImportedIndex) ?? configuration.Macros.FirstOrDefault();
        filter = LibraryFilter.All; searchText = string.Empty; page = Page.Library;
        InvalidateLibrary();
        transferStatus = $"已{(replaceExisting ? "替换" : "追加")}导入 {imported.Macros.Count} 个宏";
        transferStatusIsError = false;
        confirmReplaceImport = false;
        ImGui.CloseCurrentPopup();
    }

    private void DrawDeleteConfirmation()
    {
        var open = true;
        if (!ImGui.BeginPopupModal("删除宏", ref open, ImGuiWindowFlags.AlwaysAutoResize))
        {
            return;
        }

        ImGui.TextUnformatted($"确定删除“{pendingDelete?.Name ?? string.Empty}”？");
        ImGui.TextWrapped(pendingDelete?.IsGroup == true ? $"将同时删除组内 {pendingDelete.Children.Count} 个子宏。此操作无法撤销。" : "此操作无法撤销。");
        ImGui.Spacing();
        if (DrawColoredButton("删除", DangerColor, DangerHoverColor, new Vector2(90 * ImGuiHelpers.GlobalScale, 0)))
        {
            var deleting = pendingDelete;
            var parent = deleting == null ? null : configuration.FindParent(deleting);
            pendingDelete = null;
            if (deleting != null && configuration.Remove(deleting))
            {
                selectedMacro = parent ?? configuration.Macros.FirstOrDefault();
                InvalidateLibrary();
            }

            ImGui.CloseCurrentPopup();
        }

        ImGui.SameLine();
        if (ImGui.Button("取消", new Vector2(90 * ImGuiHelpers.GlobalScale, 0)))
        {
            pendingDelete = null;
            ImGui.CloseCurrentPopup();
        }

        ImGui.EndPopup();
    }

}
