using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Windowing;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow : Window, IDisposable
{
    private enum Page { Library, Editor, Countdown, Settings }
    private static readonly Vector4 AccentColor = new(0.11f, 0.38f, 0.72f, 1);
    private static readonly Vector4 AccentHoverColor = new(0.12f, 0.41f, 0.77f, 1);
    private static readonly Vector4 SuccessColor = new(0.35f, 0.82f, 0.54f, 1);
    private static readonly Vector4 DangerColor = new(0.93f, 0.40f, 0.43f, 1);
    private static readonly Vector4 DangerHoverColor = new(0.70f, 0.24f, 0.29f, 1);
    private static readonly Vector4 MutedColor = new(0.66f, 0.76f, 0.86f, 1);
    private readonly Configuration configuration;
    private readonly MacroExecutor macroExecutor;
    private readonly BetterWaitPatch betterWaitPatch;
    private readonly CountdownTrigger? countdownTrigger;
    private MacroEntry? selectedMacro;
    private MacroEntry? pendingDelete;
    private bool openDeletePopup, openImportPopup, confirmReplaceImport;
    private string searchText = string.Empty, importText = string.Empty, transferStatus = string.Empty;
    private bool transferStatusIsError;
    private Page page;
    private LibraryFilter filter;
    private LibrarySort sort;
    private string category = string.Empty;
    private readonly HashSet<string> collapsedCategories = [];
    private readonly HashSet<string> expandedGroups = [];
    private readonly Dictionary<string, (string Text, int Lines)> lineCounts = [];
    private List<MacroEntry>? visibleCache;
    private int cachedRootCount = -1;
    private bool showEntryProperties;
    private bool metadataDirty;
    private string? revealEntryId;
    private static float Scale => ImGuiHelpers.GlobalScale;
    private static float S(float n) => n * Scale;
    // Erased by the compiler in the plugin; tests implement this partial method to locate native controls.
    partial void RecordItem(string key);

    public MainWindow(Configuration configuration, MacroExecutor macroExecutor, BetterWaitPatch betterWaitPatch,
        CountdownTrigger? countdownTrigger = null) : base("Macro Shelf-A###MacroShelfAMain")
    {
        this.configuration = configuration; this.macroExecutor = macroExecutor;
        this.betterWaitPatch = betterWaitPatch; this.countdownTrigger = countdownTrigger;
        selectedMacro = configuration.Macros.FirstOrDefault();
        if (selectedMacro?.IsGroup == true) expandedGroups.Add(selectedMacro.Id);
        foreach (var tag in configuration.Macros.Select(MacroLibrary.Tag).Distinct())
            if (selectedMacro == null || tag != MacroLibrary.Tag(selectedMacro)) collapsedCategories.Add(tag);
        Size = new Vector2(1120, 760); SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new WindowSizeConstraints { MinimumSize = new Vector2(720, 500), MaximumSize = new Vector2(1920, 1400) };
        Flags = ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse;
    }
    public void Dispose() { }
    private void InvalidateLibrary() { visibleCache = null; }
    internal void RefreshLibrary() => InvalidateLibrary();
    internal void EditEntry(MacroEntry entry) { IsOpen = true; OpenEditor(entry); }
    private void SaveConfiguration() { configuration.Save(); metadataDirty = false; InvalidateLibrary(); }
    private List<MacroEntry> VisibleRoots()
    {
        if (visibleCache == null || cachedRootCount != configuration.Macros.Count)
        {
            visibleCache = MacroLibrary.Query(configuration.Macros, filter, category, searchText, sort);
            cachedRootCount = configuration.Macros.Count;
        }
        return visibleCache;
    }
    private int Lines(MacroEntry m)
    {
        if (m.IsGroup) return m.Children.Sum(Lines);
        if (!lineCounts.TryGetValue(m.Id, out var c) || !ReferenceEquals(c.Text, m.Commands))
            lineCounts[m.Id] = c = (m.Commands, MacroSequence.PrepareLines(m.Commands).Count);
        return c.Lines;
    }
    private MacroEntry? RootOf(MacroEntry? m) => m == null ? null : configuration.FindParent(m) ?? (configuration.Macros.Contains(m) ? m : null);
    private void OpenEditor(MacroEntry m)
    {
        selectedMacro = m; page = Page.Editor; showEntryProperties = false; revealEntryId = m.Id;
        var root = RootOf(m); if (root != null) { expandedGroups.Add(root.Id); collapsedCategories.Remove(MacroLibrary.Tag(root)); }
    }
    private void SetFilter(LibraryFilter next, string tag = "")
    {
        filter = next; category = tag; InvalidateLibrary();
    }

    public override void Draw()
    {
        PushUiTheme();
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(S(8), S(8)));
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(S(10), S(7)));
        ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, S(5));
        ImGui.PushStyleVar(ImGuiStyleVar.ChildRounding, S(5));
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(S(12), S(12)));
        try
        {
            var dl = ImGui.GetWindowDrawList();
            dl.AddRectFilled(ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize(), ImGui.GetColorU32(new Vector4(.045f, .068f, .095f, 1)));
            DrawToolbar();
            ImGui.Separator();
            var height = MathF.Max(S(180), ImGui.GetContentRegionAvail().Y - S(54));
            if (ImGui.BeginChild("##PageContent", new Vector2(0, height), false, ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse))
            {
                switch (page)
                {
                    case Page.Library: DrawLibrary(); break;
                    case Page.Editor: DrawEditor(); break;
                    case Page.Countdown: DrawCountdownTrigger(); break;
                    case Page.Settings: DrawSettings(); break;
                }
            }
            ImGui.EndChild();
            DrawFooter();
            if (openDeletePopup) { ImGui.OpenPopup("删除宏"); openDeletePopup = false; }
            if (openImportPopup) { ImGui.OpenPopup("导入配置"); openImportPopup = false; }
            DrawDeleteConfirmation(); DrawImportPopup();
            if (metadataDirty && !ImGui.IsAnyItemActive()) SaveConfiguration();
        }
        finally { ImGui.PopStyleVar(5); ImGui.PopStyleColor(18); }
    }
    private void DrawToolbar()
    {
        foreach (var (label, target, key) in new[] { ("资料库", Page.Library, "nav-library"), ("编辑台", Page.Editor, "nav-editor"), ("事件触发", Page.Countdown, "nav-countdown") })
        {
            var active = page == target;
            if (active) ImGui.PushStyleColor(ImGuiCol.Button, AccentColor);
            if (ImGui.Button(label)) { page = target; if (target == Page.Editor && selectedMacro != null) OpenEditor(selectedMacro); }
            RecordItem(key); if (active) ImGui.PopStyleColor(); ImGui.SameLine();
        }
        var trailing = S(140);
        ImGui.SetNextItemWidth(MathF.Max(S(80), ImGui.GetContentRegionAvail().X - trailing));
        if (ImGui.InputTextWithHint("##LibrarySearch", "搜索名称、子宏或命令…", ref searchText, 256)) InvalidateLibrary();
        RecordItem("search"); ImGui.SameLine();
        if (ImGui.Button("新建")) ImGui.OpenPopup("##NewMacro"); RecordItem("new-menu");
        if (ImGui.BeginPopup("##NewMacro"))
        {
            ImGui.BeginDisabled(configuration.CountEntries() + 2 > Configuration.MaxEntries);
            if (ImGui.MenuItem("新建宏组")) AddEntry(true); RecordItem("new-group"); ImGui.EndDisabled();
            ImGui.BeginDisabled(configuration.CountEntries() >= Configuration.MaxEntries);
            if (ImGui.MenuItem("新建独立宏")) AddEntry(false); RecordItem("new-macro"); ImGui.EndDisabled();
            ImGui.EndPopup();
        }
        ImGui.SameLine();
        if (ImGui.Button("设置")) page = Page.Settings; RecordItem("nav-settings");
    }
    private void AddEntry(bool isGroup)
    {
        var added = configuration.AddMacro(isGroup); if (added == null) return;
        if (filter == LibraryFilter.Category && category != "未分类") { added.Group = category; SaveConfiguration(); }
        searchText = string.Empty; InvalidateLibrary(); OpenEditor(added); showEntryProperties = true;
    }
    private void DrawLibrary()
    {
        var roots = VisibleRoots();
        var selectedRoot = RootOf(selectedMacro);
        if (selectedRoot == null || !roots.Contains(selectedRoot)) selectedMacro = roots.FirstOrDefault();
        else selectedMacro = selectedRoot;
        var width = ImGui.GetContentRegionAvail().X;
        var navWidth = Math.Clamp(width * .18f, S(150), S(260));
        var detailWidth = Math.Clamp(width * .30f, S(220), S(430));
        var listWidth = MathF.Max(S(200), width - navWidth - detailWidth - S(16));
        BeginPanel("##Categories", navWidth); DrawCategories(); ImGui.EndChild(); ImGui.SameLine();
        BeginPanel("##LibraryList", listWidth); DrawMacroList(roots); ImGui.EndChild(); ImGui.SameLine();
        BeginPanel("##Inspector", 0); DrawInspector(); ImGui.EndChild();
    }
    private static void BeginPanel(string id, float width) => ImGui.BeginChild(id, new Vector2(width, 0), true, ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);
    private void DrawCategories()
    {
        var height = MathF.Max(S(50), ImGui.GetContentRegionAvail().Y - S(95));
        ImGui.BeginChild("##CategoryScroll", new Vector2(0, height), false);
        CategoryRow("全部宏", configuration.Macros.Count, filter == LibraryFilter.All, "filter-all", () => SetFilter(LibraryFilter.All));
        CategoryRow("已收藏", configuration.Macros.Count(m => m.Pinned), filter == LibraryFilter.Favorites, "filter-favorites", () => SetFilter(LibraryFilter.Favorites));
        ImGui.Spacing(); ImGui.TextColored(MutedColor, "分类"); ImGui.Separator();
        foreach (var tag in configuration.Macros.GroupBy(MacroLibrary.Tag).OrderBy(g => g.Key == "未分类").ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase).ToArray())
            CategoryRow(tag.Key, tag.Count(), filter == LibraryFilter.Category && category == tag.Key, "category-" + tag.Key, () => SetFilter(LibraryFilter.Category, tag.Key));
        ImGui.EndChild();
        ImGui.Separator();
        ImGui.TextColored(MutedColor, $"{configuration.CountEntries()} / {Configuration.MaxEntries} 条目");
        if (ImGui.Button("导入 / 导出", new Vector2(-1, 0))) ImGui.OpenPopup("##Transfer"); RecordItem("transfer-menu");
        DrawTransferMenu();
    }
    private void CategoryRow(string text, int count, bool selected, string key, Action click)
    {
        var width = ImGui.GetContentRegionAvail().X;
        if (ImGui.Selectable("##" + key, selected, ImGuiSelectableFlags.None, new Vector2(width, S(35)))) click(); RecordItem(key);
        var p = ImGui.GetItemRectMin(); var end = ImGui.GetItemRectMax(); var dl = ImGui.GetWindowDrawList();
        var n = count.ToString(CultureInfo.InvariantCulture); var nw = ImGui.CalcTextSize(n).X;
        dl.AddText(p + new Vector2(S(7), S(7)), ImGui.GetColorU32(ImGuiCol.Text), Fit(text, width - nw - S(26)));
        dl.AddText(new Vector2(end.X - nw - S(7), p.Y + S(7)), ImGui.GetColorU32(MutedColor), n);
        if (ImGui.IsItemHovered()) ImGui.SetTooltip(text);
    }
    private void DrawMacroList(List<MacroEntry> roots)
    {
        Heading(filter == LibraryFilter.All ? "全部宏" : filter == LibraryFilter.Favorites ? "已收藏" : category);
        ImGui.TextColored(MutedColor, $"{roots.Count} 个入口"); ImGui.SameLine();
        ImGui.SetNextItemWidth(MathF.Min(S(130), ImGui.GetContentRegionAvail().X));
        var order = (int)sort;
        if (ImGui.Combo("##Sort", ref order, "保存顺序\0名称\0宏组优先\0")) { sort = (LibrarySort)order; InvalidateLibrary(); }
        RecordItem("sort"); ImGui.Spacing();
        if (roots.Count == 0)
        {
            ImGui.TextWrapped(configuration.Macros.Count == 0 ? "还没有宏。点击顶部“新建”创建独立宏或宏组。" : "没有匹配的宏。试试其他分类或搜索词。");
            if (configuration.Macros.Count > 0 && ImGui.Button("清除筛选")) { searchText = string.Empty; SetFilter(LibraryFilter.All); }
            RecordItem("clear-filter"); return;
        }
        var wide = ImGui.GetContentRegionAvail().X > S(400);
        if (!ImGui.BeginTable("##MacroTable", wide ? 4 : 3, ImGuiTableFlags.ScrollY | ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.SizingFixedFit,
            new Vector2(0, ImGui.GetContentRegionAvail().Y))) return;
        ImGui.TableSetupColumn("##Favorite", ImGuiTableColumnFlags.WidthFixed, S(26));
        ImGui.TableSetupColumn("名称", ImGuiTableColumnFlags.WidthStretch);
        if (wide) ImGui.TableSetupColumn("类型", ImGuiTableColumnFlags.WidthFixed, S(54));
        ImGui.TableSetupColumn("内容", ImGuiTableColumnFlags.WidthFixed, S(86));
        ImGui.TableSetupScrollFreeze(0, 1); ImGui.TableHeadersRow();
        foreach (var macro in roots)
        {
            ImGui.PushID(macro.Id); ImGui.TableNextRow(ImGuiTableRowFlags.None, S(43));
            if (ReferenceEquals(selectedMacro, macro)) ImGui.TableSetBgColor(ImGuiTableBgTarget.RowBg0, ImGui.GetColorU32(new Vector4(.13f, .30f, .51f, 1)));
            ImGui.TableSetColumnIndex(0);
            if (IconButton("favorite", macro.Pinned ? "取消收藏" : "收藏", Icon.Star, macro.Pinned)) { macro.Pinned = !macro.Pinned; SaveConfiguration(); }
            RecordItem("favorite-" + macro.Id);
            ImGui.TableSetColumnIndex(1);
            if (EntryRow(macro, "root-" + macro.Id, false, S(35))) selectedMacro = macro;
            if (ImGui.IsItemHovered() && ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left)) OpenEditor(macro);
            if (wide) { ImGui.TableSetColumnIndex(2); ImGui.TextColored(MutedColor, macro.IsGroup ? "宏组" : "独立宏"); }
            ImGui.TableSetColumnIndex(wide ? 3 : 2);
            ImGui.TextColored(MutedColor, macro.IsGroup ? $"{macro.Children.Count} 个子宏" : $"{Lines(macro)} 行");
            ImGui.PopID();
        }
        ImGui.EndTable();
    }
    private void DrawInspector()
    {
        if (selectedMacro == null) { Heading("宏详情"); ImGui.TextWrapped("从列表选择一个宏，查看内容并运行。"); return; }
        var entry = selectedMacro;
        var height = MathF.Max(S(80), ImGui.GetContentRegionAvail().Y - S(128));
        ImGui.BeginChild("##InspectorScroll", new Vector2(0, height), false);
        Heading(entry.Name); ImGui.TextWrapped($"{(entry.IsGroup ? "宏组" : "独立宏")} · {MacroLibrary.Tag(entry)}");
        ImGui.TextColored(MutedColor, entry.IsGroup ? $"{entry.Children.Count} 个子宏 · {Lines(entry)} 行" : $"{Lines(entry)} 行命令");
        ImGui.Spacing(); ImGui.Separator(); ImGui.Spacing();
        if (entry.IsGroup)
        {
            ImGui.TextColored(MutedColor, "子宏列表");
            for (var i = 0; i < entry.Children.Count; i++)
            {
                var child = entry.Children[i]; ImGui.PushID(child.Id);
                var runWidth = S(30); var w = MathF.Max(S(80), ImGui.GetContentRegionAvail().X - runWidth - S(8));
                if (ImGui.Selectable($"{i + 1:00}  {Fit(child.Name, w - S(35))}##inspect", false, ImGuiSelectableFlags.None, new Vector2(w, S(30)))) OpenEditor(child);
                RecordItem("inspect-child-" + child.Id); if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{child.Name}\n{Lines(child)} 行 · 点击编辑");
                ImGui.SameLine(); ImGui.BeginDisabled(macroExecutor.IsRunning);
                if (IconButton("run", "运行此子宏", Icon.Play)) macroExecutor.Start(child);
                RecordItem("inspect-run-" + child.Id); ImGui.EndDisabled();
                ImGui.Separator(); ImGui.PopID();
            }
            if (entry.Children.Count == 0) ImGui.TextWrapped("宏组为空，请先编辑并添加子宏。");
        }
        else
        {
            ImGui.TextColored(MutedColor, "命令预览");
            var preview = string.Join('\n', entry.Commands.Replace("\r\n", "\n").Split('\n').Take(16));
            ImGui.TextWrapped(preview.Length == 0 ? "尚未填写命令" : preview);
            if (Lines(entry) > 16) ImGui.TextColored(MutedColor, "…更多内容请进入编辑台");
        }
        ImGui.EndChild();
        if (ImGui.Button(entry.IsGroup ? "编辑宏组" : "编辑命令", new Vector2(-1, S(34)))) OpenEditor(entry); RecordItem("inspect-edit");
        ImGui.BeginDisabled(macroExecutor.IsRunning || (entry.IsGroup && entry.Children.Count == 0));
        if (DrawColoredButton(entry.IsGroup ? "运行整组" : "运行此宏", AccentColor, AccentHoverColor, new Vector2(-1, S(38)))) macroExecutor.Start(entry);
        RecordItem("inspect-run"); ImGui.EndDisabled();
        ImGui.TextColored(MutedColor, entry.IsGroup ? "按子宏顺序执行" : "使用当前已保存内容");
    }
    private void DrawFooter()
    {
        ImGui.Separator();
        var running = macroExecutor.IsRunning;
        if (running)
        {
            ImGui.BeginDisabled(!running);
            if (DrawColoredButton("中止整组", DangerHoverColor, DangerColor, new Vector2(S(100), S(31)))) macroExecutor.Stop();
            RecordItem("stop"); ImGui.EndDisabled(); ImGui.SameLine();
            var waitStatus = macroExecutor.IsWaitingForJobChange ? "等待职业与套装同步" : $"等待 {macroExecutor.RemainingWait:F1}s";
            var label = $"{macroExecutor.CurrentMacroName} / {macroExecutor.CurrentChildName} · {macroExecutor.ExecutedLines}/{macroExecutor.TotalLines} 行 · {waitStatus}";
            ImGui.TextColored(SuccessColor, Fit(label, ImGui.GetContentRegionAvail().X));
            if (ImGui.IsItemHovered()) ImGui.SetTooltip(label);
        }
        else { ImGui.TextColored(SuccessColor, "就绪"); ImGui.SameLine(); ImGui.TextColored(MutedColor, "未执行宏"); }
    }
    private void DrawSettings()
    {
        ImGui.BeginChild("##SettingsScroll", Vector2.Zero, false);
        Heading("设置"); ImGui.TextColored(MutedColor, "执行与悬浮入口的全局设置"); ImGui.Spacing(); ImGui.Separator();
        DrawLineLimitSetting(); ImGui.Spacing(); DrawBetterWaitSetting(); ImGui.Spacing(); DrawFloatingLauncherSetting();
        ImGui.Spacing(); ImGui.Separator(); DrawQuickBarSettings();
        ImGui.Spacing(); ImGui.Separator(); Heading("配置管理");
        if (ImGui.Button("导入配置")) BeginImport(); RecordItem("settings-import");
        ImGui.SameLine(); if (ImGui.Button("导出配置")) ExportConfiguration(); RecordItem("settings-export");
        if (!string.IsNullOrEmpty(transferStatus)) ImGui.TextWrapped(transferStatus);
        ImGui.Spacing(); ImGui.TextWrapped("默认行间隔为 0；/wait 与等待标签按实际执行时刻等待。设置不会改写已保存的宏内容。");
        ImGui.EndChild();
    }
    private void BeginImport()
    {
        importText = ImGui.GetClipboardText() ?? string.Empty; transferStatus = string.Empty;
        confirmReplaceImport = false; openImportPopup = true;
    }
    private void DrawTransferMenu()
    {
        if (!ImGui.BeginPopup("##Transfer")) return;
        if (ImGui.MenuItem("导入配置")) BeginImport(); RecordItem("menu-import");
        if (ImGui.MenuItem("导出配置")) ExportConfiguration(); RecordItem("menu-export");
        ImGui.EndPopup();
    }
    private static void Heading(string text)
    {
        ImGui.SetWindowFontScale(1.5f); ImGui.TextUnformatted(Fit(text, ImGui.GetContentRegionAvail().X)); ImGui.SetWindowFontScale(1);
        if (ImGui.IsItemHovered()) ImGui.SetTooltip(text);
    }
    internal static string Fit(string text, float width)
    {
        if (width <= 0) return string.Empty;
        if (ImGui.CalcTextSize(text).X <= width) return text;
        var indices = StringInfo.ParseCombiningCharacters(text); var low = 0; var high = indices.Length;
        while (low < high) { var mid = (low + high + 1) / 2; var end = mid == indices.Length ? text.Length : indices[mid];
            if (ImGui.CalcTextSize(text[..end] + "…").X <= width) low = mid; else high = mid - 1; }
        return (low == 0 ? "" : text[..(low == indices.Length ? text.Length : indices[low])]) + "…";
    }
    private bool EntryRow(MacroEntry macro, string key, bool selected, float height, float width = -1)
    {
        if (width < 0) width = ImGui.GetContentRegionAvail().X;
        var clicked = ImGui.Selectable("##" + key, selected, ImGuiSelectableFlags.AllowDoubleClick, new Vector2(MathF.Max(1, width), height));
        RecordItem(key);
        if (key.StartsWith("tree-", StringComparison.Ordinal) && revealEntryId == macro.Id) { ImGui.SetScrollHereY(.3f); revealEntryId = null; }
        var p = ImGui.GetItemRectMin();
        DrawIcon(macro.IsGroup ? Icon.Group : Icon.File, p + new Vector2(S(3), (height - S(16)) / 2), S(16), ImGui.GetColorU32(MutedColor));
        ImGui.GetWindowDrawList().AddText(p + new Vector2(S(28), (height - ImGui.GetFontSize()) / 2), ImGui.GetColorU32(ImGuiCol.Text), Fit(macro.Name, width - S(30)));
        if (ImGui.IsItemHovered()) ImGui.SetTooltip(macro.Name);
        return clicked;
    }
    private enum Icon { File, Group, Star, Play }
    private static bool IconButton(string id, string tooltip, Icon icon, bool active = false)
    {
        var hit = ImGui.InvisibleButton(id, new Vector2(S(26), S(30)));
        var p = ImGui.GetItemRectMin(); var dl = ImGui.GetWindowDrawList();
        if (ImGui.IsItemHovered()) { dl.AddRectFilled(p, ImGui.GetItemRectMax(), ImGui.GetColorU32(ImGuiCol.ButtonHovered), S(4)); ImGui.SetTooltip(tooltip); }
        DrawIcon(icon, p + new Vector2(S(5), S(7)), S(16), ImGui.GetColorU32(active ? new Vector4(1, .78f, .32f, 1) : MutedColor), active);
        return hit;
    }
    private static void DrawIcon(Icon icon, Vector2 p, float size, uint color, bool filled = false)
    {
        var dl = ImGui.GetWindowDrawList(); var t = MathF.Max(1, S(1.4f));
        if (icon == Icon.Play) { dl.AddTriangleFilled(p, p + new Vector2(0, size), p + new Vector2(size * .86f, size / 2), color); return; }
        if (icon == Icon.Group)
        {
            for (var i = 0; i < 4; i++) { var q = p + new Vector2(i % 2 * size * .57f, i / 2 * size * .57f); dl.AddRect(q, q + new Vector2(size * .35f), color, S(1), ImDrawFlags.None, t); }
            return;
        }
        if (icon == Icon.File)
        {
            dl.AddRect(p, p + new Vector2(size * .75f, size), color, S(1), ImDrawFlags.None, t);
            for (var i = 0; i < 2; i++) dl.AddLine(p + new Vector2(size * .18f, size * (.45f + .22f * i)), p + new Vector2(size * .57f, size * (.45f + .22f * i)), color, t);
            return;
        }
        var center = p + new Vector2(size / 2);
        for (var i = 0; i < 10; i++)
        {
            Vector2 Point(int j) { var a = -MathF.PI / 2 + j * MathF.PI / 5; var r = size * (j % 2 == 0 ? .5f : .23f); return center + new Vector2(MathF.Cos(a), MathF.Sin(a)) * r; }
            var a = Point(i); var b = Point((i + 1) % 10);
            if (filled) dl.AddTriangleFilled(center, a, b, color); else dl.AddLine(a, b, color, t);
        }
    }
    private static bool DrawColoredButton(string label, Vector4 color, Vector4 hoveredColor, Vector2? size = null)
    {
        ImGui.PushStyleColor(ImGuiCol.Button, color); ImGui.PushStyleColor(ImGuiCol.ButtonHovered, hoveredColor); ImGui.PushStyleColor(ImGuiCol.ButtonActive, hoveredColor);
        var clicked = ImGui.Button(label, size ?? Vector2.Zero); ImGui.PopStyleColor(3); return clicked;
    }
    private static void PushUiTheme()
    {
        ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(.92f, .95f, .99f, 1));
        ImGui.PushStyleColor(ImGuiCol.TextDisabled, MutedColor);
        ImGui.PushStyleColor(ImGuiCol.ChildBg, new Vector4(.075f, .115f, .165f, 1));
        ImGui.PushStyleColor(ImGuiCol.Border, new Vector4(.20f, .29f, .38f, 1));
        ImGui.PushStyleColor(ImGuiCol.FrameBg, new Vector4(.055f, .085f, .125f, 1));
        ImGui.PushStyleColor(ImGuiCol.FrameBgHovered, new Vector4(.10f, .17f, .25f, 1));
        ImGui.PushStyleColor(ImGuiCol.FrameBgActive, new Vector4(.13f, .25f, .39f, 1));
        ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(.11f, .18f, .26f, 1));
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(.16f, .30f, .44f, 1));
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, AccentColor);
        ImGui.PushStyleColor(ImGuiCol.Header, new Vector4(.13f, .30f, .51f, 1));
        ImGui.PushStyleColor(ImGuiCol.HeaderHovered, new Vector4(.16f, .32f, .50f, 1));
        ImGui.PushStyleColor(ImGuiCol.HeaderActive, AccentColor);
        ImGui.PushStyleColor(ImGuiCol.CheckMark, new Vector4(.18f, .53f, .94f, 1));
        ImGui.PushStyleColor(ImGuiCol.Tab, new Vector4(.055f, .09f, .14f, 1));
        ImGui.PushStyleColor(ImGuiCol.TabHovered, new Vector4(.12f, .29f, .47f, 1));
        ImGui.PushStyleColor(ImGuiCol.TabActive, new Vector4(.14f, .39f, .64f, 1));
        ImGui.PushStyleColor(ImGuiCol.TableHeaderBg, new Vector4(.065f, .10f, .145f, 1));
    }
}
