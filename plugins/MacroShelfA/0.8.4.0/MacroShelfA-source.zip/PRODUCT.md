# Macro Shelf-A

<!-- impeccable:product-schema 1 -->

## Platform
Windows native DalamudCN API 15 plugin using C# / ImGui. Not a website or mobile app.

## Users and task
The user manages many FF14 standalone macros and named sequential child-macro groups. The approved change addresses finding macros and editing long macros without global settings cluttering the library.

## Constraints
Keep existing data model v8, import format 4, identifiers, saved text and order. Default line interval remains zero, explicit waits remain, one command per framework update. No timeline or audio synchronization features. Existing countdown, floating launcher, long-macro setting, CRUD and exchange remain accessible.

## Approved request
A library as main UI and B tree editor as editing UI. Native local build only, no GitHub release or automatic installation. Both plugin manifest introduction fields use the exact user text: 当我受够了FF14那糟糕的宏指令

## Evidence
design/approved-library.png and design/approved-editor.png are approved generated concepts; their sample names/counts are not user data. generation-prompts.json records their origin. Native test-host captures will be actual UI renders with synthetic test fixtures, not in-game verification.

## Historical 0.8 extension (icon superseded by 0.8.1)
User requests an icon based on their second supplied image and an independent common-macro shelf for explicit one-click execution with the main page closed. Preserve the A+B design system and existing executor. The quick bar reuses Pinned for roots and children, adds only local display preferences, and remains visible independently of the main page when logged in. User supplied image 1 shows the old launcher, not the requested character. Icon prompt and generated master are recorded in design/icon/provenance.json. Local-only scope continues; no installation or GitHub publication requested.

## Current 0.8.1 correction
User explicitly rejects regenerated artwork. Use the supplied blue-haired original IMG_8518(20260822-120523).PNG, preserve its original bytes in the source and launcher resource; only mechanically aspect-fit the catalog icon to the required512-square with transparent padding. No image generation, crop or repaint. Repair picker auto-size feedback and host double scaling, move exact hint 左键运行，右键编辑或删除 to the title row, remove idle footer space. Preserve underlying macros and execution behavior. User in-game evidence supersedes prior offline visual approval.


## 0.8.2.0 local follow-up — job-change consistency candidate

User confirmed gearset6=Astrologian: plugin actions work after manually switching, and after an explicit 3-second gearset wait; the original 0.2-second macro fails. Preserve zero default interval and previous approved UI/original image. Add a bounded read-only multi-source job/gearset consistency guard before the first following action, not a fixed global delay or action retry. This is a candidate requiring in-game 0.2-second validation: matching job/gearset observations do not prove native action-name-cache readiness. Full scope and rejected strategies are in verification/job-change-analysis.md; instructions/log markers are in README.md. No online publication or user config mutation.


## 0.8.3.0 current local investigation — native dispatch boundary

Latest user evidence: all emotes/actions after a gearset switch fail consistently while chat continues; native macros work. This supersedes treating the problem only as a first-action readiness delay. The managed guard does not cover emotes. Direct ExecuteCommandInner bypasses normal per-command error-state preparation and chat context cleanup; use ProcessChatBoxEntry without manually mutating shell state or adding waits. This discrepancy is established, but its sufficiency to explain all execution failure remains unproven. Production-linked offline ABI tests exercise the real binding against a fake unmanaged callback, not actual game code. Keep public0.8.2 unchanged, retain user text/data/UI/assets, add actual-loaded-version diagnostic, deliver only local0.8.3 candidate.
