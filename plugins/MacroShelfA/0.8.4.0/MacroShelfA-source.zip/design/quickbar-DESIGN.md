---
name: "Macro Shelf-A 常用宏栏"
description: "0.8.1.0 局部实现记录；继承 A+B 主界面，不覆盖根 DESIGN.md"
colors:
  primary: "rgb(11% 38% 72%)"
  checkmark: "rgb(18% 53% 94%)"
  surface: "rgb(7.5% 11.5% 16.5%)"
  border: "rgb(20% 29% 38%)"
  text: "rgb(92% 95% 99%)"
  text-muted: "rgb(66% 76% 86%)"
  button-secondary: "rgb(11% 18% 26%)"
  button-secondary-hover: "rgb(16% 30% 44%)"
  field: "rgb(5.5% 8.5% 12.5%)"
  selection: "rgb(13% 30% 51%)"
  selection-hover: "rgb(16% 32% 50%)"
  quickbar-stop: "rgb(60% 20% 25%)"
  quickbar-stop-hover: "rgb(68% 24% 28%)"
  quickbar-error: "rgb(100% 65% 67%)"
rounded:
  quickbar-window: "6px"
  quickbar-control: "4px"
spacing:
  window-padding: "10px"
  frame-x: "8px"
  frame-y: "6px"
  item-gap: "6px"
components:
  macro-button: {backgroundColor: "{colors.button-secondary}", textColor: "{colors.text}", rounded: "{rounded.quickbar-control}"}
  stop-button: {backgroundColor: "{colors.quickbar-stop}", textColor: "{colors.text}", rounded: "{rounded.quickbar-control}", width: "62px"}
---
# Design System: Macro Shelf-A 常用宏栏

## Overview
**Creative North Star: "深蓝原生资料柜"**
本文件只记录 0.8.1.0 常用栏与图标的实际实现，继承根 DESIGN.md 的 A+B 视觉语言，不重写主资料库或树编辑台。
**Key Characteristics:** 深蓝紧凑面板、完整中文提示、显式点击执行、持续可达的中止。
源码依据为 MacroShelfA/Windows/QuickBarWindow.cs 与 MacroShelfA/QuickBarModel.cs；修正约束见 design/quickbar-brief.md，因果证据见 verification/root-cause.md。
前置 token 对应源码归一化 RGB；px 为 GlobalScale=1 的 ImGui 基准单位。下文 S(n)=n×ImGuiHelpers.GlobalScale，不是 CSS 实现。

## Colors
Primary：普通按钮 active 使用 primary，复选标记使用 checkmark；没有新增品牌色系。
Neutral：surface / border / text / text-muted 延续主界面；普通按钮使用 button-secondary / button-secondary-hover，输入底色为 field，选择反馈为 selection / selection-hover。
状态：中止使用 quickbar-stop / quickbar-stop-hover，active 回到 quickbar-stop；失败文本使用 quickbar-error。未覆写的弹窗背景、输入 hover/active、焦点和禁用透明度由宿主决定。

## Typography
继承 Dalamud ImGui 当前字体、中文覆盖与字号；没有独立字体、字重或标题放大。
标题“常用宏 · 数量”和提示“左键运行，右键编辑或删除”按实际字体测量并完整绘制；窄栏仅将操作按钮移到下一行，不缩小或截断提示。
宏按钮、添加列表名称和运行/错误反馈按 MainWindow.Fit 测量截断并提供完整 tooltip；“组 · ”与“子 · ”辅助辨识。

## Layout
窗口无原生标题栏、缩放柄或外层滚动；仅 ShowQuickBar 且登录时显示，稳定标识 MacroShelfAQuickBar，首次位置 S(24,300)。
**The Single Scale Rule.** WindowHost 在 PreDraw 后将 Window.Size 乘 GlobalScale；因此 Size 存逻辑尺寸，实际测量宽高先除以 GlobalScale，SizeCondition 为 Always。
设 C 为请求列数、B 为目标按钮宽、T 为标题与提示实测总宽（含 S(12) 间隔）、A 为四个操作按钮实测总宽（含 S(18) 间隔）：首选宽=max(S(360),S(C×(B+6)+14),T+S(20))；C>1 时还取 max(T+A+S(32))，最终不超过工作区宽−S(16)。
内容宽=窗口宽−S(20)；不足 T+A+S(12) 时只有操作按钮换行。栏头高度为一行 frameHeight，或两行 frameHeight+S(6) 间隔；仅标题提示区域可拖移，原生左键拖动阈值 3，锁定后不移动；边缘留 S(8)。
列数设置 1–8、目标按钮宽 80–200；实际列数按可用宽、目标宽和 S(6) 间距计算并限定在请求范围，按钮均分余宽。滚动时先扣除真实 ScrollbarSize 再计算列数。
网格最多 4 个可见行，按钮高=max(S(38),frameHeight)，行间距 S(6)，Child 内局部滚动；空态高度由实际换行文字测量。
**The No Idle Footer Rule.** 空闲时无底部提示、分隔线或高度预留；最后一行后仅留 S(10)。仅运行或错误增加 S(7) 间隔与实际状态行；折叠后运行态仍可中止。

## Elevation & Depth
深浅面板、细边界及内容分隔建立层次；未新增阴影、玻璃、渐变或动画。网格上方仍有分隔线，只有空闲底部状态分隔被移除；弹窗层叠由宿主管理。

## Shapes
外壳使用 quickbar-window，控件使用 quickbar-control；窗口与控件内边距取前置 spacing，仅局部覆写，不改变主界面形状系统。

## Components
- **宏按钮：** 左键调用现有 MacroExecutor.TryStart；运行时执行按钮禁用但保留 tooltip。右键“编辑此宏”打开编辑台，“移出常用栏”仅取消 Pinned，不删除宏正文；独立宏、宏组和子宏均可收藏。
- **添加器外框：** 仅 IsPopupOpen 后设置 NextWindowSize；每帧 Always 固定为 min(S(430),工作区宽−S(24)) × min(S(340),工作区高−S(24))。显式 NoResize | NoScrollbar | NoScrollWithMouse 取代 BeginPopup 默认 AlwaysAutoResize，阻断父子尺寸反馈。
- **添加器列表与底部：** footerY=弹窗高−WindowPadding.Y−frameHeight；列表高=max(1,footerY−S(8)−listTop)。列表局部滚动，底部“完成 / 打开管理”固定；搜索名称、父组路径或分类，勾选即时保存且不执行。
- **管理、更多与空态：** 管理打开主窗口；更多提供锁定、列数、按钮宽度、隐藏。空栏指向添加或收藏，空资料库指向“打开管理”，无结果显示“没有匹配的宏。”；/aklmacro bar 恢复显示，/aklmacro stop 中止，隐藏本身不中止。
- **运行与错误：** 单行反馈前置“中止”，后接宏名、执行行数及等待；错误保留全文 tooltip。目标移出、名称/命令或长宏设置变化时清除陈旧错误。
- **原图与入口：** 唯一人物来源是用户蓝发原图 IMG_8518(20260822-120523).PNG（828×804）；design/icon/original.png 与 MacroShelfA/Resources/FloatingLauncher.png 字节一致，入口按原宽高比显示。SHA256：FAAE057F0A33F26B9FD3D7F51D414921EE6E31B0E251EDCC05C6289F35058F70。
- **列表图标：** icon.png 仅以 HighQualityBicubic 等比缩小并透明留边为 512×512，以满足本机 PluginImageCache 的 max512 / requireSquare；不裁切、不拉伸、不添加元素、不生成或重绘。加工来源与哈希见 design/icon/provenance.json；旧版金发生成头像不用于本版。

## Do's and Don'ts
- **Do** 保持本文件的局部边界；0.8.0 原件、根 DESIGN.md 和生产代码不因文档工作改写。
- **Do** 区分“移出常用栏 / 删除宏”“收起或隐藏 / 中止执行”，保留折叠运行态的中止入口。
- **Do** 以 verification/quickbar-720.png 与 quickbar-picker-scale150-min.png 核对实际原生 ImGui 测试宿主画面；verification/build-test.log 记录 132 项逻辑、91 项主界面、186 项常用栏断言通过，picker-stability.json 与测试记录覆盖第 1/30/120/600 帧及 10 次重开。
- **Don't** 把离线测试、真实宿主缩放顺序模拟或测试宿主截图称为游戏内验收；本版仅本地交付，未发布或安装。
- **Don't** 重新生成人物素材、伪造 Web 组件、合成色阶或新增 token；.impeccable/quickbar-design.json 只保存 schemaVersion 2 的最小扩展。
