# Approved A + B implementation

Mode: Operate. Approval: user explicitly selected A as main and B as editor in this turn. Build path: comp-led for this change only.

First viewport: three clearly separated regions, categories 18%, compact macro list about 50%, selected-macro inspector about 32%. Search stays at the top; global controls are removed into Settings. Main selection never executes. Group children appear only for the selected group in the inspector. Persistent bottom status and stop action are available from every page.

Editor: category/group/child tree at left, selected-macro content and command editor at right. Naming, classification, favorite, order, copy and delete remain functional without filling every library row with buttons. Use existing Pinned as favorite; sorting is a view, not a rewrite of stored execution order. Retain auto-save behavior, state it clearly. No invented queue, BPM, or timeline.

Dark navy/charcoal surfaces, restrained blue selection and primary actions, pale blue secondary text, native Chinese sans type, thin separators and small corner radii. Draw vector icons natively; no generated screenshot is used as the interactive UI. Major topology, density and hierarchy inherit the approved images; host title chrome/font rendering follow Dalamud. Use a clean multiline editor rather than pretend syntax coloring over an unsynchronized buffer.

Responsive matrix: 720x500, 940x760, 1200x900, 1536x1024, and scaled 1080x750. Independent panel scrolling; footer and execution actions stay reachable. Empty states, long names, 200 entries, 400-line CJK editing, import replacement and selection changes are tested.
