$ErrorActionPreference = 'Stop'
$version = '0.8.4.0'
$workspace = Split-Path $PSScriptRoot -Parent
$root = Join-Path $PSScriptRoot "MacroShelfA-$version"
$output = Join-Path $workspace 'outputs'
$delivery = Join-Path $output "MacroShelfA-$version"
$build = Join-Path $root 'MacroShelfA\bin\x64\Release'
$baseline = 'D:\codex\2026-09-20\d-codex\outputs\MacroShelfA-0.8.3.1-emote-diagnostic'
$evidencePath = Join-Path $root "verification\$version"
function Assert($condition, [string]$message) { if (-not $condition) { throw $message } }
function Hash([string]$path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
function JsonFile([string]$path, $value) {
    [IO.File]::WriteAllText($path, ($value | ConvertTo-Json -Depth 20) + "`n", [Text.UTF8Encoding]::new($false))
}
function StreamHash($stream) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)) }

$buildLog = Get-Content -LiteralPath (Join-Path $evidencePath 'build.log') -Raw
$testLog = Get-Content -LiteralPath (Join-Path $evidencePath 'tests-ui.log') -Raw
Assert ($buildLog -match '0 个警告' -and $buildLog -match '0 个错误') 'Build did not pass cleanly'
$logic = [regex]::Match($testLog, 'RESULT (\d+)/(\d+) checks passed')
$mainUi = [regex]::Match($testLog, 'native A\+B UI: (\d+) assertions')
$barUi = [regex]::Match($testLog, 'native quickbar UI: (\d+) assertions')
Assert ($logic.Success -and $logic.Groups[1].Value -eq $logic.Groups[2].Value) 'Missing successful logic result'
Assert ($mainUi.Success -and $barUi.Success) 'Missing successful UI results'
$manifest = Get-Content -LiteralPath (Join-Path $build 'MacroShelfA.json') -Raw | ConvertFrom-Json
Assert ($manifest.AssemblyVersion -eq $version -and $manifest.DalamudApiLevel -eq 15) 'Manifest version/API mismatch'
Assert ($manifest.Punchline -eq '当我受够了FF14那糟糕的宏指令' -and $manifest.Description -eq $manifest.Punchline) 'Product copy changed'
Assert ([Reflection.AssemblyName]::GetAssemblyName((Join-Path $build 'MacroShelfA.dll')).Version.ToString() -eq $version) 'Assembly version mismatch'

$originals = [ordered]@{
    'MacroShelfA-0.8.3.1-emote-diagnostic.zip' = 'F6004992D79E0B4171C93E176F7DFF0945E40891E280E724F39251A0E6450ECF'
    'MacroShelfA-0.8.3.1-emote-diagnostic-source.zip' = 'A6C4E43D4EFDD702CFCEE5FFBEF7593F7D0D8F250C83C67BD48D1B863D6AE0FE'
}
foreach ($pair in $originals.GetEnumerator()) {
    Assert ((Hash (Join-Path (Split-Path $baseline -Parent) $pair.Key)) -eq $pair.Value) "Original changed: $($pair.Key)"
}
$allowed = @('MacroShelfA.csproj', 'Plugin.cs', 'Runtime/JobChangeGuard.cs', 'Runtime/MacroExecutor.cs', 'Runtime/MacroSequence.cs', 'Windows/MainWindow.cs', 'Windows/QuickBarWindow.cs')
$changed = @()
$unchanged = @()
foreach ($file in Get-ChildItem -LiteralPath (Join-Path $baseline 'MacroShelfA') -File -Recurse) {
    $relative = [IO.Path]::GetRelativePath((Join-Path $baseline 'MacroShelfA'), $file.FullName).Replace('\', '/')
    if ($relative -match '^(bin|obj)/') { continue }
    $current = Join-Path $root "MacroShelfA/$relative"
    Assert (Test-Path -LiteralPath $current) "Missing source: $relative"
    if ((Hash $current) -ne (Hash $file.FullName)) {
        Assert ($relative -in $allowed) "Unexpected production change: $relative"
        $changed += $relative
    } else { $unchanged += $relative }
}
Assert ($changed.Count -eq $allowed.Count) 'Expected production delta not complete'
$iconHash = 'DF9BFB68EDBA8CAB5D1D4D4C47C14F478E8E304430E749772624C7A5F41CE2AB'
$originalImageHash = 'FAAE057F0A33F26B9FD3D7F51D414921EE6E31B0E251EDCC05C6289F35058F70'
Assert ((Hash (Join-Path $build 'icon.png')) -eq $iconHash) 'Catalog image changed'
Assert ((Hash (Join-Path $root 'MacroShelfA/Resources/FloatingLauncher.png')) -eq $originalImageHash) 'Original image changed'
$evidence = [ordered]@{
    version = $version; channel = 'local-candidate'; checkedAtUtc = [DateTime]::UtcNow.ToString('o')
    build = @{ configuration = 'Release'; warnings = 0; errors = 0; dalamudApiLevel = 15 }
    tests = @{ logicPassed = [int]$logic.Groups[1].Value; mainUiAssertions = [int]$mainUi.Groups[1].Value; quickbarUiAssertions = [int]$barUi.Groups[1].Value; nativeCalls = 'offline unmanaged callbacks'; ui = 'native ImGui offline host' }
    behavior = @{ barrier = 'all subsequent rows after recognized numeric gearset change'; maximumBlockedSeconds = 10; defaultExtraIntervalSeconds = 0; fixedSettlingDelayAdded = $false; actionRetries = $false; waitStartsAtActualRowExecution = $true; diagnosticsDefaultEnabled = $false }
    limitations = @('Named/relative/unresolved gearsets and other change aliases are not resolved.', 'Matching job and gearset observations do not prove animation or action readiness.', 'Game acceptance is still required.')
    changedProductionFiles = $changed; unchangedProductionFiles = $unchanged
    configVersion = 8; exportFormat = 4; iconSha256 = $iconHash; originalImageSha256 = $originalImageHash
    preservedPackages = $originals
    published = $false; installed = $false; hotReloaded = $false; liveConfigModified = $false; inGameVerified = $false; userAcceptancePassed = $false
}
JsonFile (Join-Path $evidencePath 'verification.json') $evidence
Assert (-not (Test-Path -LiteralPath $delivery)) 'Refusing to replace an existing delivery'
& robocopy $root $delivery /E /XD bin obj .git plugin verification .vs .impeccable /NFL /NDL /NJH /NJS
Assert ($LASTEXITCODE -le 7) 'Source staging failed'
$deliveredEvidence = Join-Path $delivery "verification\$version"
New-Item -ItemType Directory -Path $deliveredEvidence -Force | Out-Null
Copy-Item -LiteralPath $evidencePath -Destination (Join-Path $delivery 'verification') -Recurse -Force
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $deliveredEvidence 'package.ps1')

$pluginZip = Join-Path $output "MacroShelfA-$version.zip"
$sourceZip = Join-Path $output "MacroShelfA-$version-source.zip"
Assert (-not (Test-Path -LiteralPath $pluginZip) -and -not (Test-Path -LiteralPath $sourceZip)) 'Refusing to replace delivered archives'
Copy-Item -LiteralPath (Join-Path $build 'MacroShelfA\latest.zip') -Destination $pluginZip
$archive = [IO.Compression.ZipFile]::OpenRead($pluginZip)
try {
    $names = @($archive.Entries.FullName | Sort-Object)
    Assert ($null -eq (Compare-Object $names @('MacroShelfA.deps.json', 'MacroShelfA.dll', 'MacroShelfA.json', 'icon.png'))) 'Unexpected plugin archive contents'
    foreach ($entry in $archive.Entries) {
        $stream = $entry.Open()
        try { Assert ((StreamHash $stream) -eq (Hash (Join-Path $build $entry.FullName))) "Archive/build mismatch: $($entry.FullName)" }
        finally { $stream.Dispose() }
    }
} finally { $archive.Dispose() }
[IO.Compression.ZipFile]::CreateFromDirectory($delivery, $sourceZip, [IO.Compression.CompressionLevel]::Optimal, $false)
[IO.Compression.ZipFile]::ExtractToDirectory($pluginZip, (Join-Path $delivery 'plugin'))

$artifacts = @()
foreach ($path in @($pluginZip, $sourceZip)) {
    $archive = [IO.Compression.ZipFile]::OpenRead($path)
    try {
        foreach ($entry in $archive.Entries) {
            $stream = $entry.Open()
            try {
                $actualHash = StreamHash $stream
                if ($path -eq $sourceZip) {
                    Assert ((Hash (Join-Path $delivery $entry.FullName)) -eq $actualHash) "Source archive mismatch: $($entry.FullName)"
                }
            } finally { $stream.Dispose() }
        }
        $artifacts += @{ file = [IO.Path]::GetFileName($path); bytes = (Get-Item -LiteralPath $path).Length; sha256 = Hash $path; entries = $archive.Entries.Count; decompressionVerified = $true }
    } finally { $archive.Dispose() }
}
$receipt = [ordered]@{ version = $version; evidence = $evidence; artifacts = $artifacts; dllSha256 = Hash (Join-Path $build 'MacroShelfA.dll'); sourceArchiveMatchesStagedFiles = $true; pluginArchiveMatchesBuild = $true }
JsonFile (Join-Path $output "MacroShelfA-$version-verification.json") $receipt
$sumLines = @($artifacts | ForEach-Object { "$($_.sha256)  $($_.file)" })
$sumLines += "$($receipt.dllSha256)  MacroShelfA-$version/plugin/MacroShelfA.dll"
[IO.File]::WriteAllText((Join-Path $output "MacroShelfA-$version-SHA256SUMS.txt"), ($sumLines -join "`n") + "`n", [Text.Encoding]::ASCII)
$receipt | ConvertTo-Json -Depth 20
