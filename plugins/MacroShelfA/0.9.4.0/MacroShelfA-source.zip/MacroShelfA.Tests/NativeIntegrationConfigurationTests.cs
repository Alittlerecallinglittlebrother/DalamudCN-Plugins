using System.Text.Json;
using MacroShelfA;

internal static class NativeIntegrationConfigurationTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool condition, string reason = "native integration configuration regression") => check(condition, reason);
        MacroEntry Decorated(string name) => new()
        {
            Name = name, Commands = "/echo 原文\n\n/echo end <wait.0.5>", Pinned = true,
            IconId = 66001, DisplayActionId = 7561, ShowSkillCooldown = false, ShowSkillCharges = false,
            NativeSourceSet = 1, NativeSourceIndex = 99,
        };
        test("ABD v8 migration keeps IDs/text/order/pins and defaults display off", () =>
        {
            var c = JsonSerializer.Deserialize<Configuration>("""{"Version":8,"Macros":[{"Id":"old-root","Name":"旧组","IsGroup":true,"Pinned":true,"Children":[{"Id":"old-child","Name":"旧子宏","Commands":"/echo 原文 <wait.0.5>"}]}]}""")!;
            c.Normalize(); var r = c.Macros[0]; var child = r.Children[0];
            Check(c.Version == 9 && r.Id == "old-root" && child.Id == "old-child" && r.Pinned);
            Check(child.Commands == "/echo 原文 <wait.0.5>" && child.DisplayActionId == 0 && child.IconId == 0);
            Check(child.NativeSourceSet == -1 && child.NativeSourceIndex == -1 && child.ShowSkillCooldown && child.ShowSkillCharges);
        });
        test("ABD copy clones metadata but generates root and child IDs", () =>
        {
            var r = Decorated("组"); r.IsGroup = true; r.Children = [Decorated("子宏")];
            var copy = r.Copy();
            Check(copy.Id != r.Id && copy.Children[0].Id != r.Children[0].Id);
            Check(copy.IconId == 66001 && copy.DisplayActionId == 7561 && !copy.ShowSkillCooldown && !copy.ShowSkillCharges);
            Check(copy.Children[0].NativeSourceIndex == 99 && copy.Children[0].NativeSourceSet == 1);
            copy.Children[0].Commands = "/echo changed"; Check(r.Children[0].Commands.Contains("原文"));
        });
        test("ABD persistence keeps same IDs and new presentation fields", () =>
        {
            var r = Decorated("持久化"); var c = new Configuration { Macros = [r] }; c.Save();
            var loaded = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!; loaded.Normalize();
            var d = loaded.Macros[0]; Check(d.Id == r.Id && d.Commands == r.Commands && d.IconId == r.IconId);
            Check(d.DisplayActionId == r.DisplayActionId && !d.ShowSkillCooldown && !d.ShowSkillCharges && d.NativeSourceIndex == 99);
        });
        test("ABD exchange v5 round trip carries fields but does not preserve entrance IDs", () =>
        {
            var r = Decorated("交换"); r.IsGroup = true; r.Children = [Decorated("子")];
            var json = ConfigurationExchange.Export(new Configuration { Macros = [r] });
            Check(json.Contains("\"Version\": 5") && !json.Contains(r.Id));
            Check(ConfigurationExchange.TryImport(json, out var d, out var e), e);
            var copy = d.Macros[0]; Check(copy.Id != r.Id && copy.Children[0].Id != r.Children[0].Id);
            Check(copy.DisplayActionId == r.DisplayActionId && copy.IconId == r.IconId && !copy.ShowSkillCharges && !copy.ShowSkillCooldown);
            Check(copy.Children[0].Commands == r.Children[0].Commands && copy.NativeSourceSet == 1);
        });
        test("ABD old exchange formats remain supported and ignore newly spoofed fields", () =>
        {
            for (var version = 1; version <= 4; version++)
            {
                var json = $$"""{"Format":"MacroShelfA","Version":{{version}},"Macros":[{"Name":"旧宏","Commands":"/echo old","IconId":66001,"DisplayActionId":7561,"NativeSourceSet":0,"NativeSourceIndex":1,"ShowSkillCooldown":false}]}""";
                Check(ConfigurationExchange.TryImport(json, out var d, out var e), e);
                Check(d.Macros[0].DisplayActionId == 0 && d.Macros[0].IconId == 0 && d.Macros[0].NativeSourceSet == -1 && d.Macros[0].ShowSkillCooldown);
            }
        });
        test("ABD malformed provenance clears together without altering正文", () =>
        {
            foreach (var pair in new[] { (-1, 0), (0, -1), (2, 10), (0, 100), (1, int.MaxValue) })
            {
                var r = Decorated("无效来源"); r.NativeSourceSet = pair.Item1; r.NativeSourceIndex = pair.Item2;
                var text = r.Commands; new Configuration { Macros = [r] }.Normalize();
                Check(r.NativeSourceSet == -1 && r.NativeSourceIndex == -1 && r.Commands == text);
            }
        });
        test("ABD exact ID lookup finds roots and individual children without name fallback", () =>
        {
            var r = Decorated("相同名称"); r.IsGroup = true; r.Children = [Decorated("相同名称")];
            var c = new Configuration { Macros = [r] };
            Check(c.FindEntryById(r.Id) == r && c.FindEntryById(r.Children[0].Id) == r.Children[0]);
            Check(c.FindEntryById("相同名称") == null && c.FindEntryById("deleted-id") == null && c.FindEntryById(" ") == null);
            c.Macros.Add(new MacroEntry { Id = r.Id, Commands = "/echo duplicate" }); Check(c.FindEntryById(r.Id) == null);
        });
        test("ABD pre-v9 backup is immutable and does not alter in-memory data", () =>
        {
            var directory = Path.Combine(AppContext.BaseDirectory, "native-integration-backup-fixture", Guid.NewGuid().ToString("N"));
            var c = new Configuration { Version = 8, Macros = [Decorated("升级前")] };
            ConfigurationBackup.BeforeNativeIntegrationMigration(c, directory);
            var file = Path.Combine(directory, "config-before-native-integration-v9.json"); var before = File.ReadAllBytes(file);
            Check(c.Version == 8 && c.Macros[0].Name == "升级前");
            c.Macros[0].Name = "升级后"; ConfigurationBackup.BeforeNativeIntegrationMigration(c, directory);
            Check(File.ReadAllBytes(file).SequenceEqual(before));
            c.Version = 9; ConfigurationBackup.BeforeNativeIntegrationMigration(c, directory);
            Check(File.ReadAllBytes(file).SequenceEqual(before));
        });
    }
}
