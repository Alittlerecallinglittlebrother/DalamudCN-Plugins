using System.Runtime.InteropServices;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;
using MacroShelfA.Runtime;

// Real production raw-string and icon adapters, generated bindings redirected
// ONLY to offline unmanaged callbacks. No instance lookup or game allocator runs.
internal static unsafe class NativeMacroBridgeAbiTests
{
    private static int ctorCalls, copyCalls, dtorCalls, iconCalls;
    private static nuint observedLength;

    [UnmanagedCallersOnly]
    private static Utf8String* Construct(Utf8String* value, byte* raw, nuint length)
    {
        ctorCalls++; observedLength = length;
        value->StringPtr = (byte*)NativeMemory.AllocZeroed(length + 1);
        new ReadOnlySpan<byte>(raw, (int)length).CopyTo(new Span<byte>(value->StringPtr.Value, (int)length));
        value->BufUsed = value->BufSize = (long)length + 1;
        value->StringLength = (long)length;
        return value;
    }
    [UnmanagedCallersOnly]
    private static void Copy(Utf8String* destination, Utf8String* source)
    {
        copyCalls++;
        NativeMemory.Free(destination->StringPtr.Value);
        destination->StringPtr = (byte*)NativeMemory.AllocZeroed((nuint)source->BufUsed);
        source->AsSpan().CopyTo(new Span<byte>(destination->StringPtr.Value, source->Length));
        destination->BufUsed = destination->BufSize = source->BufUsed;
        destination->StringLength = source->StringLength;
    }
    [UnmanagedCallersOnly]
    private static void Destruct(Utf8String* value)
    { dtorCalls++; NativeMemory.Free(value->StringPtr.Value); value->StringPtr = (byte*)null; }
    [UnmanagedCallersOnly]
    private static void SetIcon(RaptureMacroModule.Macro* value, uint icon)
    { iconCalls++; value->IconId = icon; value->MacroIconRowId = 765; }

    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "native bridge ABI assertion failed") => check(value, message);
        test("bridge native ABI exact-length Copy preserves payload zero and invalid UTF8", () =>
        {
            var oldCtor = Utf8String.Addresses.Ctor_FromSequence.Value;
            var oldCopy = Utf8String.Addresses.Copy.Value;
            var oldDtor = Utf8String.Addresses.Dtor.Value;
            var value = default(Utf8String);
            ctorCalls = copyCalls = dtorCalls = 0;
            try
            {
                Utf8String.Addresses.Ctor_FromSequence.Value = (nint)(delegate* unmanaged<Utf8String*, byte*, nuint, Utf8String*>)&Construct;
                Utf8String.Addresses.Copy.Value = (nint)(delegate* unmanaged<Utf8String*, Utf8String*, void>)&Copy;
                Utf8String.Addresses.Dtor.Value = (nint)(delegate* unmanaged<Utf8String*, void>)&Destruct;
                var raw = new byte[] { 0x02, 0xff, 0, 0x13, 0x03 };
                NativeMacroBridgeHost.SetRaw(ref value, raw);
                Check(NativeMacroBridgeHost.ReadRaw(in value).SequenceEqual(raw) && observedLength == 5);
                Check(ctorCalls == 1 && copyCalls == 1 && dtorCalls == 1, "temporary native string must be destroyed once");
                NativeMacroBridgeHost.SetRaw(ref value, []);
                Check(NativeMacroBridgeHost.ReadRaw(in value).Length == 0 && value.BufUsed == 1);
                Check(ctorCalls == 2 && copyCalls == 2 && dtorCalls == 2);
                value.BufUsed = 0;
                try { NativeMacroBridgeHost.ReadRaw(in value); throw new Exception("invalid shape accepted"); }
                catch (InvalidOperationException) { }
            }
            finally
            {
                NativeMemory.Free(value.StringPtr.Value);
                Utf8String.Addresses.Ctor_FromSequence.Value = oldCtor;
                Utf8String.Addresses.Copy.Value = oldCopy;
                Utf8String.Addresses.Dtor.Value = oldDtor;
            }
            Check(Utf8String.Addresses.Ctor_FromSequence.Value == oldCtor && Utf8String.Addresses.Copy.Value == oldCopy && Utf8String.Addresses.Dtor.Value == oldDtor);
        });
        test("bridge native ABI icon normalization uses scratch macro and native row", () =>
        {
            var original = RaptureMacroModule.Macro.Addresses.SetIcon.Value;
            iconCalls = 0;
            try
            {
                RaptureMacroModule.Macro.Addresses.SetIcon.Value = (nint)(delegate* unmanaged<RaptureMacroModule.Macro*, uint, void>)&SetIcon;
                var host = new NativeMacroBridgeHost();
                Check(host.TryResolveIcon(66001, out var icon, out var row, out _) && icon == 66001 && row == 765 && iconCalls == 1);
                RaptureMacroModule.Macro.Addresses.SetIcon.Value = 0;
                Check(!host.TryResolveIcon(66001, out _, out _, out _) && iconCalls == 1);
            }
            finally { RaptureMacroModule.Macro.Addresses.SetIcon.Value = original; }
        });
    }
}
