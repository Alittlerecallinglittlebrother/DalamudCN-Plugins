using MacroShelfA;
using MacroShelfA.Runtime;
using System.Text;

internal static class NativeMacroBridgeTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "native macro bridge assertion failed") => check(value, message);
        MacroEntry Leaf(string id = "old") => new() { Id = id, Name = "开场", Commands = "/echo unchanged" };
        NativeMacroContent Content(string name, string firstLine, uint icon = 42, uint row = 17)
        {
            var lines = Enumerable.Range(0, 15).Select(_ => Array.Empty<byte>()).ToArray();
            lines[0] = Encoding.UTF8.GetBytes(firstLine);
            return new NativeMacroContent(Encoding.UTF8.GetBytes(name), lines, icon, row);
        }

        test("bridge parser accepts saved legacy token and rejects command injection", () =>
        {
            Check(MacroRunCommand.TryParse(" run old ", out var id, out _) && id == "old");
            Check(MacroRunCommand.TryParse("RUN a-b_123", out _, out _));
            foreach (var invalid in new[] { "run", "run x y", "run x\n/echo injection", "run x<wait.1>", "run \"x\"", "run /echo", "run x;echo", "run x\0", "run " + new string('a', 129) })
                Check(!MacroRunCommand.TryParse(invalid, out _, out _), invalid);
            Check(MacroRunCommand.IsRunCommand("run") && MacroRunCommand.IsRunCommand("RUN old") && !MacroRunCommand.IsRunCommand("running"));
        });
        test("bridge ID route resolves roots groups and children but never names", () =>
        {
            var child = Leaf("child"); var group = new MacroEntry { Id = "group", IsGroup = true, Children = [child] };
            var root = Leaf(); root.Name = "child";
            MacroEntry? received = null;
            bool Start(MacroEntry entry, out string error) { received = entry; error = ""; return true; }
            Check(MacroRunCommand.TryRun("run child", new[] { group, root }, Start, out _) && received == child);
            Check(MacroRunCommand.TryRun("run group", new[] { group, root }, Start, out _) && received == group);
            Check(MacroRunCommand.TryRun("run old", new[] { group, root }, Start, out _) && received == root);
            Check(!MacroRunCommand.TryRun("run missing", new[] { group, root }, Start, out var error) && error.Contains("不存在"));
            child.Id = "old";
            Check(!MacroRunCommand.TryRun("run old", new[] { group, root }, Start, out error) && error.Contains("不唯一"));
        });
        test("bridge route delegates login busy and preflight to same executor callback", () =>
        {
            var calls = 0;
            bool Start(MacroEntry entry, out string error) { calls++; error = "正在运行"; return false; }
            Check(!MacroRunCommand.TryRun("run old", new[] { Leaf() }, Start, out var error) && error == "正在运行" && calls == 1);
            Check(!MacroRunCommand.TryRun("run missing", new[] { Leaf() }, Start, out _) && calls == 1);
        });
        test("bridge content defensively copies raw fifteen-line payloads and fingerprints icons", () =>
        {
            var name = new byte[] { 0x02, 0x13, 0xff, 0x03 };
            var lines = Enumerable.Range(0, 15).Select(index => new byte[] { 0x02, (byte)index, 0x00, 0xff, 0x03 }).ToArray();
            var raw = new NativeMacroContent(name, lines, 8, 9); var fingerprint = raw.Fingerprint;
            name[0] = 88; lines[0][0] = 88; raw.RawName[0] = 77; raw.RawLines[0][0] = 77;
            Check(raw.RawName[0] == 0x02 && raw.RawLines[0][0] == 0x02 && raw.Fingerprint == fingerprint);
            Check(!raw.SameAs(new NativeMacroContent(raw.RawName, raw.RawLines, 8, 10)));
        });
        test("bridge generation writes one line only and leaves full long body unchanged", () =>
        {
            var host = new Host(); var store = new Store(); var service = new NativeMacroBridgeService(host, store);
            var leaf = Leaf(); leaf.Commands = string.Join('\n', Enumerable.Repeat("/echo full", 45)); var before = leaf.Commands;
            Check(service.TryPreview(0, 0, out var preview, out _));
            Check(service.TryGenerate(preview!, leaf, new[] { leaf }, false, out _));
            Check(host.Current.LineCount == 1 && host.Current.RawLines[0].SequenceEqual(Encoding.UTF8.GetBytes("/aklmacro run old")));
            Check(host.Current.RawLines.Skip(1).All(value => value.Length == 0) && leaf.Commands == before);
            Check(host.Current.IconId == 66001 && host.Current.MacroIconRowId == 501 && store.Saved.Count == 1);
        });
        test("occupied bridge slot requires explicit confirmation and backup before write", () =>
        {
            var host = new Host { Current = Content("existing", "/echo keep") }; var store = new Store();
            host.BeforeWrite = () => Check(store.Saved.Count == 1 && store.Saved[0].Original.SameAs(Content("existing", "/echo keep")));
            var service = new NativeMacroBridgeService(host, store); var leaf = Leaf(); service.TryPreview(0, 0, out var preview, out _);
            Check(!service.TryGenerate(preview!, leaf, new[] { leaf }, false, out _) && host.Writes == 0 && store.Saved.Count == 0);
            Check(service.TryGenerate(preview!, leaf, new[] { leaf }, true, out _) && host.Writes == 1);
            Check(host.Current.IconId == 42 && host.Current.MacroIconRowId == 17);
        });
        test("bridge failed durable backup never changes a game slot", () =>
        {
            var host = new Host(); var store = new Store { Fail = true }; var service = new NativeMacroBridgeService(host, store);
            service.TryPreview(0, 0, out var preview, out _); var leaf = Leaf();
            Check(!service.TryGenerate(preview!, leaf, new[] { leaf }, false, out var error) && error.Contains("未修改") && host.Writes == 0);
        });
        test("bridge changed character or preview refuses before backing up", () =>
        {
            var host = new Host(); var store = new Store(); var service = new NativeMacroBridgeService(host, store); var leaf = Leaf();
            service.TryPreview(0, 0, out var preview, out _); host.ContentId++;
            Check(!service.TryGenerate(preview!, leaf, new[] { leaf }, false, out _) && store.Saved.Count == 0);
            host.ContentId--; host.Current = Content("foreign", "/echo new");
            Check(!service.TryGenerate(preview!, leaf, new[] { leaf }, false, out _) && store.Saved.Count == 0 && host.Writes == 0);
        });
        test("bridge slot mutation during durable save is rejected by final compare", () =>
        {
            var host = new Host(); var store = new Store(); store.OnSave = () => host.Current = Content("changed", "/echo new");
            var service = new NativeMacroBridgeService(host, store); var leaf = Leaf(); service.TryPreview(0, 0, out var preview, out _);
            Check(!service.TryGenerate(preview!, leaf, new[] { leaf }, false, out _) && host.Writes == 0 && store.Saved.Count == 1);
            Check(host.Current.DisplayName == "changed");
        });
        test("bridge rejects removed replaced ambiguous and unsafe entry IDs", () =>
        {
            var host = new Host(); var store = new Store(); var service = new NativeMacroBridgeService(host, store); var leaf = Leaf();
            service.TryPreview(0, 0, out var preview, out _);
            Check(!service.TryGenerate(preview!, leaf, Array.Empty<MacroEntry>(), false, out _));
            Check(!service.TryGenerate(preview!, leaf, new[] { Leaf() }, false, out _));
            Check(!service.TryGenerate(preview!, leaf, new[] { leaf, Leaf() }, false, out _));
            leaf.Id = "bad\n/echo injected"; Check(!service.TryGenerate(preview!, leaf, new[] { leaf }, false, out _));
            Check(store.Saved.Count == 0 && host.Writes == 0);
        });
        test("bridge restore preserves all original bytes and creates independent undo backup", () =>
        {
            var rawLines = Enumerable.Range(0, 15).Select(index => new byte[] { 0x02, (byte)index, 0xff, 0x03 }).ToArray();
            var original = new NativeMacroContent(new byte[] { 0x02, 0xff, 0x03 }, rawLines, 1234, 4321);
            var host = new Host { Current = original }; var store = new Store(); var service = new NativeMacroBridgeService(host, store); var leaf = Leaf();
            service.TryPreview(0, 0, out var preview, out _); Check(service.TryGenerate(preview!, leaf, new[] { leaf }, true, out _));
            var backup = store.Saved.Single(); service.TryPreview(0, 0, out preview, out _);
            Check(service.TryRestore(preview!, backup, false, out _) && host.Current.SameAs(original));
            Check(store.Saved.Count == 2 && store.Saved[1].Operation == "restore" && store.Saved[1].Original.SameAs(backup.Replacement));
            Check(host.Current.RawLines.Zip(rawLines).All(pair => pair.First.SequenceEqual(pair.Second)));
        });
        test("bridge restore refuses foreign identity slot and silently changed content", () =>
        {
            var host = new Host(); var store = new Store(); var service = new NativeMacroBridgeService(host, store); var leaf = Leaf();
            service.TryPreview(0, 0, out var preview, out _); Check(service.TryGenerate(preview!, leaf, new[] { leaf }, false, out _)); var backup = store.Saved[0];
            host.Current = Content("foreign", "/echo foreign"); service.TryPreview(0, 0, out preview, out _);
            Check(!service.TryRestore(preview!, backup, false, out _) && store.Saved.Count == 1);
            Check(!service.TryRestore(preview! with { ContentId = 999 }, backup, true, out _));
            Check(!service.TryRestore(preview! with { Slot = 1 }, backup, true, out _));
            Check(service.TryRestore(preview!, backup, true, out _) && host.Current.IsEmpty && store.Saved.Count == 2);
        });
        test("bridge empty-slot selection and bounds do not mutate native data", () =>
        {
            var host = new Host { EmptySlot = 7 }; var service = new NativeMacroBridgeService(host, new Store());
            Check(service.TryFindEmpty(1, out var preview, out _) && preview!.Slot == 7 && preview.Set == 1);
            Check(!service.TryPreview(-1, 0, out _, out _) && !service.TryPreview(0, 100, out _, out _));
            host.Available = false; Check(!service.TryFindEmpty(0, out _, out _) && host.Writes == 0);
        });
        test("bridge durable backup files are immutable scoped validated and raw-byte exact", () =>
        {
            var directory = Path.Combine(AppContext.BaseDirectory, "bridge-backup-fixture", Guid.NewGuid().ToString("N"));
            var store = new NativeMacroBridgeBackups(directory); var original = Content("中文名", "/echo 中文");
            var backup = new NativeMacroBackup(Guid.NewGuid().ToString("N"), DateTime.UtcNow, 123, 1, 99,
                "old", "generate", original, NativeMacroContent.Bridge("入口", "old", 66001, 987));
            store.SaveNew(backup); var bytes = File.ReadAllBytes(Directory.GetFiles(Path.Combine(directory, "native-macro-backups")).Single());
            try { store.SaveNew(backup with { Original = Content("changed", "/echo changed") }); throw new Exception("backup unexpectedly overwritten"); }
            catch (IOException) { }
            var list = store.List(123, 1, 99); Check(list.Count == 1 && list[0].Original.SameAs(original));
            Check(store.List(456, 1, 99).Count == 0 && store.List(123, 0, 99).Count == 0);
            var file = Directory.GetFiles(Path.Combine(directory, "native-macro-backups")).Single(); Check(File.ReadAllBytes(file).SequenceEqual(bytes));
            // Only a fresh offline fixture is modified; malformed data is never a restore option.
            File.WriteAllText(file, "{}"); Check(store.List(123, 1, 99).Count == 0);
        });
    }

    private sealed class Host : INativeMacroBridgeHost
    {
        public ulong ContentId = 123;
        public NativeMacroContent Current = NativeMacroContent.Empty();
        public bool Available = true;
        public int Writes, EmptySlot;
        public Action? BeforeWrite;
        public bool TryResolveIcon(uint requested, out uint icon, out uint row, out string error)
        { icon = requested; row = 501; error = ""; return true; }
        public bool TryPreview(int set, int slot, out NativeMacroPreview? preview, out string error)
        {
            preview = null; error = "host unavailable";
            if (!Available) return false;
            var content = slot < EmptySlot ? NativeMacroContent.Bridge("occupied", "old", 1, 2) : Current;
            preview = new NativeMacroPreview(ContentId, set, slot, content); error = ""; return true;
        }
        public bool TryWrite(NativeMacroPreview expected, NativeMacroContent replacement, out string error)
        {
            error = "changed during backup";
            if (!Available || expected.ContentId != ContentId || !expected.Content.SameAs(Current)) return false;
            BeforeWrite?.Invoke(); Current = replacement; Writes++; error = ""; return true;
        }
    }
    private sealed class Store : INativeMacroBackupStore
    {
        public bool Fail;
        public Action? OnSave;
        public List<NativeMacroBackup> Saved = [];
        public void SaveNew(NativeMacroBackup backup)
        { if (Fail) throw new IOException("fixture disk failure"); Saved.Add(backup); OnSave?.Invoke(); }
        public IReadOnlyList<NativeMacroBackup> List(ulong contentId, int set, int slot)
            => Saved.Where(value => value.ContentId == contentId && value.Set == set && value.Slot == slot).ToArray();
    }
}
