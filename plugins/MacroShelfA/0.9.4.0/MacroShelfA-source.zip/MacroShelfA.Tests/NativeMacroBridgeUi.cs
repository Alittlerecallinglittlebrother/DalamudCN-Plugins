using System.Numerics;
using System.Text;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

internal static unsafe class NativeMacroBridgeUi
{
    private static int width = 700, height = 840, checks;
    private static float? nextScroll;
    private static void Check(bool value, string message) { if (!value) throw new Exception(message); checks++; }
    public static void Run(string output)
    {
        Directory.CreateDirectory(output);
        using var library = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory, "cimgui.dll"));
        ImGui.InitApi(library); var context = ImGui.CreateContext();
        try
        {
            var io = ImGui.GetIO(); io.IniFilename = null; io.DeltaTime = 1f / 60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 17, default, io.Fonts.GetGlyphRangesChineseFull());
            Check(io.Fonts.Build(), "bridge UI font atlas failed"); ImGui.StyleColorsDark();
            var config = new Configuration { AllowLongMacros = true };
            var entry = new MacroEntry { Id = "bridge-ui-fixture", Name = "舞台开场 · 45 行宏组", IsGroup = true,
                Children = Enumerable.Range(0, 3).Select(index => new MacroEntry { Name = $"宏{index + 1}", Commands = string.Join('\n', Enumerable.Repeat("/echo 仅离线示例", 15)) }).ToList() };
            config.Macros.Add(entry);
            var before = entry.Children.Select(child => child.Commands).ToArray();
            var host = new Host(); var backups = new Store(); var service = new NativeMacroBridgeService(host, backups);
            var scheduled = 0;
            Task Scheduler(Action action) { scheduled++; action(); return Task.CompletedTask; }
            using var window = new NativeMacroBridgeWindow(config, service, Scheduler);
            Check(host.Reads == 0 && host.Writes == 0 && scheduled == 0, "constructing bridge window touched native boundary");
            window.OpenFor(entry); Frame(window);
            foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})
            {config.Theme=theme;Capture(window,output,$"theme-aux-bridge-{theme}.png",700,840);Check(host.Writes==0,"theme preview wrote a native macro");}
            config.Theme=ShelfTheme.Persona3;
            Check(window.TestPreview?.Content.IsEmpty == true && host.Reads == 1 && host.Writes == 0, "opening did not preview first empty slot");
            Capture(window, output, "bridge-offline-empty.png", 700, 840);
            Click(window, "generate");
            Check(host.Writes == 1 && backups.Saved.Count == 1 && host.Slots[0].LineCount == 1, "UI did not generate single-line bridge with backup");
            Check(host.Slots[0].DisplayCommands.StartsWith("/aklmacro run bridge-ui-fixture") && entry.Children.Select(child => child.Commands).SequenceEqual(before), "bridge UI modified full macro body");
            Capture(window, output, "bridge-offline-generated.png", 700, 840);

            var originalLines = Enumerable.Range(0, 15).Select(index => Encoding.UTF8.GetBytes(index == 0 ? "/echo 原槽位保留内容" : $"/echo 原第{index + 1}行")).ToArray();
            var original = new NativeMacroContent(Encoding.UTF8.GetBytes("原生宏 · 原始备份测试"), originalLines, 66002, 23);
            host.Slots[0] = original; Click(window, "read");
            Check(window.TestPreview?.Content.SameAs(original) == true && window.UiItems.ContainsKey("overwriteconfirm"), "occupied preview did not require overwrite checkbox");
            Click(window, "generate"); Check(host.Writes == 1 && backups.Saved.Count == 1, "disabled generation overwrote occupied slot");
            Capture(window, output, "bridge-offline-occupied.png", 700, 840);
            Click(window, "overwriteconfirm"); Click(window, "generate");
            Check(host.Writes == 2 && backups.Saved.Count == 2 && backups.Saved[^1].Original.SameAs(original), "confirmed overwrite missed complete backup");
            var restoreBackup = backups.Saved[^1];
            Click(window, "backupselect"); Click(window, "backup-" + restoreBackup.Id);
            Capture(window, output, "bridge-offline-restore-ready.png", 700, 840);
            Click(window, "restore");
            Check(host.Writes == 3 && backups.Saved.Count == 3 && host.Slots[0].SameAs(original), "UI raw backup restoration failed");
            Capture(window, output, "bridge-offline-restored.png", 700, 840);

            host.ContentId = 456;
            Click(window, "read");
            Check(window.TestBackups.Count == 0, "backup picker leaked previous character backups");
            var oldPreview = window.TestPreview!; host.ContentId = 789;
            Click(window, "overwriteconfirm"); Click(window, "generate");
            Check(host.Writes == 3 && window.TestMessage.Contains("角色"), "stale-character UI preview allowed write");
            Capture(window, output, "bridge-offline-identity-error.png", 700, 840);
            Capture(window, output, "bridge-offline-narrow.png", 520, 560);
            nextScroll = 10000; Frame(window); Frame(window);
            Capture(window, output, "bridge-offline-narrow-footer.png", 520, 560);
            ImGuiHelpers.GlobalScale = 1.5f; io.FontGlobalScale = 1.5f; nextScroll = 0;
            Capture(window, output, "bridge-offline-scale150.png", 1050, 1050);
            nextScroll = 10000; Frame(window); Frame(window);
            Capture(window, output, "bridge-offline-scale150-footer.png", 1050, 1050);
            File.WriteAllText(Path.Combine(output, "bridge-offline-ui-note.txt"),
                "截图由实际生产 ImGui 窗口在离线宿主中渲染；槽位／图标／备份为独立内存夹具，不是游戏内截图。未读取游戏进程，未写游戏宏／热键栏或实际插件配置。\n");
            Console.WriteLine($"PASS native macro bridge offline UI: {checks} assertions; preview, empty/occupied, explicit overwrite, one-line generation, backup picker, raw restore, character scope, stale identity and scaled/narrow screenshots; no game-native calls or live config writes.");
        }
        catch { SoftwareRenderer.Save(Path.Combine(output, "bridge-offline-ui-failure.png")); throw; }
        finally { ImGuiHelpers.GlobalScale = 1; ImGui.DestroyContext(context); }
    }

    private static void Frame(NativeMacroBridgeWindow window)
    {
        var io = ImGui.GetIO(); io.DisplaySize = new Vector2(width, height); io.DeltaTime = 1f / 60;
        window.UiItems.Clear(); ImGui.NewFrame();window.PreDraw();
        ImGui.SetNextWindowPos(Vector2.Zero, ImGuiCond.Always); ImGui.SetNextWindowSize(new Vector2(width, height), ImGuiCond.Always);
        ImGui.Begin("D 入口宏 · 离线宿主（非游戏截图）###BridgeTestHost", ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoCollapse);
        if (nextScroll.HasValue) { ImGui.SetScrollY(nextScroll.Value); nextScroll = null; }
        window.Draw(); ImGui.End();window.PostDraw(); ImGui.Render();
    }
    private static void Capture(NativeMacroBridgeWindow window, string output, string file, int w, int h)
    { width = w; height = h; ImGui.GetIO().AddMousePosEvent(-100, -100); Frame(window); Frame(window); SoftwareRenderer.Save(Path.Combine(output, file)); }
    private static void Click(NativeMacroBridgeWindow window, string key)
    {
        Frame(window);
        if (!window.UiItems.TryGetValue(key, out var rect)) throw new Exception("bridge UI control unavailable: " + key);
        var point = (rect.Min + rect.Max) / 2;
        Check(point.X >= 0 && point.X < width && point.Y >= 0 && point.Y < height, "bridge UI control outside viewport: " + key);
        var io = ImGui.GetIO(); io.AddMousePosEvent(point.X, point.Y); Frame(window);
        io.AddMouseButtonEvent(0, true); Frame(window); io.AddMouseButtonEvent(0, false); Frame(window); Frame(window);
    }

    internal sealed class Host : INativeMacroBridgeHost
    {
        public int Reads, Writes;
        public ulong ContentId = 123;
        public Dictionary<int, NativeMacroContent> Slots { get; } = [];
        public bool TryResolveIcon(uint desired, out uint icon, out uint row, out string error)
        { icon = desired; row = 42; error = ""; return true; }
        public bool TryPreview(int set, int slot, out NativeMacroPreview? preview, out string error)
        { Reads++; preview = new NativeMacroPreview(ContentId, set, slot, Slots.GetValueOrDefault(set * 100 + slot, NativeMacroContent.Empty())); error = ""; return true; }
        public bool TryWrite(NativeMacroPreview expected, NativeMacroContent replacement, out string error)
        {
            error = "角色或槽位变化";
            if (ContentId != expected.ContentId || !Slots.GetValueOrDefault(expected.Set * 100 + expected.Slot, NativeMacroContent.Empty()).SameAs(expected.Content)) return false;
            Writes++; Slots[expected.Set * 100 + expected.Slot] = replacement; error = ""; return true;
        }
    }
    internal sealed class Store : INativeMacroBackupStore
    {
        public List<NativeMacroBackup> Saved { get; } = [];
        public void SaveNew(NativeMacroBackup backup) => Saved.Add(backup);
        public IReadOnlyList<NativeMacroBackup> List(ulong contentId, int set, int slot)
            => Saved.Where(value => value.ContentId == contentId && value.Set == set && value.Slot == slot).OrderByDescending(value => value.CreatedUtc).ToArray();
    }
}

namespace MacroShelfA.Windows
{
    internal sealed partial class NativeMacroBridgeWindow
    {
        internal readonly Dictionary<string, (Vector2 Min, Vector2 Max)> UiItems = [];
        internal NativeMacroPreview? TestPreview => state.Preview;
        internal IReadOnlyList<NativeMacroBackup> TestBackups => state.Backups;
        internal string TestMessage => state.Message;
        partial void RecordItem(string key)
        { if (ImGui.IsItemVisible()) UiItems[key] = (ImGui.GetItemRectMin(), ImGui.GetItemRectMax()); }
    }
}
