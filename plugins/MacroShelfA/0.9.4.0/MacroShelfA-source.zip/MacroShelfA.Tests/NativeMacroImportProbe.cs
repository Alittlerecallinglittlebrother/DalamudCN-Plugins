using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

internal sealed partial class NativeMacroImportWindow
{
    internal readonly Dictionary<string, (Vector2 Min, Vector2 Max)> UiItems = [];
    partial void RecordItem(string key)
    {
        if (ImGui.IsItemVisible()) UiItems[key] = (ImGui.GetItemRectMin(), ImGui.GetItemRectMax());
    }
    internal int TestSelectedCount => selected.Count;
    internal NativeMacroReadSnapshot TestSnapshot => snapshot;
    internal string TestStatus => status;
    internal string TestCategory => category;
    internal void TestPump() => PumpRequests();
    internal void TestImport() => StartImport();
    internal void TestSelect(string key) => selected.Add(key);
    internal void TestRefresh() => Refresh();
}
