using System.Text;
using MacroShelfA;
using MacroShelfA.Runtime;
using FFXIVClientStructs.FFXIV.Client.System.String;

internal static unsafe class NativeMacroImportTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string error = "native macro import assertion failed") => check(value, error);
        static NativeMacroSnapshotEntry Entry(int index = 0, string name = "中文测试宏", string body = "/echo 原始内容")
            => new(0, index, name, body, 66123);
        static NativeMacroIdentity Identity(ulong id = 123, uint entity = 7) => new(true, id, entity);

        test("native import strict UTF8 preserves multilingual text and literal spaces", () =>
        {
            var expected = "/echo 中文 日本語 Français 👋  <wait.0.5>";
            Check(NativeMacroImportModel.TryDecodePlainText(Encoding.UTF8.GetBytes(expected), out var text, out var error));
            Check(text == expected && error == "");
        });
        test("native import copies bounded installed Utf8String buffers without native calls", () =>
        {
            var data = Encoding.UTF8.GetBytes("/echo 中文\0");
            fixed (byte* pointer = data)
            {
                var value = default(Utf8String);
                value.StringPtr = pointer; value.BufSize = data.Length; value.BufUsed = data.Length;
                Check(NativeMacroReader.TryCopyBytes(in value, out var bytes, out _) &&
                    bytes.SequenceEqual(data[..^1]));
                // Deliberately alter the managed fixture bounds; no client signatures are invoked.
                value.BufUsed = 0; Check(!NativeMacroReader.TryCopyBytes(in value, out _, out _));
                value.BufUsed = data.Length + 1; Check(!NativeMacroReader.TryCopyBytes(in value, out _, out _));
                value.BufUsed = NativeMacroImportModel.MaximumStringBytes + 2;
                value.BufSize = value.BufUsed; Check(!NativeMacroReader.TryCopyBytes(in value, out _, out _));
                value.BufUsed = data.Length; value.BufSize = data.Length; value.StringPtr = (byte*)0;
                Check(!NativeMacroReader.TryCopyBytes(in value, out _, out _));
                value.StringPtr = pointer; data[^1] = 1;
                Check(!NativeMacroReader.TryCopyBytes(in value, out _, out var error) && error.Contains("结束符"));
            }
        });
        test("native import refuses invalid UTF8 instead of replacement characters", () =>
        {
            foreach (var data in new byte[][] { [0xC3, 0x28], [0xF0, 0x9F], [0xED, 0xA0, 0x80], [0xFF] })
            {
                Check(!NativeMacroImportModel.TryDecodePlainText(data, out var text, out var error));
                Check(text == "" && error.Contains("UTF-8"));
            }
        });
        test("native import blocks SeString payload names and lines atomically", () =>
        {
            var payload = new byte[] { (byte)'/', (byte)'e', 0x02, 0x2E, 0x02, 0x03 };
            var invalid = NativeMacroImportModel.DecodeEntry(0, 1, 0, Encoding.UTF8.GetBytes("自动翻译宏"),
                [Encoding.UTF8.GetBytes("/echo ordinary"), payload]);
            Check(!invalid.CanImport && invalid.Commands == "" && invalid.Error.Contains("第 2 行") && invalid.Error.Contains("SeString"));
            var name = NativeMacroImportModel.DecodeEntry(0, 2, 0, payload, [Encoding.UTF8.GetBytes("/echo test")]);
            Check(!name.CanImport && name.Error.StartsWith("名称"));
            var c = new Configuration();
            Check(!NativeMacroImportModel.TryImportCopies(c, [Entry(), invalid], "分类", c.Save, out var imported, out _));
            Check(imported == 0 && c.Macros.Count == 0);
        });
        test("native import blank internal lines preserved and unused trailing slots removed", () =>
        {
            var entry = NativeMacroImportModel.DecodeEntry(1, 99, 500,
                Encoding.UTF8.GetBytes("行顺序"), [Encoding.UTF8.GetBytes("  /echo first  "), [],
                    Encoding.UTF8.GetBytes("/wait 0.5"), [], [], []]);
            Check(entry.Commands == "  /echo first  \n\n/wait 0.5" && entry.LineCount == 3 && entry.CanImport);
            var leading = NativeMacroImportModel.DecodeEntry(0, 0, 0, [], [[], Encoding.UTF8.GetBytes("/echo later")]);
            Check(leading.Commands == "\n/echo later");
        });
        test("native import empty slots and title-only drafts distinguished", () =>
        {
            var empty = NativeMacroImportModel.DecodeEntry(0, 0, 66123, [], [[], []]);
            Check(empty.IsEmpty && !empty.CanImport);
            var draft = NativeMacroImportModel.DecodeEntry(0, 1, 66123, Encoding.UTF8.GetBytes("未完成草稿"), [[], []]);
            Check(draft.CanImport && draft.Commands == "" && draft.LineCount == 0);
            Check(NativeMacroImportModel.TryCreateCopies(new(), [draft], "", out var copies, out _));
            Check(copies.Count == 1 && copies[0].Name == "未完成草稿");
        });
        test("native import checks set index line count controls and byte limits", () =>
        {
            Check(NativeMacroImportModel.DecodeEntry(2, 0, 0, [], []).Error.Length > 0);
            Check(NativeMacroImportModel.DecodeEntry(0, 100, 0, [], []).Error.Length > 0);
            Check(NativeMacroImportModel.DecodeEntry(0, 0, 0, [], Enumerable.Repeat(Array.Empty<byte>(), 16).ToArray()).Error.Length > 0);
            foreach (var value in new byte[] { 0, 0x01, 0x0A, 0x0D, 0x7F })
                Check(!NativeMacroImportModel.TryDecodePlainText([value], out _, out _));
            Check(!NativeMacroImportModel.TryDecodePlainText(Encoding.UTF8.GetBytes("\u0085"), out _, out _));
            Check(!NativeMacroImportModel.TryDecodePlainText(new byte[NativeMacroImportModel.MaximumStringBytes + 1], out _, out _));
        });
        test("native import counts child capacity and admits exact 200 boundary", () =>
        {
            var c = new Configuration { Macros = [new() { Name = "总宏", IsGroup = true,
                Children = Enumerable.Range(0, 64).Select(i => new MacroEntry { Name = $"子宏{i}" }).ToList() }] };
            c.Macros.AddRange(Enumerable.Range(0, 133).Select(i => new MacroEntry { Name = $"现有{i}" }));
            Check(c.CountEntries() == 198);
            var before = c.Macros.Count;
            Check(!NativeMacroImportModel.TryCreateCopies(c, [Entry(0), Entry(1), Entry(2)], "分类", out var bad, out var error));
            Check(bad.Count == 0 && error.Contains("剩余 2") && c.Macros.Count == before);
            Check(NativeMacroImportModel.TryImportCopies(c, [Entry(0), Entry(1)], "分类", c.Save, out var count, out _));
            Check(count == 2 && c.CountEntries() == 200);
        });
        test("native import creates independent unique IDs icon source and never autopins", () =>
        {
            var original = new MacroEntry { Id = "keep-id", Name = "中文测试宏", Commands = "/echo unchanged", Pinned = true };
            var c = new Configuration { Macros = [original] };
            Check(NativeMacroImportModel.TryImportCopies(c, [Entry(), Entry(1)], "  新分类  ", c.Save, out var count, out _));
            Check(count == 2 && c.Macros[0] == original && original.Id == "keep-id" && original.Commands == "/echo unchanged" && original.Pinned);
            Check(c.Macros.Select(m => m.Id).Distinct().Count() == 3);
            Check(c.Macros[1].Name == "中文测试宏（导入 2）" && c.Macros[2].Name == "中文测试宏（导入 3）");
            foreach (var entry in c.Macros.Skip(1))
                Check(!entry.Pinned && !entry.IsGroup && entry.Children.Count == 0 && entry.IconId == 66123 &&
                    entry.NativeSourceSet == 0 && entry.Group == "新分类" && entry.DisplayActionId == 0);
            c.Macros[1].Commands = "edited";
            Check(c.Macros[2].Commands == "/echo 原始内容" && original.Commands == "/echo unchanged");
        });
        test("native import duplicate-name suffix fits 32 UTF16 chars and includes children", () =>
        {
            var title = new string('长', 25) + "👋";
            var c = new Configuration { Macros = [new() { Name = "宏组", IsGroup = true,
                Children = [new() { Name = title }] }] };
            Check(NativeMacroImportModel.TryCreateCopies(c, [Entry(name: title), Entry(1, title)], "", out var copies, out _));
            Check(copies.All(m => m.Name.Length <= 32 && !m.Name.Contains("\uD83D（", StringComparison.Ordinal)));
            Check(copies[0].Name != title && copies[0].Name != copies[1].Name);
            Check(c.Macros[0].Children[0].Name == title);
        });
        test("native import detects duplicate slots invalid sources and oversized metadata without partial writes", () =>
        {
            var c = new Configuration();
            foreach (var batch in new NativeMacroSnapshotEntry[][]
            {
                [Entry(), Entry()], [Entry() with { Set = -1 }], [Entry() with { Index = 100 }],
                [Entry(name: new string('长', 33))], [Entry(body: string.Join('\n', Enumerable.Repeat("/echo x", 16)))],
                [Entry(body: "/echo x\rhidden")],
            })
                Check(!NativeMacroImportModel.TryCreateCopies(c, batch, "", out _, out _));
            Check(!NativeMacroImportModel.TryCreateCopies(c, [Entry()], new string('类', 25), out _, out _));
            Check(!NativeMacroImportModel.TryCreateCopies(c, [Entry()], "分类\t名称", out _, out _));
            Check(c.CountEntries() == 0);
        });
        test("native import missing title uses stable slot fallback and save failure rolls back batch", () =>
        {
            var original = new List<MacroEntry> { new() { Name = "原有", Commands = "/echo keep" } };
            var c = new Configuration { Macros = original };
            Check(!NativeMacroImportModel.TryImportCopies(c, [Entry(name: "")], "",
                () => throw new IOException("simulated disk failure"), out var imported, out var error));
            Check(imported == 0 && ReferenceEquals(c.Macros, original) && c.CountEntries() == 1 && error.Contains("回退"));
            Check(NativeMacroImportModel.TryCreateCopies(c, [Entry(name: "")], "", out var copies, out _));
            Check(copies[0].Name == "个人宏 00");
            Check(NativeMacroImportModel.TryCreateCopies(c, [new(1, 99, "", "/echo end", 0)], "", out var last, out _));
            Check(last[0].Name == "共通宏 99");
        });
        test("native import fresh validation refuses logout character entity and source changes", () =>
        {
            var e = Entry(); var original = new NativeMacroReadSnapshot(Identity(), [e]);
            Check(NativeMacroImportModel.ValidateFreshSelection(original, new(Identity(), [e]), [e], out _));
            foreach (var fresh in new NativeMacroReadSnapshot[]
            {
                NativeMacroReadSnapshot.Unavailable("logged out"), new(Identity(456), [e]),
                new(Identity(entity: 99), [e]), new(Identity(), [e with { Commands = "/echo changed" }]),
                new(Identity(), [e with { IconId = 1 }]), new(Identity(), []), new(Identity(), [e, e]),
            }) Check(!NativeMacroImportModel.ValidateFreshSelection(original, fresh, [e], out var error) && error.Length > 0);
            Check(!Identity().Matches(new(true, 0, 7)));
        });
    }
}
