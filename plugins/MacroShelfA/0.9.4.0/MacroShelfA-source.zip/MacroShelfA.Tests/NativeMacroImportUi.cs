using System.Numerics;
using System.Text.Json;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Windows;

internal static unsafe class NativeMacroImportUi
{
    private static int width = 940, height = 660, checks;
    private static void Check(bool value, string error) { if (!value) throw new Exception(error); checks++; }
    internal sealed class FakeReader : INativeMacroReader
    {
        public NativeMacroReadSnapshot Snapshot = Fixture();
        public Task<NativeMacroReadSnapshot>? Pending;
        public int ReadCalls;
        public Task<NativeMacroReadSnapshot> ReadAsync() { ReadCalls++; return Pending ?? Task.FromResult(Snapshot); }
        public Task<NativeMacroIdentity> ReadIdentityAsync() => Task.FromResult(Snapshot.Identity);
    }
    private static NativeMacroReadSnapshot Fixture()
    {
        var list = new List<NativeMacroSnapshotEntry>();
        for (var set = 0; set < 2; set++)
            for (var index = 0; index < 100; index++)
                list.Add(index == 98 ? new(set, index, "", "", 0) : index == 2
                    ? new(set, index, "自动翻译测试", "", 66123, "第 2 行：含自动翻译或其他 SeString 载荷，当前纯文本执行器不能无损导入。")
                    : new(set, index, index == 0 ? "开场招呼" : $"{(set == 0 ? "个人" : "共通")}宏 {index:00} 很长的中文名称用于列表裁切",
                        "/echo 第一行\n\n/wait 0.5\n/echo 最后一行", 66123));
        return new(new(true, 123, 7), list);
    }

    public static void Run(string output)
    {
        Directory.CreateDirectory(output); checks = 0;
        using var native = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory, "cimgui.dll"));
        ImGui.InitApi(native); var context = ImGui.CreateContext();
        try
        {
            var io = ImGui.GetIO(); io.IniFilename = null; io.DeltaTime = 1f / 60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 17, default, io.Fonts.GetGlyphRangesChineseFull());
            io.Fonts.Build(); ImGui.StyleColorsDark();
            var c = new Configuration(); var calls = 0; var reader = new FakeReader();
            using var window = new NativeMacroImportWindow(c, () => calls++, reader);
            Check(reader.ReadCalls == 0, "reader touched host in constructor");
            window.Open(); Frame(window);
            foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})
            {c.Theme=theme;Capture(window,output,$"theme-aux-import-{theme}.png",940,660);Check(c.Macros.Count==0,"theme preview imported macro data");}
            c.Theme=ShelfTheme.Persona3;
            Check(window.TestSnapshot.Entries.Count == 200 && window.TestSnapshot.Available, "did not read both100-slot sets");
            Click(window, "native-preview-0:0"); Click(window, "native-select-0:0");
            Check(window.TestSelectedCount == 1 && c.CountEntries() == 0, "preview/selection modified library");
            var cjkCategory = new string('类', Configuration.MaxGroupLength);
            Type(window, "native-category", cjkCategory);
            Check(window.TestCategory == cjkCategory, "24-character CJK category was truncated as UTF8bytes");
            Type(window, "native-category", "演出常用");
            Click(window, "native-tab-1"); Click(window, "native-select-1:0");
            Check(window.TestSelectedCount == 2, "cross-tab selection lost");
            Type(window, "native-search", "不存在的搜索结果");
            Check(window.TestSelectedCount == 2, "search cleared selected entries");
            Capture(window, output, "native-import-no-results-720.png", 720, 500);
            Type(window, "native-search", ""); Click(window, "native-tab-0");
            foreach (var scale in new[] { 1f, 1.5f })
            {
                ImGuiHelpers.GlobalScale = scale; io.FontGlobalScale = scale;
                Capture(window, output, scale == 1 ? "native-import-720.png" : "native-import-scale150-720.png", 720, 500);
                Check(window.UiItems.ContainsKey("native-import") && window.UiItems["native-import"].Max.Y < height,
                    "import control clipped at720x500/scaled");
                Capture(window, output, scale == 1 ? "native-import-940.png" : "native-import-scale150.png",
                    scale == 1 ? 940 : 1080, scale == 1 ? 660 : 750);
            }
            ImGuiHelpers.GlobalScale = 1; io.FontGlobalScale = 1; width = 940; height = 660; Frame(window);
            Click(window, "native-import");
            Check(c.CountEntries() == 2 && calls == 1 && c.Macros.All(m => m.Group == "演出常用" && !m.Pinned), "batch import did not save/invalidate");
            Check(c.Macros.Select(m => m.Name).Distinct().Count() == 2 && c.Macros[0].Commands.Contains("\n\n"), "same-name/blank-line behavior wrong");
            Capture(window, output, "native-import-success.png", 940, 660);
            Click(window, "native-preview-0:2"); Click(window, "native-select-0:2");
            Check(window.TestSelectedCount == 0, "unsupported payload entry was selectable");
            Capture(window, output, "native-import-payload-blocked.png", 940, 660);
            Click(window, "native-select-0:0");
            reader.Snapshot = reader.Snapshot with { Entries = reader.Snapshot.Entries.Select(e => e.Key == "0:0"
                ? e with { Commands = "/echo source changed" } : e).ToArray() };
            Click(window, "native-import");
            Check(c.CountEntries() == 2 && window.TestStatus.Contains("修改") && window.TestSelectedCount == 0, "stale source imported");
            Capture(window, output, "native-import-source-changed.png", 940, 660);
            window.TestRefresh(); Frame(window); Click(window, "native-select-0:0");
            reader.Snapshot = reader.Snapshot with { Identity = new(true, 456, 99) };
            Click(window, "native-import");
            Check(c.CountEntries() == 2 && !window.TestSnapshot.Available && window.TestSelectedCount == 0,
                "different character was imported");
            Capture(window, output, "native-import-character-changed.png", 720, 500);
            reader.Snapshot = Fixture(); window.TestRefresh(); Frame(window);
            window.TestSelect("0:0"); var pending = new TaskCompletionSource<NativeMacroReadSnapshot>();
            reader.Pending = pending.Task; window.TestImport(); window.OnClose(); pending.SetResult(reader.Snapshot);
            window.TestPump(); Check(c.CountEntries() == 2, "closed window committed pending import");
            reader.Pending = null; reader.Snapshot = NativeMacroReadSnapshot.Unavailable("请登录角色后刷新。");
            window.Open(); Frame(window);
            Capture(window, output, "native-import-logged-out.png", 720, 500);
            Check(!window.TestSnapshot.Available && window.TestSelectedCount == 0, "logged-out window kept character data");
            reader.Snapshot = Fixture();
            var geometry = new List<object>();
            for (var i = 0; i < 10; i++)
            {
                window.Open(); Frame(window); var rect = window.UiItems["native-import"];
                Check(rect.Max.Y < 500 && rect.Min.X >= 0, "reopen resize drifted footer");
                geometry.Add(new { cycle = i, importY = rect.Min.Y }); window.OnClose();
            }
            File.WriteAllText(Path.Combine(output, "native-import-ui-geometry.json"), JsonSerializer.Serialize(geometry,
                new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine($"PASS feature A native import UI: {checks} assertions; managed fake reader only; 200 slots, tabs, preview, search, selected copies, save, payload refusal, source/character changes, pending-close cancellation and 720x500/150% layouts");
        }
        catch { SoftwareRenderer.Save(Path.Combine(output, "native-import-ui-failure.png")); throw; }
        finally { ImGuiHelpers.GlobalScale = 1; ImGui.DestroyContext(context); }
    }

    private static void Capture(NativeMacroImportWindow window, string output, string name, int w, int h)
    {
        width = w; height = h; ImGui.GetIO().AddMousePosEvent(-100, -100); Frame(window); Frame(window);
        SoftwareRenderer.Save(Path.Combine(output, name));
    }
    private static void Frame(NativeMacroImportWindow window)
    {
        var io = ImGui.GetIO(); io.DisplaySize = new Vector2(width, height); io.DeltaTime = 1f / 60;
        window.UiItems.Clear(); ImGui.NewFrame();window.PreDraw(); ImGui.SetNextWindowPos(Vector2.Zero, ImGuiCond.Always);
        ImGui.SetNextWindowSize(new Vector2(width, height), ImGuiCond.Always);
        ImGui.Begin("从游戏宏导入###NativeImportTestHost", ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove |
            ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);
        window.Draw(); ImGui.End();window.PostDraw(); ImGui.Render();
        Check(ImGui.GetDrawData().TotalVtxCount > 100, "empty native import render");
    }
    private static void Click(NativeMacroImportWindow window, string key)
    {
        Frame(window);
        if (!window.UiItems.TryGetValue(key, out var rect)) throw new Exception("native import control unavailable: " + key);
        var point = (rect.Min + rect.Max) / 2;
        Check(point.X >= 0 && point.X < width && point.Y >= 0 && point.Y < height, "native import control outside viewport: " + key);
        var io = ImGui.GetIO(); io.AddMousePosEvent(point.X, point.Y); Frame(window);
        io.AddMouseButtonEvent(0, true); Frame(window); io.AddMouseButtonEvent(0, false); Frame(window); Frame(window);
    }
    private static void Type(NativeMacroImportWindow window, string key, string value)
    {
        Click(window, key); var io = ImGui.GetIO(); io.AddKeyEvent(ImGuiKey.ModCtrl, true); io.AddKeyEvent(ImGuiKey.A, true); Frame(window);
        io.AddKeyEvent(ImGuiKey.A, false); io.AddKeyEvent(ImGuiKey.ModCtrl, false); Frame(window);
        if (value.Length == 0) { io.AddKeyEvent(ImGuiKey.Backspace, true); Frame(window); io.AddKeyEvent(ImGuiKey.Backspace, false); }
        else foreach (var character in value) io.AddInputCharacter(character);
        Frame(window); Frame(window);
    }
}
