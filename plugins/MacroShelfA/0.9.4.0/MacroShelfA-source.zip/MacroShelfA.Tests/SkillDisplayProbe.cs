using System.Numerics;
using Dalamud.Bindings.ImGui;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class MacroDisplayWindow
{
    internal readonly Dictionary<string, (Vector2 Min, Vector2 Max)> SkillUiItems = [];
    internal uint TestDisplaySelection => selectedId;
    internal string TestDisplaySearch => search;
    partial void RecordItem(string key)
    {
        if (ImGui.IsItemVisible()) SkillUiItems[key] = (ImGui.GetItemRectMin(), ImGui.GetItemRectMax());
    }
}

internal sealed partial class QuickBarWindow
{
    internal readonly Dictionary<string, SkillDisplaySnapshot> TestSkillSnapshots = [];
    partial void RecordSkillState(string id, SkillDisplaySnapshot snapshot) => TestSkillSnapshots[id] = snapshot;
}
