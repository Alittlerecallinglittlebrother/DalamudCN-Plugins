using MacroShelfA.Runtime;

internal static class SkillDisplayTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool result, string message = "skill display assertion failed") => check(result, message);
        SkillDisplaySample Sample(uint charges = 1, int maximum = 1, uint status = 0, uint conditions = 0,
            bool active = false, float elapsed = 0, float total = 0, float extraElapsed = 0, float extraTotal = 0) =>
            new(true, 7561, status, conditions, charges, maximum, active, elapsed, total, extraElapsed, extraTotal, 123);
        var availableContext = new SkillDisplayContext(true, 10, 20, 24, 100);
        test("skill display logout transition and either loading-area flag prohibit native reads", () =>
        {
            Check(SkillDisplayLifecycle.CanRead(true, false, false, false));
            Check(!SkillDisplayLifecycle.CanRead(false, false, false, false));
            Check(!SkillDisplayLifecycle.CanRead(true, true, false, false));
            Check(!SkillDisplayLifecycle.CanRead(true, false, true, false));
            Check(!SkillDisplayLifecycle.CanRead(true, false, false, true));
        });
        test("skill display unavailable native or invalid adjusted ID remains unknown", () =>
        {
            Check(SkillDisplaySnapshot.Interpret(default).Availability == SkillAvailability.Unknown);
            Check(SkillDisplaySnapshot.Interpret(Sample() with { Available = false }).Availability == SkillAvailability.Unknown);
            Check(SkillDisplaySnapshot.Interpret(Sample() with { AdjustedActionId = 0 }).Availability == SkillAvailability.Unknown);
        });
        test("skill display rejects invalid timers and impossible charge counts", () =>
        {
            Check(SkillDisplaySnapshot.Interpret(Sample(total: float.NaN)).Availability == SkillAvailability.Unknown);
            Check(SkillDisplaySnapshot.Interpret(Sample(elapsed: -1)).Availability == SkillAvailability.Unknown);
            Check(SkillDisplaySnapshot.Interpret(Sample(elapsed: 11, total: 10)).Availability == SkillAvailability.Unknown);
            Check(SkillDisplaySnapshot.Interpret(Sample(extraTotal: float.PositiveInfinity)).Availability == SkillAvailability.Unknown);
            Check(SkillDisplaySnapshot.Interpret(Sample(maximum: 0)).Availability == SkillAvailability.Unknown);
            Check(SkillDisplaySnapshot.Interpret(Sample(charges: 3, maximum: 2)).Availability == SkillAvailability.Unknown);
        });
        test("skill display one available charge never gray merely because second recharges", () =>
        {
            var state = SkillDisplaySnapshot.Interpret(Sample(charges: 1, maximum: 2, active: true, elapsed: 45, total: 60));
            Check(state.Availability == SkillAvailability.Ready && state.Charges == 1 && state.MaxCharges == 2 && state.Remaining == 15);
            Check(state.Label(true, true).Contains("1/2") && state.Label(true, true).Contains("15.0s"));
        });
        test("skill display depleted charge shows time until next charge not full refill", () =>
        {
            var state = SkillDisplaySnapshot.Interpret(Sample(charges: 0, maximum: 2, status: 999, active: true, elapsed: 5, total: 60));
            Check(state.Availability == SkillAvailability.Cooldown && state.Remaining == 25 && state.Status == 999);
        });
        test("skill display additional cooldown still limits available charge", () =>
        {
            var state = SkillDisplaySnapshot.Interpret(Sample(charges: 1, maximum: 2, status: 44, active: true,
                elapsed: 45, total: 60, extraElapsed: 1, extraTotal: 2.5f));
            Check(state.Availability == SkillAvailability.Cooldown && state.Remaining == 1.5f);
        });
        test("skill display nonzero unverified requirements stay generic and preserve code", () =>
        {
            var state = SkillDisplaySnapshot.Interpret(Sample(status: 56789, conditions: 56789));
            Check(state.Availability == SkillAvailability.Conditions && state.StateText == "条件不满足" && state.ConditionsStatus == 56789);
            Check(!state.StateText.Contains("目标") && !state.StateText.Contains("魔力"));
            Check(SkillDisplaySnapshot.Interpret(Sample(status: 2)).Availability == SkillAvailability.Conditions);
        });
        test("skill display no cooldown and native status zero shows ready", () =>
        {
            var state = SkillDisplaySnapshot.Interpret(Sample());
            Check(state.Availability == SkillAvailability.Ready && state.Label(true, true) == "可用");
            Check(SkillDisplaySnapshot.Interpret(Sample(charges: 0)).Availability != SkillAvailability.Ready);
        });
        test("skill display presentation toggles do not affect interpretation", () =>
        {
            var state = SkillDisplaySnapshot.Interpret(Sample(charges: 1, maximum: 2, active: true, elapsed: 45, total: 60));
            Check(state.Label(false, false) == "可用" && state.Label(false, true) == "可用 · 1/2");
            Check(!state.Label(true, false).Contains("1/2") && SkillDisplaySnapshot.Unknown.Label(true, true) == "未知");
        });
        test("skill display cache requires settled context and clears player job or territory", () =>
        {
            var cache = new SkillDisplayCache();
            Check(!cache.Synchronize(availableContext)); Check(cache.Synchronize(availableContext));
            cache.Put(7561, SkillDisplaySnapshot.Interpret(Sample()), 10);
            Check(cache.Get(7561, 10).Availability == SkillAvailability.Ready);
            foreach (var context in new[] { availableContext with { Job = 25 }, availableContext with { ContentId = 11 },
                availableContext with { EntityId = 21 }, availableContext with { Territory = 101 },
                availableContext with { TargetId = 123 }, availableContext with { Available = false } })
            {
                Check(!cache.Synchronize(context)); Check(cache.Get(7561, 10).Availability == SkillAvailability.Unknown);
                cache.Synchronize(availableContext); cache.Synchronize(availableContext);
                cache.Put(7561, SkillDisplaySnapshot.Interpret(Sample()), 10);
            }
        });
        test("skill display stale backward clock and lifecycle cache do not retain green state", () =>
        {
            var cache = new SkillDisplayCache(); cache.Synchronize(availableContext); cache.Synchronize(availableContext);
            cache.Put(7561, SkillDisplaySnapshot.Interpret(Sample()), 10);
            Check(cache.Get(7561, 12.01).Availability == SkillAvailability.Unknown);
            Check(cache.Get(7561, 9).Availability == SkillAvailability.Unknown);
            Check(cache.Get(7561, double.NaN).Availability == SkillAvailability.Unknown);
            cache.Clear(); Check(cache.Get(7561, 10).Availability == SkillAvailability.Unknown);
            Check(!cache.Synchronize(availableContext));
        });
        test("skill display local catalog ID and name search never invents persisted invalid IDs", () =>
        {
            var catalog = new SkillCatalog(new[] { new SkillCatalogEntry(7561, "即刻咏唱", 104), new SkillCatalogEntry(125, "复活", 105) });
            Check(catalog.Find(uint.MaxValue) == null && catalog.Find(0) == null);
            Check(catalog.Search("7561").Single().Name == "即刻咏唱");
            Check(catalog.Search("复活").Single().Id == 125 && catalog.Search("no such spell").Count == 0);
        });
    }
}
