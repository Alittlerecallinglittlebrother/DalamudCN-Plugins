using System.Numerics;
using System.Text.Json;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

internal static unsafe class SkillDisplayUi
{
    private static int width = 720, height = 620, checks;
    private static Vector2 windowMinimum, windowMaximum;
    private static void Check(bool result, string message) { if (!result) throw new Exception(message); checks++; }

    private sealed class FakeDisplay(SkillCatalog catalog) : ISkillDisplayProvider
    {
        public readonly Dictionary<uint, SkillDisplaySnapshot> Snapshots = [];
        public SkillDisplaySnapshot GetSnapshot(uint id) => Snapshots.GetValueOrDefault(id);
        public SkillCatalogEntry? GetSkill(uint id) => catalog.Find(id);
    }

    public static int Run(string output)
    {
        Directory.CreateDirectory(output); checks = 0; width = 720; height = 620;
        using var native = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory, "cimgui.dll"));
        ImGui.InitApi(native); var context = ImGui.CreateContext();
        try
        {
            var io = ImGui.GetIO(); io.IniFilename = null; io.DeltaTime = 1f / 60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 17, default, io.Fonts.GetGlyphRangesChineseFull());
            Check(io.Fonts.Build(), "skill UI font atlas failed"); ImGui.StyleColorsDark();
            var macro = new MacroEntry { Name = "即刻复活与长名称截断测试", Commands = "/echo unchanged <wait.2>", Pinned = true, IconId = 104 };
            var config = new Configuration { Macros = [macro] }; config.Normalize();
            var catalog = new SkillCatalog(new[] { new SkillCatalogEntry(7561, "即刻咏唱", 104),
                new SkillCatalogEntry(125, "复活", 105), new SkillCatalogEntry(9876, "很长的技能名称用于本地列表截断与悬停说明验证", 106) });
            var display = new FakeDisplay(catalog);
            display.Snapshots[7561] = SkillDisplaySnapshot.Interpret(new(true, 7561, 0, 0, 1, 2, true, 45, 60, 0, 0, 123));
            display.Snapshots[125] = SkillDisplaySnapshot.Interpret(new(true, 125, 42, 0, 0, 1, true, 5, 30, 0, 0, 123));
            var settings = new MacroDisplayWindow(config, catalog, display);
            settings.Open(macro);
            foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})
            {config.Theme=theme;Capture(settings,output,$"theme-aux-skill-{theme}.png",720,620);Check(macro.DisplayActionId==0,"theme preview changed display skill");}
            config.Theme=ShelfTheme.Persona3;
            var before = JsonSerializer.Serialize(config);
            settings.Open(macro); DisplayFrame(settings);
            Check(settings.TestDisplaySelection == 0 && !settings.SkillUiItems.ContainsKey("display-skill-0"), "unsupported action appeared in local catalog");
            Type(settings, "display-search", "复活");
            Check(settings.TestDisplaySearch == "复活" && settings.SkillUiItems.ContainsKey("display-skill-125") &&
                !settings.SkillUiItems.ContainsKey("display-skill-7561"), "display skill name search failed");
            Type(settings, "display-search", "7561"); Click(settings, "display-skill-7561");
            Check(settings.TestDisplaySelection == 7561 && macro.DisplayActionId == 0, "selection persisted before explicit save");
            Click(settings, "display-cooldown"); Click(settings, "display-charges");
            Check(JsonSerializer.Serialize(config) == before, "unsaved display UI mutated saved config");
            Capture(settings, output, "skill-display-selected.png", 720, 620);
            Click(settings, "display-save");
            Check(!settings.IsOpen && macro.DisplayActionId == 7561 && !macro.ShowSkillCooldown && !macro.ShowSkillCharges,
                "display skill or presentation toggles did not save");
            var persisted = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
            Check(persisted.Macros[0].DisplayActionId == 7561 && !persisted.Macros[0].ShowSkillCooldown && !persisted.Macros[0].ShowSkillCharges,
                "display settings did not persist through config store");
            var saved = JsonSerializer.Serialize(config);
            settings.Open(macro); DisplayFrame(settings); Click(settings, "display-skill-125"); Click(settings, "display-cooldown"); Click(settings, "display-cancel");
            Check(!settings.IsOpen && JsonSerializer.Serialize(config) == saved, "display cancellation changed saved settings");
            settings.Open(macro); DisplayFrame(settings); Click(settings, "display-reset");
            Check(settings.TestDisplaySelection == 0 && macro.DisplayActionId == 7561, "display reset modified saved selection immediately");
            Click(settings, "display-save"); Check(macro.DisplayActionId == 0 && macro.IconId == 104, "reset lost native icon fallback");
            settings.Open(macro); DisplayFrame(settings); Type(settings, "display-search", "不存在");
            Check(!settings.SkillUiItems.Keys.Any(k => k.StartsWith("display-skill-")), "empty search retained stale skill controls");
            Capture(settings, output, "skill-display-no-results.png", 480, 550); CheckFooter(settings);
            Type(settings, "display-search", "");
            ImGuiHelpers.GlobalScale = 1.5f; io.FontGlobalScale = 1.5f;
            Capture(settings, output, "skill-display-scale150-narrow.png", 720, 700); CheckFooter(settings);
            Click(settings, "display-cancel"); ImGuiHelpers.GlobalScale = 1; io.FontGlobalScale = 1;
            macro.DisplayActionId = 7561; macro.ShowSkillCooldown = true; macro.ShowSkillCharges = true;
            var cooldownMacro = new MacroEntry { Name = "冷却参考", Commands = "/echo cooldown <wait.2>", Pinned = true, DisplayActionId = 125 };
            var unknownMacro = new MacroEntry { Name = "无效技能未知", Commands = "/echo unknown <wait.2>", Pinned = true, DisplayActionId = uint.MaxValue };
            config.Macros.Add(cooldownMacro); config.Macros.Add(unknownMacro); config.Normalize();
            using var executor = new MacroExecutor(config, () => 0);
            using var main = new MainWindow(config, executor, new BetterWaitPatch()); main.IsOpen = false;
            Plugin.ClientState.IsLoggedIn = true;
            var opened = (MacroEntry?)null;
            var bar = new QuickBarWindow(config, executor, main, display, e => opened = e);
            var barBefore = JsonSerializer.Serialize(config); var sentBefore = Plugin.CommandManager.Sent.Count;
            Capture(bar, output, "quickbar-skill-states.png", 720, 420);
            Check(bar.TestSkillSnapshots[macro.Id].Availability == SkillAvailability.Ready && bar.TestSkillSnapshots[macro.Id].Charges == 1 &&
                bar.TestSkillSnapshots[macro.Id].MaxCharges == 2, "ready partial charge did not render as ready");
            Check(bar.TestSkillSnapshots[cooldownMacro.Id].Availability == SkillAvailability.Cooldown &&
                bar.TestSkillSnapshots[unknownMacro.Id].Availability == SkillAvailability.Unknown, "cooldown/unknown rendered incorrectly");
            Check(!executor.IsRunning && Plugin.CommandManager.Sent.Count == sentBefore && JsonSerializer.Serialize(config) == barBefore,
                "skill rendering dispatched an action or changed configuration");
            BarClick(bar, "run-" + macro.Id);
            Check(executor.IsRunning && executor.CurrentMacroName == macro.Name && executor.TotalLines == 1 && !main.IsOpen,
                "ready icon shortcut stopped using existing macro executor");
            Plugin.Framework.Tick(); Check(Plugin.CommandManager.Sent.Count == sentBefore + 1 && Plugin.CommandManager.Sent.Last() == "/echo unchanged",
                "ready shortcut altered existing inline-wait command dispatch");
            BarClick(bar, "stop"); BarClick(bar, "run-" + cooldownMacro.Id);
            Check(executor.IsRunning && executor.CurrentMacroName == cooldownMacro.Name, "cooldown status improperly disabled macro executor");
            BarClick(bar, "stop"); BarClick(bar, "run-" + unknownMacro.Id);
            Check(executor.IsRunning && executor.CurrentMacroName == unknownMacro.Name, "unknown status improperly disabled macro executor");
            BarClick(bar, "stop"); BarClick(bar, "run-" + macro.Id, 1); BarClick(bar, "display-" + macro.Id);
            Check(ReferenceEquals(opened, macro), "quickbar display settings targeted wrong entry");
            config.QuickBarColumns = 8; ImGuiHelpers.GlobalScale = 1.5f; io.FontGlobalScale = 1.5f;
            Capture(bar, output, "quickbar-skill-scale150-narrow.png", 480, 500);
            Check(windowMinimum.X >= 0 && windowMinimum.Y >= 0 && windowMaximum.X <= width && windowMaximum.Y <= height,
                "skill bar escaped narrow scaled viewport");
            Check(macro.Commands == "/echo unchanged <wait.2>", "display features rewrote macro commands");
            Console.WriteLine($"PASS offline skill display UI: {checks} assertions; search, select, save, cancel, toggles, reset, narrow layouts and unchanged executor");
            return checks;
        }
        catch { SoftwareRenderer.Save(Path.Combine(output, "skill-display-failure.png")); throw; }
        finally { ImGuiHelpers.GlobalScale = 1; Plugin.ClientState.IsLoggedIn = true; ImGui.DestroyContext(context); }
    }

    private static void BeginFrame()
    {
        var io = ImGui.GetIO(); io.DisplaySize = new(width, height); io.DeltaTime = 1f / 60; ImGui.NewFrame();
        ImGui.GetBackgroundDrawList().AddRectFilled(Vector2.Zero, io.DisplaySize, ImGui.GetColorU32(new Vector4(.035f, .05f, .075f, 1)));
    }
    private static void DisplayFrame(MacroDisplayWindow settings)
    {
        settings.SkillUiItems.Clear(); BeginFrame();settings.PreDraw();
        ImGui.SetNextWindowPos(new(16, 16), ImGuiCond.Always);
        ImGui.SetNextWindowSize(new(MathF.Min(580 * ImGuiHelpers.GlobalScale, width - 32), MathF.Min(530 * ImGuiHelpers.GlobalScale, height - 48)), ImGuiCond.Always);
        ImGui.Begin("常用宏显示技能###SkillDisplayTest", settings.Flags); settings.Draw();
        windowMinimum = ImGui.GetWindowPos(); windowMaximum = windowMinimum + ImGui.GetWindowSize(); ImGui.End();settings.PostDraw(); ImGui.Render();
    }
    private static void BarFrame(QuickBarWindow bar)
    {
        bar.UiItems.Clear(); bar.Regions.Clear(); bar.TestSkillSnapshots.Clear(); BeginFrame(); bar.PreDraw();
        if (bar.Size.HasValue) ImGui.SetNextWindowSize(bar.Size.Value * ImGuiHelpers.GlobalScale, bar.SizeCondition);
        ImGui.SetNextWindowPos(new(24, 48), ImGuiCond.FirstUseEver);
        ImGui.Begin("Macro Shelf-A 常用宏###SkillQuickbarTest", bar.Flags); bar.Draw();
        windowMinimum = ImGui.GetWindowPos(); windowMaximum = windowMinimum + ImGui.GetWindowSize();
        ImGui.End(); bar.PostDraw(); ImGui.Render();
    }
    private static void Capture(MacroDisplayWindow settings, string output, string name, int w, int h)
    { width = w; height = h; ImGui.GetIO().AddMousePosEvent(-100, -100); DisplayFrame(settings); DisplayFrame(settings); SoftwareRenderer.Save(Path.Combine(output, name)); }
    private static void Capture(QuickBarWindow bar, string output, string name, int w, int h)
    { width = w; height = h; ImGui.GetIO().AddMousePosEvent(-100, -100); BarFrame(bar); BarFrame(bar); SoftwareRenderer.Save(Path.Combine(output, name)); }
    private static void Click(MacroDisplayWindow settings, string key)
    {
        DisplayFrame(settings); Check(settings.SkillUiItems.ContainsKey(key), "missing skill UI control: " + key);
        var region = settings.SkillUiItems[key]; ClickAt((region.Min + region.Max) / 2, () => DisplayFrame(settings), 0);
    }
    private static void BarClick(QuickBarWindow bar, string key, int button = 0)
    {
        BarFrame(bar); Check(bar.UiItems.ContainsKey(key), "missing skill quickbar control: " + key);
        var region = bar.UiItems[key]; ClickAt((region.Min + region.Max) / 2, () => BarFrame(bar), button);
    }
    private static void ClickAt(Vector2 point, Action frame, int button)
    {
        Check(point.X >= 0 && point.Y >= 0 && point.X < width && point.Y < height, "skill UI control escaped screen");
        var io = ImGui.GetIO(); io.AddMousePosEvent(point.X, point.Y); frame();
        io.AddMouseButtonEvent(button, true); frame(); io.AddMouseButtonEvent(button, false); frame(); frame();
    }
    private static void Type(MacroDisplayWindow settings, string key, string text)
    {
        Click(settings, key); var io = ImGui.GetIO(); io.AddKeyEvent(ImGuiKey.ModCtrl, true); io.AddKeyEvent(ImGuiKey.A, true); DisplayFrame(settings);
        io.AddKeyEvent(ImGuiKey.A, false); io.AddKeyEvent(ImGuiKey.ModCtrl, false); DisplayFrame(settings);
        if (text.Length == 0) { io.AddKeyEvent(ImGuiKey.Backspace, true); DisplayFrame(settings); io.AddKeyEvent(ImGuiKey.Backspace, false); }
        else foreach (var character in text) io.AddInputCharacter(character);
        DisplayFrame(settings); DisplayFrame(settings);
    }
    private static void CheckFooter(MacroDisplayWindow settings)
    {
        foreach (var key in new[] { "display-save", "display-cancel" })
        {
            Check(settings.SkillUiItems.TryGetValue(key, out var region), "display footer clipped: " + key);
            Check(region.Min.X >= windowMinimum.X && region.Max.X <= windowMaximum.X && region.Min.Y >= windowMinimum.Y && region.Max.Y <= windowMaximum.Y,
                "display footer escaped window: " + key);
        }
    }
}
