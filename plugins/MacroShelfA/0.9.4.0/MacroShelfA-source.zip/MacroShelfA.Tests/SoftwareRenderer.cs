using System.Drawing.Imaging;
using System.Numerics;
using System.Runtime.InteropServices;
using Dalamud.Bindings.ImGui;

internal static unsafe class SoftwareRenderer
{
    private sealed record Texture(byte[] Pixels, int Width, int Height);
    private static readonly Dictionary<ulong, Texture> Textures = [];
    public static void RegisterTexture(ulong id, Stream source)
    {
        using var image = new Bitmap(source);
        using var bitmap = new Bitmap(image.Width, image.Height, PixelFormat.Format32bppArgb);
        using (var graphics = Graphics.FromImage(bitmap)) graphics.DrawImageUnscaled(image, 0, 0);
        var data = bitmap.LockBits(new Rectangle(0,0,bitmap.Width,bitmap.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        var pixels = new byte[bitmap.Width * bitmap.Height * 4];
        try { for(var y=0;y<bitmap.Height;y++) Marshal.Copy(data.Scan0+y*data.Stride,pixels,y*bitmap.Width*4,bitmap.Width*4); }
        finally { bitmap.UnlockBits(data); }
        for(var i=0;i<pixels.Length;i+=4) (pixels[i],pixels[i+2])=(pixels[i+2],pixels[i]);
        Textures[id]=new(pixels,bitmap.Width,bitmap.Height);
    }
    public static void ClearTextures() => Textures.Clear();
    public static void Save(string path)
    {
        var draw = ImGui.GetDrawData();
        var width = (int)draw.DisplaySize.X; var height = (int)draw.DisplaySize.Y;
        byte* atlas = null; int texWidth = 0, texHeight = 0;
        ImGui.GetIO().Fonts.GetTexDataAsRGBA32(0, ref atlas, ref texWidth, ref texHeight);
        var output = new byte[width * height * 4];
        for (var i = 3; i < output.Length; i += 4) output[i] = 255;
        for (var listIndex = 0; listIndex < draw.CmdListsCount; listIndex++)
        {
            ImDrawListPtr list = draw.CmdLists[listIndex];
            for (var commandIndex = 0; commandIndex < list.CmdBuffer.Size; commandIndex++)
            {
                var cmd = list.CmdBuffer[commandIndex];
                if (cmd.UserCallback != null) continue;
                Textures.TryGetValue(cmd.TextureId.Handle,out var texture);
                fixed(byte* custom = texture?.Pixels)
                {
                for (uint triangle = 0; triangle + 2 < cmd.ElemCount; triangle += 3)
                {
                    var a = list.VtxBuffer[(int)(list.IdxBuffer[(int)(cmd.IdxOffset + triangle)] + cmd.VtxOffset)];
                    var b = list.VtxBuffer[(int)(list.IdxBuffer[(int)(cmd.IdxOffset + triangle + 1)] + cmd.VtxOffset)];
                    var c = list.VtxBuffer[(int)(list.IdxBuffer[(int)(cmd.IdxOffset + triangle + 2)] + cmd.VtxOffset)];
                    Triangle(a, b, c, cmd.ClipRect, output, width, height, custom == null ? atlas : custom,
                        texture?.Width ?? texWidth, texture?.Height ?? texHeight);
                }
                }
            }
        }
        using var bitmap = new Bitmap(width, height, PixelFormat.Format32bppArgb);
        var data = bitmap.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try { Marshal.Copy(output, 0, data.Scan0, output.Length); }
        finally { bitmap.UnlockBits(data); }
        bitmap.Save(path, ImageFormat.Png);
        if (output.Where((_, index) => index % 4 != 3).Distinct().Count() < 20) throw new InvalidOperationException("render pixels are blank");
    }

    private static void Triangle(ImDrawVert a, ImDrawVert b, ImDrawVert c, Vector4 clip, byte[] pixels, int width, int height, byte* texture, int tw, int th)
    {
        var determinant = Cross(b.Pos - a.Pos, c.Pos - a.Pos);
        if (Math.Abs(determinant) < 0.001f) return;
        // Test pixel centres, including the pixel containing a fractional minimum vertex.
        // Ceiling here skipped otherwise covered pixels along adjacent decorative quads.
        var x0 = Math.Max(0, (int)MathF.Floor(Math.Max(clip.X, Math.Min(a.Pos.X, Math.Min(b.Pos.X, c.Pos.X)))));
        var x1 = Math.Min(width, (int)MathF.Ceiling(Math.Min(clip.Z, Math.Max(a.Pos.X, Math.Max(b.Pos.X, c.Pos.X)))));
        var y0 = Math.Max(0, (int)MathF.Floor(Math.Max(clip.Y, Math.Min(a.Pos.Y, Math.Min(b.Pos.Y, c.Pos.Y)))));
        var y1 = Math.Min(height, (int)MathF.Ceiling(Math.Min(clip.W, Math.Max(a.Pos.Y, Math.Max(b.Pos.Y, c.Pos.Y)))));
        for (var y = y0; y < y1; y++)
        for (var x = x0; x < x1; x++)
        {
            var p = new Vector2(x + 0.5f, y + 0.5f);
            if (p.X < clip.X || p.Y < clip.Y || p.X >= clip.Z || p.Y >= clip.W) continue;
            var wa = Cross(b.Pos - p, c.Pos - p) / determinant;
            var wb = Cross(c.Pos - p, a.Pos - p) / determinant;
            var wc = 1 - wa - wb;
            // Float barycentrics at shared triangle edges can be -epsilon. GPU rasterizers
            // use a consistent edge rule; excluding these pixels creates false dotted seams.
            if (wa < -0.00001f || wb < -0.00001f || wc < -0.00001f) continue;
            var uv = a.Uv * wa + b.Uv * wb + c.Uv * wc;
            // ImGui's GPU backend uses linear sampling, including fractionally scaled fonts.
            var fx=Math.Clamp(uv.X*tw-.5f,0,tw-1);var fy=Math.Clamp(uv.Y*th-.5f,0,th-1);
            var tx=(int)fx;var ty=(int)fy;fx-=tx;fy-=ty;
            var t00=texture+(ty*tw+tx)*4;var t10=texture+(ty*tw+Math.Min(tx+1,tw-1))*4;
            var t01=texture+(Math.Min(ty+1,th-1)*tw+tx)*4;var t11=texture+(Math.Min(ty+1,th-1)*tw+Math.Min(tx+1,tw-1))*4;
            var texAlpha=(t00[3]*(1-fx)+t10[3]*fx)*(1-fy)+(t01[3]*(1-fx)+t11[3]*fx)*fy;
            var alpha = (Component(a.Col, 24) * wa + Component(b.Col, 24) * wb + Component(c.Col, 24) * wc) * texAlpha / 65025f;
            var offset = (y * width + x) * 4;
            for (var channel = 0; channel < 3; channel++)
            {
                var texColor=(t00[channel]*(1-fx)+t10[channel]*fx)*(1-fy)+(t01[channel]*(1-fx)+t11[channel]*fx)*fy;
                var color = (Component(a.Col, channel * 8) * wa + Component(b.Col, channel * 8) * wb + Component(c.Col, channel * 8) * wc) * texColor / 255f;
                var index = offset + 2 - channel;
                pixels[index] = (byte)Math.Clamp(color * alpha + pixels[index] * (1 - alpha), 0, 255);
            }
        }
    }
    private static float Cross(Vector2 a, Vector2 b) => a.X * b.Y - a.Y * b.X;
    private static float Component(uint color, int shift) => (color >> shift) & 255;
}
