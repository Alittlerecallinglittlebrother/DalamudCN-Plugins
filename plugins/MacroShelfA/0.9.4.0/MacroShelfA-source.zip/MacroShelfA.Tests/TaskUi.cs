using System.Numerics;
using System.Text.Json;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

// Executes production native ImGui, with managed game/configuration boundaries.
// These are real draw lists and input events, not a recreation of the mockup.
internal static unsafe class TaskUi
{
    private static int width=1536,height=1024,checks;
    private static string output="";
    private static MainWindow window=null!;
    private static QuickBarWindow bar=null!;
    private static NativeMacroImportWindow importer=null!;
    private static MacroDisplayWindow displayPage=null!;
    private static NativeMacroBridgeWindow bridge=null!;
    private static readonly List<object> geometry=[];
    private static readonly ShelfTheme[] themes=[ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5];
    private sealed class Display(SkillCatalog catalog):ISkillDisplayProvider
    {
        public SkillDisplaySnapshot GetSnapshot(uint id)=>id==0?SkillDisplaySnapshot.Unknown:new(SkillAvailability.Ready,id,0,0,1,2,0,100);
        public SkillCatalogEntry? GetSkill(uint id)=>catalog.Find(id);
    }
    private static void Check(bool value,string message){if(!value)throw new Exception(message);checks++;}
    public static void Run(string directory)
    {
        output=directory;Directory.CreateDirectory(output);checks=0;geometry.Clear();
        using var native=new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory,"cimgui.dll"));ImGui.InitApi(native);var context=ImGui.CreateContext();
        try
        {
            var io=ImGui.GetIO();io.IniFilename=null;io.DeltaTime=1f/60;io.ConfigInputTextCursorBlink=false;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc",17,default,io.Fonts.GetGlyphRangesChineseFull());Check(io.Fonts.Build(),"font atlas");ImGui.StyleColorsDark();
            checks+=ThemeUi.VerifyStyleAndMotion();
            VerifyNativeFont();
            var entry=new MacroEntry{Name="开场问候",Group="演出",Commands="/echo 欢迎来到演出\n/wait 0.5\n/echo 接下来请欣赏合奏\n/wait 1\n/echo 准备开始\n/echo 祝大家游戏愉快\n/wait 1\n/echo 开场结束",Pinned=true,DisplayActionId=7561};
            var group=new MacroEntry{Name="完整演出流程",Group="演出",IsGroup=true,Children=[new(){Name="01 开场",Commands="/echo 开场\n/wait 1"},new(){Name="02 主段",Commands="/echo 主段\n/wait 1"},new(){Name="03 谢幕",Commands="/echo 谢幕"}]};
            var config=new Configuration{Theme=ShelfTheme.Needy,AllowLongMacros=true,Macros=[entry,group,new(){Name="结束致谢",Group="演出",Commands="/echo 感谢观看"}]};config.Normalize();
            using var executor=new MacroExecutor(config,()=>0);
            using var main=new MainWindow(config,executor,new BetterWaitPatch()){Artwork=new ThemeUi.Artwork()};window=main;
            var catalog=new SkillCatalog(new[]{new SkillCatalogEntry(7561,"即刻咏唱",0),new SkillCatalogEntry(125,"复活",0)});window.SkillDisplay=new Display(catalog);
            bar=new QuickBarWindow(config,executor,window,window.SkillDisplay,_=>{});window.DrawQuickDock=bar.DrawDocked;
            var reader=new NativeMacroImportUi.FakeReader();using var imports=new NativeMacroImportWindow(config,window.RefreshLibrary,reader);importer=imports;
            window.ImportPage=importer;importer.ViewImported=window.ShowImportedMacros;
            displayPage=new MacroDisplayWindow(config,catalog,window.SkillDisplay);window.DisplayPage=displayPage;
            var host=new NativeMacroBridgeUi.Host();var backups=new NativeMacroBridgeUi.Store();
            using var bridgeWindow=new NativeMacroBridgeWindow(config,new NativeMacroBridgeService(host,backups),action=>{action();return Task.CompletedTask;});bridge=bridgeWindow;window.BridgePage=bridge;
            window.TestOpen(entry);Resize(1536,1024);
            foreach(var theme in themes)
            {
                SelectTheme(theme);Navigate(MainWindow.TaskPage.Macros);
                Capture($"tasks-{theme}-macros.png",1536,1024);
                Check(window.UiItems.ContainsKey("edit-commands")&&window.UiItems.ContainsKey("edit-run"),"macro editor missing");
                foreach(var page in Enum.GetValues<MainWindow.TaskPage>())
                {
                    Navigate(page);Check(window.TestTaskPage==page,"task navigation failed: "+page);
                    Check(!window.UiItems.Keys.Any(k=>k is "mode-simple" or "mode-advanced" or "nav-library" or "entry-more"),"legacy workbench controls remain");
                    Check(!executor.IsRunning&&host.Writes==0,"page navigation ran or wrote a macro");
                    if(page==MainWindow.TaskPage.NativeImport)Capture($"tasks-{theme}-import.png",1536,1024);
                    if(theme==ShelfTheme.Needy&&page!=MainWindow.TaskPage.Macros&&page!=MainWindow.TaskPage.NativeImport)Capture($"tasks-Needy-{page}.png",1536,1024);
                }
                Navigate(MainWindow.TaskPage.Macros);Scroll("task-body",0);Capture($"tasks-{theme}-720.png",720,500);CheckCompact();Resize(1536,1024);Scroll("task-body",0);
            }
            Console.WriteLine("TASK UI: navigation and native font passed");
            SelectTheme(ShelfTheme.Needy);Navigate(MainWindow.TaskPage.Macros);window.TestOpen(entry);Frame();
            Type("edit-name","中文测试宏");Type("edit-category","自定义分类");Click("edit-favorite");
            Check(entry.Name=="中文测试宏"&&entry.Group=="自定义分类"&&!entry.Pinned,"metadata/pin change not persisted");
            var persisted=Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
            Check(persisted.Macros[0].Name==entry.Name&&persisted.Macros[0].Group==entry.Group,"metadata not saved to host boundary");
            Click("edit-favorite");Type("search","不存在的名称");Check(!window.UiItems.ContainsKey("tree-"+entry.Id),"macro search did not filter");
            Click("new-macro");var created=window.TestSelected!;Check(created!=entry&&window.UiItems.ContainsKey("tree-"+created.Id),"new macro hidden by old search");
            Type("edit-commands","/echo 新建宏\n/wait 1");Click("duplicate");var duplicate=window.TestSelected!;
            Check(duplicate!=created&&duplicate.Id!=created.Id&&duplicate.Commands==created.Commands,"duplicate not independent");
            Click("delete");Click("delete-cancel");Check(config.Macros.Contains(duplicate),"delete cancellation changed library");
            Click("delete");Click("delete-confirm");Check(!config.Macros.Contains(duplicate)&&config.Macros.Contains(created),"delete did not isolate target");
            window.TestOpen(entry);Frame();Click("edit-run");Check(executor.IsRunning&&executor.TotalLines==8,"macro run not wired");
            var running=JsonSerializer.Serialize(config.Macros);SelectTheme(ShelfTheme.Persona3);Check(executor.IsRunning&&JsonSerializer.Serialize(config.Macros)==running,"theme switch changed runtime/data");Click("stop");Check(!executor.IsRunning,"stop failed");
            Navigate(MainWindow.TaskPage.Groups);Check(window.TestSelected==group,"group page selected independent macro");Click("add-child");var child=window.TestSelected!;
            Type("edit-commands","/echo 新子宏\n/wait 1");Click("move-up");Check(group.Children[^2]==child,"child reorder failed");
            Click("edit-run");Check(executor.IsRunning&&executor.TotalChildren==1,"child ran entire group");Click("stop");
            Click("edit-run-group");Check(executor.IsRunning&&executor.TotalChildren==4,"group button ran single child");Click("stop");
            Click("edit-favorite");Check(child.Pinned,"child pin not saved");
            Navigate(MainWindow.TaskPage.QuickBar);Seek("quick-remove-"+entry.Id);Click("quick-remove-"+entry.Id);
            Check(!entry.Pinned&&config.Macros.Contains(entry),"quickbar removal deleted macro");
            Scroll("task-body",0);Click("quick-add");Click("quick-add-"+entry.Id);Check(entry.Pinned,"quickbar add failed");
            Seek("quick-edit-"+child.Id);Click("quick-edit-"+child.Id);Check(window.TestSelected==child&&window.TestTaskPage==MainWindow.TaskPage.Groups&&!executor.IsRunning,"quickbar edit lost child scope");
            Console.WriteLine("TASK UI: CRUD, explicit child/group execution and quickbar passed");

            Navigate(MainWindow.TaskPage.NativeImport);Scroll("task-body",0);var originalCount=config.CountEntries();
            Click("native-preview-0:0");Click("native-select-0:0");Click("native-tab-1");Click("native-select-1:0");
            Check(importer.TestSelectedCount==2&&config.CountEntries()==originalCount,"selecting native macros mutated library");
            Seek("native-import");Click("native-import");Check(config.CountEntries()==originalCount+2&&!executor.IsRunning&&host.Writes==0,"embedded import copied wrong number or auto-executed/wrote");
            Click("native-view-imported");Check(window.TestTaskPage==MainWindow.TaskPage.Macros&&window.TestSelected==config.Macros[^1],"import result not opened in editor");
            Navigate(MainWindow.TaskPage.NativeImport);Scroll("task-body",0);Click("native-tab-0");Click("native-select-0:0");
            var pending=new TaskCompletionSource<NativeMacroReadSnapshot>();reader.Pending=pending.Task;Seek("native-import");Click("native-import");
            Navigate(MainWindow.TaskPage.Execution);pending.SetResult(reader.Snapshot);reader.Pending=null;importer.TestPump();
            Check(config.CountEntries()==originalCount+2&&!importer.TestSnapshot.Available,"leaving import page committed pending copy");
            Click("setting-long");Check(!config.AllowLongMacros,"long macro toggle not wired");Click("setting-long");
            var oldWait=config.BetterWaitEnabled;Click("setting-wait");Check(config.BetterWaitEnabled!=oldWait,"wait toggle not wired");Click("setting-wait");

            Navigate(MainWindow.TaskPage.Display);Click("task-target");Click("target-"+child.Id);Type("display-search","125");Click("display-skill-125");
            Check(child.DisplayActionId==0,"skill selection saved before explicit save");Seek("display-save");Click("display-save");
            Check(child.DisplayActionId==125&&entry.DisplayActionId==7561&&!executor.IsRunning,"display settings changed wrong entry or executed");
            Scroll("task-body",0);Click("display-reset");Seek("display-cancel");Click("display-cancel");Check(displayPage.TestDisplaySelection==125&&child.DisplayActionId==125,"display cancel changed saved state");

            Navigate(MainWindow.TaskPage.Bridge);Click("task-target");Click("target-"+child.Id);var textBefore=child.Commands;
            Seek("generate");Click("generate");Check(host.Writes==1&&backups.Saved.Count==1&&host.Slots[0].LineCount==1,"embedded bridge did not back up and generate exactly one line");
            Check(host.Slots[0].DisplayCommands.Contains(child.Id)&&child.Commands==textBefore,"bridge lost target or rewrote full macro");
            var saved=backups.Saved[^1];Seek("backupselect");Click("backupselect");Click("backup-"+saved.Id);Seek("restore");Click("restore");
            Check(host.Writes==2&&backups.Saved.Count==2&&host.Slots[0].IsEmpty,"embedded backup restore did not preserve empty original");
            Console.WriteLine("TASK UI: embedded import, display settings and bridge backup/restore passed");

            Navigate(MainWindow.TaskPage.Countdown);Click("countdown-target");Click("countdown-option-"+group.Id);Click("countdown-enabled");
            Check(config.CountdownTriggerEnabled&&config.CountdownMacroId==group.Id&&!executor.IsRunning,"countdown page misbound or executed immediately");Click("countdown-enabled");
            Navigate(MainWindow.TaskPage.Appearance);var beforeAppearance=JsonSerializer.Serialize(config.Macros);
            Click("setting-decoration");Click("setting-reduce-motion");Navigate(MainWindow.TaskPage.Macros);Scroll("task-body",0);window.TestOpen(entry);Frame();
            Check(window.TestLayout.ArtWidth==0&&config.ReduceThemeMotion,"appearance controls not applied");
            ImGui.GetIO().AddMousePosEvent(-100,-100);for(var n=0;n<30;n++)Frame();var still=ThemeUi.DrawFingerprint();for(var n=0;n<8;n++)Frame();Check(still==ThemeUi.DrawFingerprint(),"reduced motion keeps animating");
            Check(JsonSerializer.Serialize(config.Macros)==beforeAppearance,"appearance modified macro contents");
            Navigate(MainWindow.TaskPage.Appearance);Click("setting-decoration");Click("setting-reduce-motion");
            Navigate(MainWindow.TaskPage.Macros);window.TestOpen(entry);Scroll("task-body",0);var hit=window.UiItems["edit-run"];ImGui.GetIO().AddMousePosEvent(hit.Min.X+20,hit.Min.Y+12);for(var n=0;n<15;n++)Frame();
            Check(window.UiItems["edit-run"]==hit&&!executor.IsRunning,"hover animation moved click region or ran");
            VerifySelection(config,entry);
            VerifyResponsive(config,entry,executor);
            Console.WriteLine("TASK UI: settings, reduced motion, selection and responsive layouts passed");

            Resize(1536,1024);Navigate(MainWindow.TaskPage.Backup);Scroll("task-body",0);
            var exchange=new Configuration{Macros=[new(){Name="备份恢复测试",Commands="/echo restored"}]};exchange.Normalize();var json=ConfigurationExchange.Export(exchange);
            Type("backup-json",json);var beforeAppend=config.CountEntries();Seek("backup-replace");Click("backup-replace");Check(config.CountEntries()==beforeAppend,"replace button ignored required confirmation");
            Click("backup-append");Check(config.CountEntries()==beforeAppend+1&&config.Macros.Any(m=>m.Name=="备份恢复测试"),"append did not retain original library");
            Navigate(MainWindow.TaskPage.Backup);Scroll("task-body",0);Type("backup-json",json);Seek("backup-confirm");Click("backup-confirm");Click("backup-replace");
            Check(config.Macros.Count==1&&config.Macros[0].Commands=="/echo restored"&&!executor.IsRunning,"confirmed replace did not replace library");
            Check(window.TestTaskPage==MainWindow.TaskPage.Macros&&window.TestSelected==config.Macros[0],"backup completion not routed to editor");
            config.Macros.Clear();window.TestRefresh();Frame();Click("welcome-example");Check(config.Macros.Count==1&&window.TestSelected?.Name=="我的第一个宏"&&!executor.IsRunning,"empty-state example not editable/idle");
            File.WriteAllText(Path.Combine(output,"task-ui-geometry.json"),JsonSerializer.Serialize(geometry,new JsonSerializerOptions{WriteIndented=true}));
            File.WriteAllText(Path.Combine(output,"task-ui-report.json"),JsonSerializer.Serialize(new{checks,nativeImGui=ImGui.GetVersion(),pages=10,lastLineCases=18,scales=new[]{"100%","font 130% / UI 100%","125%","150%","200%"},gameVerified=false},new JsonSerializerOptions{WriteIndented=true}));
            Console.WriteLine($"PASS task navigation UI: {checks} assertions; native ImGui input and rendering, all 10 pages × 3 themes. Offline host, not game verification.");
        }
        catch{SoftwareRenderer.Save(Path.Combine(output,"task-ui-failure.png"));throw;}
        finally{SoftwareRenderer.ClearTextures();ImGuiHelpers.GlobalScale=1;ImGui.DestroyContext(context);}
    }
    private static void Frame()
    {
        var io=ImGui.GetIO();io.DisplaySize=new(width,height);io.DeltaTime=1f/60;
        window.UiItems.Clear();window.ThemeRegions.Clear();bar.UiItems.Clear();bar.Regions.Clear();importer.UiItems.Clear();displayPage.SkillUiItems.Clear();bridge.UiItems.Clear();
        ImGui.NewFrame();window.PreDraw();ImGui.SetNextWindowPos(Vector2.Zero,ImGuiCond.Always);ImGui.SetNextWindowSize(new(width,height),ImGuiCond.Always);
        ImGui.Begin("TaskNavigatorHost",window.Flags|ImGuiWindowFlags.NoMove|ImGuiWindowFlags.NoResize);window.Draw();ImGui.End();window.PostDraw();ImGui.Render();
    }
    private static void Resize(int w,int h){width=w;height=h;Frame();Frame();}
    private static void Capture(string file,int w,int h)
    {
        Resize(w,h);ImGui.GetIO().AddMousePosEvent(-100,-100);for(var n=0;n<25;n++)Frame();SoftwareRenderer.Save(Path.Combine(output,file));
        geometry.Add(new{file,w,h,scale=ImGuiHelpers.GlobalScale,fontScale=ImGui.GetIO().FontGlobalScale,regions=window.ThemeRegions.ToDictionary(x=>x.Key,x=>new{min=new[]{x.Value.Min.X,x.Value.Min.Y},max=new[]{x.Value.Max.X,x.Value.Max.Y}})});
    }
    private static Dictionary<string,(Vector2 Min,Vector2 Max)> Items()
    {
        var all=new Dictionary<string,(Vector2 Min,Vector2 Max)>(window.UiItems);
        foreach(var source in new[]{importer.UiItems,displayPage.SkillUiItems,bridge.UiItems,bar.UiItems})foreach(var pair in source)all.TryAdd(pair.Key,pair.Value);return all;
    }
    private static void Scroll(string region,float y){window.ScrollRequests[region]=y;Frame();Frame();Frame();}
    private static void Navigate(MainWindow.TaskPage page)
    {
        Scroll("task-navigation",0);var key="task-"+page;
        for(var n=0;n<40&&!InRegion(key,"task-navigation");n++)Wheel("task-navigation",window.UiItems.TryGetValue(key,out var row)&&row.Min.Y<window.ThemeRegions["task-navigation"].Min.Y?.7f:-.7f);
        Check(InRegion(key,"task-navigation"),"navigation row not fully reachable: "+key);
        Click(key);Frame();
    }
    private static void Wheel(string region,float amount)
    {
        var r=window.ThemeRegions[region];var io=ImGui.GetIO();io.AddMousePosEvent(r.Min.X+10,(r.Min.Y+r.Max.Y)/2);Frame();io.AddMouseWheelEvent(0,amount);Frame();Frame();
    }
    private static void Click(string key)
    {
        Frame();if(!Items().TryGetValue(key,out var r))throw new Exception("missing task control: "+key);
        var point=(r.Min+r.Max)/2;Check(point.X>=0&&point.Y>=0&&point.X<=width&&point.Y<=height,"control outside viewport: "+key);ClickAt(point);
    }
    private static void ClickAt(Vector2 point){var io=ImGui.GetIO();io.AddMousePosEvent(point.X,point.Y);Frame();io.AddMouseButtonEvent(0,true);Frame();io.AddMouseButtonEvent(0,false);Frame();Frame();}
    private static void Key(ImGuiKey key,bool ctrl=false,bool shift=false){var io=ImGui.GetIO();if(ctrl)io.AddKeyEvent(ImGuiKey.ModCtrl,true);if(shift)io.AddKeyEvent(ImGuiKey.ModShift,true);io.AddKeyEvent(key,true);Frame();io.AddKeyEvent(key,false);if(ctrl)io.AddKeyEvent(ImGuiKey.ModCtrl,false);if(shift)io.AddKeyEvent(ImGuiKey.ModShift,false);Frame();Frame();}
    private static void Type(string key,string text){Click(key);Key(ImGuiKey.A,ctrl:true);if(text.Length==0)Key(ImGuiKey.Backspace);else{foreach(var c in text)ImGui.GetIO().AddInputCharacter(c);Frame();Frame();}}
    private static void SelectTheme(ShelfTheme theme){Click("theme-selector");Click("theme-"+theme);Frame();}
    private static void CheckCompact()
    {
        foreach(var key in new[]{"task-entry-picker","edit-name","stop"})
        {Check(window.UiItems.TryGetValue(key,out var r),"compact control missing: "+key);Check(r.Min.X>=0&&r.Max.X<=width&&r.Min.Y>=0&&r.Max.Y<=height,"compact control outside viewport: "+key);}
        var footer=window.ThemeRegions["footer"];var stop=window.UiItems["stop"];
        Check(stop.Min.Y>=footer.Min.Y&&stop.Max.Y<=footer.Max.Y,"stop clipped by footer");
        Seek("edit-run");Check(InRegion("edit-run","task-body"),"small-window run button cannot be revealed");
        Scroll("task-body",0);
    }
    private static bool InRegion(string key,string region)
    {if(!Items().TryGetValue(key,out var r)||!window.ThemeRegions.TryGetValue(region,out var area))return false;return r.Min.Y>=area.Min.Y&&r.Max.Y<=area.Max.Y&&r.Min.X>=area.Min.X&&r.Max.X<=area.Max.X;}
    private static void Seek(string key)
    {Scroll("task-body",0);for(var n=0;n<20&&!InRegion(key,"task-body");n++)Scroll("task-body",(n+1)*65*ImGuiHelpers.GlobalScale);Check(InRegion(key,"task-body"),"task control not scroll-reachable: "+key);}
    private static void VerifyNativeFont()
    {
        ImGui.NewFrame();ImGui.Begin("FontAudit");var dl=ImGui.GetWindowDrawList();var position=ImGui.GetCursorScreenPos();var color=Vector4.One;const string label="命令编辑 清晰字体 0123";
        var start=dl.VtxBuffer.Size;dl.AddText(position,ImGui.GetColorU32(color),label);var count=dl.VtxBuffer.Size-start;var copy=dl.VtxBuffer.Size;
        ShelfDrawing.Text(dl,position,label,ImGui.GetFontSize()*2,color,.3f);Check(dl.VtxBuffer.Size-copy==count&&count>0,"synthetic bold duplicated glyph vertices");
        for(var i=0;i<count;i++)Check(dl.VtxBuffer[start+i].Pos==dl.VtxBuffer[copy+i].Pos&&dl.VtxBuffer[start+i].Uv==dl.VtxBuffer[copy+i].Uv,"functional font differs from native settings font");
        ImGui.End();ImGui.Render();
    }
    private static void VerifySelection(Configuration config,MacroEntry entry)
    {
        var io=ImGui.GetIO();var lines=Enumerable.Range(1,8).Select(i=>$"/echo 第{i}行中文 · 最后一行对齐测试 <wait.0.2> "+new string('长',80)).ToArray();entry.Commands=string.Join('\n',lines);var lastOffset=lines.Take(7).Sum(l=>l.Length+1);
        foreach(var theme in themes)foreach(var scale in new[]{(Ui:1f,Font:1f),(Ui:1f,Font:1.3f),(Ui:1.25f,Font:1.25f),(Ui:1.5f,Font:1.5f),(Ui:2f,Font:2f)})
        {
            config.Theme=theme;ImGuiHelpers.GlobalScale=scale.Ui;io.FontGlobalScale=scale.Font;Resize((int)(1536*scale.Ui),(int)(1024*scale.Ui));window.TestOpen(entry);Scroll("task-body",0);Scroll("editor-scroll",0);for(var n=0;n<10;n++)Frame();
            var editor=window.TestCodeEditor;var point=editor.TestOrigin+new Vector2(1,editor.TestLineHeight*7.5f);Check(point.Y<editor.TestMaximum.Y,"eighth line does not fit normal editor");ClickAt(point);
            var state=ImGui.GetCurrentContext().InputTextState;Check(state.Stb.Cursor==lastOffset,$"eighth-line click off by one: {theme}/{scale}");
            Check(MathF.Abs(ImGui.GetCurrentContext().PlatformImeData.InputLineHeight-editor.TestLineHeight)<.01f,"native caret / painted line height mismatch");
            Key(ImGuiKey.End,shift:true);state=ImGui.GetCurrentContext().InputTextState;
            Check(Math.Min(state.Stb.SelectStart,state.Stb.SelectEnd)==lastOffset&&Math.Max(state.Stb.SelectStart,state.Stb.SelectEnd)==entry.Commands.Length,"last-line selection includes previous line");
            Check(state.ScrollX>0,"long line did not scroll horizontally");Key(ImGuiKey.Home,ctrl:true);io.AddInputCharacter('中');Frame();Check(entry.Commands.StartsWith("中/echo"),"CJK insertion misaligned");Key(ImGuiKey.Z,ctrl:true);Check(entry.Commands==string.Join('\n',lines),"native undo lost commands");
            Click("task-Execution");Navigate(MainWindow.TaskPage.Macros);
        }
        ImGuiHelpers.GlobalScale=1;io.FontGlobalScale=1;Resize(1536,1024);var readable=Enumerable.Range(1,8).Select(i=>$"/echo 第 {i} 行：编辑自动保存；只选中当前这一行").ToArray();entry.Commands=string.Join('\n',readable);
        foreach(var theme in themes)
        {
            config.Theme=theme;window.TestOpen(entry);Frame();for(var n=0;n<25;n++)Frame();var editor=window.TestCodeEditor;ClickAt(editor.TestOrigin+new Vector2(1,editor.TestLineHeight*7.5f));Key(ImGuiKey.End,shift:true);
            var state=ImGui.GetCurrentContext().InputTextState.Stb;Check(Math.Min(state.SelectStart,state.SelectEnd)==readable.Take(7).Sum(l=>l.Length+1)&&Math.Max(state.SelectStart,state.SelectEnd)==entry.Commands.Length,"readable eighth-line regression");
            SoftwareRenderer.Save(Path.Combine(output,$"last-line-aligned-{theme}.png"));Navigate(MainWindow.TaskPage.Execution);Navigate(MainWindow.TaskPage.Macros);
        }
        entry.Commands=string.Join('\n',Enumerable.Range(1,120).Select(i=>lines[i%8]));window.TestOpen(entry);Frame();Frame();ClickAt(window.TestCodeEditor.TestOrigin+new Vector2(2,8));Key(ImGuiKey.End);
        var horizontalOrigin=window.TestCodeEditor.TestOrigin.X;var scrollbar=new Vector2(window.TestCodeEditor.TestMaximum.X+7,window.TestCodeEditor.TestMinimum.Y+10);
        io.AddMousePosEvent(scrollbar.X,scrollbar.Y);Frame();io.AddMouseButtonEvent(0,true);Frame();Check(ImGui.GetCurrentContext().ActiveId!=ImGui.GetCurrentContext().InputTextState.ID,"native scrollbar did not take active ID");
        Check(MathF.Abs(window.TestCodeEditor.TestOrigin.X-horizontalOrigin)<.01f,"vertical drag reset horizontal overlay origin");io.AddMousePosEvent(scrollbar.X,scrollbar.Y+65);Frame();
        Check(MathF.Abs(window.TestCodeEditor.TestOrigin.X-horizontalOrigin)<.01f,"dragging separated native selection from painted text");io.AddMouseButtonEvent(0,false);Frame();Navigate(MainWindow.TaskPage.Execution);Navigate(MainWindow.TaskPage.Macros);
    }
    private static void VerifyResponsive(Configuration config,MacroEntry entry,MacroExecutor executor)
    {
        var io=ImGui.GetIO();entry.Commands="/echo 布局测试\n/wait 1";
        foreach(var theme in themes)foreach(var sample in new[]{(W:720,H:500,Ui:1f,Font:1f),(W:720,H:500,Ui:1f,Font:1.3f),(W:1120,H:760,Ui:1f,Font:1f),(W:1280,H:800,Ui:1f,Font:1f),(W:1920,H:1200,Ui:1.5f,Font:1.5f)})
        {
            config.Theme=theme;ImGuiHelpers.GlobalScale=sample.Ui;io.FontGlobalScale=sample.Font;Resize(sample.W,sample.H);window.TestOpen(entry);Scroll("task-body",0);
            foreach(var page in Enum.GetValues<MainWindow.TaskPage>())
            {
                Navigate(page);Check(window.TestTaskPage==page,"narrow navigation unreachable: "+page);Check(InRegion("stop","footer"),"stop clipped at scale "+sample);
                var action=page switch{MainWindow.TaskPage.Macros or MainWindow.TaskPage.Groups=>"edit-run",MainWindow.TaskPage.QuickBar=>"quick-add",MainWindow.TaskPage.NativeImport=>"native-import",MainWindow.TaskPage.Bridge=>"generate",MainWindow.TaskPage.Display=>"display-save",MainWindow.TaskPage.Countdown=>"countdown-enabled",MainWindow.TaskPage.Backup=>"backup-replace",MainWindow.TaskPage.Execution=>"setting-wait",_=>"setting-floating-size"};
                Seek(action);Scroll("task-body",0);
            }
            Navigate(MainWindow.TaskPage.Macros);Scroll("task-body",0);Seek("edit-run");Check(!executor.IsRunning,"responsive navigation automatically ran");Scroll("task-body",0);
            Capture($"responsive-{theme}-{sample.W}-f{sample.Font:0.0}.png",sample.W,sample.H);
        }
        ImGuiHelpers.GlobalScale=1;io.FontGlobalScale=1;Resize(1536,1024);Scroll("task-body",0);
        for(var n=0;n<28;n++)config.Macros.Add(new(){Name=$"列表滚动测试 {n:00}",Commands="/echo test",Pinned=true});config.Normalize();var last=config.Macros[^1];window.TestOpen(last);Frame();Frame();
        Check(window.UiItems.TryGetValue("tree-"+last.Id,out var lastRow)&&lastRow.Min.Y>=window.ThemeRegions["tree-list"].Min.Y-1&&lastRow.Max.Y<=window.ThemeRegions["tree-list"].Max.Y+1,"last selected macro not revealed in list");
        foreach(var theme in themes)foreach(var sample in new[]{(W:1536,H:1024,Ui:1f,Font:1f),(W:1280,H:1000,Ui:1f,Font:1.3f),(W:1920,H:1536,Ui:1.5f,Font:1.5f)})
        {
            config.Theme=theme;ImGuiHelpers.GlobalScale=sample.Ui;io.FontGlobalScale=sample.Font;Resize(sample.W,sample.H);for(var n=0;n<10;n++)Frame();Check(bar.Regions.TryGetValue("dock-items",out var dock),"dock absent");
            foreach(var item in bar.UiItems.Where(x=>x.Key.StartsWith("run-")).Select(x=>x.Value))Check(item.Min.Y>=dock.Min.Y-.5f&&item.Max.Y<=dock.Max.Y+.5f,"dock item vertically clipped");
            io.AddMousePosEvent(dock.Min.X+20,(dock.Min.Y+dock.Max.Y)/2);Frame();for(var n=0;n<8;n++){io.AddMouseWheelEvent(-50,0);Frame();}
            Check(bar.UiItems.ContainsKey("run-"+last.Id),"last quickbar entry unreachable");if(sample==(1536,1024,1f,1f))Capture($"dock-complete-{theme}.png",1536,1024);
        }
        ImGuiHelpers.GlobalScale=1;io.FontGlobalScale=1;Resize(1536,1024);
    }
}
