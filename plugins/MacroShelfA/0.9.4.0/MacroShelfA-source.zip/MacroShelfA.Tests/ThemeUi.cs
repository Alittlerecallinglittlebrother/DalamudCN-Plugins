using System.Numerics;
using System.Reflection;
using System.Text.Json;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

internal static unsafe class ThemeUi
{
    private static int width=1536,height=960,checks;
    private static string directory="";
    private static QuickBarWindow bar=null!;
    private static readonly List<object> Geometry=[];
    private static void Check(bool ok,string message){if(!ok)throw new Exception(message);checks++;}
    internal sealed class Artwork : IShelfArtwork
    {
        public Artwork()
        {
            foreach(var (id,name) in new[]{(201UL,"P3Makoto.png"),(202UL,"ShelfWordmark.png"),(203UL,"ShelfLettering.png")})
            {
                using var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("MacroShelfA.Resources."+name)!;
                SoftwareRenderer.RegisterTexture(id,stream);
            }
        }
        public void Draw(ImDrawListPtr list,bool wordmark,Vector2 minimum,Vector2 maximum,uint tint=0xffffffff)=>list.AddImage(new ImTextureID(wordmark?202UL:201UL),minimum,maximum,Vector2.Zero,Vector2.One,tint);
        public bool DrawLettering(ImDrawListPtr list,string label,Vector2 minimum,float height,uint tint=0xffffffff)
        {
            if(!ShelfArtwork.TryLetter(label,out var r))return false;
            list.AddImage(new ImTextureID(203UL),minimum,minimum+new Vector2(height*r.Width/r.Height,height),new Vector2(r.X/1600,r.Y/600),new Vector2((r.X+r.Width)/1600,(r.Y+r.Height)/600),tint);return true;
        }
    }
    private sealed class Display : ISkillDisplayProvider
    {
        public SkillDisplaySnapshot GetSnapshot(uint id)=>id==1?new(SkillAvailability.Ready,1,0,0,1,2,0,100):id==2?new(SkillAvailability.Cooldown,2,42,0,0,1,8.2f,100):SkillDisplaySnapshot.Unknown;
        public SkillCatalogEntry? GetSkill(uint id)=>id==1?new(1,"示例充能技能",0):id==2?new(2,"示例冷却技能",0):null;
    }
    public static void Run(string output)
    {
        directory=output;Directory.CreateDirectory(output);checks=0;Geometry.Clear();
        using var native=new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory,"cimgui.dll"));
        ImGui.InitApi(native);var context=ImGui.CreateContext();
        try
        {
            var io=ImGui.GetIO();io.IniFilename=null;io.DeltaTime=1f/60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc",17,default,io.Fonts.GetGlyphRangesChineseFull());
            Check(io.Fonts.Build(),"theme font atlas failed");ImGui.StyleColorsDark();
            VerifyThemeIsolation();VerifyMotion();
            var legacy=Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>("{\"Version\":9,\"Macros\":[{\"Name\":\"旧宏\",\"Commands\":\"/echo retained\"}]}")!;
            legacy.Normalize();
            Check(legacy.Theme==ShelfTheme.Persona3&&legacy.ShowThemeDecoration&&legacy.ShowWorkbenchQuickBar&&legacy.Macros[0].Commands=="/echo retained","existing config did not receive additive theme defaults");
            legacy.Theme=(ShelfTheme)999;legacy.Normalize();Check(legacy.Theme==ShelfTheme.Persona3,"invalid stored theme did not recover");
            var config=new Configuration{AllowLongMacros=true,AdvancedWorkbench=true,ShowGettingStarted=false};
            var group=new MacroEntry{Name="花间序曲",Group="演出舞蹈",IsGroup=true,Pinned=true,DisplayActionId=1};
            foreach(var name in new[]{"01 开场","02 主段","03 间奏","04 谢幕"})group.Children.Add(new MacroEntry{Name=name,Commands="/echo 主段开始\n/wait 0.5\n/echo 下一动作\n/wait 1\n/echo 谢幕准备\n/echo 主段结束",DisplayActionId=1});
            var child=group.Children[1];child.Pinned=true;config.Macros.Add(group);
            config.Macros.Add(new MacroEntry{Name="月下独舞",Group="演出舞蹈",Commands="/echo 月下独舞",Pinned=true,DisplayActionId=2});
            foreach(var name in new[]{"暖场问候","落幕谢礼"})config.Macros.Add(new MacroEntry{Name=name,Group="演出舞蹈",Commands="/echo "+name});
            config.Normalize();var now=0.0;using var executor=new MacroExecutor(config,()=>now);
            using var window=new MainWindow(config,executor,new BetterWaitPatch()){Artwork=new Artwork(),SkillDisplay=new Display()};
            bar=new QuickBarWindow(config,executor,window,window.SkillDisplay,_=>{});window.DrawQuickDock=bar.DrawDocked;
            var imports=0;MacroEntry? displayed=null,bridged=null;
            window.OpenNativeMacroImport=()=>imports++;window.OpenDisplaySettings=m=>displayed=m;window.OpenNativeMacroBridge=m=>bridged=m;
            window.TestOpen(child);Frame(window);Frame(window);
            foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})
            {
                SelectTheme(window,theme);Check(config.Theme==theme,"theme did not persist: "+theme);
                var persisted=Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
                Check(persisted.Theme==theme,"theme lost during configuration round trip");
                Capture(window,$"theme-{Slug(theme)}-1536.png",1536,1024);
                var originalPinned=child.Pinned;
                Click(window,"tree-pin-"+child.Id);Check(child.Pinned!=originalPinned&&window.TestSelected==child&&!executor.IsRunning,"tree star selected/executed instead of only pinning");
                Click(window,"tree-pin-"+child.Id);Check(child.Pinned==originalPinned,"tree star did not restore favorite");
                window.TestOpen(group);Frame(window);ClickDock(window,"direct-edit-"+child.Id);
                Check(window.TestSelected==child&&!executor.IsRunning,"direct pencil edit executed or lost child identity");
                var beforeMotion=JsonSerializer.Serialize(config.Macros);
                Click(window,"nav-settings");Click(window,"setting-reduce-motion");Check(config.ReduceThemeMotion,"reduced motion setting not persisted");
                Check(Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!.ReduceThemeMotion,"reduced motion lost on config save");
                Click(window,"nav-editor");io.AddMousePosEvent(-100,-100);for(var settle=0;settle<30;settle++)Frame(window);
                var still=DrawFingerprint();for(var settle=0;settle<8;settle++)Frame(window);
                Check(still==DrawFingerprint(),"reduced motion did not freeze presentation: "+theme);
                Click(window,"nav-settings");Click(window,"setting-reduce-motion");Click(window,"nav-editor");
                Check(!config.ReduceThemeMotion&&JsonSerializer.Serialize(config.Macros)==beforeMotion,"motion setting altered macro contents");
                var stableRect=window.UiItems["edit-run"];io.AddMousePosEvent(stableRect.Min.X+20,stableRect.Min.Y+12);
                for(var tick=0;tick<12;tick++)Frame(window);
                Check(window.UiItems["edit-run"]==stableRect&&!executor.IsRunning,"hover animation moved native hit rectangle or ran macro");
                if(Environment.GetEnvironmentVariable("SHELF_CAPTURE_MOTION")=="1")CaptureMotion(window,theme);
                Click(window,"nav-library");Capture(window,$"theme-{Slug(theme)}-library.png",1536,1024);
                Capture(window,$"theme-{Slug(theme)}-library720.png",720,500);
                Check(window.UiItems.TryGetValue("inspect-edit",out var editRect)&&editRect.Max.X<=width&&editRect.Max.Y<=height,"narrow themed library lost inspector action");
                Resize(window,1536,1024);window.TestOpen(child);Frame(window);
                Check(window.TestLayout.EditorWidth>=500,"wide layout reduced the command editor too far");
                if(theme==ShelfTheme.Persona3)Check(window.ThemeRegions["artwork"].Max.X<=window.ThemeRegions["workbench"].Min.X,"P3 artwork occupies functional region");
                else Check(!window.ThemeRegions.ContainsKey("artwork"),"P3 artwork leaked to other theme");
                Check(window.UiItems.ContainsKey("direct-display")&&window.UiItems.ContainsKey("direct-bridge"),"wide right-side actions missing");
                Click(window,"direct-display");Check(ReferenceEquals(displayed,child)&&!executor.IsRunning,"skill action lost child scope or executed");
                Click(window,"direct-bridge");Check(ReferenceEquals(bridged,child)&&!executor.IsRunning,"bridge action wrote/executed or changed target");
                var importsBefore=imports;Click(window,"nav-native-import");Check(imports==importsBefore+1,"native import callback did not run exactly once");
                Click(window,"inline-cooldown");Check(!child.ShowSkillCooldown,"inline cooldown toggle not saved");Click(window,"inline-cooldown");
                Click(window,"sequence-"+group.Children[2].Id);Check(window.TestSelected==group.Children[2],"sequence selector lost child identity");
                Click(window,"tree-"+child.Id);Check(window.TestSelected==child&&!executor.IsRunning,"tree selection executes macro");
                var oldName=child.Name;Type(window,"edit-name","主题测试 · 主段");Click(window,"edit-favorite");
                Check(child.Name=="主题测试 · 主段"&&!child.Pinned,"always-visible properties did not save");
                Type(window,"edit-name",oldName);Click(window,"edit-favorite");
                var macrosBefore=JsonSerializer.Serialize(config.Macros);
                Click(window,"edit-run");Check(executor.IsRunning&&executor.TotalChildren==1&&executor.TotalLines==6,"child run scope changed");
                var lines=executor.TotalLines;SelectTheme(window,theme==ShelfTheme.Persona3?ShelfTheme.Needy:ShelfTheme.Persona3);
                Check(executor.IsRunning&&executor.TotalLines==lines&&JsonSerializer.Serialize(config.Macros)==macrosBefore,"theme switch modified active execution/data");
                SelectTheme(window,theme);Capture(window,$"theme-{Slug(theme)}-running.png",1536,960);Click(window,"stop");
                Check(!executor.IsRunning,"stop not working after theme switch");
                Click(window,"edit-run-group");Check(executor.TotalChildren==4&&executor.IsRunning,"group run not explicit group scope");Click(window,"stop");
                ClickDock(window,"run-"+child.Id);Check(executor.IsRunning&&executor.TotalChildren==1,"docked child ran siblings");
                ClickDock(window,"run-"+group.Id);Check(executor.TotalChildren==1,"docked busy guard restarted execution");Click(window,"stop");
                window.TestOpen(group);Frame(window);ClickDock(window,"run-"+child.Id,1);ClickDock(window,"edit-"+child.Id);
                Check(window.TestSelected==child&&!executor.IsRunning,"docked context edit ran or selected the wrong macro");
                ClickDock(window,"dock-add");ClickDock(window,"pin-"+group.Children[0].Id);ClickDock(window,"picker-done");
                Check(group.Children[0].Pinned,"docked picker did not share favorites");
                ClickDock(window,"run-"+group.Children[0].Id,1);ClickDock(window,"remove-"+group.Children[0].Id);
                Check(!group.Children[0].Pinned&&group.Children.Count==4,"docked remove deleted the macro");
                ClickDock(window,"dock-manage");Check(window.UiItems.ContainsKey("setting-workbench-dock"),"docked manage did not open settings");Click(window,"nav-editor");
                Capture(window,$"theme-{Slug(theme)}-1280.png",1280,800);
                Check(window.TestLayout.HasSide&&window.UiItems.ContainsKey("direct-display")&&window.UiItems.ContainsKey("direct-bridge"),"default size hides direct actions");AssertCoreInside(window);
                var beforeAppearance=JsonSerializer.Serialize(config.Macros);
                Click(window,"nav-settings");Click(window,"setting-decoration");Click(window,"setting-workbench-dock");Click(window,"nav-editor");
                Capture(window,$"theme-{Slug(theme)}-minimal.png",1280,800);
                Check(window.TestLayout.ArtWidth==0&&window.TestLayout.DockHeight==0,"decoration/dock switches not respected");
                Check(JsonSerializer.Serialize(config.Macros)==beforeAppearance,"appearance toggles changed macro data");
                Click(window,"nav-settings");Click(window,"setting-decoration");Click(window,"setting-workbench-dock");Click(window,"nav-editor");
                Capture(window,$"theme-{Slug(theme)}-1120.png",1120,760);
                Check(window.TestLayout.ArtWidth==0&&!window.TestLayout.HasSide,"medium layout kept decoration at expense of controls");
                Click(window,"compact-tab-1");Click(window,"direct-display");Check(displayed==child,"compact skill tab changed scope");
                Click(window,"compact-tab-2");Click(window,"direct-bridge");Check(bridged==child,"compact bridge tab changed scope");
                Click(window,"compact-tab-0");
                Capture(window,$"theme-{Slug(theme)}-720.png",720,500);AssertCoreInside(window);
                ImGuiHelpers.GlobalScale=1.5f;io.FontGlobalScale=1.5f;
                Capture(window,$"theme-{Slug(theme)}-scale150.png",1080,750);AssertCoreInside(window);
                Check(window.TestLayout.ArtWidth==0&&window.TestLayout.DockHeight==0,"150% retained decorative consumption");
                Click(window,"edit-run");Click(window,"nav-countdown");Check(executor.IsRunning,"navigation interrupts execution");Click(window,"stop");
                Click(window,"nav-settings");Check(window.UiItems.ContainsKey("theme-selector"),"settings theme switch unreachable");
                Capture(window,$"theme-{Slug(theme)}-settings150.png",1080,750);
                Click(window,"nav-editor");ImGuiHelpers.GlobalScale=2;io.FontGlobalScale=2;
                Capture(window,$"theme-{Slug(theme)}-scale200.png",1440,1000);AssertCoreInside(window);
                ImGuiHelpers.GlobalScale=1;io.FontGlobalScale=1;Resize(window,1536,960);Click(window,"nav-editor");
            }
            // 400-line editing and a 64-child sequence stress the native editable controls, not a mock HTML layout.
            var longText=string.Join('\n',Enumerable.Range(1,400).Select(i=>$"/echo 第 {i:000} 行 中文测试 <wait.0.1>"));
            Type(window,"edit-commands",longText);Check(child.Commands==longText,"multiline text was truncated");
            var caret=ImGui.GetCurrentContext().InputTextState;
            Check(caret.Stb.Cursor==longText.Length,"CJK native caret and source positions diverged");
            io.AddKeyEvent(ImGuiKey.ModCtrl,true);io.AddKeyEvent(ImGuiKey.Home,true);Frame(window);io.AddKeyEvent(ImGuiKey.Home,false);io.AddKeyEvent(ImGuiKey.ModCtrl,false);Frame(window);
            io.AddInputCharacter('中');Frame(window);Check(child.Commands=="中"+longText,"native insertion edited the wrong code position");
            io.AddKeyEvent(ImGuiKey.ModCtrl,true);io.AddKeyEvent(ImGuiKey.Z,true);Frame(window);io.AddKeyEvent(ImGuiKey.Z,false);io.AddKeyEvent(ImGuiKey.ModCtrl,false);Frame(window);
            Check(child.Commands==longText,"syntax presentation broke native undo");
            Capture(window,"theme-p5-long-editor.png",1536,960);
            Click(window,"move-down");Check(group.Children[2]==child,"move down not persisted");Click(window,"move-up");Check(group.Children[1]==child,"move up not persisted");
            Click(window,"duplicate");var copy=window.TestSelected!;Check(copy!=child&&copy.Commands==longText&&copy.Id!=child.Id,"duplicate lost independent identity");
            window.TestOpen(child);while(group.Children.Count<64)config.AddChild(group);Frame(window);
            Capture(window,"theme-64-children.png",1120,760);AssertCoreInside(window);
            Resize(window,1536,960);Click(window,"new-macro");Check(window.TestSelected!=null&&!window.TestSelected.IsGroup&&config.Macros.Contains(window.TestSelected),"new macro is not a direct action");
            Click(window,"new-group");Check(window.TestSelected?.IsGroup==true&&window.TestSelected.Children.Count==1,"new group is not a direct action");
            while(config.CountEntries()<Configuration.MaxEntries)config.Macros.Add(new MacroEntry{Name="容量测试 "+config.CountEntries(),Commands="/echo full"});
            config.Save();window.TestRefresh();window.TestOpen(child);Resize(window,1536,960);
            Click(window,"new-macro");Click(window,"new-group");Check(config.CountEntries()==Configuration.MaxEntries&&window.TestSelected==child,"full capacity allowed extra entries");
            Capture(window,"theme-200-entries.png",1536,960);
            var snapshot=JsonSerializer.Serialize(config.Macros);SelectTheme(window,ShelfTheme.Classic);Check(config.Theme==ShelfTheme.Classic&&JsonSerializer.Serialize(config.Macros)==snapshot,"classic fallback altered data");
            Click(window,"nav-settings");SelectTheme(window,ShelfTheme.Persona3);Check(config.Theme==ShelfTheme.Persona3,"classic-to-theme switch failed");
            Click(window,"nav-editor");var artwork=window.Artwork;window.Artwork=null;Capture(window,"theme-artwork-unavailable.png",1536,960);
            AssertCoreInside(window);window.Artwork=artwork;
            Click(window,"nav-editor");config.Macros.Clear();config.Save();window.TestRefresh();Frame(window);Frame(window);
            Check(window.TestSelected==null&&!window.UiItems.ContainsKey("edit-run"),"deleted/replaced selection stayed runnable");
            Capture(window,"theme-empty.png",720,500);
            foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})
            foreach(var (w,h) in new[]{(720f,500f),(1120f,760f),(1536f,960f),(1920f,1080f)})
            {
                var layout=WorkbenchLayout.Calculate(w,h,theme,true,true);
                Check(layout.EditorWidth>300&&layout.BodyHeight>=180,"layout constraints invalid");
                Check(layout.ArtWidth==0||layout.ArtWidth/layout.Width<=.18,"artwork rail exceeds 18%");
            }
            File.WriteAllText(Path.Combine(output,"theme-geometry.json"),JsonSerializer.Serialize(Geometry,new JsonSerializerOptions{WriteIndented=true}));
            Console.WriteLine($"PASS three-theme native UI: {checks} assertions; live theme switch, art isolation, direct A/B/D, CJK editing, child/group scope, dock execution/picker/context/busy guard, responsive 720/1120/1280/1536/150%/200%, 64 children, 200 entries, classic fallback and empty state. Offline host, not in-game verification.");
        }
        catch { SoftwareRenderer.Save(Path.Combine(output,"theme-failure.png"));throw; }
        finally{SoftwareRenderer.ClearTextures();ImGuiHelpers.GlobalScale=1;ImGui.DestroyContext(context);}
    }
    private static string Slug(ShelfTheme theme)=>theme==ShelfTheme.Persona3?"p3":theme==ShelfTheme.Needy?"needy":"p5";
    private static void Frame(MainWindow window)
    {
        var io=ImGui.GetIO();io.DisplaySize=new Vector2(width,height);io.DeltaTime=1f/60;
        window.UiItems.Clear();window.ThemeRegions.Clear();bar.UiItems.Clear();
        ImGui.NewFrame();window.PreDraw();ImGui.SetNextWindowPos(Vector2.Zero,ImGuiCond.Always);ImGui.SetNextWindowSize(new Vector2(width,height),ImGuiCond.Always);
        ImGui.Begin("Macro Shelf-A###ThemeHost",ImGuiWindowFlags.NoResize|ImGuiWindowFlags.NoMove|ImGuiWindowFlags.NoCollapse|window.Flags);
        window.Draw();ImGui.End();window.PostDraw();ImGui.Render();
    }
    private static void Resize(MainWindow window,int w,int h){width=w;height=h;Frame(window);Frame(window);}
    private static void Capture(MainWindow window,string name,int w,int h)
    {
        Resize(window,w,h);ImGui.GetIO().AddMousePosEvent(-100,-100);for(var tick=0;tick<30;tick++)Frame(window);SoftwareRenderer.Save(Path.Combine(directory,name));
        Geometry.Add(new{name,width,height,scale=ImGuiHelpers.GlobalScale,layout=window.TestLayout,items=window.UiItems.ToDictionary(p=>p.Key,p=>new{min=new[]{p.Value.Min.X,p.Value.Min.Y},max=new[]{p.Value.Max.X,p.Value.Max.Y}})});
    }
    private static void AssertCoreInside(MainWindow window)
    {
        foreach(var key in new[]{"new-macro","new-group","nav-native-import","edit-run","stop"})
        {
            Check(window.UiItems.TryGetValue(key,out var r),"responsive control missing: "+key);
            Check(r.Min.X>=0&&r.Min.Y>=0&&r.Max.X<=width&&r.Max.Y<=height,"responsive control clipped: "+key);
        }
        Check(window.UiItems.TryGetValue("edit-commands",out var editor),"narrow layout hid the command editor under properties");
        Check(editor.Max.Y-editor.Min.Y>=45*ImGuiHelpers.GlobalScale,"narrow command input has unusable height");
    }
    private static void VerifyThemeIsolation()
    {
        var style=ImGui.GetStyle();var before=Enumerable.Range(0,(int)ImGuiCol.Count).Select(i=>style.Colors[i]).ToArray();
        var poison=new Vector4(.137f,.973f,.313f,.613f);
        foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})
        {
            for(var i=0;i<before.Length;i++)style.Colors[i]=poison;
            var round=style.FrameRounding;var windowRound=style.WindowRounding;var border=style.FrameBorderSize;
            using(ShelfSkin.Apply(theme,true))
            {
                for(var i=0;i<before.Length;i++)Check(style.Colors[i]!=poison,$"inherited color leaked: {theme}/{(ImGuiCol)i}");
                Check(ShelfMotion.Reduced,"motion scope not applied");
            }
            for(var i=0;i<before.Length;i++)Check(style.Colors[i]==poison,$"theme style escaped to other plugin: {theme}/{(ImGuiCol)i}");
            Check(style.FrameRounding==round&&style.WindowRounding==windowRound&&style.FrameBorderSize==border&&!ShelfMotion.Reduced,"theme style/motion scope not restored");
        }
        using(ShelfSkin.Apply(ShelfTheme.Classic))for(var i=0;i<before.Length;i++)Check(style.Colors[i]==poison,"classic theme unexpectedly replaced host colors");
        for(var i=0;i<before.Length;i++)style.Colors[i]=before[i];
    }
    internal static int VerifyStyleAndMotion(){checks=0;VerifyThemeIsolation();VerifyMotion();return checks;}
    private static void VerifyMotion()
    {
        var io=ImGui.GetIO();io.DisplaySize=new Vector2(1536,1024);io.DeltaTime=1f/60;
        float Step(bool reduced,bool hover)
        {
            ImGui.NewFrame();float v;using(ShelfSkin.Apply(ShelfTheme.Persona5,reduced)){v=ShelfMotion.Hover(0xFA120050,hover);Check(!reduced||ShelfMotion.Time==0,"reduced motion clock did not stop");}ImGui.Render();return v;
        }
        Step(true,false);var first=Step(false,true);var next=Step(false,true);
        Check(first>0&&first<next&&next<1,"hover has no time-based easing");
        Check(Step(true,true)==1&&Step(true,false)==0,"reduced hover does not snap to state");
    }
    internal static ulong DrawFingerprint()
    {
        var data=ImGui.GetDrawData();ulong hash=14695981039346656037;
        void Mix(uint value){hash^=value;hash*=1099511628211;}
        for(var l=0;l<data.CmdListsCount;l++)
        {
            ImDrawListPtr list=data.CmdLists[l];for(var i=0;i<list.VtxBuffer.Size;i++){var v=list.VtxBuffer[i];Mix(BitConverter.SingleToUInt32Bits(v.Pos.X));Mix(BitConverter.SingleToUInt32Bits(v.Pos.Y));Mix(v.Col);}
        }
        return hash;
    }
    private static void CaptureMotion(MainWindow window,ShelfTheme theme)
    {
        var folder=Path.Combine(directory,"motion-"+Slug(theme));Directory.CreateDirectory(folder);Resize(window,1536,1024);
        ImGui.GetIO().MouseDrawCursor=true;
        for(var frame=0;frame<40;frame++)
        {
            if(frame==15)Click(window,"nav-settings");if(frame==25)Click(window,"nav-editor");
            var key=frame<10?"new-macro":frame<15?"edit-run":frame<25?"nav-editor":"nav-settings";
            if(window.UiItems.TryGetValue(key,out var r)){var p=(r.Min+r.Max)/2;ImGui.GetIO().AddMousePosEvent(p.X,p.Y);}
            for(var tick=0;tick<6;tick++)Frame(window);
            SoftwareRenderer.Save(Path.Combine(folder,$"{frame:000}.png"));
        }
        ImGui.GetIO().MouseDrawCursor=false;ImGui.GetIO().AddMousePosEvent(-100,-100);Frame(window);
    }
    private static void SelectTheme(MainWindow window,ShelfTheme theme){Click(window,"theme-selector");Click(window,"theme-"+theme);Frame(window);}
    private static void Click(MainWindow window,string key)
    {
        Frame(window);if(!window.UiItems.TryGetValue(key,out var rect))throw new Exception("theme native control unavailable: "+key);
        var p=(rect.Min+rect.Max)/2;Check(p.X>=0&&p.X<width&&p.Y>=0&&p.Y<height,"theme control outside viewport: "+key);
        var io=ImGui.GetIO();io.AddMousePosEvent(p.X,p.Y);Frame(window);io.AddMouseButtonEvent(0,true);Frame(window);io.AddMouseButtonEvent(0,false);Frame(window);Frame(window);
    }
    private static void ClickDock(MainWindow window,string key,int button=0)
    {
        Frame(window);if(!bar.UiItems.TryGetValue(key,out var rect))throw new Exception("docked native control unavailable: "+key);
        var p=(rect.Min+rect.Max)/2;Check(p.X>=0&&p.X<width&&p.Y>=0&&p.Y<height,"docked control outside viewport: "+key);
        var io=ImGui.GetIO();io.AddMousePosEvent(p.X,p.Y);Frame(window);io.AddMouseButtonEvent(button,true);Frame(window);io.AddMouseButtonEvent(button,false);Frame(window);Frame(window);
    }
    private static void Type(MainWindow window,string key,string value)
    {
        Click(window,key);var io=ImGui.GetIO();io.AddKeyEvent(ImGuiKey.ModCtrl,true);io.AddKeyEvent(ImGuiKey.A,true);Frame(window);
        io.AddKeyEvent(ImGuiKey.A,false);io.AddKeyEvent(ImGuiKey.ModCtrl,false);Frame(window);foreach(var c in value)io.AddInputCharacter(c);Frame(window);Frame(window);
    }
}
