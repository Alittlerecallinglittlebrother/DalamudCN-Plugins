using System;
using System.Collections.Generic;
using System.Linq;

namespace MacroShelfA;

[Serializable]
public sealed class MacroEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");

    public string Name { get; set; } = "新宏";

    public string Group { get; set; } = string.Empty;

    public string Commands { get; set; } = string.Empty;

    public bool Pinned { get; set; }

    // Presentation only. A selected Action never changes the saved macro or casts it.
    public uint IconId { get; set; }
    public uint DisplayActionId { get; set; }
    public bool ShowSkillCooldown { get; set; } = true;
    public bool ShowSkillCharges { get; set; } = true;
    // Provenance of an imported COPY, not a live or cross-character binding.
    public int NativeSourceSet { get; set; } = -1;
    public int NativeSourceIndex { get; set; } = -1;

    // A group owns ordered copies, not references to entries elsewhere.
    public bool IsGroup { get; set; }
    public List<MacroEntry> Children { get; set; } = [];

    public MacroEntry Clone()
    {
        return new MacroEntry
        {
            Name = $"{Name} 副本",
            Group = Group,
            Commands = Commands,
            Pinned = Pinned,
            IconId = IconId,
            DisplayActionId = DisplayActionId,
            ShowSkillCooldown = ShowSkillCooldown,
            ShowSkillCharges = ShowSkillCharges,
            NativeSourceSet = NativeSourceSet,
            NativeSourceIndex = NativeSourceIndex,
            IsGroup = IsGroup,
            Children = Children.Select(child => child.Copy()).ToList(),
        };
    }

    public MacroEntry Copy()
    {
        var copy = Clone();
        copy.Name = Name;
        return copy;
    }
}
