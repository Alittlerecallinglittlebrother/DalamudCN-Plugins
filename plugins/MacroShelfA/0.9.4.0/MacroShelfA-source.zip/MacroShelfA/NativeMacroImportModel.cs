using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MacroShelfA;

// Only managed values cross the game-thread boundary. A snapshot never retains a native pointer.
internal readonly record struct NativeMacroIdentity(bool Available, ulong ContentId, uint EntityId,
    string Error = "")
{
    public bool Matches(NativeMacroIdentity other) => Available && other.Available &&
        ContentId != 0 && ContentId == other.ContentId && EntityId == other.EntityId;
}

internal sealed record NativeMacroSnapshotEntry(int Set, int Index, string Name, string Commands,
    uint IconId, string Error = "")
{
    public string Key => $"{Set}:{Index}";
    public bool IsEmpty => string.IsNullOrWhiteSpace(Name) && string.IsNullOrEmpty(Commands) && Error.Length == 0;
    public bool CanImport => !IsEmpty && Error.Length == 0;
    public string DisplayName => string.IsNullOrWhiteSpace(Name)
        ? IsEmpty ? "（空槽）" : $"{(Set == 0 ? "个人" : "共通")}宏 {Index:00}" : Name;
    public int LineCount => Commands.Length == 0 ? 0 : Commands.Count(c => c == '\n') + 1;
}

internal sealed record NativeMacroReadSnapshot(NativeMacroIdentity Identity,
    IReadOnlyList<NativeMacroSnapshotEntry> Entries, string Error = "")
{
    public bool Available => Identity.Available && Identity.ContentId != 0 && Error.Length == 0;
    public static NativeMacroReadSnapshot Unavailable(string error) => new(new(false, 0, 0, error), [], error);
}

internal interface INativeMacroReader
{
    Task<NativeMacroReadSnapshot> ReadAsync();
    Task<NativeMacroIdentity> ReadIdentityAsync();
}

internal static class NativeMacroImportModel
{
    private static readonly UTF8Encoding StrictUtf8 = new(false, true);
    public const int Sets = 2;
    public const int SlotsPerSet = 100;
    public const int LinesPerMacro = 15;
    public const int MaximumStringBytes = 4096;

    // SeString auto-translate and other payloads cannot round-trip through the existing plain-text
    // executor. Refuse the complete entry instead of stripping payloads or importing replacement text.
    public static bool TryDecodePlainText(ReadOnlySpan<byte> bytes, out string text, out string error)
    {
        text = string.Empty; error = string.Empty;
        if (bytes.Length > MaximumStringBytes) { error = "文本字节长度异常。"; return false; }
        if (bytes.Contains((byte)0x02) || bytes.Contains((byte)0x03))
        {
            error = "含自动翻译或其他 SeString 载荷，当前纯文本执行器不能无损导入。"; return false;
        }
        foreach (var value in bytes)
            if ((value < 0x20 && value != '\t') || value == 0x7F)
            { error = "文本含嵌入的控制字符，不能无损导入。"; return false; }
        try
        {
            text = StrictUtf8.GetString(bytes);
            if (text.Any(c => char.IsControl(c) && c != '\t'))
            { text = string.Empty; error = "文本含未支持的控制字符。"; return false; }
            return true;
        }
        catch (DecoderFallbackException) { error = "UTF-8 字节无效，已阻止有损导入。"; return false; }
    }

    public static NativeMacroSnapshotEntry DecodeEntry(int set, int index, uint iconId,
        ReadOnlySpan<byte> name, IReadOnlyList<byte[]> lines)
    {
        if (set is < 0 or >= Sets || index is < 0 or >= SlotsPerSet || lines.Count > LinesPerMacro)
            return new(set, index, string.Empty, string.Empty, iconId, "原生宏槽或行数异常。");
        if (!TryDecodePlainText(name, out var title, out var error))
            return new(set, index, "（名称无法读取）", string.Empty, iconId, $"名称：{error}");
        var decoded = new string[lines.Count];
        for (var i = 0; i < lines.Count; i++)
        {
            if (lines[i] == null || !TryDecodePlainText(lines[i], out decoded[i], out error))
                return new(set, index, title, string.Empty, iconId,
                    $"第 {i + 1} 行：{(lines[i] == null ? "文本数据缺失。" : error)}");
        }
        // Fixed native storage contains fifteen slots. Remove only unused trailing slots;
        // internal blank lines and every non-empty line retain their original order and spaces.
        var last = decoded.Length - 1;
        while (last >= 0 && decoded[last].Length == 0) last--;
        return new(set, index, title, string.Join('\n', decoded.Take(last + 1)), iconId);
    }

    public static int CountSameNames(Configuration configuration, IEnumerable<NativeMacroSnapshotEntry> entries)
    {
        var names = new HashSet<string>(configuration.Macros.SelectMany(m => m.IsGroup
            ? new[] { m }.Concat(m.Children) : new[] { m }).Select(m => m.Name), StringComparer.Ordinal);
        return entries.Count(e => names.Contains(e.DisplayName.Trim()));
    }

    public static bool TryCreateCopies(Configuration configuration,
        IEnumerable<NativeMacroSnapshotEntry> selected, string category,
        out List<MacroEntry> copies, out string error)
    {
        copies = []; error = string.Empty;
        var entries = selected.ToList();
        if (entries.Count == 0) { error = "请先选择至少一个可导入的宏。"; return false; }
        var normalizedCategory = (category ?? string.Empty).Trim();
        if (normalizedCategory.Length > Configuration.MaxGroupLength)
        { error = $"分类不能超过 {Configuration.MaxGroupLength} 个字符。"; return false; }
        if (normalizedCategory.Any(char.IsControl))
        { error = "分类不能包含控制字符。"; return false; }
        if (configuration.CountEntries() + entries.Count > Configuration.MaxEntries)
        { error = $"资料库剩余容量不足：需要 {entries.Count}，剩余 {Math.Max(0, Configuration.MaxEntries - configuration.CountEntries())}（含子宏）。"; return false; }
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var entry in entries)
        {
            if (entry.Set is < 0 or >= Sets || entry.Index is < 0 or >= SlotsPerSet || !seen.Add(entry.Key))
            { error = "选择包含无效或重复的原生宏槽。"; return false; }
            if (!entry.CanImport)
            { error = $"{entry.DisplayName}：{(entry.IsEmpty ? "空槽不能导入。" : entry.Error)}"; return false; }
            if (entry.DisplayName.Trim().Length > Configuration.MaxNameLength)
            { error = $"{entry.DisplayName}：名称超过 {Configuration.MaxNameLength} 个字符，未截断导入。"; return false; }
            if (entry.Commands.Length > Configuration.MaxCommandLength || entry.LineCount > LinesPerMacro)
            { error = $"{entry.DisplayName}：原生宏正文长度或行数异常。"; return false; }
            if (entry.Name.Any(c => char.IsControl(c)) || entry.Commands.Any(c => char.IsControl(c) && c != '\n' && c != '\t'))
            { error = $"{entry.DisplayName}：含未支持的控制字符。"; return false; }
        }
        var ids = new HashSet<string>(configuration.Macros.SelectMany(m => m.IsGroup
            ? new[] { m }.Concat(m.Children) : new[] { m }).Select(m => m.Id), StringComparer.Ordinal);
        var names = new HashSet<string>(configuration.Macros.SelectMany(m => m.IsGroup
            ? new[] { m }.Concat(m.Children) : new[] { m }).Select(m => m.Name), StringComparer.Ordinal);
        foreach (var entry in entries)
        {
            string id;
            do { id = Guid.NewGuid().ToString("N"); } while (!ids.Add(id));
            var name = entry.DisplayName.Trim();
            if (!names.Add(name))
            {
                var originalName = name;
                for (var suffix = 2; ; suffix++)
                {
                    var ending = $"（导入 {suffix}）";
                    var prefixLength = Math.Min(originalName.Length, Configuration.MaxNameLength - ending.Length);
                    // Never split a UTF-16 surrogate pair when making room for the collision suffix.
                    if (prefixLength > 0 && char.IsHighSurrogate(originalName[prefixLength - 1])) prefixLength--;
                    name = originalName[..prefixLength] + ending;
                    if (names.Add(name)) break;
                }
            }
            copies.Add(new MacroEntry
            {
                Id = id, Name = name, Commands = entry.Commands,
                Group = normalizedCategory, IconId = entry.IconId,
                NativeSourceSet = entry.Set, NativeSourceIndex = entry.Index,
                Pinned = false, IsGroup = false,
            });
        }
        return true;
    }

    public static bool TryImportCopies(Configuration configuration,
        IEnumerable<NativeMacroSnapshotEntry> selected, string category, Action persist,
        out int imported, out string error)
    {
        imported = 0;
        if (!TryCreateCopies(configuration, selected, category, out var copies, out error)) return false;
        var original = configuration.Macros;
        configuration.Macros = [.. original, .. copies];
        try { persist(); }
        catch (Exception exception)
        {
            // An interrupted save never leaves half a batch in the active in-memory library.
            configuration.Macros = original;
            error = $"保存导入结果失败，整批已回退：{exception.Message}"; return false;
        }
        imported = copies.Count; return true;
    }

    public static bool ValidateFreshSelection(NativeMacroReadSnapshot original,
        NativeMacroReadSnapshot fresh, IEnumerable<NativeMacroSnapshotEntry> selected, out string error)
    {
        error = string.Empty;
        if (!original.Available || !fresh.Available || !original.Identity.Matches(fresh.Identity))
        { error = "登录状态或角色已变化，请刷新后重新选择。"; return false; }
        var freshByKey = fresh.Entries.GroupBy(e => e.Key).ToDictionary(g => g.Key, g => g.ToList());
        foreach (var entry in selected)
            if (!freshByKey.TryGetValue(entry.Key, out var matches) || matches.Count != 1 || matches[0] != entry)
            { error = $"{entry.DisplayName} 已在游戏中修改或不可读取，请刷新后重新选择。"; return false; }
        return true;
    }
}
