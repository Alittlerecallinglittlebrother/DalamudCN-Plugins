using System;
using System.Collections.Generic;
using System.Linq;

namespace MacroShelfA.Runtime;

// The hotbar and UI share one existing executor. This class only resolves the exact
// saved identifier; names and list indexes are deliberately never treated as IDs.
internal static class MacroRunCommand
{
    internal delegate bool StartMacro(MacroEntry entry, out string error);
    public static bool IsRunCommand(string arguments)
    {
        var text = arguments.TrimStart();
        return text.Equals("run", StringComparison.OrdinalIgnoreCase) ||
            (text.Length > 3 && text[..3].Equals("run", StringComparison.OrdinalIgnoreCase) && char.IsWhiteSpace(text[3]));
    }

    public static bool IsSafeId(string? id) => !string.IsNullOrEmpty(id) && id.Length <= 128 &&
        id.All(c => c is >= 'a' and <= 'z' or >= 'A' and <= 'Z' or >= '0' and <= '9' or '-' or '_');

    public static bool TryParse(string arguments, out string id, out string error)
    {
        id = string.Empty;
        error = "用法：/aklmacro run <条目ID>。";
        // Whitespace between tokens is accepted; control bytes inside the argument
        // are not. A command may never contain another line, wait tag or command.
        if (arguments.Any(char.IsControl)) return false;
        var parts = arguments.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length != 2 || !parts[0].Equals("run", StringComparison.OrdinalIgnoreCase)) return false;
        if (!IsSafeId(parts[1])) { error = "条目 ID 格式无效；入口必须使用资料库的单一安全 ID。"; return false; }
        id = parts[1]; error = string.Empty; return true;
    }

    public static bool TryRun(string arguments, IEnumerable<MacroEntry> roots, StartMacro start, out string error)
    {
        if (!TryParse(arguments, out var id, out error)) return false;
        var matches = Enumerate(roots).Where(entry => string.Equals(entry.Id, id, StringComparison.Ordinal)).Take(2).ToArray();
        if (matches.Length == 0) { error = "入口指向的条目已删除或不存在；请重新生成入口宏。"; return false; }
        if (matches.Length != 1) { error = "入口 ID 不唯一；无法确定运行条目，请修复资料库后重新生成。"; return false; }
        return start(matches[0], out error);
    }

    public static IEnumerable<MacroEntry> Enumerate(IEnumerable<MacroEntry> roots)
    {
        foreach (var entry in roots)
        {
            if (entry == null) continue;
            yield return entry;
            if (entry.IsGroup && entry.Children != null)
                foreach (var child in entry.Children)
                    if (child != null) yield return child;
        }
    }
}
