using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace MacroShelfA.Runtime;

// Each operation gets a new file. No existing backup is opened for writing and no
// native write is permitted before Flush(true) has completed successfully.
internal sealed class NativeMacroBridgeBackups : INativeMacroBackupStore
{
    private readonly string directory;
    public NativeMacroBridgeBackups(string pluginConfigDirectory)
        => directory = Path.Combine(Path.GetFullPath(pluginConfigDirectory), "native-macro-backups");

    public void SaveNew(NativeMacroBackup backup)
    {
        Validate(backup);
        Directory.CreateDirectory(directory);
        var file = Path.Combine(directory, $"{backup.ContentId:X16}-{backup.Set}-{backup.Slot:D2}-{backup.Id}.json");
        var payload = JsonSerializer.SerializeToUtf8Bytes(Document.From(backup), new JsonSerializerOptions { WriteIndented = true });
        using var stream = new FileStream(file, FileMode.CreateNew, FileAccess.Write, FileShare.Read);
        stream.Write(payload); stream.Flush(true);
    }

    public IReadOnlyList<NativeMacroBackup> List(ulong contentId, int set, int slot)
    {
        if (contentId == 0 || set is < 0 or > 1 || slot is < 0 or >= 100 || !Directory.Exists(directory)) return [];
        var result = new List<NativeMacroBackup>();
        foreach (var file in Directory.EnumerateFiles(directory, $"{contentId:X16}-{set}-{slot:D2}-*.json"))
        {
            // Partial files left by an interrupted disk write cannot be offered
            // for restoration; malformed/tampered backups are not trusted.
            try
            {
                if (new FileInfo(file).Length > 2 * 1024 * 1024) continue;
                var document = JsonSerializer.Deserialize<Document>(File.ReadAllBytes(file));
                var backup = document?.ToBackup();
                if (backup == null || backup.ContentId != contentId || backup.Set != set || backup.Slot != slot) continue;
                Validate(backup); result.Add(backup);
            }
            catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or JsonException or ArgumentException or InvalidDataException)
            { /* A corrupt backup is never a restore candidate. */ }
        }
        return result.OrderByDescending(value => value.CreatedUtc).ToArray();
    }

    private static void Validate(NativeMacroBackup value)
    {
        if (!Guid.TryParseExact(value.Id, "N", out _) || value.ContentId == 0 || value.Set is < 0 or > 1 ||
            value.Slot is < 0 or >= 100 || value.Original == null || value.Replacement == null ||
            value.Operation is not ("generate" or "restore") || value.CreatedUtc == default || !MacroRunCommand.IsSafeId(value.EntryId))
            throw new InvalidDataException("原生宏备份的身份、槽位或内容无效。");
    }

    // Mutable serialization DTOs never escape this store. Content constructors
    // clone every array and verify their bounded fifteen-line shape.
    public sealed class Document
    {
        public int Version { get; set; } = 1;
        public string Id { get; set; } = "";
        public DateTime CreatedUtc { get; set; }
        public ulong ContentId { get; set; }
        public int Set { get; set; }
        public int Slot { get; set; }
        public string EntryId { get; set; } = "";
        public string Operation { get; set; } = "";
        public ContentDocument? Original { get; set; }
        public ContentDocument? Replacement { get; set; }
        public static Document From(NativeMacroBackup value) => new()
        {
            Id = value.Id, CreatedUtc = value.CreatedUtc, ContentId = value.ContentId, Set = value.Set, Slot = value.Slot,
            EntryId = value.EntryId, Operation = value.Operation, Original = ContentDocument.From(value.Original),
            Replacement = ContentDocument.From(value.Replacement),
        };
        public NativeMacroBackup ToBackup()
        {
            if (Version != 1 || Original == null || Replacement == null) throw new InvalidDataException("不支持此备份版本。");
            return new NativeMacroBackup(Id, CreatedUtc, ContentId, Set, Slot, EntryId, Operation, Original.ToContent(), Replacement.ToContent());
        }
    }
    public sealed class ContentDocument
    {
        public byte[]? Name { get; set; }
        public byte[][]? Lines { get; set; }
        public uint IconId { get; set; }
        public uint MacroIconRowId { get; set; }
        public string Fingerprint { get; set; } = "";
        public static ContentDocument From(NativeMacroContent value) => new()
        { Name = value.RawName, Lines = value.RawLines, IconId = value.IconId, MacroIconRowId = value.MacroIconRowId, Fingerprint = value.Fingerprint };
        public NativeMacroContent ToContent()
        {
            if (Name == null || Lines == null) throw new InvalidDataException("备份缺少原始字节。");
            var result = new NativeMacroContent(Name, Lines, IconId, MacroIconRowId);
            if (!string.Equals(result.Fingerprint, Fingerprint, StringComparison.Ordinal)) throw new InvalidDataException("备份校验值不匹配。");
            return result;
        }
    }
}
