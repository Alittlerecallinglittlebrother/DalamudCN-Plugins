using System;
using Dalamud.Game.ClientState.Conditions;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;

namespace MacroShelfA.Runtime;

internal sealed unsafe class NativeMacroBridgeHost : INativeMacroBridgeHost
{
    public bool TryResolveIcon(uint desiredIconId, out uint iconId, out uint macroIconRowId, out string error)
    {
        iconId = 0; macroIconRowId = 0;
        if (!Plugin.ClientState.IsLoggedIn || Plugin.Condition[ConditionFlag.LoggingOut] ||
            Plugin.Condition[ConditionFlag.BetweenAreas] || Plugin.Condition[ConditionFlag.BetweenAreas51])
        { error = "请先登录角色并等待载入完成后解析宏图标。"; return false; }
        try
        {
            // SetIcon's installed binding computes the real MacroIcon row mapping.
            // It acts on a local scratch value, never on a live slot before backup.
            var scratch = default(RaptureMacroModule.Macro);
            scratch.SetIcon(desiredIconId);
            iconId = scratch.IconId; macroIconRowId = scratch.MacroIconRowId;
            error = string.Empty; return true;
        }
        catch (Exception exception) { error = $"无法解析原生宏图标；未修改游戏宏。{exception.Message}"; return false; }
    }

    public bool TryPreview(int set, int slot, out NativeMacroPreview? preview, out string error)
    {
        preview = null;
        if (!TryReady(set, slot, out var contentId, out var module, out _, out error)) return false;
        var macro = module->GetMacro((uint)set, (uint)slot);
        if (macro == null) { error = "游戏原生宏槽位尚未就绪。"; return false; }
        try { preview = new NativeMacroPreview(contentId, set, slot, ReadContent(macro)); }
        catch (Exception exception) { error = $"无法完整读取宏槽位；未修改内容。{exception.Message}"; return false; }
        error = string.Empty; return true;
    }

    public bool TryWrite(NativeMacroPreview expected, NativeMacroContent replacement, out string error)
    {
        if (!TryReady(expected.Set, expected.Slot, out var contentId, out var module, out var hotbars, out error)) return false;
        var macro = module->GetMacro((uint)expected.Set, (uint)expected.Slot);
        if (contentId != expected.ContentId || macro == null)
        { error = "角色已切换或槽位尚未就绪；未修改游戏宏。"; return false; }
        try
        {
            if (!ReadContent(macro).SameAs(expected.Content))
            { error = "槽位已在备份期间变化；请刷新预览后重新确认。"; return false; }
        }
        catch (Exception exception)
        { error = $"无法完整比较当前槽位；未修改游戏宏。{exception.Message}"; return false; }
        // Preserve all opaque SeString bytes rather than decode/re-encode text or
        // split a concatenation on newlines. A restore can include payloads.
        try
        {
            SetRaw(ref macro->Name, replacement.RawName);
            var lines = replacement.RawLines;
            for (var index = 0; index < NativeMacroContent.LineCapacity; index++) SetRaw(ref macro->Lines[index], lines[index]);
            macro->IconId = replacement.IconId;
            macro->MacroIconRowId = replacement.MacroIconRowId;
            module->SetSavePendingFlag(true, (uint)expected.Set);
            module->SaveFile(false);
            hotbars->ReloadMacroSlots((byte)expected.Set, (byte)expected.Slot);
            if (!ReadContent(macro).SameAs(replacement))
            { error = "写入后内容校验不一致；原槽位已有完整备份，请检查并恢复。"; return false; }
            error = string.Empty; return true;
        }
        catch (Exception exception)
        {
            error = $"原生宏写入或保存失败；原槽位备份已落盘，可在备份列表恢复。{exception.Message}";
            return false;
        }
    }

    private static bool TryReady(int set, int slot, out ulong contentId, out RaptureMacroModule* module,
        out RaptureHotbarModule* hotbars, out string error)
    {
        contentId = 0; module = null; hotbars = null;
        error = "请先登录角色并等待原生宏与热键栏加载完成。";
        if (set is < 0 or > 1 || slot is < 0 or >= 100) { error = "无效的原生宏槽位。"; return false; }
        if (!Plugin.ClientState.IsLoggedIn || Plugin.Condition[ConditionFlag.LoggingOut] ||
            Plugin.Condition[ConditionFlag.BetweenAreas] || Plugin.Condition[ConditionFlag.BetweenAreas51]) return false;
        var player = PlayerState.Instance(); var local = Control.GetLocalPlayer();
        module = RaptureMacroModule.Instance(); hotbars = RaptureHotbarModule.Instance();
        if (player == null || !player->IsLoaded || player->ContentId == 0 || local == null ||
            local->EntityId != player->EntityId || module == null || hotbars == null || !hotbars->ModuleReady ||
            module->CharacterContentId != player->ContentId || hotbars->CharacterContentId != player->ContentId)
            return false;
        contentId = player->ContentId; error = string.Empty; return true;
    }

    internal static NativeMacroContent ReadContent(RaptureMacroModule.Macro* macro)
    {
        if (macro == null) throw new ArgumentException("宏地址为空。");
        var lines = new byte[NativeMacroContent.LineCapacity][];
        for (var index = 0; index < lines.Length; index++) lines[index] = ReadRaw(in macro->Lines[index]);
        return new NativeMacroContent(ReadRaw(in macro->Name), lines, macro->IconId, macro->MacroIconRowId);
    }

    internal static byte[] ReadRaw(in Utf8String value)
    {
        if (value.BufUsed < 1 || value.BufUsed > NativeMacroContent.MaximumRawLength + 1 ||
            value.BufSize < value.BufUsed || value.StringPtr.Value == null || value.StringPtr.Value[value.BufUsed - 1] != 0)
            throw new InvalidOperationException("原生字符串长度或缓冲区无效。");
        return value.AsSpan().ToArray();
    }

    internal static void SetRaw(ref Utf8String destination, byte[] raw)
    {
        var terminated = new byte[raw.Length + 1]; raw.CopyTo(terminated, 0);
        var temporary = default(Utf8String);
        fixed (byte* bytes = terminated)
        {
            temporary.Ctor_FromSequence(bytes, (nuint)raw.Length);
            try { destination.Copy(&temporary); }
            finally { temporary.Dtor(); }
        }
    }
}
