using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace MacroShelfA.Runtime;

internal sealed class NativeMacroContent
{
    public const int LineCapacity = 15;
    public const int MaximumRawLength = 32768;
    private readonly byte[] name;
    private readonly byte[][] lines;
    public uint IconId { get; }
    public uint MacroIconRowId { get; }
    public byte[] RawName => (byte[])name.Clone();
    public byte[][] RawLines => lines.Select(value => (byte[])value.Clone()).ToArray();
    public int LineCount => lines.Count(value => value.Length != 0);
    public bool IsEmpty => name.Length == 0 && LineCount == 0;
    public string DisplayName => Encoding.UTF8.GetString(name).Replace('\n', ' ').Replace('\r', ' ');
    public string DisplayCommands => string.Join('\n', lines.Take(Array.FindLastIndex(lines, value => value.Length != 0) + 1).Select(Encoding.UTF8.GetString));
    public string Fingerprint { get; }

    public NativeMacroContent(byte[] rawName, byte[][] rawLines, uint iconId, uint macroIconRowId)
    {
        if (rawName == null || rawName.Length > MaximumRawLength || rawLines == null || rawLines.Length != LineCapacity ||
            rawLines.Any(value => value == null || value.Length > MaximumRawLength))
            throw new ArgumentException("原生宏备份数据不完整或超出长度限制。");
        name = (byte[])rawName.Clone(); lines = rawLines.Select(value => (byte[])value.Clone()).ToArray();
        IconId = iconId; MacroIconRowId = macroIconRowId;
        using var stream = new MemoryStream(); using var writer = new BinaryWriter(stream);
        writer.Write(IconId); writer.Write(MacroIconRowId); writer.Write(name.Length); writer.Write(name);
        foreach (var value in lines) { writer.Write(value.Length); writer.Write(value); }
        writer.Flush(); Fingerprint = Convert.ToHexString(SHA256.HashData(stream.ToArray()));
    }

    public bool SameAs(NativeMacroContent other) => Fingerprint == other.Fingerprint;
    public static NativeMacroContent Empty() => new([], Enumerable.Range(0, LineCapacity).Select(_ => Array.Empty<byte>()).ToArray(), 0, 0);
    public static NativeMacroContent Bridge(string name, string entryId, uint iconId, uint macroIconRowId)
    {
        if (!MacroRunCommand.IsSafeId(entryId)) throw new ArgumentException("条目 ID 不能安全地写入原生入口宏。");
        var text = name.Replace('\r', ' ').Replace('\n', ' ');
        // Native macro names are restricted to twenty Unicode scalars. Never split
        // a surrogate pair when a name contains a supplementary character.
        var runes = text.EnumerateRunes().Where(r => !Rune.IsControl(r)).Take(20);
        var safeName = string.Concat(runes.Select(r => r.ToString()));
        if (string.IsNullOrWhiteSpace(safeName)) safeName = "Macro Shelf-A";
        var lines = Enumerable.Range(0, LineCapacity).Select(_ => Array.Empty<byte>()).ToArray();
        lines[0] = Encoding.UTF8.GetBytes($"/aklmacro run {entryId}");
        return new NativeMacroContent(Encoding.UTF8.GetBytes(safeName), lines, iconId, macroIconRowId);
    }
}

internal sealed record NativeMacroPreview(ulong ContentId, int Set, int Slot, NativeMacroContent Content);
internal sealed record NativeMacroBackup(string Id, DateTime CreatedUtc, ulong ContentId, int Set, int Slot,
    string EntryId, string Operation, NativeMacroContent Original, NativeMacroContent Replacement);

internal interface INativeMacroBridgeHost
{
    // Every production call must happen on Framework.Update. Writes compare the
    // expected identity and bytes again before touching a single live field.
    bool TryPreview(int set, int slot, out NativeMacroPreview? preview, out string error);
    bool TryResolveIcon(uint desiredIconId, out uint iconId, out uint macroIconRowId, out string error);
    bool TryWrite(NativeMacroPreview expected, NativeMacroContent replacement, out string error);
}

internal interface INativeMacroBackupStore
{
    void SaveNew(NativeMacroBackup backup);
    IReadOnlyList<NativeMacroBackup> List(ulong contentId, int set, int slot);
}

internal sealed class NativeMacroBridgeService
{
    private readonly INativeMacroBridgeHost host;
    private readonly INativeMacroBackupStore store;
    public NativeMacroBridgeService(INativeMacroBridgeHost host, INativeMacroBackupStore store)
    { this.host = host; this.store = store; }

    public bool TryPreview(int set, int slot, out NativeMacroPreview? preview, out string error)
    {
        preview = null;
        if (set is < 0 or > 1 || slot is < 0 or >= 100) { error = "请选择个人／共通宏及 0–99 的有效槽位。"; return false; }
        return host.TryPreview(set, slot, out preview, out error);
    }

    public bool TryFindEmpty(int set, out NativeMacroPreview? preview, out string error)
    {
        preview = null;
        for (var slot = 0; slot < 100; slot++)
        {
            if (!TryPreview(set, slot, out var candidate, out error)) return false;
            if (candidate!.Content.IsEmpty) { preview = candidate; return true; }
        }
        error = "当前宏页没有空槽；请选择槽位并明确确认覆盖。"; return false;
    }

    public IReadOnlyList<NativeMacroBackup> Backups(NativeMacroPreview preview) => store.List(preview.ContentId, preview.Set, preview.Slot);

    public bool TryGenerate(NativeMacroPreview preview, MacroEntry entry, IEnumerable<MacroEntry> roots,
        bool confirmedOverwrite, out string error)
    {
        var matches = MacroRunCommand.Enumerate(roots).Where(value => value.Id == entry.Id).Take(2).ToArray();
        if (matches.Length != 1 || !ReferenceEquals(matches[0], entry))
        { error = "条目已删除、被替换或 ID 不唯一；请重新选择条目。"; return false; }
        if (!MacroRunCommand.IsSafeId(entry.Id)) { error = "旧条目 ID 不能安全写入入口；请复制条目后使用新副本。"; return false; }
        if (!preview.Content.IsEmpty && !confirmedOverwrite)
        { error = "所选槽位已有宏；勾选覆盖确认后才会生成。"; return false; }
        var iconId = preview.Content.IconId; var iconRowId = preview.Content.MacroIconRowId;
        if (entry.IconId != 0 || preview.Content.IsEmpty || iconId == 0)
            if (!host.TryResolveIcon(entry.IconId == 0 ? 66001U : entry.IconId, out iconId, out iconRowId, out error)) return false;
        var replacement = NativeMacroContent.Bridge(entry.Name, entry.Id, iconId, iconRowId);
        return TryPersistAndWrite(preview, replacement, entry.Id, "generate", out error);
    }

    public bool TryRestore(NativeMacroPreview preview, NativeMacroBackup backup, bool confirmedForeignOverwrite, out string error)
    {
        if (backup.ContentId != preview.ContentId || backup.Set != preview.Set || backup.Slot != preview.Slot)
        { error = "备份不属于当前角色和槽位，不能恢复。"; return false; }
        if (!preview.Content.SameAs(backup.Replacement) && !confirmedForeignOverwrite)
        { error = "槽位已被游戏或其他操作修改；请检查预览并明确确认覆盖后恢复。"; return false; }
        return TryPersistAndWrite(preview, backup.Original, backup.EntryId, "restore", out error);
    }

    private bool TryPersistAndWrite(NativeMacroPreview expected, NativeMacroContent replacement, string entryId,
        string operation, out string error)
    {
        // The first check prevents misleading backups. Host.TryWrite performs the
        // same comparison a second time after durable backup IO has completed.
        if (!TryPreview(expected.Set, expected.Slot, out var current, out error)) return false;
        if (expected.ContentId == 0 || current!.ContentId != expected.ContentId || !current.Content.SameAs(expected.Content))
        { error = "角色或槽位内容已改变；请刷新预览后重新确认。"; return false; }
        var backup = new NativeMacroBackup(Guid.NewGuid().ToString("N"), DateTime.UtcNow,
            expected.ContentId, expected.Set, expected.Slot, entryId, operation, expected.Content, replacement);
        try { store.SaveNew(backup); }
        catch (Exception exception) { error = $"无法创建并落盘原槽位备份；未修改游戏宏。{exception.Message}"; return false; }
        if (!host.TryWrite(expected, replacement, out error)) return false;
        error = string.Empty; return true;
    }
}
