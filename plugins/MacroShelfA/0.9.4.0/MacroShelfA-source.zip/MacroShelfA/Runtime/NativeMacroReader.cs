using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dalamud.Game.ClientState.Conditions;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;

namespace MacroShelfA.Runtime;

// Read-only, framework-thread access through the ClientStructs already supplied by Dalamud.
// Constructing this reader never accesses the client; every request produces a managed snapshot.
internal sealed class NativeMacroReader : INativeMacroReader
{
    public Task<NativeMacroReadSnapshot> ReadAsync() => Plugin.Framework.RunOnFrameworkThread(ReadSnapshot);
    public Task<NativeMacroIdentity> ReadIdentityAsync() => Plugin.Framework.RunOnFrameworkThread(ReadIdentity);

    private static unsafe NativeMacroIdentity ReadIdentity()
    {
        if (!Plugin.ClientState.IsLoggedIn) return new(false, 0, 0, "请登录角色后刷新。");
        if (Plugin.Condition[ConditionFlag.BetweenAreas] || Plugin.Condition[ConditionFlag.BetweenAreas51] ||
            Plugin.Condition[ConditionFlag.LoggingOut]) return new(false, 0, 0, "切换区域或登出中，请稍后刷新。");
        var state = PlayerState.Instance();
        var local = Control.GetLocalPlayer();
        if (state == null || local == null || !state->IsLoaded || state->ContentId == 0 ||
            state->EntityId != local->EntityId) return new(false, 0, 0, "角色资料尚未就绪。");
        var module = RaptureMacroModule.Instance();
        if (module == null || module->CharacterContentId != state->ContentId)
            return new(false, 0, 0, "原生宏模块尚未就绪或不属于当前角色。");
        return new(true, state->ContentId, local->EntityId);
    }

    private static unsafe NativeMacroReadSnapshot ReadSnapshot()
    {
        var identity = ReadIdentity();
        if (!identity.Available) return NativeMacroReadSnapshot.Unavailable(identity.Error);
        var module = RaptureMacroModule.Instance();
        if (module == null || module->CharacterContentId != identity.ContentId)
            return NativeMacroReadSnapshot.Unavailable("原生宏模块已变化，请重新刷新。");
        var result = new List<NativeMacroSnapshotEntry>(NativeMacroImportModel.Sets * NativeMacroImportModel.SlotsPerSet);
        for (var set = 0; set < NativeMacroImportModel.Sets; set++)
        {
            var macros = set == 0 ? module->Individual : module->Shared;
            if (macros.Length != NativeMacroImportModel.SlotsPerSet)
                return NativeMacroReadSnapshot.Unavailable("原生宏槽数量与已安装客户端结构不匹配。");
            for (var index = 0; index < macros.Length; index++)
            {
                ref var macro = ref macros[index];
                if (!TryCopyBytes(in macro.Name, out var name, out var error))
                {
                    result.Add(new(set, index, "（名称无法读取）", string.Empty, macro.IconId, $"名称：{error}"));
                    continue;
                }
                var lines = new byte[NativeMacroImportModel.LinesPerMacro][];
                var failedLine = -1;
                if (macro.Lines.Length != lines.Length)
                {
                    result.Add(new(set, index, "（原生行数异常）", string.Empty, macro.IconId, "原生宏行数不匹配。"));
                    continue;
                }
                for (var line = 0; line < lines.Length; line++)
                    if (!TryCopyBytes(in macro.Lines[line], out lines[line], out error)) { failedLine = line; break; }
                if (failedLine >= 0)
                {
                    NativeMacroImportModel.TryDecodePlainText(name, out var title, out _);
                    result.Add(new(set, index, title, string.Empty, macro.IconId, $"第 {failedLine + 1} 行：{error}"));
                    continue;
                }
                result.Add(NativeMacroImportModel.DecodeEntry(set, index, macro.IconId, name, lines));
            }
        }
        var after = ReadIdentity();
        if (!identity.Matches(after)) return NativeMacroReadSnapshot.Unavailable("读取期间角色状态变化，请重新刷新。");
        return new(identity, result.AsReadOnly());
    }

    // Inspect the buffer bounds before materializing bytes. Do not use Utf8String.ToString(),
    // whose replacement decoder could silently change a command or strip its payload semantics.
    internal static unsafe bool TryCopyBytes(in Utf8String value, out byte[] bytes, out string error)
    {
        bytes = []; error = string.Empty;
        if (value.BufUsed < 1 || value.BufUsed > NativeMacroImportModel.MaximumStringBytes + 1 ||
            value.BufSize < value.BufUsed || (byte*)value.StringPtr == null)
        { error = "原生文本缓冲区尚未就绪或长度异常。"; return false; }
        var length = checked((int)value.BufUsed - 1);
        var pointer = (byte*)value.StringPtr;
        if (pointer[length] != 0) { error = "原生文本缺少结束符。"; return false; }
        var span = value.AsSpan();
        if (span.Length != length) { error = "原生文本长度校验失败。"; return false; }
        bytes = span.ToArray(); return true;
    }
}
