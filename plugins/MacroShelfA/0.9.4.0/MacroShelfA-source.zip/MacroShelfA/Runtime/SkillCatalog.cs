using System;
using System.Collections.Generic;
using System.Linq;
using Dalamud.Plugin.Services;
using GameAction = Lumina.Excel.Sheets.Action;

namespace MacroShelfA.Runtime;

internal sealed record SkillCatalogEntry(uint Id, string Name, uint IconId);

// Only local client data is searched. An absent/unsupported row must never be passed to native ActionManager.
internal sealed class SkillCatalog
{
    private readonly IDataManager? dataManager;
    private readonly object loadGate = new();
    private Dictionary<uint, SkillCatalogEntry>? entries;
    public string ErrorText { get; private set; } = string.Empty;

    public SkillCatalog(IDataManager dataManager) => this.dataManager = dataManager;
    // Offline UI/test seam: fixed catalog data, no client files or native calls required.
    public SkillCatalog(IEnumerable<SkillCatalogEntry> knownSkills) => entries = knownSkills.ToDictionary(e => e.Id);

    public SkillCatalogEntry? Find(uint id)
    {
        EnsureLoaded();
        return entries!.GetValueOrDefault(id);
    }
    public IReadOnlyList<SkillCatalogEntry> Search(string query, int maximum = 100)
    {
        EnsureLoaded();
        query = query.Trim();
        return entries!.Values.Where(e => query.Length == 0 || e.Name.Contains(query, StringComparison.OrdinalIgnoreCase)
                || e.Id.ToString().Contains(query, StringComparison.Ordinal))
            .OrderBy(e => e.Id).Take(Math.Clamp(maximum, 1, 200)).ToArray();
    }
    private void EnsureLoaded()
    {
        if (entries != null) return;
        lock (loadGate)
        {
            if (entries != null) return;
            var loaded = new Dictionary<uint, SkillCatalogEntry>();
            try
            {
                var sheet = dataManager!.GetExcelSheet<GameAction>();
                foreach (var row in sheet)
                {
                    var name = row.Name.ToString();
                    if (row.RowId == 0 || !row.IsPlayerAction || row.IsPvP || string.IsNullOrWhiteSpace(name)) continue;
                    loaded[row.RowId] = new(row.RowId, name, row.Icon);
                }
            }
            catch (Exception) { ErrorText = "本地 Action 数据暂不可用；技能状态保持未知。"; loaded.Clear(); }
            // Publish only a complete immutable-by-convention dictionary, never a partially loaded sheet.
            entries = loaded;
        }
    }
}
