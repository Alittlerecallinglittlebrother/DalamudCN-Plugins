using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.UI;

namespace MacroShelfA.Runtime;

// Framework-thread read-only snapshots. Rendering never dereferences game pointers or applies actions.
internal sealed unsafe class SkillDisplayService : ISkillDisplayProvider, IDisposable
{
    private readonly IFramework framework;
    private readonly IClientState clientState;
    private readonly ICondition condition;
    private readonly SkillCatalog catalog;
    private readonly SkillDisplayCache cache = new();
    private readonly Dictionary<uint, double> requested = [];
    private readonly object gate = new();
    private readonly long started = Stopwatch.GetTimestamp();
    private double lastPoll;
    private int cursor;
    private bool disposed;
    private double Now => Stopwatch.GetElapsedTime(started).TotalSeconds;

    public SkillDisplayService(Configuration configuration, IFramework framework, IClientState clientState,
        ICondition condition, SkillCatalog catalog)
    {
        this.framework = framework; this.clientState = clientState; this.condition = condition; this.catalog = catalog;
        framework.Update += Update;
    }

    public SkillCatalogEntry? GetSkill(uint actionId) => catalog.Find(actionId);
    public SkillDisplaySnapshot GetSnapshot(uint actionId)
    {
        if (disposed || actionId == 0 || catalog.Find(actionId) == null) return SkillDisplaySnapshot.Unknown;
        lock (gate)
        {
            if (!requested.ContainsKey(actionId) && requested.Count >= 256) return SkillDisplaySnapshot.Unknown;
            var now = Now; requested[actionId] = now;
            return cache.Get(actionId, now);
        }
    }

    private void Update(IFramework _)
    {
        if (disposed) return;
        lock (gate)
        {
            var now = Now;
            foreach (var id in requested.Where(p => now - p.Value > 3).Select(p => p.Key).ToArray()) requested.Remove(id);
            if (requested.Count == 0) { cache.Clear(); return; }
            try
            {
                var usable = SkillDisplayLifecycle.CanRead(clientState.IsLoggedIn, condition[ConditionFlag.LoggingOut],
                    condition[ConditionFlag.BetweenAreas], condition[ConditionFlag.BetweenAreas51]);
                var local = usable ? Control.GetLocalPlayer() : null;
                var player = usable ? PlayerState.Instance() : null;
                var targetSystem = usable ? TargetSystem.Instance() : null;
                var target = targetSystem == null ? 0xE0000000ul : (ulong)targetSystem->GetTargetObjectId();
                var context = new SkillDisplayContext(local != null && player != null && player->IsLoaded &&
                    player->ContentId != 0 && player->EntityId == local->EntityId && local->ClassJob != 0 && player->CurrentClassJobId == local->ClassJob,
                    player == null ? 0 : player->ContentId, local == null ? 0 : local->EntityId,
                    local == null ? (byte)0 : local->ClassJob, clientState.TerritoryType, target);
                if (!cache.Synchronize(context)) { lastPoll = 0; return; }
                if (now - lastPoll < .1) return;
                lastPoll = now;
                var manager = ActionManager.Instance();
                if (manager == null || targetSystem == null) { cache.Clear(); return; }
                var ids = requested.Keys.OrderBy(x => x).ToArray();
                // Bounded round-robin: at most 32 skills / 100 ms, 256 requests, no polling of unshown macros.
                for (var i = 0; i < Math.Min(32, ids.Length); i++)
                {
                    var id = ids[cursor++ % ids.Length];
                    var adjusted = manager->GetAdjustedActionId(id);
                    if (catalog.Find(adjusted) == null) { cache.Put(id, SkillDisplaySnapshot.Unknown, now); continue; }
                    var info = new HotbarCooldownInfo();
                    manager->GetHotbarCooldownInfo(&info, ActionType.Action, adjusted);
                    var sample = new SkillDisplaySample(true, adjusted,
                        manager->GetActionStatus(ActionType.Action, adjusted, target),
                        manager->GetActionStatus(ActionType.Action, adjusted, target, false, false),
                        manager->GetCurrentCharges(adjusted), info.CurrentMaxCharges, info.CooldownActive,
                        info.PrimaryElapsedTime, info.PrimaryTotalTime, info.AdditionalElapsedTime, info.AdditionalTotalTime, target);
                    cache.Put(id, SkillDisplaySnapshot.Interpret(sample), now);
                }
                if (cursor > 100000) cursor = 0;
            }
            catch (Exception) { cache.Clear(); }
        }
    }

    public void Dispose()
    {
        disposed = true; framework.Update -= Update;
        lock (gate) { requested.Clear(); cache.Clear(); }
    }
}
