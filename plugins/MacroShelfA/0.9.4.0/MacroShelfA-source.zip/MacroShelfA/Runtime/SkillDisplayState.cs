using System;
using System.Collections.Generic;

namespace MacroShelfA.Runtime;

internal enum SkillAvailability { Unknown, Ready, Cooldown, Conditions }

internal static class SkillDisplayLifecycle
{
    public static bool CanRead(bool loggedIn, bool loggingOut, bool betweenAreas, bool betweenAreas51)
        => loggedIn && !loggingOut && !betweenAreas && !betweenAreas51;
}

internal readonly record struct SkillDisplaySample(bool Available, uint AdjustedActionId,
    uint Status, uint ConditionsStatus, uint Charges, int MaxCharges,
    bool CooldownActive, float PrimaryElapsed, float PrimaryTotal,
    float AdditionalElapsed, float AdditionalTotal, ulong TargetId);

internal readonly record struct SkillDisplaySnapshot(SkillAvailability Availability, uint AdjustedActionId,
    uint Status, uint ConditionsStatus, uint Charges, int MaxCharges, float Remaining, ulong TargetId)
{
    public static SkillDisplaySnapshot Unknown => default;
    public string StateText => Availability switch
    {
        SkillAvailability.Ready => "可用",
        SkillAvailability.Cooldown => "冷却中",
        SkillAvailability.Conditions => "条件不满足",
        _ => "未知",
    };

    public string Label(bool cooldown, bool charges)
    {
        var label = StateText;
        if (charges && Availability != SkillAvailability.Unknown && MaxCharges > 1) label += $" · {Charges}/{MaxCharges}";
        if (cooldown && Availability != SkillAvailability.Unknown && Remaining > .05f) label += $" · {Remaining:F1}s";
        return label;
    }

    public static SkillDisplaySnapshot Interpret(SkillDisplaySample s)
    {
        if (!s.Available || s.AdjustedActionId == 0 || s.MaxCharges is < 1 or > 10 || s.Charges > s.MaxCharges ||
            !ValidTimer(s.PrimaryElapsed, s.PrimaryTotal) || !ValidTimer(s.AdditionalElapsed, s.AdditionalTotal))
            return Unknown;
        // Hotbar totals already account for the current player's level. A primary total is the full charge pool.
        // A partial charge is usable: never gray 1/2 merely because the pool is still replenishing.
        var nextCharge = s.PrimaryTotal / s.MaxCharges;
        var primary = s.CooldownActive && nextCharge > 0 && s.Charges < s.MaxCharges
            ? MathF.Max(0, nextCharge - s.PrimaryElapsed % nextCharge) : 0;
        var additional = MathF.Max(0, s.AdditionalTotal - s.AdditionalElapsed);
        var availability = s.ConditionsStatus != 0 ? SkillAvailability.Conditions
            : (s.Charges == 0 && s.CooldownActive) || additional > .05f ? SkillAvailability.Cooldown
            : s.Status == 0 && s.Charges > 0 ? SkillAvailability.Ready : SkillAvailability.Conditions;
        // If a charge exists, only the additional/GCD timer blocks usage. Do not label the whole recharge pool
        // as an unavailable cooldown; on Ready the displayed primary timer is explicitly the next recharge.
        var remaining = s.Charges > 0 && additional > .05f ? additional : MathF.Max(primary, additional);
        return new(availability, s.AdjustedActionId, s.Status, s.ConditionsStatus, s.Charges, s.MaxCharges,
            remaining, s.TargetId);
    }

    private static bool ValidTimer(float elapsed, float total) => float.IsFinite(elapsed) && float.IsFinite(total)
        && elapsed >= 0 && total >= 0 && total <= 86400 && elapsed <= total + .1f;
}

internal readonly record struct SkillDisplayContext(bool Available, ulong ContentId, uint EntityId, byte Job, uint Territory, ulong TargetId = 0);

// Managed-only, runtime-only cache. Tests exercise invalidation without ever resolving native addresses.
internal sealed class SkillDisplayCache
{
    private readonly Dictionary<uint, (SkillDisplaySnapshot Snapshot, double At)> snapshots = [];
    private SkillDisplayContext? context;
    public const double MaximumAge = 2;

    public bool Synchronize(SkillDisplayContext next)
    {
        var changed = context != next;
        if (changed || !next.Available) snapshots.Clear();
        context = next;
        // Require one settled observation after a player/job/zone transition.
        return !changed && next.Available;
    }
    public void Put(uint actionId, SkillDisplaySnapshot snapshot, double now)
    {
        if (context is { Available: true } && double.IsFinite(now)) snapshots[actionId] = (snapshot, now);
    }
    public SkillDisplaySnapshot Get(uint actionId, double now)
    {
        if (!double.IsFinite(now) || !snapshots.TryGetValue(actionId, out var saved) || now < saved.At || now - saved.At > MaximumAge)
            return SkillDisplaySnapshot.Unknown;
        return saved.Snapshot;
    }
    public void Clear() { snapshots.Clear(); context = null; }
}

internal interface ISkillDisplayProvider
{
    SkillDisplaySnapshot GetSnapshot(uint actionId);
    SkillCatalogEntry? GetSkill(uint actionId);
}
