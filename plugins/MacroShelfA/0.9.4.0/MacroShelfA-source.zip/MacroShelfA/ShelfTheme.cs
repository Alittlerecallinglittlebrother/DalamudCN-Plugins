namespace MacroShelfA;

// Numeric values are persisted. Adding a theme must never renumber existing themes.
public enum ShelfTheme { Classic = 0, Persona3 = 1, Needy = 2, Persona5 = 3 }
