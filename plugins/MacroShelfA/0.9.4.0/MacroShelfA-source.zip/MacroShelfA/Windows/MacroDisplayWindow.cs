using System;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Windowing;
using Dalamud.Interface.Textures;
using Dalamud.Plugin.Services;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class MacroDisplayWindow : Window
{
    private readonly Configuration configuration;
    private readonly SkillCatalog catalog;
    private readonly ISkillDisplayProvider? display;
    private MacroEntry? entry;
    private string search = string.Empty;
    private uint selectedId;
    private bool showCooldown, showCharges;
    private static float S(float value) => value * ImGuiHelpers.GlobalScale;
    partial void RecordItem(string key);
    private bool embedded;
    private string embeddedStatus="";
    private const string EmbeddedLimits="仅支持普通玩家 PvE 技能，以当前目标为准；不解析 <mo> / <f>，不含物品、制作动作及 PvP 技能。";
    internal ITextureProvider? Textures { get; set; }
    internal void OpenEmbedded(MacroEntry macro){Open(macro);IsOpen=false;embeddedStatus="";}
    internal void DrawEmbedded(){embedded=true;try{Draw();}finally{embedded=false;}}

    public MacroDisplayWindow(Configuration configuration, SkillCatalog catalog, ISkillDisplayProvider? display = null)
        : base("常用宏显示技能###MacroShelfADisplaySkill")
    {
        this.configuration = configuration; this.catalog = catalog; this.display = display;
        Size = new Vector2(580, 530); SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new WindowSizeConstraints { MinimumSize = new(420, 400), MaximumSize = new(900, 800) };
        Flags = ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse;
    }

    public void Open(MacroEntry macro)
    {
        entry = macro; selectedId = macro.DisplayActionId; showCooldown = macro.ShowSkillCooldown;
        showCharges = macro.ShowSkillCharges; search = string.Empty; IsOpen = true;
    }

    private IDisposable? windowSkin;
    public override void PreDraw() { windowSkin = ShelfSkin.Apply(configuration.Theme, configuration.ReduceThemeMotion); }
    public override void PostDraw() { windowSkin?.Dispose(); windowSkin = null; }
    public override void Draw()
    {
        using var skin = ShelfSkin.Apply(configuration.Theme, configuration.ReduceThemeMotion);
        if (entry == null || !configuration.AllEntries().Any(e => ReferenceEquals(e, entry)))
        { ImGui.TextWrapped("此条目已被删除或替换，请重新打开显示设置。"); return; }
        if(!embedded)
        {
            ImGui.TextUnformatted(MainWindow.Fit(entry.Name, ImGui.GetContentRegionAvail().X));
            ImGui.TextWrapped("仅显示一个普通玩家技能（Action）的当前目标状态；不代表整段宏可执行或执行成功。不会自动施放、重试或等待。");
            ImGui.TextWrapped("不解析宏中的 <mo>、<f> 等目标；PvP、物品、制作动作与 GeneralAction 不在本版范围内。");
            ImGui.Separator();
        }
        var selected = selectedId == 0 ? null : catalog.Find(selectedId);
        var selection = selectedId == 0 ? "无显示技能（保留导入图标）"
            : selected == null ? $"未知 / 不支持的技能 ID {selectedId}" : $"{selected.Name} · #{selected.Id}";
        ImGui.TextUnformatted(MainWindow.Fit("当前选择：" + selection, ImGui.GetContentRegionAvail().X));
        if (ImGui.IsItemHovered()) ImGui.SetTooltip(selection);
        if (selectedId != 0 && display != null)
            ImGui.TextDisabled("即时预览：" + display.GetSnapshot(selectedId).Label(showCooldown, showCharges));
        if(embedded)DrawIconPreview(selected);
        if (ImGui.SmallButton("不显示技能")) selectedId = 0;
        RecordItem("display-reset");
        ImGui.SameLine(); ImGui.TextDisabled(entry.IconId == 0 ? "未保存原生宏图标" : $"导入图标 #{entry.IconId}");
        ImGui.Checkbox("显示冷却秒数", ref showCooldown); RecordItem("display-cooldown");
        if(ImGui.GetItemRectMax().X+ImGui.CalcTextSize("显示充能次数").X+ImGui.GetFrameHeight()+S(16)<ImGui.GetCurrentContext().CurrentWindow.InnerClipRect.Max.X)ImGui.SameLine();
        ImGui.Checkbox("显示充能次数", ref showCharges); RecordItem("display-charges");
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##DisplaySearch", "按本地技能名称或 ID 搜索…", ref search, 128);
        RecordItem("display-search");
        var rows = catalog.Search(search, 150);
        if (catalog.ErrorText.Length > 0) ImGui.TextWrapped(catalog.ErrorText);
        var footerHeight=ImGui.GetFrameHeight()+S(18);
        if(embedded)
        {
            footerHeight+=ImGui.CalcTextSize(EmbeddedLimits,false,ImGui.GetContentRegionAvail().X).Y+ImGui.GetStyle().ItemSpacing.Y*2;
            if(embeddedStatus.Length>0)footerHeight+=ImGui.CalcTextSize(embeddedStatus,false,ImGui.GetContentRegionAvail().X).Y+ImGui.GetStyle().ItemSpacing.Y;
        }
        var listHeight = MathF.Max(S(80), ImGui.GetContentRegionAvail().Y-footerHeight);
        ImGui.BeginChild("##DisplayActions", new Vector2(0, listHeight), true);
        if (rows.Count == 0) ImGui.TextWrapped("没有匹配的普通玩家技能。");
        foreach (var skill in rows)
        {
            var label = $"{skill.Id} · {skill.Name}";
            if (ImGui.Selectable(MainWindow.Fit(label, ImGui.GetContentRegionAvail().X) + "##Skill" + skill.Id, selectedId == skill.Id)) selectedId = skill.Id;
            RecordItem("display-skill-" + skill.Id);
            if (ImGui.IsItemHovered()) ImGui.SetTooltip(label);
        }
        if (rows.Count == 150) ImGui.TextDisabled("仅显示前 150 项；继续输入名称或 ID 缩小范围。");
        ImGui.EndChild();
        ImGui.Separator();
        ImGui.BeginDisabled(selectedId != 0 && selected == null);
        if (ImGui.Button("保存显示设置"))
        {
            entry.DisplayActionId = selectedId; entry.ShowSkillCooldown = showCooldown; entry.ShowSkillCharges = showCharges;
            configuration.Save(); IsOpen = false;
            embeddedStatus="已保存所选宏的图标与技能显示设置。";
        }
        RecordItem("display-save");
        ImGui.EndDisabled();
        var cancelLabel=embedded?"放弃未保存修改":"取消";
        if(ImGui.GetItemRectMax().X+ImGui.CalcTextSize(cancelLabel).X+ImGui.GetStyle().FramePadding.X*2+S(8)<ImGui.GetCurrentContext().CurrentWindow.InnerClipRect.Max.X)ImGui.SameLine();
        if (ImGui.Button(cancelLabel)){if(embedded)OpenEmbedded(entry);else IsOpen=false;}RecordItem("display-cancel");
        if(embedded&&embeddedStatus.Length>0)ImGui.TextWrapped(embeddedStatus);
        if(embedded)ImGui.TextWrapped(EmbeddedLimits);
    }
    private void DrawIconPreview(SkillCatalogEntry? selected)
    {
        var iconId=selected?.IconId??entry?.IconId??0;var size=new Vector2(S(48));var drawn=false;
        if(Textures!=null&&iconId!=0&&Textures.TryGetFromGameIcon(new GameIconLookup(iconId),out var texture)&&texture.TryGetWrap(out var wrap,out _))
        {ImGui.Image(wrap.Handle,size);drawn=true;}
        else
        {
            var start=ImGui.GetCursorScreenPos();var palette=ShelfSkin.Palette(configuration.Theme);var dl=ImGui.GetWindowDrawList();
            dl.AddRectFilled(start,start+size,ImGui.GetColorU32(palette.Code));dl.AddRect(start,start+size,ImGui.GetColorU32(palette.Border));
            ShelfDrawing.Glyph(dl,ShelfGlyph.File,start+new Vector2(S(14)),S(20),palette.Accent);ImGui.Dummy(size);
        }
        RecordItem("display-icon-preview");ImGui.SameLine();ImGui.BeginGroup();
        ImGui.TextUnformatted(drawn?"图标预览":"图标未获取（占位）");
        ImGui.TextWrapped(selectedId==0?"使用导入时保存的原生图标":"保存后显示所选技能图标");ImGui.EndGroup();
    }
}

