using System;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow
{
    internal Action? OpenNativeMacroImport { get; set; }
    internal Action<MacroEntry>? OpenDisplaySettings { get; set; }
    internal Action<MacroEntry>? OpenNativeMacroBridge { get; set; }

    private void DrawIntegrationMenu(MacroEntry entry)
    {
        if (ImGui.Button("图标与热键栏")) ImGui.OpenPopup("##NativeIntegrationActions");
        RecordItem("integration-menu");
        if (!ImGui.BeginPopup("##NativeIntegrationActions")) return;
        ImGui.BeginDisabled(OpenDisplaySettings == null);
        if (ImGui.MenuItem("设置图标与显示技能")) OpenDisplaySettings?.Invoke(entry);
        RecordItem("integration-display");
        ImGui.EndDisabled();
        ImGui.BeginDisabled(OpenNativeMacroBridge == null);
        if (ImGui.MenuItem("生成游戏热键栏入口")) OpenNativeMacroBridge?.Invoke(entry);
        RecordItem("integration-bridge");
        ImGui.EndDisabled();
        ImGui.Separator();
        if (ImGui.MenuItem("复制条目 ID")) ImGui.SetClipboardText(entry.Id);
        RecordItem("integration-copy-id");
        ImGui.EndPopup();
    }
}
