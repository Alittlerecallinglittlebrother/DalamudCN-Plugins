using System;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow
{
    private void SetAdvancedWorkbench(bool value)
    {
        configuration.AdvancedWorkbench=value;compactInspector=0;compactTree=false;
        SetFilter(LibraryFilter.All);SaveConfiguration();
    }
    private void DrawSimpleTools()
    {
        var h=S(themedLayout.HeaderHeight>100?40:28);
        ImGui.BeginDisabled(configuration.CountEntries()>=Configuration.MaxEntries);
        if(ShelfSkin.Button(CurrentTheme,"新建宏",new Vector2(S(125),h),true,glyph:ShelfGlyph.Plus))AddEntry(false);RecordItem("new-macro");ImGui.EndDisabled();ImGui.SameLine();
        ImGui.BeginDisabled(OpenNativeMacroImport==null);
        if(ShelfSkin.Button(CurrentTheme,"从游戏导入",new Vector2(S(157),h),glyph:ShelfGlyph.Download))OpenNativeMacroImport?.Invoke();RecordItem("nav-native-import");ImGui.EndDisabled();ImGui.SameLine();
        if(ShelfSkin.Button(CurrentTheme,"更多…",new Vector2(S(82),h)))ImGui.OpenPopup("##SimpleTools");RecordItem("simple-tools");ImGui.SameLine();
        if(ShelfSkin.Button(CurrentTheme,"进阶功能",new Vector2(S(106),h)))SetAdvancedWorkbench(true);RecordItem("mode-advanced");
        if(ImGui.BeginPopup("##SimpleTools"))
        {
            ImGui.TextDisabled("备份与整理（不影响日常运行）");ImGui.Separator();
            if(ImGui.MenuItem("导入插件备份"))BeginImport();RecordItem("toolbar-import");
            if(ImGui.MenuItem("导出插件备份"))ExportConfiguration();RecordItem("toolbar-export");
            if(ImGui.MenuItem("全部宏 · 表格管理"))page=Page.Library;RecordItem("nav-library");
            ImGui.Separator();ImGui.BeginDisabled(configuration.CountEntries()+2>Configuration.MaxEntries);
            if(ImGui.MenuItem("新建宏组（依次运行多段宏）"))AddEntry(true);RecordItem("new-group");ImGui.EndDisabled();
            if(ImGui.MenuItem("事件触发设置"))page=Page.Countdown;RecordItem("nav-countdown");ImGui.EndPopup();
        }
    }
    private void DrawGettingStarted()
    {
        var compact=themedLayout.BodyHeight<300;
        var height=compact?MathF.Max(S(36),ImGui.GetTextLineHeight()+S(10)):MathF.Max(S(60),ImGui.GetTextLineHeight()*2+S(18));
        ImGui.BeginChild("##GettingStarted",new Vector2(0,height),false,ImGuiWindowFlags.NoScrollbar|ImGuiWindowFlags.NoScrollWithMouse);
        var start=ImGui.GetCursorScreenPos();var width=ImGui.GetContentRegionAvail().X;var p=ShelfSkin.Palette(CurrentTheme);
        ImGui.TextColored(p.Text,Fit(compact?"1 新建或导入   /   2 编辑   /   3 点击运行":"1 新建或导入   /   2 编辑（自动保存）   /   3 点击运行",width-S(87)));
        if(!compact)ImGui.TextColored(p.Muted,Fit("想一键运行？点击宏旁的星标，加入常用栏。",width-S(87)));
        ImGui.SetCursorScreenPos(start+new Vector2(MathF.Max(0,width-S(78)),0));
        if(ShelfSkin.Button(CurrentTheme,"知道了",new Vector2(S(78),S(28)))){configuration.ShowGettingStarted=false;SaveConfiguration();}RecordItem("guide-dismiss");
        RecordRegion("guide",ImGui.GetWindowPos(),ImGui.GetWindowPos()+ImGui.GetWindowSize());ImGui.EndChild();
    }
    private void DrawFirstMacro()
    {
        BeginThemePanel("##FirstMacro",Vector2.Zero,true,true);
        ImGui.Spacing();Heading("先创建你的第一个宏");
        ImGui.TextWrapped("宏就是按顺序执行的一组游戏命令。你可以新建，也可以把游戏里已有的宏导入这里。");
        ImGui.Spacing();ImGui.TextUnformatted("1. 创建或导入    2. 修改命令    3. 点击运行");ImGui.Spacing();
        if(ShelfSkin.Button(CurrentTheme,"创建示例宏，试着编辑",new Vector2(MathF.Min(S(320),ImGui.GetContentRegionAvail().X),S(44)),true,glyph:ShelfGlyph.Plus))
        {
            var entry=configuration.AddMacro(false);
            if(entry!=null){entry.Name="我的第一个宏";entry.Commands="/echo 你好，Macro Shelf-A！\n/wait 1\n/echo 示例结束。可以把这里改成自己的命令。";SaveConfiguration();OpenEditor(entry);}
        }
        RecordItem("welcome-example");
        ImGui.BeginDisabled(OpenNativeMacroImport==null);
        if(ShelfSkin.Button(CurrentTheme,"导入游戏里已有的宏",new Vector2(MathF.Min(S(320),ImGui.GetContentRegionAvail().X),S(40)),glyph:ShelfGlyph.Download))OpenNativeMacroImport?.Invoke();RecordItem("welcome-import");ImGui.EndDisabled();
        ImGui.Spacing();ImGui.TextWrapped("内容自动保存；创建、导入和编辑都不会自动运行。熟悉以后再打开“进阶功能”。");
        ImGui.EndChild();
    }
    private void DrawSimpleTree()
    {
        ImGui.TextUnformatted("我的宏");ImGui.SameLine();ImGui.TextDisabled($"{configuration.CountEntries()} / {Configuration.MaxEntries}");
        ImGui.SetNextItemWidth(-1);if(ImGui.InputTextWithHint("##SimpleSearch","搜索名称或命令…",ref searchText,256))InvalidateLibrary();RecordItem("search");
        var w=(ImGui.GetContentRegionAvail().X-ImGui.GetStyle().ItemSpacing.X)/2;
        if(ShelfSkin.Button(CurrentTheme,"全部",new Vector2(w,S(28)),selected:filter!=LibraryFilter.Favorites))SetFilter(LibraryFilter.All);RecordItem("filter-all");ImGui.SameLine();
        if(ShelfSkin.Button(CurrentTheme,"常用",new Vector2(w,S(28)),selected:filter==LibraryFilter.Favorites))SetFilter(LibraryFilter.Favorites);RecordItem("filter-favorites");
        ImGui.Separator();ImGui.BeginChild("##SimpleTreeScroll",Vector2.Zero,false);ImGui.SetWindowFontScale(1);
        var clip=ImGui.GetCurrentContext().CurrentWindow.InnerClipRect;RecordRegion("tree-list",clip.Min,clip.Max);
        var rowHeight=MathF.Max(S(38),ImGui.GetTextLineHeight()+S(12));var found=false;
        foreach(var root in configuration.Macros.Where(m=>MacroLibrary.Matches(m,searchText)))
        {
            if(filter==LibraryFilter.Favorites&&!root.Pinned&&!root.Children.Any(c=>c.Pinned))continue;found=true;ImGui.PushID(root.Id);
            if(ThemedTreeRow(root,rowHeight)){selectedMacro=root;compactTree=false;}
            if(root.IsGroup)
            {
                ImGui.Indent(S(18));
                foreach(var child in root.Children)
                {
                    if(!MacroLibrary.MatchesSelf(root,searchText)&&!MacroLibrary.MatchesSelf(child,searchText))continue;
                    if(ThemedTreeRow(child,rowHeight)){selectedMacro=child;compactTree=false;}
                }
                ImGui.Unindent(S(18));
            }
            ImGui.PopID();
        }
        if(!found)ImGui.TextWrapped("没有匹配的宏。清空搜索或切回“全部”试试。");ImGui.Dummy(new Vector2(0,S(5)));ImGui.EndChild();
    }
    private void DrawSimpleSelected()
    {
        var entry=ValidSelection();if(entry==null){ImGui.TextWrapped("点击左侧的宏开始编辑；也可以点击上方“新建宏”或“从游戏导入”。");return;}
        var parent=configuration.FindParent(entry);var name=entry.Name;
        var favoriteWidth=ImGui.CalcTextSize("加入常用栏").X+ImGui.GetFrameHeight()+S(14);
        ImGui.TextUnformatted("名称");ImGui.SameLine();ImGui.SetNextItemWidth(MathF.Max(S(70),ImGui.GetContentRegionAvail().X-favoriteWidth));
        if(ImGui.InputText("##SimpleName",ref name,Configuration.MaxNameLength*4+1)){entry.Name=name;metadataDirty=true;InvalidateLibrary();}RecordItem("edit-name");if(ImGui.IsItemDeactivatedAfterEdit())SaveConfiguration();
        ImGui.SameLine();var pinned=entry.Pinned;if(ImGui.Checkbox("加入常用栏",ref pinned)){entry.Pinned=pinned;SaveConfiguration();}RecordItem("edit-favorite");
        var h=MathF.Max(S(40),ImGui.GetFrameHeight());var body=MathF.Max(S(60),ImGui.GetContentRegionAvail().Y-h-ImGui.GetStyle().ItemSpacing.Y-S(3));
        ImGui.BeginChild("##SimpleEditBody",new Vector2(0,body),false);ImGui.SetWindowFontScale(1);
        if(entry.IsGroup){ImGui.TextWrapped("宏组会按下面的顺序运行。点击其中一段可以单独编辑。");DrawGroupEditor(entry);}
        else
        {
            if(entry.Commands.Length==0){ImGui.TextWrapped("每行填写一条 /命令。先试试 /echo 你好；编辑后会自动保存。");}
            if(parent!=null)ImGui.TextColored(ShelfSkin.Palette(CurrentTheme).Muted,Fit("所属宏组："+parent.Name,ImGui.GetContentRegionAvail().X));
            DrawCommandEditor(entry);
        }
        ImGui.EndChild();var available=ImGui.GetContentRegionAvail().X;var more=S(87);var spacing=ImGui.GetStyle().ItemSpacing.X;
        var run=(available-more-spacing*(parent==null?1:2))/(parent==null?1:2);
        ImGui.BeginDisabled(macroExecutor.IsRunning||(entry.IsGroup&&entry.Children.Count==0)||(!entry.IsGroup&&string.IsNullOrWhiteSpace(entry.Commands)));
        if(ShelfSkin.Button(CurrentTheme,entry.IsGroup?"运行整组":parent==null?"运行此宏":"只运行这一段",new Vector2(run,h),true,glyph:ShelfGlyph.Play))macroExecutor.Start(entry);RecordItem("edit-run");
        if(parent!=null){ImGui.SameLine();if(ShelfSkin.Button(CurrentTheme,"运行整组",new Vector2(run,h),glyph:ShelfGlyph.Next))macroExecutor.Start(parent);RecordItem("edit-run-group");}
        ImGui.EndDisabled();ImGui.SameLine();
        if(ShelfSkin.Button(CurrentTheme,"更多…",new Vector2(more,h)))ImGui.OpenPopup("##SimpleEntryActions");RecordItem("entry-more");
        if(ImGui.BeginPopup("##SimpleEntryActions")){DrawSimpleEntryOptions(entry,parent);ImGui.EndPopup();}
    }
    private void DrawSimpleEntryOptions(MacroEntry entry,MacroEntry? parent)
    {
        ImGui.TextDisabled("整理这个宏");
        var siblings=parent?.Children??configuration.Macros;var index=siblings.IndexOf(entry);
        ImGui.BeginDisabled(index<=0);if(ImGui.MenuItem("上移")){configuration.Move(entry,-1);InvalidateLibrary();}RecordItem("move-up");ImGui.EndDisabled();
        ImGui.BeginDisabled(index>=siblings.Count-1);if(ImGui.MenuItem("下移")){configuration.Move(entry,1);InvalidateLibrary();}RecordItem("move-down");ImGui.EndDisabled();
        ImGui.BeginDisabled(configuration.CountEntries()+1+(entry.IsGroup?entry.Children.Count:0)>Configuration.MaxEntries||(parent!=null&&parent.Children.Count>=Configuration.MaxChildren));
        if(ImGui.MenuItem("复制这个宏")){var copy=configuration.Duplicate(entry);if(copy!=null)OpenEditor(copy);InvalidateLibrary();}RecordItem("duplicate");ImGui.EndDisabled();
        if(ImGui.MenuItem("删除…")){pendingDelete=entry;openDeletePopup=true;}RecordItem("delete");ImGui.Separator();
        var category=(parent??entry).Group;ImGui.BeginDisabled(parent!=null);ImGui.SetNextItemWidth(S(180));
        if(ImGui.InputTextWithHint("分类##SimpleTag","可不填",ref category,Configuration.MaxGroupLength*4+1)){entry.Group=category;SaveConfiguration();}RecordItem("edit-category");ImGui.EndDisabled();
        ImGui.Separator();ImGui.TextDisabled("可选进阶功能");
        ImGui.BeginDisabled(OpenDisplaySettings==null);if(ImGui.MenuItem("设置显示图标 / 技能"))OpenDisplaySettings?.Invoke(entry);RecordItem("direct-display");ImGui.EndDisabled();
        ImGui.BeginDisabled(OpenNativeMacroBridge==null);if(ImGui.MenuItem("放到游戏热键栏…"))OpenNativeMacroBridge?.Invoke(entry);RecordItem("direct-bridge");ImGui.EndDisabled();
    }
}
