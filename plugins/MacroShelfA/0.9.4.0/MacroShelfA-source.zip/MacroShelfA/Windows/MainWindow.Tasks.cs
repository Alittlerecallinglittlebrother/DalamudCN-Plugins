using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow
{
    internal enum TaskPage { Macros, Groups, QuickBar, NativeImport, Bridge, Display, Countdown, Backup, Execution, Appearance }
    private TaskPage taskPage, previousTaskPage = (TaskPage)(-1);
    private string taskTargetId = "", taskCategory = "";
    private bool taskBackupInline;
    private bool resetTaskBody;
    private string? lastTaskEditorId;
    private MacroEntry? loadedDisplay, loadedBridge;
    internal NativeMacroImportWindow? ImportPage { get; set; }
    internal MacroDisplayWindow? DisplayPage { get; set; }
    internal NativeMacroBridgeWindow? BridgePage { get; set; }
    internal void ShowImportedMacros()
    {searchText="";taskCategory="";var entry=configuration.Macros.LastOrDefault();if(entry!=null)OpenEditor(entry);else NavigateTask(TaskPage.Macros);}
    private static readonly (TaskPage Page,string Title,string Hint,string Group,ShelfGlyph Icon)[] Tasks =
    [
        (TaskPage.Macros,"我的宏","新建、编辑、分类与运行","日常使用",ShelfGlyph.File),
        (TaskPage.Groups,"顺序宏组","将多段宏按顺序执行","",ShelfGlyph.Folder),
        (TaskPage.QuickBar,"常用宏悬浮栏","收藏宏，一键运行","",ShelfGlyph.Star),
        (TaskPage.NativeImport,"从游戏导入宏","复制个人宏或共通宏到插件","游戏配合",ShelfGlyph.Download),
        (TaskPage.Bridge,"生成游戏热键入口","生成入口宏；恢复原槽位","",ShelfGlyph.Link),
        (TaskPage.Display,"图标与技能状态","设置图标、冷却与充能显示","",ShelfGlyph.Grid),
        (TaskPage.Countdown,"倒计时结束后运行","战斗倒计时结束，运行一次","",ShelfGlyph.Bolt),
        (TaskPage.Backup,"插件宏备份与恢复","复制备份；追加或替换导入","数据与设置",ShelfGlyph.Copy),
        (TaskPage.Execution,"行数与等待设置","长宏、小数等待与长等待","",ShelfGlyph.Gear),
        (TaskPage.Appearance,"主题与悬浮入口","配色、动效与悬浮图标","",ShelfGlyph.Home),
    ];
    private void NavigateTask(TaskPage next)
    {
        if(next==taskPage)return;
        if(metadataDirty)SaveConfiguration();
        if(taskPage is TaskPage.Macros or TaskPage.Groups && next is TaskPage.Macros or TaskPage.Groups)taskCategory="";
        taskPage=next;
        resetTaskBody=true;
        if(selectedMacro!=null)taskTargetId=selectedMacro.Id;
    }
    private void SyncTaskPage()
    {
        if(previousTaskPage==taskPage)return;
        if(previousTaskPage==TaskPage.NativeImport)ImportPage?.LeaveEmbedded();
        if(taskPage==TaskPage.NativeImport)ImportPage?.EnterEmbedded();
        if(taskPage==TaskPage.Display)loadedDisplay=null;
        if(taskPage==TaskPage.Bridge)loadedBridge=null;
        previousTaskPage=taskPage;
    }
    public override void OnClose() { if(previousTaskPage==TaskPage.NativeImport)ImportPage?.LeaveEmbedded();previousTaskPage=(TaskPage)(-1); }
    private void DrawTaskWindow()
    {
        renderingTheme=configuration.Theme;ImGui.SetWindowFontScale(1);
        using var skin=ShelfSkin.Apply(CurrentTheme,configuration.ReduceThemeMotion);
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing,new Vector2(S(8),S(7)));
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding,new Vector2(S(8),S(5)));
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding,new Vector2(S(10)));
        try
        {
            var origin=ImGui.GetCursorScreenPos();var size=ImGui.GetContentRegionAvail();
            var width=size.X/Scale;var height=size.Y/Scale;var roomy=width>=1180&&height>=720;
            var art=CurrentTheme==ShelfTheme.Persona3&&configuration.ShowThemeDecoration&&roomy?Math.Clamp(width*.105f,125,170):0;
            var header=roomy?(CurrentTheme==ShelfTheme.Persona3?116:CurrentTheme==ShelfTheme.Persona5?105:70):65;
            var dock=configuration.ShowWorkbenchQuickBar&&configuration.AllEntries().Any(m=>m.Pinned)&&width>=1180&&height>=900?QuickBarWindow.MinimumDockHeight(CurrentTheme):0;
            themedLayout=new WorkbenchLayout(width,height,art,header,0,MathF.Max(56,ImGui.GetFontSize()/Scale+28),dock,0,0);
            var l=themedLayout;DrawThemeBackdrop(origin,size,l);DrawThemeHeader(origin,l,true);
            var nav=MathF.Min(S(258),MathF.Max(S(188),S(l.ContentWidth)*.24f));var gap=S(10);
            At(origin,l.ContentLeft,l.BodyTop);
            BeginThemePanel("##TaskNavigation",new Vector2(nav,S(l.Height-l.BodyTop-10)),true);
            RecordRegion("task-navigation",ImGui.GetWindowPos(),ImGui.GetWindowPos()+ImGui.GetWindowSize());
            DrawTaskNavigation();ImGui.EndChild();SyncTaskPage();
            var pageX=l.ContentLeft+(nav+gap)/Scale;var pageWidth=S(l.ContentWidth)-nav-gap;
            At(origin,pageX,l.BodyTop);
            BeginThemePanel("##TaskPage",new Vector2(pageWidth,S(l.BodyHeight)),false);
            RecordRegion("task-page",ImGui.GetWindowPos(),ImGui.GetWindowPos()+ImGui.GetWindowSize());
            var reveal=ShelfMotion.Reveal(ImGui.GetID("task-reveal-"+taskPage+CurrentTheme));
            ImGui.PushStyleVar(ImGuiStyleVar.Alpha,ImGui.GetStyle().Alpha*(.82f+.18f*reveal));
            DrawTaskHeading();
            ImGui.BeginChild("##TaskPageBody-"+taskPage,Vector2.Zero,false,ImGuiWindowFlags.AlwaysUseWindowPadding);
            if(resetTaskBody){ImGui.SetScrollY(0);resetTaskBody=false;}
            RecordRegion("task-body",ImGui.GetCurrentContext().CurrentWindow.InnerClipRect.Min,ImGui.GetCurrentContext().CurrentWindow.InnerClipRect.Max);
            switch(taskPage)
            {
                case TaskPage.Macros: case TaskPage.Groups:DrawTaskCollection();break;
                case TaskPage.QuickBar:DrawTaskQuickBar();break;
                case TaskPage.NativeImport:
                    if(ImportPage!=null)ImportPage.DrawEmbedded();
                    else { ImGui.TextWrapped("连接游戏后可选择个人 / 共通宏、勾选预览，再复制到插件。");if(ImGui.Button("打开游戏宏导入窗口"))OpenNativeMacroImport?.Invoke();RecordItem("task-import-open"); }
                    break;
                case TaskPage.Display:DrawTaskDisplay();break;
                case TaskPage.Bridge:DrawTaskBridge();break;
                case TaskPage.Countdown:DrawCountdownTrigger();break;
                case TaskPage.Backup:DrawTaskBackup();break;
                case TaskPage.Execution:DrawLineLimitSetting();ImGui.Spacing();DrawBetterWaitSetting();ImGui.Spacing();ImGui.TextWrapped("这些设置不删除已有命令；宏仍按行执行并保留显式等待。关闭长宏后，超过 15 行的宏需重新开启此选项才能运行。");break;
                case TaskPage.Appearance:DrawTaskAppearance();break;
            }
            ImGui.EndChild();ImGui.PopStyleVar();ImGui.EndChild();
            At(origin,pageX,l.FooterTop);BeginThemePanel("##TaskStatus",new Vector2(pageWidth,S(l.FooterHeight)),false);
            DrawTaskStatus();ImGui.EndChild();
            if(l.DockHeight>0)
            {At(origin,pageX,l.Height-l.DockHeight+14);DrawQuickDock?.Invoke(new Vector2(pageWidth,S(l.DockHeight-22)));}
            if(openDeletePopup){ImGui.OpenPopup("删除宏");openDeletePopup=false;}
            DrawDeleteConfirmation();
            if(metadataDirty&&!ImGui.IsAnyItemActive())SaveConfiguration();
        }
        finally {ImGui.PopStyleVar(3);ImGui.SetWindowFontScale(1);}
    }
    private void DrawTaskNavigation()
    {
        var p=ShelfSkin.Palette(CurrentTheme);
        foreach(var task in Tasks)
        {
            if(task.Group.Length>0){if(task.Page!=TaskPage.Macros)ImGui.Spacing();ImGui.TextColored(p.Muted,task.Group);ImGui.Separator();}
            var textWidth=MathF.Max(S(80),ImGui.GetContentRegionAvail().X-S(32));
            var titleSize=ImGui.CalcTextSize(task.Title,false,textWidth);var hintSize=ImGui.CalcTextSize(task.Hint,false,textWidth);
            var row=new Vector2(ImGui.GetContentRegionAvail().X,titleSize.Y+hintSize.Y+S(13));
            var min=ImGui.GetCursorScreenPos();var chosen=taskPage==task.Page;
            ImGui.PushStyleColor(ImGuiCol.Header,Vector4.Zero);ImGui.PushStyleColor(ImGuiCol.HeaderHovered,Vector4.Zero);ImGui.PushStyleColor(ImGuiCol.HeaderActive,Vector4.Zero);
            if(ImGui.Selectable("##Task-"+task.Page,chosen,ImGuiSelectableFlags.None,row))NavigateTask(task.Page);
            RecordItem("task-"+task.Page);ImGui.PopStyleColor(3);
            ShelfSkin.Selection(CurrentTheme,min,min+row,chosen,ImGui.IsItemHovered());
            var ink=chosen?p.OnSelection:p.Text;var dl=ImGui.GetWindowDrawList();
            ShelfDrawing.Glyph(dl,task.Icon,min+new Vector2(S(4),S(8)),S(17),ink);
            dl.AddText(ImGui.GetFont(),ImGui.GetFontSize(),min+new Vector2(S(28),S(4)),ImGui.GetColorU32(ink),task.Title,textWidth);
            dl.AddText(ImGui.GetFont(),ImGui.GetFontSize(),min+new Vector2(S(28),titleSize.Y+S(7)),ImGui.GetColorU32(chosen?ink:p.Muted),task.Hint,textWidth);
            if(ImGui.IsItemHovered())ImGui.SetTooltip(task.Title+"\n"+task.Hint);
        }
    }
    private void DrawTaskHeading()
    {
        var task=Tasks[(int)taskPage];var p=ShelfSkin.Palette(CurrentTheme);
        ImGui.TextColored(p.Text,task.Title);
        var collection=taskPage is TaskPage.Macros or TaskPage.Groups;
        if(collection)
        {
            ImGui.SameLine();var group=taskPage==TaskPage.Groups;
            ImGui.BeginDisabled(configuration.CountEntries()+(group?2:1)>Configuration.MaxEntries);
            if(ShelfSkin.Button(CurrentTheme,group?"新建宏组":"新建宏",new Vector2(S(116),ImGui.GetFrameHeight()),true,glyph:ShelfGlyph.Plus)){AddEntry(group);}
            RecordItem(group?"new-group":"new-macro");ImGui.EndDisabled();
        }
        var description=taskPage switch
        {
            TaskPage.Macros=>"选择或新建一个宏，编辑后点击运行；修改自动保存。",
            TaskPage.Groups=>"将多段宏按顺序组合；可以只运行一段，也可以运行整组。",
            TaskPage.QuickBar=>"收藏宏显示为独立悬浮按钮；移出常用栏不会删除原宏。",
            TaskPage.NativeImport=>"复制游戏已有宏到插件；不会修改来源游戏宏，也不会自动运行。",
            TaskPage.Bridge=>"生成连接到插件宏的一行入口；完成后手动拖到游戏热键栏。",
            TaskPage.Display=>"仅显示所选技能的图标与状态，不会施放技能，不代表整个宏可用。",
            TaskPage.Countdown=>"小队战斗倒计时结束后，自动运行一次指定宏或宏组。",
            TaskPage.Backup=>"备份插件宏，不是读取游戏宏，也不是恢复游戏原生槽位。",
            TaskPage.Execution=>"调整宏的行数限制和等待格式，不修改宏正文。",
            _=>"只改变界面显示；悬浮入口用于打开主窗口，不是运行宏按钮。"
        };
        ImGui.TextWrapped(description);
        if(ImGui.GetContentRegionAvail().Y>S(360))
            ImGui.TextColored(p.Muted,taskPage switch
            {TaskPage.NativeImport=>"1 选择来源  /  2 勾选并预览  /  3 复制到插件",TaskPage.Bridge=>"1 选择插件宏  /  2 检查槽位  /  3 备份并生成",TaskPage.Macros or TaskPage.Groups=>"1 选择或新建  /  2 编辑（自动保存）  /  3 点击运行",_=>task.Hint});
        ImGui.Separator();
    }
    private void DrawTaskCollection()
    {
        var groups=taskPage==TaskPage.Groups;
        if(selectedMacro==null||RootOf(selectedMacro)==null||RootOf(selectedMacro)!.IsGroup!=groups)
            selectedMacro=configuration.Macros.FirstOrDefault(m=>m.IsGroup==groups);
        var wide=ImGui.GetContentRegionAvail().X>=S(665);
        if(wide)
        {
            BeginThemePanel("##TaskMacroList",new Vector2(Math.Clamp(ImGui.GetContentRegionAvail().X*.27f,S(192),S(265)),0),false);
            DrawTaskMacroList(groups);ImGui.EndChild();ImGui.SameLine();
        }
        else
        {
            ImGui.TextUnformatted(groups?"选择宏组或子宏":"选择要编辑的宏");ImGui.SetNextItemWidth(-1);
            if(ImGui.BeginCombo("##TaskCompactEntry",selectedMacro?.Name??"还没有宏",ImGuiComboFlags.HeightLarge))
            {DrawTaskListFilters(groups);foreach(var row in TaskCollectionRows(groups))
             {if(ImGui.Selectable(row.Label+"##"+row.Macro.Id,selectedMacro==row.Macro))OpenEditor(row.Macro);RecordItem("tree-"+row.Macro.Id);}ImGui.EndCombo();}
            RecordItem("task-entry-picker");
        }
        // A tiny window scrolls the task body instead of squeezing the input
        // beneath metadata to a few clipped pixels. The stop footer is fixed.
        var editorHeight=wide?0:MathF.Max(S(430),ImGui.GetContentRegionAvail().Y);
        BeginThemePanel("##TaskMacroEditor",new Vector2(0,editorHeight),false);
        var clip=ImGui.GetCurrentContext().CurrentWindow.InnerClipRect;RecordRegion("editor-panel",clip.Min,clip.Max);
        DrawTaskMacroEditor(groups,!wide);ImGui.EndChild();
    }
    private void DrawTaskMacroList(bool groups)
    {
        ImGui.TextUnformatted(groups?"宏组与子宏":"宏列表");
        DrawTaskListFilters(groups);
        ImGui.BeginChild("##TaskMacroRows",new Vector2(0,MathF.Max(S(45),ImGui.GetContentRegionAvail().Y-ImGui.GetFrameHeight()-S(10))),false);
        var clip=ImGui.GetCurrentContext().CurrentWindow.InnerClipRect;RecordRegion("tree-list",clip.Min,clip.Max);
        var roots=MacroLibrary.Query(configuration.Macros,taskCategory.Length==0?LibraryFilter.All:LibraryFilter.Category,taskCategory,searchText,sort).Where(m=>m.IsGroup==groups).ToArray();
        foreach(var root in roots)
        {
            if(ThemedTreeRow(root,MathF.Max(S(34),ImGui.GetTextLineHeight()+S(12))))OpenEditor(root);
            if(root.IsGroup)
            {ImGui.Indent(S(17));foreach(var child in root.Children){if(ThemedTreeRow(child,MathF.Max(S(34),ImGui.GetTextLineHeight()+S(12))))OpenEditor(child);}ImGui.Unindent(S(17));}
        }
        if(roots.Length==0)ImGui.TextWrapped("没有匹配项。清空搜索或选择全部分类。");ImGui.Dummy(new Vector2(0,S(6)));ImGui.EndChild();
        DrawTaskMoveButtons(selectedMacro);
    }
    private IEnumerable<QuickBarEntry> TaskCollectionRows(bool groups)
    {
        foreach(var root in MacroLibrary.Query(configuration.Macros,taskCategory.Length==0?LibraryFilter.All:LibraryFilter.Category,taskCategory,searchText,sort).Where(m=>m.IsGroup==groups))
        {yield return new(root,null);if(root.IsGroup)foreach(var child in root.Children)yield return new(child,root);}
    }
    private void DrawTaskListFilters(bool groups)
    {
        ImGui.SetNextItemWidth(-1);if(ImGui.InputTextWithHint("##TaskSearch","搜索名称或命令",ref searchText,256))InvalidateLibrary();RecordItem("search");
        ImGui.SetNextItemWidth(-1);
        if(ImGui.BeginCombo("##TaskCategory",taskCategory.Length==0?"分类：全部":"分类："+taskCategory))
        {if(ImGui.Selectable("全部",taskCategory.Length==0))taskCategory="";RecordItem("category-all");foreach(var tag in configuration.Macros.Where(m=>m.IsGroup==groups).Select(MacroLibrary.Tag).Distinct()){if(ImGui.Selectable(tag,taskCategory==tag))taskCategory=tag;RecordItem("category-"+tag);}ImGui.EndCombo();}RecordItem("task-category");
        ImGui.SetNextItemWidth(-1);var order=Math.Min(1,(int)sort);if(ImGui.Combo("##TaskSort",ref order,"保存顺序\0按名称显示\0")){sort=(LibrarySort)order;InvalidateLibrary();}RecordItem("task-sort");
        if(ImGui.IsItemHovered())ImGui.SetTooltip("选择“保存顺序”后可用上移 / 下移调整顺序；按名称显示不改动保存顺序。");
    }
    private void DrawTaskMoveButtons(MacroEntry? entry)
    {
        var parent=entry==null?null:configuration.FindParent(entry);var siblings=parent?.Children??configuration.Macros;
        var visible=parent?.Children??(entry==null?[]:TaskCollectionRows(entry.IsGroup).Where(e=>e.Parent==null).Select(e=>e.Macro).ToList());var index=entry==null?-1:visible.IndexOf(entry);
        var manual=parent!=null||sort==LibrarySort.SavedOrder;
        void Move(int direction){var destination=visible[index+direction];configuration.Move(entry!,siblings.IndexOf(destination)-siblings.IndexOf(entry!));InvalidateLibrary();revealEntryId=entry!.Id;}
        ImGui.BeginDisabled(!manual||index<=0);if(ImGui.Button("上移"))Move(-1);RecordItem("move-up");ImGui.EndDisabled();ImGui.SameLine();
        ImGui.BeginDisabled(!manual||index<0||index>=visible.Count-1);if(ImGui.Button("下移"))Move(1);RecordItem("move-down");ImGui.EndDisabled();
    }
    private void DrawTaskMacroEditor(bool groups,bool compact=false)
    {
        var entry=ValidSelection();
        if(entry==null)
        {
            ImGui.TextWrapped(groups?"点击“新建宏组”，再添加需要依次执行的子宏。":"点击“新建宏”开始，也可以从游戏复制已有宏。");
            ImGui.BeginDisabled(configuration.CountEntries()>=Configuration.MaxEntries);
            if(!groups&&ImGui.Button("创建可编辑的示例宏"))
            {var m=configuration.AddMacro(false);if(m!=null){m.Name="我的第一个宏";m.Commands="/echo 你好\n/wait 1\n/echo 示例结束";SaveConfiguration();OpenEditor(m);}}RecordItem("welcome-example");
            ImGui.EndDisabled();
            if(configuration.CountEntries()>=Configuration.MaxEntries)ImGui.TextWrapped("宏库已达 200 条（包括宏组与子宏），请先整理已有条目。");
            if(ImGui.Button("从游戏导入宏"))NavigateTask(TaskPage.NativeImport);RecordItem("welcome-import");return;
        }
        var parent=configuration.FindParent(entry);var frame=ImGui.GetFrameHeight();var reserve=MathF.Max(S(37),frame)+S(9);
        ImGui.BeginChild("##TaskEditScroll",new Vector2(0,MathF.Max(S(85),ImGui.GetContentRegionAvail().Y-reserve)),false);
        if(lastTaskEditorId!=entry.Id){ImGui.SetScrollY(0);lastTaskEditorId=entry.Id;}
        RecordRegion("editor-scroll",ImGui.GetCurrentContext().CurrentWindow.InnerClipRect.Min,ImGui.GetCurrentContext().CurrentWindow.InnerClipRect.Max);
        var paired=compact&&ImGui.GetContentRegionAvail().X>=S(370);var nameWidth=(ImGui.GetContentRegionAvail().X-ImGui.GetStyle().ItemSpacing.X)/2;
        var name=entry.Name;ImGui.TextUnformatted("名称");ImGui.SameLine();ImGui.SetNextItemWidth(paired?nameWidth-ImGui.CalcTextSize("名称").X-ImGui.GetStyle().ItemSpacing.X:-1);
        if(ImGui.InputText("##TaskName",ref name,Configuration.MaxNameLength*4+1)){entry.Name=name;metadataDirty=true;InvalidateLibrary();}RecordItem("edit-name");if(ImGui.IsItemDeactivatedAfterEdit())SaveConfiguration();
        var tag=(parent??entry).Group;if(paired)ImGui.SameLine();ImGui.TextUnformatted("分类");ImGui.SameLine();ImGui.SetNextItemWidth(-1);ImGui.BeginDisabled(parent!=null);
        if(ImGui.InputTextWithHint("##TaskTag","未分类",ref tag,Configuration.MaxGroupLength*4+1)){entry.Group=tag;metadataDirty=true;InvalidateLibrary();}RecordItem("edit-category");ImGui.EndDisabled();
        var pinned=entry.Pinned;if(ImGui.Checkbox(parent!=null?"仅此子宏加入常用栏":"加入常用宏悬浮栏",ref pinned)){entry.Pinned=pinned;SaveConfiguration();}RecordItem("edit-favorite");
        ImGui.BeginDisabled(configuration.CountEntries()+1+(entry.IsGroup?entry.Children.Count:0)>Configuration.MaxEntries||(parent!=null&&parent.Children.Count>=Configuration.MaxChildren));
        if(ImGui.Button(parent==null?"复制为新宏":"复制此子宏")){var copy=configuration.Duplicate(entry);if(copy!=null)OpenEditor(copy);InvalidateLibrary();}RecordItem("duplicate");ImGui.EndDisabled();ImGui.SameLine();
        if(ImGui.Button(entry.IsGroup?"删除此宏组":parent==null?"删除此宏":"删除此子宏")){pendingDelete=entry;openDeletePopup=true;}RecordItem("delete");
        if(compact&&parent==null){if(ImGui.GetItemRectMax().X+ImGui.CalcTextSize("上移下移").X+ImGui.GetStyle().FramePadding.X*4+ImGui.GetStyle().ItemSpacing.X*2<ImGui.GetCurrentContext().CurrentWindow.InnerClipRect.Max.X)ImGui.SameLine();DrawTaskMoveButtons(entry);}
        if(parent!=null)
        {ImGui.TextUnformatted(Fit("所属宏组："+parent.Name,ImGui.GetContentRegionAvail().X));if(ImGui.SmallButton("返回所属宏组"))OpenEditor(parent);RecordItem("task-parent");ImGui.SameLine();DrawTaskMoveButtons(entry);}
        if(entry.IsGroup)DrawGroupEditor(entry);else DrawCommandEditor(entry);
        ImGui.EndChild();
        var width=ImGui.GetContentRegionAvail().X;var buttonWidth=parent==null?width:(width-ImGui.GetStyle().ItemSpacing.X)/2;
        ImGui.BeginDisabled(macroExecutor.IsRunning||(entry.IsGroup?entry.Children.Count==0:string.IsNullOrWhiteSpace(entry.Commands)));
        if(ShelfSkin.Button(CurrentTheme,entry.IsGroup?"运行整组":parent==null?"运行此宏":"只运行此子宏",new Vector2(buttonWidth,MathF.Max(S(37),frame)),true,glyph:ShelfGlyph.Play))macroExecutor.Start(entry);RecordItem("edit-run");ImGui.EndDisabled();
        if(parent!=null){ImGui.SameLine();ImGui.BeginDisabled(macroExecutor.IsRunning);if(ShelfSkin.Button(CurrentTheme,"运行所属宏组",new Vector2(buttonWidth,MathF.Max(S(37),frame))))macroExecutor.Start(parent);RecordItem("edit-run-group");ImGui.EndDisabled();}
    }
    private MacroEntry? DrawTaskTarget()
    {
        var rows=QuickBarModel.All(configuration);var current=rows.FirstOrDefault(e=>e.Macro.Id==taskTargetId);
        if(current.Macro==null&&rows.Count>0){current=rows[0];taskTargetId=current.Macro.Id;}
        ImGui.TextUnformatted("作用对象：选择插件宏、宏组或子宏");ImGui.SetNextItemWidth(-1);
        if(ImGui.BeginCombo("##TaskTarget",current.Macro==null?"请先创建或导入宏":current.Label+"（"+current.Kind+"）"))
        {foreach(var row in rows){if(ImGui.Selectable(row.Label+"（"+row.Kind+"）##"+row.Macro.Id,row.Macro.Id==taskTargetId))taskTargetId=row.Macro.Id;RecordItem("target-"+row.Macro.Id);}ImGui.EndCombo();}RecordItem("task-target");
        ImGui.Separator();return rows.FirstOrDefault(e=>e.Macro.Id==taskTargetId).Macro;
    }
    private void DrawTaskDisplay()
    {
        var entry=DrawTaskTarget();if(entry==null)return;
        if(DisplayPage==null){if(ImGui.Button("设置所选宏的显示技能"))OpenDisplaySettings?.Invoke(entry);RecordItem("direct-display");return;}
        if(!ReferenceEquals(entry,loadedDisplay)){DisplayPage.OpenEmbedded(entry);loadedDisplay=entry;}
        DisplayPage.DrawEmbedded();
    }
    private void DrawTaskBridge()
    {
        var entry=DrawTaskTarget();if(entry==null)return;
        if(ImGui.Button("复制所选条目 ID"))ImGui.SetClipboardText(entry.Id);RecordItem("direct-copy-id");
        if(BridgePage==null){if(ImGui.Button("预览并生成所选宏的游戏入口"))OpenNativeMacroBridge?.Invoke(entry);RecordItem("direct-bridge");return;}
        if(!ReferenceEquals(entry,loadedBridge)){BridgePage.OpenEmbedded(entry);loadedBridge=entry;}
        BridgePage.DrawEmbedded();
    }
    private void DrawTaskQuickBar()
    {
        DrawQuickBarSettings();ImGui.Separator();ImGui.TextUnformatted("选择需要加入的宏（不会自动运行）");ImGui.SetNextItemWidth(-1);
        if(ImGui.BeginCombo("##AddTaskQuickBar","添加宏 / 宏组 / 子宏"))
        {foreach(var row in QuickBarModel.All(configuration)){if(ImGui.Selectable(row.Label+"（"+row.Kind+"）##"+row.Macro.Id,row.Macro.Pinned))QuickBarModel.SetPinned(configuration,row.Macro,!row.Macro.Pinned);RecordItem("quick-add-"+row.Macro.Id);}ImGui.EndCombo();}RecordItem("quick-add");
        foreach(var row in QuickBarModel.Pinned(configuration).ToArray())
        {
            ImGui.PushID(row.Macro.Id);ImGui.Separator();ImGui.TextWrapped(row.Label+"（"+row.Kind+"）");
            ImGui.BeginDisabled(macroExecutor.IsRunning);if(ImGui.Button("运行"))macroExecutor.Start(row.Macro);RecordItem("quick-run-"+row.Macro.Id);ImGui.EndDisabled();ImGui.SameLine();
            if(ImGui.Button("编辑命令"))OpenEditor(row.Macro);RecordItem("quick-edit-"+row.Macro.Id);ImGui.SameLine();
            if(ImGui.Button("移出常用栏"))QuickBarModel.SetPinned(configuration,row.Macro,false);RecordItem("quick-remove-"+row.Macro.Id);ImGui.PopID();
        }
    }
    private void DrawTaskBackup()
    {
        ImGui.TextUnformatted("备份：复制当前插件宏库");if(ImGui.Button("复制插件备份到剪贴板"))ExportConfiguration();RecordItem("backup-copy");
        ImGui.Separator();ImGui.TextUnformatted("恢复：粘贴 Macro Shelf-A 导出的 JSON");
        ImGui.TextWrapped("追加导入保留现有宏；替换会覆盖全部插件宏、停止执行，并应用备份的等待 / 行数设置。");
        if(ImGui.Button("从剪贴板粘贴")){importText=ImGui.GetClipboardText()??"";confirmReplaceImport=false;}RecordItem("backup-paste");ImGui.SameLine();
        if(ImGui.Button("清空输入")){importText="";confirmReplaceImport=false;}RecordItem("backup-clear");
        ImGui.InputTextMultiline("##TaskBackupJson",ref importText,ConfigurationExchange.MaximumJsonLength,new Vector2(-1,MathF.Max(S(90),ImGui.GetContentRegionAvail().Y-S(155))));RecordItem("backup-json");
        ImGui.Checkbox("我确认替换将覆盖当前插件宏库",ref confirmReplaceImport);RecordItem("backup-confirm");
        taskBackupInline=true;
        try
        {
            if(ImGui.Button("追加导入，保留现有宏"))ImportConfiguration(false);RecordItem("backup-append");
            ImGui.BeginDisabled(!confirmReplaceImport);if(ImGui.Button("替换现有插件宏库"))ImportConfiguration(true);RecordItem("backup-replace");ImGui.EndDisabled();
        }
        finally{taskBackupInline=false;}
        if(transferStatus.Length>0)ImGui.TextWrapped(transferStatus);
    }
    private void DrawTaskAppearance()
    {
        ImGui.TextUnformatted("界面主题");ImGui.SetNextItemWidth(-1);DrawThemeSelector("##TaskTheme");
        var decor=configuration.ShowThemeDecoration;if(ImGui.Checkbox("显示主题装饰（不遮挡功能）",ref decor)){configuration.ShowThemeDecoration=decor;SaveConfiguration();}RecordItem("setting-decoration");
        var motion=configuration.ReduceThemeMotion;if(ImGui.Checkbox("减少动态效果",ref motion)){configuration.ReduceThemeMotion=motion;SaveConfiguration();}RecordItem("setting-reduce-motion");
        var dock=configuration.ShowWorkbenchQuickBar;if(ImGui.Checkbox("大窗口底部显示常用栏预览",ref dock)){configuration.ShowWorkbenchQuickBar=dock;SaveConfiguration();}RecordItem("setting-workbench-dock");
        ImGui.Separator();ImGui.TextUnformatted("关闭主窗口后的悬浮入口");DrawFloatingLauncherSetting();
        ImGui.TextWrapped("悬浮图标只用于重新打开插件；直接运行宏请使用左侧“常用宏悬浮栏”。");
        ImGui.Separator();ImGui.TextUnformatted("界面文字统一使用游戏插件原生常规字重，不叠画加粗，不单独放大。");
    }
    private void DrawTaskStatus()
    {
        var start=ImGui.GetCursorScreenPos();var width=ImGui.GetContentRegionAvail().X;var running=macroExecutor.IsRunning;
        ImGui.SetCursorScreenPos(start+new Vector2(MathF.Max(0,width-S(110)),0));ImGui.BeginDisabled(!running);
        if(ShelfSkin.Button(CurrentTheme,"停止运行",new Vector2(S(110),ImGui.GetFrameHeight()),running))macroExecutor.Stop();RecordItem("stop");ImGui.EndDisabled();
        var text=running?$"正在运行：{macroExecutor.CurrentMacroName} · {macroExecutor.ExecutedLines}/{macroExecutor.TotalLines}":configuration.CountdownTriggerEnabled?"就绪 · 倒计时结束后运行已启用":taskPage is TaskPage.Macros or TaskPage.Groups?"就绪 · 宏编辑自动保存；点击运行可执行":"就绪 · 当前没有宏在运行";
        if(running&&macroExecutor.IsWaitingForJobChange)text="运行中 · 等待职业与套装同步";
        ImGui.SetCursorScreenPos(start+new Vector2(0,ImGui.GetStyle().FramePadding.Y));ImGui.TextUnformatted(Fit(text,width-S(124)));
        var clip=ImGui.GetCurrentContext().CurrentWindow.InnerClipRect;RecordRegion("footer",clip.Min,clip.Max);
    }
}
