using System;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Plugin.Services;
using MacroShelfA.Runtime;
namespace MacroShelfA.Windows;
internal sealed partial class MainWindow
{
    internal IShelfArtwork? Artwork{get;set;}
    internal ISkillDisplayProvider? SkillDisplay{get;set;}
    internal ITextureProvider? Textures{get;set;}
    internal Action<Vector2>? DrawQuickDock{get;set;}
    private ShelfTheme renderingTheme=ShelfTheme.Persona3;
    private ShelfTheme CurrentTheme=>renderingTheme;
    private bool compactTree;
    private WorkbenchLayout themedLayout;
    private IDisposable? hostTheme;
    private bool hostBackdrop;
    public override void PreDraw()
    {
        renderingTheme=configuration.Theme;
        ShelfSkin.Artwork=Artwork;
        Flags=ImGuiWindowFlags.NoScrollbar|ImGuiWindowFlags.NoScrollWithMouse|(CurrentTheme==ShelfTheme.Classic?0:ImGuiWindowFlags.NoTitleBar);
        hostTheme=ShelfSkin.Apply(CurrentTheme,configuration.ReduceThemeMotion);
        hostBackdrop=CurrentTheme!=ShelfTheme.Classic;
        if(hostBackdrop)ImGui.PushStyleColor(ImGuiCol.WindowBg,ShelfSkin.Palette(CurrentTheme).Background);
    }
    public override void PostDraw(){if(hostBackdrop)ImGui.PopStyleColor();hostBackdrop=false;hostTheme?.Dispose();hostTheme=null;}
    partial void RecordRegion(string key,Vector2 minimum,Vector2 maximum);
    private void DrawThemedWindow()
    {
        renderingTheme=configuration.Theme;
        ImGui.SetWindowFontScale(1);
        using var skin=ShelfSkin.Apply(CurrentTheme,configuration.ReduceThemeMotion);
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing,new Vector2(S(9),S(8)));
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding,new Vector2(S(9),S(6)));
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding,new Vector2(S(12)));
        try
        {
            var origin=ImGui.GetCursorScreenPos();var size=ImGui.GetContentRegionAvail();
            var outer=size.X/Scale>=1400?S(18):0;origin+=new Vector2(outer);size-=new Vector2(outer*2);
            var dock=configuration.ShowWorkbenchQuickBar&&(configuration.AdvancedWorkbench||configuration.AllEntries().Any(m=>m.Pinned));
            themedLayout=WorkbenchLayout.Calculate(size.X/Scale,size.Y/Scale,CurrentTheme,configuration.ShowThemeDecoration,dock,configuration.AdvancedWorkbench,QuickBarWindow.MinimumDockHeight(CurrentTheme),ImGui.GetCurrentContext().FontBaseSize*1.1f*1.16f/Scale+28);
            var l=themedLayout;
            DrawThemeBackdrop(origin,size,l);DrawThemeHeader(origin,l);
            At(origin,l.ContentLeft,l.HeaderHeight);
            ImGui.PushStyleColor(ImGuiCol.ChildBg,CurrentTheme==ShelfTheme.Needy?Vector4.Zero:ShelfSkin.Palette(CurrentTheme).Panel);
            ImGui.BeginChild("##WorkbenchTools",new Vector2(S(l.ContentWidth),S(l.ToolbarHeight)),false,ImGuiWindowFlags.NoScrollbar|ImGuiWindowFlags.NoScrollWithMouse);
            ImGui.PopStyleColor();DrawWorkbenchTools();ImGui.EndChild();
            At(origin,l.ContentLeft,l.BodyTop);
            ImGui.PushStyleColor(ImGuiCol.ChildBg,Vector4.Zero);
            ImGui.BeginChild("##WorkbenchContent",new Vector2(S(l.ContentWidth),S(l.BodyHeight)),false,ImGuiWindowFlags.NoScrollbar|ImGuiWindowFlags.NoScrollWithMouse);
            ImGui.PopStyleColor();
            RecordRegion("workbench",ImGui.GetWindowPos(),ImGui.GetWindowPos()+ImGui.GetWindowSize());
            var reveal=ShelfMotion.Reveal(ImGui.GetID("page-reveal-"+CurrentTheme+"-"+page));
            ImGui.PushStyleVar(ImGuiStyleVar.Alpha,ImGui.GetStyle().Alpha*(.78f+.22f*reveal));
            switch(page)
            {
                case Page.Editor:
                    if(!configuration.AdvancedWorkbench&&configuration.ShowGettingStarted&&configuration.Macros.Count>0)DrawGettingStarted();
                    DrawWorkbenchEditor(l);break;
                case Page.Library:DrawThemedLibrary();break;
                case Page.Settings:DrawSettings();break;
                case Page.Countdown:DrawCountdownTrigger();break;
                case Page.QuickBar:
                    BeginThemePanel("##QuickSettingsScroll",Vector2.Zero,true);
                    DrawQuickBarSettings();ImGui.Spacing();DrawAppearanceSettings();ImGui.EndChild();break;
            }
            ImGui.PopStyleVar();
            ImGui.EndChild();
            At(origin,l.ContentLeft,l.FooterTop);
            BeginThemePanel("##WorkbenchFooter",new Vector2(S(l.ContentWidth),S(l.FooterHeight)),false);
            var footerClip=ImGui.GetCurrentContext().CurrentWindow.InnerClipRect;RecordRegion("footer",footerClip.Min,footerClip.Max);
            DrawWorkbenchFooter();ImGui.EndChild();
            if(l.DockHeight>0)
            {
                var inset=CurrentTheme==ShelfTheme.Persona3?S(48):CurrentTheme==ShelfTheme.Needy?S(125):S(88);
                At(origin,l.ContentLeft+inset/Scale,l.Height-l.DockHeight+14);
                DrawQuickDock?.Invoke(new Vector2(S(l.ContentWidth)-inset*2,S(l.DockHeight-22)));
            }
            if(openDeletePopup){ImGui.OpenPopup("删除宏");openDeletePopup=false;}
            if(openImportPopup){ImGui.OpenPopup("导入配置");openImportPopup=false;}
            DrawDeleteConfirmation();DrawImportPopup();
            if(metadataDirty&&!ImGui.IsAnyItemActive())SaveConfiguration();
        }
        finally{ImGui.PopStyleVar(3);ImGui.SetWindowFontScale(1);}
    }
    private void BeginThemePanel(string id,Vector2 size,bool scroll,bool featured=false)
    {
        // Paint chrome on the parent draw list. Painting after BeginChild on
        // the child itself covers the native scrollbar that BeginChild drew.
        var chrome=ImGui.GetWindowDrawList();var available=ImGui.GetContentRegionAvail();var start=ImGui.GetCursorScreenPos();
        var resolved=new Vector2(MathF.Floor(size.X>0?size.X:MathF.Max(4,available.X+size.X)),MathF.Floor(size.Y>0?size.Y:MathF.Max(4,available.Y+size.Y)));
        // ImGui 1.88 may batch child decorations on its parent draw list, so
        // chrome must precede BeginChild rather than merely use another list.
        ShelfSkin.Panel(CurrentTheme,start,start+resolved,featured,chrome);
        ImGui.PushStyleColor(ImGuiCol.ChildBg,Vector4.Zero);
        ImGui.BeginChild(id,resolved,false,ImGuiWindowFlags.AlwaysUseWindowPadding|(scroll?ImGuiWindowFlags.None:ImGuiWindowFlags.NoScrollbar|ImGuiWindowFlags.NoScrollWithMouse));
        ImGui.PopStyleColor();
        ImGui.SetWindowFontScale(1);
    }
    private static void At(Vector2 origin,float x,float y)=>ImGui.SetCursorScreenPos(origin+new Vector2(S(x),S(y)));
    private void DrawThemeHeader(Vector2 origin,WorkbenchLayout l,bool taskNavigation=false)
    {
        var dl=ImGui.GetWindowDrawList();var p=ShelfSkin.Palette(CurrentTheme);var wide=l.HeaderHeight>100;
        // Empty title band is a real drag handle; no hit regions move with the artwork animation.
        At(origin,8,0);ImGui.InvisibleButton("##ThemeTitleDrag",new Vector2(S(MathF.Max(80,l.Width-248)),S(wide?43:37)));
        if(ImGui.IsItemActive()&&ImGui.IsMouseDragging(ImGuiMouseButton.Left,3))ImGui.SetWindowPos(ImGui.GetWindowPos()+ImGui.GetIO().MouseDelta);
        RecordItem("window-drag");
        if(CurrentTheme==ShelfTheme.Needy)
        {
            ShelfDrawing.Cat(dl,origin+new Vector2(S(20),S(10)),S(2.7f),p.Text);
            if(Artwork?.DrawLettering(dl,"needy-brand",origin+new Vector2(S(50),S(7)),S(wide?32:28),ImGui.GetColorU32(p.Text))!=true)ShelfDrawing.Text(dl,origin+new Vector2(S(57),S(10)),"Macro Shelf-A",S(wide?26:23),p.Text);
            if(l.Width>1100)dl.AddText(origin+new Vector2(S(300),S(17)),ImGui.GetColorU32(p.Accent),"— 让每一个宏，都成为你游戏中的小小魔法");
        }
        else
        {
            var pos=origin+new Vector2(S(l.ArtWidth+(CurrentTheme==ShelfTheme.Persona5?25:29)),S(wide?9:3));
            var logoSize=wide?new Vector2(S(CurrentTheme==ShelfTheme.Persona5?310:350),S(68)):new Vector2(S(265),S(45));
            if(Artwork!=null)Artwork.Draw(dl,true,pos,pos+logoSize,CurrentTheme==ShelfTheme.Persona5?0xff000000:0xffffffff);
            else ShelfDrawing.Text(dl,pos,"Macro Shelf-A",S(38),new Vector4(.01f,.05f,.12f,1),.16f);
            if(wide&&CurrentTheme==ShelfTheme.Persona3)dl.AddText(pos+new Vector2(S(5),S(71)),ImGui.GetColorU32(new Vector4(.005f,.08f,.25f,1)),"F O R   A   B R I G H T E R   T O M O R R O W");
        }
        At(origin,l.Width-34,6);
        if(ShelfSkin.Button(CurrentTheme,"×##ThemeClose",new Vector2(S(27),S(27))))IsOpen=false;RecordItem("window-close");
        if(taskNavigation)
        {At(origin,l.Width-244,wide&&CurrentTheme==ShelfTheme.Persona5?65:7);ImGui.SetNextItemWidth(S(203));DrawThemeSelector("##HeaderTheme");return;}
        var navX=wide&&CurrentTheme==ShelfTheme.Persona5?362:wide&&CurrentTheme==ShelfTheme.Persona3?MathF.Max(l.ContentLeft+240,l.Width-714):l.ContentLeft;
        var navY=wide&&CurrentTheme==ShelfTheme.Persona5?25:l.HeaderHeight-46;
        At(origin,navX,navY);
        var h=wide?38:29;var padding=wide?58:21;
        float TabWidth(string text)=>wide&&CurrentTheme==ShelfTheme.Needy?MathF.Min(S(190),S(l.ContentWidth-254)/5):ImGui.CalcTextSize(text).X+S(padding);
        void Tab(string label,Page target,string key,ShelfGlyph glyph)
        {
            var w=TabWidth(label);
            if(ShelfSkin.Button(CurrentTheme,label,new Vector2(w,S(h)),false,page==target,glyph:wide&&CurrentTheme==ShelfTheme.Needy?glyph:ShelfGlyph.None,nav:true))page=target;
            RecordItem(key);ImGui.SameLine();
        }
        if(!configuration.AdvancedWorkbench)
        {
            Tab("我的宏",Page.Editor,"nav-editor",ShelfGlyph.Home);Tab("常用栏",Page.QuickBar,"nav-quickbar",ShelfGlyph.Star);Tab("设置",Page.Settings,"nav-settings",ShelfGlyph.Gear);
            if(ShelfSkin.Button(CurrentTheme,"使用帮助",new Vector2(TabWidth("使用帮助"),S(h)),nav:true)){configuration.ShowGettingStarted=true;page=Page.Editor;SaveConfiguration();}RecordItem("nav-help");
        }
        else
        {
        Tab("工作台",Page.Editor,"nav-editor",ShelfGlyph.Home);
        ImGui.BeginDisabled(OpenNativeMacroImport==null);
        if(ShelfSkin.Button(CurrentTheme,"游戏宏导入",new Vector2(TabWidth("游戏宏导入"),S(h)),glyph:wide&&CurrentTheme==ShelfTheme.Needy?ShelfGlyph.Upload:ShelfGlyph.None,nav:true))OpenNativeMacroImport?.Invoke();
        RecordItem("nav-native-import");ImGui.EndDisabled();ImGui.SameLine();
        Tab("常用栏",Page.QuickBar,"nav-quickbar",ShelfGlyph.Star);Tab("事件触发",Page.Countdown,"nav-countdown",ShelfGlyph.Bolt);
        if(ShelfSkin.Button(CurrentTheme,"设置",new Vector2(TabWidth("设置"),S(h)),false,page==Page.Settings,glyph:wide&&CurrentTheme==ShelfTheme.Needy?ShelfGlyph.Gear:ShelfGlyph.None,nav:true))page=Page.Settings;RecordItem("nav-settings");
        }
        var comboY=wide&&CurrentTheme==ShelfTheme.Needy?navY+2:wide&&CurrentTheme==ShelfTheme.Persona5?69:wide?18:4;
        At(origin,l.Width-244,comboY);ImGui.SetNextItemWidth(S(203));DrawThemeSelector("##HeaderTheme");
    }
    private void DrawThemeSelector(string id)
    {
        if(ImGui.BeginCombo(id,ShelfSkin.Name(configuration.Theme)))
        {
            foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5,ShelfTheme.Classic})
            {if(ImGui.Selectable(ShelfSkin.Name(theme),configuration.Theme==theme)){configuration.Theme=theme;SaveConfiguration();}RecordItem("theme-"+theme);}
            ImGui.EndCombo();
        }
        RecordItem("theme-selector");
    }
    private void DrawAppearanceSettings()
    {
        ImGui.TextUnformatted("界面主题");ImGui.SameLine();ImGui.SetNextItemWidth(S(230));DrawThemeSelector("##SettingsTheme");
        var decoration=configuration.ShowThemeDecoration;if(ImGui.Checkbox("显示主题装饰（窄窗口自动收起）",ref decoration)){configuration.ShowThemeDecoration=decoration;SaveConfiguration();}RecordItem("setting-decoration");
        var dock=configuration.ShowWorkbenchQuickBar;if(ImGui.Checkbox("主工作台底部显示常用栏预览",ref dock)){configuration.ShowWorkbenchQuickBar=dock;SaveConfiguration();}RecordItem("setting-workbench-dock");
        var reduced=configuration.ReduceThemeMotion;if(ImGui.Checkbox("减少动态效果（停止背景漂移与过渡动画）",ref reduced)){configuration.ReduceThemeMotion=reduced;SaveConfiguration();}RecordItem("setting-reduce-motion");
    }
    private void DrawWorkbenchTools()
    {
        if(!configuration.AdvancedWorkbench){DrawSimpleTools();return;}
        var wide=themedLayout.HeaderHeight>100;var h=S(wide?40:28);
        ImGui.BeginDisabled(configuration.CountEntries()>=Configuration.MaxEntries);
        if(ShelfSkin.Button(CurrentTheme,"新建宏",new Vector2(S(wide?137:100),h),CurrentTheme!=ShelfTheme.Persona3,glyph:ShelfGlyph.Plus))AddEntry(false);RecordItem("new-macro");ImGui.EndDisabled();ImGui.SameLine();
        ImGui.BeginDisabled(configuration.CountEntries()+2>Configuration.MaxEntries);
        if(ShelfSkin.Button(CurrentTheme,"新建宏组",new Vector2(S(wide?145:113),h),CurrentTheme==ShelfTheme.Persona5,glyph:ShelfGlyph.Folder))AddEntry(true);RecordItem("new-group");ImGui.EndDisabled();ImGui.SameLine();
        if(ShelfSkin.Button(CurrentTheme,"导入配置",new Vector2(S(wide?137:110),h),glyph:wide?ShelfGlyph.Upload:ShelfGlyph.None))BeginImport();RecordItem("toolbar-import");ImGui.SameLine();
        if(ShelfSkin.Button(CurrentTheme,"导出配置",new Vector2(S(wide?137:110),h),glyph:wide?ShelfGlyph.Download:ShelfGlyph.None))ExportConfiguration();RecordItem("toolbar-export");
        ImGui.SameLine();if(ShelfSkin.Button(CurrentTheme,"资料库",new Vector2(S(81),h),selected:page==Page.Library))page=Page.Library;RecordItem("nav-library");
        ImGui.SameLine();if(ShelfSkin.Button(CurrentTheme,"简洁模式",new Vector2(S(96),h)))SetAdvancedWorkbench(false);RecordItem("mode-simple");
        if(wide&&CurrentTheme==ShelfTheme.Persona5&&ImGui.GetContentRegionAvail().X>S(900))Artwork?.DrawLettering(ImGui.GetWindowDrawList(),"WORKBENCH",ImGui.GetWindowPos()+new Vector2(ImGui.GetWindowSize().X-S(245),S(2)),S(44));
    }
    private void DrawWorkbenchFooter()
    {
        var p=ShelfSkin.Palette(CurrentTheme);var start=ImGui.GetCursorScreenPos();var available=ImGui.GetContentRegionAvail().X;var running=macroExecutor.IsRunning;var dl=ImGui.GetWindowDrawList();
        var state=running?ShelfSkin.StateColor(CurrentTheme,SkillAvailability.Ready):CurrentTheme==ShelfTheme.Needy?new Vector4(0,.67f,.57f,1):p.Muted;
        dl.AddCircleFilled(start+new Vector2(S(12),S(16)),S(9+(!configuration.ReduceThemeMotion&&running?(float)Math.Sin(ShelfMotion.Time*3)*1:0)),ImGui.GetColorU32(state),24);
        ImGui.SetCursorScreenPos(start+new Vector2(MathF.Max(0,available-S(108)),S(1)));
        ImGui.BeginDisabled(!running);if(ShelfSkin.Button(CurrentTheme,configuration.AdvancedWorkbench?"中止整组":"停止运行",new Vector2(S(108),S(33)),running))macroExecutor.Stop();RecordItem("stop");ImGui.EndDisabled();
        var waiting=macroExecutor.IsWaitingForJobChange?"等待职业与套装同步":$"等待 {macroExecutor.RemainingWait:F1}s";
        var idle=configuration.AdvancedWorkbench?"就绪 · 尚未运行     |     逐帧执行 · 显式等待保留":configuration.Macros.Count==0?"就绪 · 创建或导入你的第一个宏":"就绪 · 编辑自动保存，点击“运行”开始";
        var text=running?$"运行中 · {macroExecutor.CurrentMacroName} / {macroExecutor.CurrentChildName} · {macroExecutor.ExecutedLines}/{macroExecutor.TotalLines} · {waiting}":transferStatus.Length>0?transferStatus:idle;
        ImGui.SetCursorScreenPos(start+new Vector2(S(33),S(8)));ImGui.TextColored(p.Text,Fit(text,available-S(160)));if(ImGui.IsItemHovered())ImGui.SetTooltip(text);
    }
    private void DrawThemeBackdrop(Vector2 origin,Vector2 size,WorkbenchLayout l)
    {
        var dl=ImGui.GetWindowDrawList();var p=ShelfSkin.Palette(CurrentTheme);Vector2 V(float x,float y)=>origin+new Vector2(S(x),S(y));var motion=(float)ShelfMotion.Time;var wide=l.HeaderHeight>100;
        dl.AddRectFilled(origin,origin+size,ImGui.GetColorU32(p.Background));
        if(CurrentTheme==ShelfTheme.Persona3)
        {
            dl.AddRectFilledMultiColor(origin,origin+size,ImGui.GetColorU32(new Vector4(0,.77f,.94f,1)),ImGui.GetColorU32(new Vector4(0,.35f,.9f,1)),ImGui.GetColorU32(new Vector4(.025f,.07f,.31f,1)),ImGui.GetColorU32(new Vector4(.015f,.3f,.77f,1)));
            if(configuration.ShowThemeDecoration)ShelfDrawing.WaterLight(dl,origin,origin+size,motion);
            ShelfSkin.Quad(dl,V(l.ArtWidth-20,0),V(l.Width*.79f,0),V(l.Width*.57f,l.HeaderHeight-51),V(l.ArtWidth,l.HeaderHeight+15),ImGui.GetColorU32(Vector4.One));
            if(l.ArtWidth>0)
            {
                RecordRegion("artwork",origin,V(l.ArtWidth,l.Height));dl.PushClipRect(origin,V(l.ContentLeft-3,l.Height),true);var w=l.ArtWidth;
                var flags=dl.Flags;dl.Flags&=~ImDrawListFlags.AntiAliasedFill;
                for(var i=0;i<64;i++)
                {
                    Vector2 O(float t)=>V(w*(1.05f-.65f*MathF.Sin(t*MathF.PI)),l.Height*t);
                    Vector2 I(float t)=>V(w*(1.65f-.62f*MathF.Sin(t*MathF.PI)),l.Height*t);
                    ShelfSkin.Quad(dl,O(i/64f),I(i/64f),I((i+1)/64f),O((i+1)/64f),ImGui.GetColorU32(Vector4.One));
                }
                var ih=MathF.Min(l.Height*.47f,w*1.75f);var point=V(-w*.11f,l.Height-l.DockHeight-46-ih);
                Artwork?.Draw(dl,false,point,point+new Vector2(S(ih*694/448),S(ih)));
                for(var i=0;i<28;i++)
                {
                    var x=w*i/28;var xx=w*(i+1)/28;var y=l.Height-l.DockHeight-45+(x/w)*(x/w)*32;var yy=l.Height-l.DockHeight-45+(xx/w)*(xx/w)*32;
                    ShelfSkin.Quad(dl,V(x,y),V(xx,yy),V(xx,l.Height),V(x,l.Height),ImGui.GetColorU32(new Vector4(.018f,.095f,.28f,1)));dl.AddLine(V(x,y),V(xx,yy),ImGui.GetColorU32(p.Accent),S(4));
                }
                dl.Flags=flags;ShelfDrawing.Text(dl,V(17,l.Height-74),"ONE WORLD.",S(21),new Vector4(.43f,.8f,1,1),.16f);ShelfDrawing.Text(dl,V(17,l.Height-51),"YOUR RHYTHM.",S(21),new Vector4(.43f,.8f,1,1),.16f);dl.PopClipRect();
            }
            if(configuration.ShowThemeDecoration)
            {
                for(var i=0;i<4;i++)
                {
                    Vector2 Prev(float x)=>V(x,25+i*18+MathF.Sin(x/l.Width*6+motion*.12f+i)*14);
                    for(var x=0f;x<l.Width;x+=30)dl.AddLine(Prev(x),Prev(MathF.Min(l.Width,x+30)),ImGui.GetColorU32(new Vector4(.5f,.95f,1,.12f)),S(2));
                }
                if(wide)Artwork?.DrawLettering(dl,"03",V(l.Width-158,38),S(107),ImGui.GetColorU32(new Vector4(.5f,.87f,1,.38f)));
                for(var i=0;i<10;i++){var x=19+(i*83)%Math.Max(25,(int)l.ArtWidth);var y=(i*97+motion*(5+i%3))%l.Height;dl.AddCircle(V(x,y),S(2+i%3),ImGui.GetColorU32(new Vector4(.53f,.94f,1,.28f)),16,S(.8f));}
            }
        }
        else if(CurrentTheme==ShelfTheme.Needy)
        {
            dl.AddRectFilled(origin,V(l.Width,l.Height-l.DockHeight-3),ImGui.GetColorU32(p.Panel),S(5));
            dl.AddRect(origin,V(l.Width,l.Height-l.DockHeight-3),ImGui.GetColorU32(p.Text),S(5),ImDrawFlags.None,S(3));dl.AddRect(V(3,3),V(l.Width-3,l.Height-l.DockHeight-6),ImGui.GetColorU32(p.Border),S(3),ImDrawFlags.None,S(2));
            dl.AddRectFilledMultiColor(V(5,5),V(l.Width-5,45),ImGui.GetColorU32(new Vector4(.86f,.82f,1,1)),ImGui.GetColorU32(new Vector4(1,.75f,.93f,1)),ImGui.GetColorU32(new Vector4(1,.85f,.97f,1)),ImGui.GetColorU32(new Vector4(.94f,.85f,1,1)));
            if(configuration.ShowThemeDecoration&&wide)
            {
                ShelfDrawing.Cat(dl,V(l.Width-83,119),S(3.3f),p.Border);ShelfDrawing.Heart(dl,V(l.Width-140,125+(float)Math.Sin(motion*1.4f)*2),S(1.8f),p.Accent);
                for(var i=0;i<9;i++)ShelfDrawing.Heart(dl,V(20+i*137,l.Height-35+(float)Math.Sin(motion*.7f+i)*3),S(1.1f),new Vector4(.77f,.36f,.75f,.7f));
            }
        }
        else
        {
            var bottom=l.Height-l.DockHeight-4;
            ShelfSkin.Quad(dl,V(1,1),V(l.Width-3,3),V(l.Width,bottom-4),V(0,bottom),ImGui.GetColorU32(Vector4.One));
            ShelfSkin.Quad(dl,V(7,7),V(l.Width-7,7),V(l.Width-6,bottom-7),V(7,bottom-5),ImGui.GetColorU32(p.Accent));
            ShelfSkin.Quad(dl,V(20,7),V(l.Width-135,10),V(l.Width-105,l.HeaderHeight-3),V(20,l.HeaderHeight+2),ImGui.GetColorU32(new Vector4(.015f,.02f,.024f,1)));
            ShelfSkin.Quad(dl,V(16,wide?24:6),V(wide?334:306,3),V(wide?349:317,wide?79:44),V(25,wide?97:49),ImGui.GetColorU32(Vector4.One));
            if(configuration.ShowThemeDecoration)
            {
                ShelfDrawing.Dots(dl,V(0,1),V(15,100),new Vector4(.005f,.005f,.006f,.9f),true);
                ShelfDrawing.Star(dl,V(wide?345:330,wide?65:29),S(wide?26:17),Vector4.One);
                if(wide)
                {
                    for(var i=0;i<6;i++){var x=370+i*130;dl.AddTriangleFilled(V(x,7),V(x+105,7),V(x+33,15+(i%3)*7),ImGui.GetColorU32(p.Accent));}
                    ShelfDrawing.Dots(dl,V(l.Width-135,8),V(l.Width-8,93),new Vector4(.01f,.01f,.015f,.85f));
                }
            }
        }
    }
}
