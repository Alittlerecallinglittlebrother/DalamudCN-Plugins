using System;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Textures;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow
{
    private int compactInspector;
    private void DrawThemedLibrary()
    {
        var roots=VisibleRoots();var root=RootOf(selectedMacro);
        selectedMacro=root!=null&&roots.Contains(root)?root:roots.FirstOrDefault();
        var width=ImGui.GetContentRegionAvail().X;var wide=width>=S(1000);
        if(wide){BeginThemePanel("##ThemeCategories",new Vector2(width*.20f,0),false);DrawCategories();ImGui.EndChild();ImGui.SameLine();}
        else
        {
            if(ShelfSkin.Button(CurrentTheme,"全部",new Vector2(S(75),S(27)),selected:filter==LibraryFilter.All))SetFilter(LibraryFilter.All);RecordItem("filter-all");ImGui.SameLine();
            if(ShelfSkin.Button(CurrentTheme,"收藏",new Vector2(S(75),S(27)),selected:filter==LibraryFilter.Favorites))SetFilter(LibraryFilter.Favorites);RecordItem("filter-favorites");ImGui.SameLine();
            ImGui.SetNextItemWidth(MathF.Max(S(90),ImGui.GetContentRegionAvail().X));
            if(ImGui.InputTextWithHint("##ThemeLibrarySearch","搜索名称、子宏或命令…",ref searchText,256))InvalidateLibrary();RecordItem("search");
        }
        BeginThemePanel("##ThemeLibraryList",new Vector2(width*(wide?.42f:.49f),0),true);DrawMacroList(roots);ImGui.EndChild();ImGui.SameLine();
        BeginThemePanel("##ThemeInspector",Vector2.Zero,true,true);DrawInspector();ImGui.EndChild();
    }
    private void DrawWorkbenchEditor(WorkbenchLayout layout)
    {
        if(!configuration.AdvancedWorkbench&&configuration.Macros.Count==0){DrawFirstMacro();return;}
        var width=ImGui.GetContentRegionAvail().X;
        // At minimum width a switchable library panel preserves a full-size text editor.
        var narrow=width<S(665);
        if(narrow)
        {
            if(ImGui.Button(compactTree?"返回编辑命令":"宏库 / 选择条目"))compactTree=!compactTree;
            RecordItem("compact-tree-toggle");
            if(compactTree){DrawWorkbenchTree();return;}
            DrawWorkbenchSelected(false);return;
        }
        BeginThemePanel("##WorkbenchTree",new Vector2(S(layout.TreeWidth),0),false);
        DrawWorkbenchTree();ImGui.EndChild();ImGui.SameLine();
        var editorWidth=layout.HasSide?MathF.Max(S(350),ImGui.GetContentRegionAvail().X-S(layout.SideWidth)-S(9)):0;
        BeginThemePanel("##WorkbenchEditor",new Vector2(editorWidth,0),false,configuration.AdvancedWorkbench&&CurrentTheme!=ShelfTheme.Persona3);
        var clip=ImGui.GetCurrentContext().CurrentWindow.InnerClipRect;RecordRegion("editor-panel",clip.Min,clip.Max);
        DrawWorkbenchSelected(layout.HasSide);ImGui.EndChild();
        if(layout.HasSide)
        {
            ImGui.SameLine();ImGui.PushStyleColor(ImGuiCol.ChildBg,Vector4.Zero);ImGui.BeginChild("##WorkbenchAside",Vector2.Zero,false,ImGuiWindowFlags.NoScrollbar|ImGuiWindowFlags.NoScrollWithMouse);ImGui.PopStyleColor();
            var remaining=ImGui.GetContentRegionAvail().Y;
            BeginThemePanel("##SkillCard",new Vector2(0,remaining*(remaining>S(480)?.49f:.54f)),true,true);DrawSkillPanel();ImGui.EndChild();
            BeginThemePanel("##BridgeCard",Vector2.Zero,true,true);DrawBridgePanel();ImGui.EndChild();
            ImGui.EndChild();
        }
    }
    private void DrawWorkbenchTree()
    {
        if(!configuration.AdvancedWorkbench){DrawSimpleTree();return;}
        var treeWidth=ImGui.GetContentRegionAvail().X;
        if(themedLayout.HeaderHeight>100&&CurrentTheme==ShelfTheme.Persona5)ShelfSkin.SectionTitle(CurrentTheme,"宏库");
        ImGui.SetNextItemWidth(-1);
        if(ImGui.InputTextWithHint("##WorkbenchSearch","搜索宏或命令…",ref searchText,256))InvalidateLibrary();RecordItem("search");
        if(ShelfSkin.Button(CurrentTheme,"全部",new Vector2(S(62),S(27)),false,filter!=LibraryFilter.Favorites))SetFilter(LibraryFilter.All);
        RecordItem("filter-all");ImGui.SameLine();
        if(ShelfSkin.Button(CurrentTheme,"收藏",new Vector2(S(62),S(27)),false,filter==LibraryFilter.Favorites))SetFilter(LibraryFilter.Favorites);
        RecordItem("filter-favorites");if(treeWidth>S(210)){ImGui.SameLine();ImGui.TextDisabled($"{configuration.CountEntries()}/{Configuration.MaxEntries}");}
        ImGui.Separator();
        var decor=configuration.ShowThemeDecoration&&CurrentTheme!=ShelfTheme.Persona3&&ImGui.GetContentRegionAvail().Y>S(390);
        ImGui.BeginChild("##WorkbenchTreeScroll",new Vector2(0,decor?ImGui.GetContentRegionAvail().Y-S(65):0),false);
        ImGui.SetWindowFontScale(1);
        var matches=configuration.Macros.Where(m=>MacroLibrary.Matches(m,searchText));
        if(filter==LibraryFilter.Favorites)matches=matches.Where(m=>m.Pinned||m.Children.Any(c=>c.Pinned));
        var groups=matches.GroupBy(MacroLibrary.Tag).OrderBy(g=>g.Key=="未分类").ThenBy(g=>g.Key,StringComparer.OrdinalIgnoreCase).ToArray();
        foreach(var tag in groups)
        {
            var open=!collapsedCategories.Contains(tag.Key)||searchText.Length>0||filter==LibraryFilter.Favorites;
            if(ImGui.Selectable($"{(open?"v":">")}  {Fit(tag.Key,ImGui.GetContentRegionAvail().X-S(25))}##theme-category-{tag.Key}",false,ImGuiSelectableFlags.None,new Vector2(0,S(28))))
            {if(open)collapsedCategories.Add(tag.Key);else collapsedCategories.Remove(tag.Key);}
            RecordItem("tree-category-"+tag.Key);
            if(!open)continue;
            foreach(var root in tag.ToArray())
            {
                ImGui.PushID(root.Id);
                if(root.IsGroup)
                {
                    var expanded=expandedGroups.Contains(root.Id)||searchText.Length>0||filter==LibraryFilter.Favorites;
                    if(ImGui.SmallButton(expanded?"v":">")){if(expanded)expandedGroups.Remove(root.Id);else expandedGroups.Add(root.Id);}
                    RecordItem("tree-expand-"+root.Id);ImGui.SameLine();
                    if(ThemedTreeRow(root,MathF.Max(S(35),ImGui.GetTextLineHeight()+S(12)))){selectedMacro=root;compactTree=false;}
                    if(expanded)
                    {
                        ImGui.Indent(S(21));
                        foreach(var child in root.Children.ToArray())
                        {
                            if(!MacroLibrary.MatchesSelf(root,searchText)&&!MacroLibrary.MatchesSelf(child,searchText))continue;
                            if(ThemedTreeRow(child,MathF.Max(S(35),ImGui.GetTextLineHeight()+S(12)))){selectedMacro=child;compactTree=false;}
                        }
                        ImGui.Unindent(S(21));
                    }
                }
                else if(ThemedTreeRow(root,MathF.Max(S(36),ImGui.GetTextLineHeight()+S(12)))){selectedMacro=root;compactTree=false;}
                ImGui.PopID();
            }
            ImGui.Spacing();
        }
        if(groups.Length==0)ImGui.TextWrapped(configuration.Macros.Count==0?"还没有宏。使用上方的新建按钮开始。":"没有匹配的宏；当前编辑内容仍保留。");
        ImGui.EndChild();
        if(decor)
        {
            var p=ImGui.GetCursorScreenPos();var dl=ImGui.GetWindowDrawList();var palette=ShelfSkin.Palette(CurrentTheme);
            if(CurrentTheme==ShelfTheme.Needy){ShelfDrawing.Cat(dl,p+new Vector2(S(10),S(9)),S(3.6f),palette.Border);ShelfDrawing.Heart(dl,p+new Vector2(S(55),S(4)),S(1.5f),palette.Accent);dl.AddText(p+new Vector2(S(77),S(13)),ImGui.GetColorU32(palette.Muted),"SAME PLAYS\nBRIGHTER DAYS.");}
            else if(CurrentTheme==ShelfTheme.Persona5){ShelfDrawing.Dots(dl,p,p+new Vector2(treeWidth,S(62)),palette.Accent);ShelfDrawing.Star(dl,p+new Vector2(treeWidth-S(26),S(37)),S(22),Vector4.One);ShelfDrawing.Text(dl,p+new Vector2(S(8),S(12)),"PLAY YOUR\nMACROS.",S(17),palette.Text,.16f);}
        }
    }
    private bool ThemedTreeRow(MacroEntry entry,float height)
    {
        var width=ImGui.GetContentRegionAvail().X;var selected=ReferenceEquals(selectedMacro,entry);
        var hit=EntryRow(entry,"tree-"+entry.Id,selected,height,width-S(29));
        var textY=ImGui.GetItemRectMin().Y+(height-ImGui.GetFontSize())/2;var clip=ImGui.GetCurrentContext().CurrentWindow.ClipRect;
        ImGui.SameLine(0,0);
        if(textY<clip.Min.Y||textY+ImGui.GetFontSize()>clip.Max.Y){ImGui.Dummy(new Vector2(S(26),S(30)));return hit;}
        if(IconButton("pin-"+entry.Id,entry.Pinned?"移出常用栏":"加入常用栏",Icon.Star,entry.Pinned)){entry.Pinned=!entry.Pinned;SaveConfiguration();}
        RecordItem("tree-pin-"+entry.Id);return hit;
    }
    private void DrawWorkbenchSelected(bool sideVisible)
    {
        if(!configuration.AdvancedWorkbench){DrawSimpleSelected();return;}
        if(selectedMacro==null||RootOf(selectedMacro)==null)
        {selectedMacro=null;ShelfSkin.SectionTitle(CurrentTheme,"工作台");ImGui.TextWrapped("从宏库选择一个条目，或使用顶部“新建宏 / 新建宏组”。");return;}
        var entry=selectedMacro;var parent=configuration.FindParent(entry);
        var shortEditor=ImGui.GetContentRegionAvail().Y<S(350);
        var path=parent==null?MacroLibrary.Tag(entry):$"{MacroLibrary.Tag(parent)} / {parent.Name}";
        ImGui.TextColored(ShelfSkin.Palette(CurrentTheme).Muted,Fit(path+" / "+entry.Name,ImGui.GetContentRegionAvail().X-(shortEditor?S(76):0)));
        if(ImGui.IsItemHovered())ImGui.SetTooltip(path+" / "+entry.Name);
        if(shortEditor){ImGui.SameLine();if(ImGui.SmallButton(showEntryProperties?"返回命令":"名称属性"))showEntryProperties=!showEntryProperties;RecordItem("edit-properties");}
        if(!sideVisible)
        {
            var total=ImGui.GetContentRegionAvail().X;var buttonWidth=(total-S(14))/3;
            foreach(var (label,index) in new[]{("命令",0),("图标与技能",1),("热键栏入口",2)})
            {
                if(index>0)ImGui.SameLine();
                if(ShelfSkin.Button(CurrentTheme,label,new Vector2(buttonWidth,S(27)),false,compactInspector==index))compactInspector=index;
                RecordItem("compact-tab-"+index);
            }
        }
        var actionHeight=MathF.Max(S(42),ImGui.GetFrameHeight())+S(16);
        if(parent==null)actionHeight+=ImGui.GetFrameHeight()+ImGui.GetStyle().ItemSpacing.Y;
        if(!shortEditor)actionHeight+=ImGui.GetTextLineHeight()+S(6);
        var bodyHeight=MathF.Max(S(80),ImGui.GetContentRegionAvail().Y-actionHeight);
        ImGui.BeginChild("##WorkbenchEditScroll",new Vector2(0,bodyHeight),false);
        ImGui.SetWindowFontScale(1);
        if(!sideVisible&&compactInspector==1)DrawSkillPanel();
        else if(!sideVisible&&compactInspector==2)DrawBridgePanel();
        else
        {
            if(!shortEditor||showEntryProperties)
            {
                DrawWorkbenchMetadata(entry,parent);
                if(parent!=null)DrawSequenceStrip(parent,entry);
            }
            if(macroExecutor.IsRunning)ImGui.TextColored(ShelfSkin.Palette(CurrentTheme).Muted,"执行使用启动时快照；编辑在下次运行生效。");
            if(entry.IsGroup)DrawGroupEditor(entry);
            else if(!shortEditor||!showEntryProperties)DrawCommandEditor(entry);
        }
        ImGui.EndChild();
        DrawWorkbenchActions(entry,parent);
    }
    private void DrawWorkbenchMetadata(MacroEntry entry,MacroEntry? parent)
    {
        var width=ImGui.GetContentRegionAvail().X;var wide=width>=S(565);var name=entry.Name;
        ImGui.TextUnformatted("名称");ImGui.SameLine();ImGui.SetNextItemWidth(wide?width*.31f:MathF.Max(S(95),width-S(175)));
        if(ImGui.InputText("##MacroName",ref name,Configuration.MaxNameLength*4+1)){entry.Name=name;metadataDirty=true;InvalidateLibrary();}RecordItem("edit-name");if(ImGui.IsItemDeactivatedAfterEdit())SaveConfiguration();
        ImGui.SameLine();
        if(wide)
        {
            ImGui.TextUnformatted("分类");ImGui.SameLine();ImGui.SetNextItemWidth(width*.20f);
            var tag=(parent??entry).Group;ImGui.BeginDisabled(parent!=null);
            if(ImGui.InputTextWithHint("##MacroTag","未分类",ref tag,Configuration.MaxGroupLength*4+1)){entry.Group=tag;metadataDirty=true;InvalidateLibrary();}
            RecordItem("edit-category");ImGui.EndDisabled();if(ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled)&&parent!=null)ImGui.SetTooltip("子宏分类继承自宏组；在宏组属性中更改。");
            if(ImGui.IsItemDeactivatedAfterEdit())SaveConfiguration();ImGui.SameLine();
        }
        var pinned=entry.Pinned;if(ImGui.Checkbox("加入常用栏",ref pinned)){entry.Pinned=pinned;SaveConfiguration();}RecordItem("edit-favorite");
        if(!wide&&parent==null)
        {
            ImGui.TextUnformatted("分类");ImGui.SameLine();ImGui.SetNextItemWidth(-1);var tag=entry.Group;
            if(ImGui.InputTextWithHint("##MacroTag","未分类",ref tag,Configuration.MaxGroupLength*4+1)){entry.Group=tag;metadataDirty=true;InvalidateLibrary();}
            RecordItem("edit-category");if(ImGui.IsItemDeactivatedAfterEdit())SaveConfiguration();
        }
        ImGui.Spacing();ImGui.Separator();
    }
    private void DrawSequenceStrip(MacroEntry parent,MacroEntry entry)
    {
        var start=ImGui.GetCursorScreenPos();var available=ImGui.GetContentRegionAvail().X;
        ImGui.TextColored(ShelfSkin.Palette(CurrentTheme).Muted,"子宏顺序");
        ImGui.SetCursorScreenPos(start+new Vector2(MathF.Max(S(85),available-S(224)),0));
        ImGui.BeginDisabled(parent.Children.Count>=Configuration.MaxChildren||configuration.CountEntries()>=Configuration.MaxEntries);
        if(ShelfSkin.Button(CurrentTheme,"添加子宏",new Vector2(S(97),S(24)),glyph:ShelfGlyph.Plus)){var child=configuration.AddChild(parent);if(child!=null)OpenEditor(child);}RecordItem("add-child");ImGui.EndDisabled();ImGui.SameLine();
        var index=parent.Children.IndexOf(entry);
        ImGui.BeginDisabled(index<=0);if(ShelfSkin.Button(CurrentTheme,"上移",new Vector2(S(54),S(24)))){configuration.Move(entry,-1);InvalidateLibrary();}RecordItem("move-up");ImGui.EndDisabled();ImGui.SameLine();
        ImGui.BeginDisabled(index<0||index>=parent.Children.Count-1);if(ShelfSkin.Button(CurrentTheme,"下移",new Vector2(S(54),S(24)))){configuration.Move(entry,1);InvalidateLibrary();}RecordItem("move-down");ImGui.EndDisabled();
        ImGui.BeginChild("##SubmacroSequence",new Vector2(0,S(48)),false,ImGuiWindowFlags.HorizontalScrollbar);
        var cell=Math.Clamp((available-S(15)*Math.Max(0,parent.Children.Count-1))/Math.Max(1,parent.Children.Count),S(98),S(146));
        for(var i=0;i<parent.Children.Count;i++)
        {
            var child=parent.Children[i];if(i>0){ImGui.SameLine(0,S(2));ImGui.TextColored(ShelfSkin.Palette(CurrentTheme).Muted,"›");ImGui.SameLine(0,S(2));}
            var prefix=$"{i+1:00} ";var name=child.Name.StartsWith(prefix,StringComparison.Ordinal)?child.Name[prefix.Length..]:child.Name;
            if(ShelfSkin.Button(CurrentTheme,prefix+Fit(name,cell-S(39))+"##seq-"+child.Id,new Vector2(cell,S(32)),false,ReferenceEquals(entry,child)))selectedMacro=child;
            RecordItem("sequence-"+child.Id);if(ImGui.IsItemHovered())ImGui.SetTooltip(child.Name);
        }
        ImGui.EndChild();
    }
    private void DrawWorkbenchActions(MacroEntry entry,MacroEntry? parent)
    {
        ImGui.Separator();var width=ImGui.GetContentRegionAvail().X;var p=ShelfSkin.Palette(CurrentTheme);var small=width<S(450);
        if(parent==null)
        {
            var index=configuration.Macros.IndexOf(entry);ImGui.BeginDisabled(index<=0);
            if(ImGui.SmallButton("上移")){configuration.Move(entry,-1);InvalidateLibrary();}RecordItem("move-up");ImGui.EndDisabled();ImGui.SameLine();
            ImGui.BeginDisabled(index>=configuration.Macros.Count-1);if(ImGui.SmallButton("下移")){configuration.Move(entry,1);InvalidateLibrary();}RecordItem("move-down");ImGui.EndDisabled();
        }
        var spacing=ImGui.GetStyle().ItemSpacing.X;var buttons=parent==null?3:4;var free=width-spacing*(buttons-1);var runWidth=parent==null?free*.56f:free*.34f;var groupWidth=free*.30f;var editWidth=parent==null?free*.22f:free*.18f;
        ImGui.BeginDisabled(macroExecutor.IsRunning||(entry.IsGroup&&entry.Children.Count==0));
        var label=entry.IsGroup?"运行整组":parent==null?"运行此宏":"运行此子宏";
        if(ShelfSkin.Button(CurrentTheme,label,new Vector2(runWidth,S(small?34:42)),true,glyph:small?ShelfGlyph.None:ShelfGlyph.Play))macroExecutor.Start(entry);RecordItem("edit-run");
        if(parent!=null){ImGui.SameLine();if(ShelfSkin.Button(CurrentTheme,"运行整组",new Vector2(groupWidth,S(small?34:42)),glyph:small?ShelfGlyph.None:ShelfGlyph.Next))macroExecutor.Start(parent);RecordItem("edit-run-group");}
        ImGui.EndDisabled();ImGui.SameLine();
        ImGui.BeginDisabled(configuration.CountEntries()+1+(entry.IsGroup?entry.Children.Count:0)>Configuration.MaxEntries||(parent!=null&&parent.Children.Count>=Configuration.MaxChildren));
        if(ShelfSkin.Button(CurrentTheme,"复制",new Vector2(editWidth,S(small?34:42)),glyph:small?ShelfGlyph.None:ShelfGlyph.Copy)){var copy=configuration.Duplicate(entry);if(copy!=null)OpenEditor(copy);InvalidateLibrary();}RecordItem("duplicate");ImGui.EndDisabled();ImGui.SameLine();
        if(ShelfSkin.Button(CurrentTheme,"删除",new Vector2(editWidth,S(small?34:42)),danger:true,glyph:small?ShelfGlyph.None:ShelfGlyph.Trash)){pendingDelete=entry;openDeletePopup=true;}RecordItem("delete");
        if(ImGui.GetContentRegionAvail().Y>S(19))ImGui.TextColored(p.Muted,parent!=null?"仅运行当前选中的子宏          整组按顺序执行所有子宏":"使用当前保存内容；编辑在下次运行生效");
    }
    private MacroEntry? ValidSelection()=>selectedMacro!=null&&RootOf(selectedMacro)!=null?selectedMacro:null;
    private void DrawSkillPanel()
    {
        ShelfSkin.SectionTitle(CurrentTheme,"图标与技能显示","01");
        var entry=ValidSelection();if(entry==null){ImGui.TextWrapped("选择一个宏后设置图标与技能。");return;}
        var p=ShelfSkin.Palette(CurrentTheme);var snapshot=SkillDisplay?.GetSnapshot(entry.DisplayActionId)??SkillDisplaySnapshot.Unknown;
        var skill=SkillDisplay?.GetSkill(snapshot.AdjustedActionId!=0?snapshot.AdjustedActionId:entry.DisplayActionId);var iconId=skill?.IconId??entry.IconId;
        var start=ImGui.GetCursorScreenPos();var iconSize=S(ImGui.GetContentRegionAvail().Y>S(206)?72:58);
        var dl=ImGui.GetWindowDrawList();
        if(Textures!=null&&iconId!=0&&Textures.TryGetFromGameIcon(new GameIconLookup(iconId),out var icon)&&icon.TryGetWrap(out var gameWrap,out _))ImGui.Image(gameWrap.Handle,new Vector2(iconSize));
        else
        {
            dl.AddRectFilledMultiColor(start,start+new Vector2(iconSize),ImGui.GetColorU32(p.Code),ImGui.GetColorU32(p.Button),ImGui.GetColorU32(p.Code),ImGui.GetColorU32(p.Code));
            dl.AddCircle(start+new Vector2(iconSize/2),iconSize*.32f,ImGui.GetColorU32(p.Accent),32,S(1));
            ShelfDrawing.Glyph(dl,ShelfGlyph.Star,start+new Vector2(iconSize*.29f),iconSize*.42f,p.Accent);ImGui.Dummy(new Vector2(iconSize));
        }
        dl.AddRect(start-new Vector2(S(2)),start+new Vector2(iconSize+S(2)),ImGui.GetColorU32(p.Border),S(3),ImDrawFlags.None,S(2));
        ImGui.SameLine();ImGui.BeginGroup();
        var label=entry.DisplayActionId==0?"未选择显示技能":skill?.Name??$"未知技能 #{entry.DisplayActionId}";
        ImGui.TextUnformatted(Fit(label,ImGui.GetContentRegionAvail().X));ImGui.BeginDisabled(OpenDisplaySettings==null);
        if(ShelfSkin.Button(CurrentTheme,"选择技能 / 图标",new Vector2(-1,S(31))))OpenDisplaySettings?.Invoke(entry);RecordItem("direct-display");ImGui.EndDisabled();ImGui.EndGroup();
        var cooldown=entry.ShowSkillCooldown;if(ImGui.Checkbox("显示冷却",ref cooldown)){entry.ShowSkillCooldown=cooldown;SaveConfiguration();}RecordItem("inline-cooldown");
        ImGui.SameLine();var charges=entry.ShowSkillCharges;if(ImGui.Checkbox("显示充能",ref charges)){entry.ShowSkillCharges=charges;SaveConfiguration();}RecordItem("inline-charges");
        var box=ImGui.GetCursorScreenPos();var boxSize=new Vector2(ImGui.GetContentRegionAvail().X,S(39));var state=ShelfSkin.StateColor(CurrentTheme,snapshot.Availability);
        ImGui.Dummy(boxSize);RecordItem("inline-skill-state");dl.AddRectFilled(box,box+boxSize,ImGui.GetColorU32(CurrentTheme==ShelfTheme.Needy?new Vector4(.9f,.99f,.97f,1):p.Code),S(3));
        dl.AddRect(box,box+boxSize,ImGui.GetColorU32(state with{W=.45f}),S(3));dl.AddRectFilled(box,box+new Vector2(S(3),boxSize.Y),ImGui.GetColorU32(state));
        ShelfDrawing.Text(dl,box+new Vector2(S(13),S(10)),snapshot.Label(entry.ShowSkillCooldown,entry.ShowSkillCharges),ImGui.GetFontSize(),state);
        ImGui.PushStyleColor(ImGuiCol.Text,p.Muted);ImGui.TextWrapped("仅表示所选技能，不代表整段宏。");ImGui.PopStyleColor();
    }
    private void DrawBridgePanel()
    {
        ShelfSkin.SectionTitle(CurrentTheme,"游戏热键栏入口","02");
        var entry=ValidSelection();if(entry==null){ImGui.TextWrapped("选择一个宏后生成入口。");return;}
        var p=ShelfSkin.Palette(CurrentTheme);var parent=configuration.FindParent(entry);var kind=entry.IsGroup?"宏组":parent==null?"独立宏":"子宏";
        ImGui.TextUnformatted(Fit($"目标：{entry.Name}（{kind}）",ImGui.GetContentRegionAvail().X));if(ImGui.IsItemHovered())ImGui.SetTooltip(entry.Name+" · "+kind);
        ImGui.Spacing();ImGui.BeginDisabled(OpenNativeMacroBridge==null);var width=ImGui.GetContentRegionAvail().X;
        if(ShelfSkin.Button(CurrentTheme,"生成"+kind+"入口",new Vector2(width*.60f,S(42)),true,glyph:width>S(330)?ShelfGlyph.Link:ShelfGlyph.None))OpenNativeMacroBridge?.Invoke(entry);RecordItem("direct-bridge");ImGui.SameLine();
        if(ShelfSkin.Button(CurrentTheme,"备份恢复",new Vector2(MathF.Max(S(70),ImGui.GetContentRegionAvail().X),S(42))))OpenNativeMacroBridge?.Invoke(entry);RecordItem("direct-backups");ImGui.EndDisabled();
        ImGui.Spacing();ImGui.TextColored(p.Muted,"先预览确认，再备份与写入；");ImGui.TextColored(p.Muted,"手动拖入游戏热键栏。");
        if(ImGui.SmallButton("复制条目 ID"))ImGui.SetClipboardText(entry.Id);RecordItem("direct-copy-id");
        if(configuration.ShowThemeDecoration&&CurrentTheme==ShelfTheme.Persona5&&ImGui.GetContentRegionAvail().Y>S(48))
        {var pos=ImGui.GetCursorScreenPos();ShelfDrawing.Dots(ImGui.GetWindowDrawList(),pos,pos+ImGui.GetContentRegionAvail(),p.Accent);ShelfDrawing.Text(ImGui.GetWindowDrawList(),pos+new Vector2(S(12),S(13)),"MAKE IT YOURS.",S(23),p.Text,.16f);}
    }
}
