using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class NativeMacroBridgeWindow : Window, IDisposable
{
    private readonly Configuration configuration;
    private readonly NativeMacroBridgeService service;
    private readonly Func<Action, Task> onFramework;
    private int set, slot, busy;
    private bool disposed, confirmOverwrite, confirmForeignRestore;
    private string entryId = "", selectedBackupId = "";
    private State state = new(null, [], "先选择资料库条目，再读取原生宏槽位。", false);
    private sealed record State(NativeMacroPreview? Preview, IReadOnlyList<NativeMacroBackup> Backups, string Message, bool Error);
    partial void RecordItem(string key);
    private bool embedded;
    internal void OpenEmbedded(MacroEntry entry){OpenFor(entry);IsOpen=false;}
    internal void DrawEmbedded(){embedded=true;try{Draw();}finally{embedded=false;}}

    public NativeMacroBridgeWindow(Configuration configuration, NativeMacroBridgeService service, Func<Action, Task> onFramework)
        : base("生成热键栏入口宏###MacroShelfANativeBridge")
    {
        this.configuration = configuration; this.service = service; this.onFramework = onFramework;
        Size = new Vector2(690, 690); SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new WindowSizeConstraints { MinimumSize = new Vector2(500, 480), MaximumSize = new Vector2(1200, 1100) };
    }

    public void OpenFor(MacroEntry entry)
    {
        entryId = entry.Id; confirmOverwrite = confirmForeignRestore = false; IsOpen = true;
        // Selecting a library entry is the first user action. Opening an unused
        // window or constructing the plugin never reads/writes native memory.
        FindEmpty();
    }

    public void Dispose() => disposed = true;

    private void Queue(Action action)
    {
        if (disposed || Interlocked.CompareExchange(ref busy, 1, 0) != 0) return;
        _ = RunScheduled(action);
    }

    private async Task RunScheduled(Action action)
    {
        try { await onFramework(() => { if (!disposed) action(); }).ConfigureAwait(false); }
        catch (Exception exception)
        { Volatile.Write(ref state, new State(null, [], $"操作未完成：{exception.Message}", true)); }
        finally { Interlocked.Exchange(ref busy, 0); }
    }

    private void LoadPreview(int selectedSet, int selectedSlot, string successMessage = "槽位预览已读取。")
    {
        if (!service.TryPreview(selectedSet, selectedSlot, out var preview, out var error))
        { Volatile.Write(ref state, new State(null, [], error, true)); return; }
        Volatile.Write(ref state, new State(preview, service.Backups(preview!), successMessage, false));
    }

    private void FindEmpty()
    {
        var selectedSet = set; confirmOverwrite = confirmForeignRestore = false;
        Queue(() =>
        {
            if (service.TryFindEmpty(selectedSet, out var preview, out var error))
            {
                slot = preview!.Slot;
                Volatile.Write(ref state, new State(preview, service.Backups(preview), "已选择当前宏页的第一个空槽。", false));
            }
            else Volatile.Write(ref state, new State(null, [], error, true));
        });
    }

    private IDisposable? windowSkin;
    public override void PreDraw() { windowSkin = ShelfSkin.Apply(configuration.Theme, configuration.ReduceThemeMotion); }
    public override void PostDraw() { windowSkin?.Dispose(); windowSkin = null; }
    public override void Draw()
    {
        using var skin = ShelfSkin.Apply(configuration.Theme, configuration.ReduceThemeMotion);
        var current = Volatile.Read(ref state);
        var entry = MacroRunCommand.Enumerate(configuration.Macros).Where(value => value.Id == entryId).Take(2).ToArray();
        var target = entry.Length == 1 ? entry[0] : null;
        ImGui.TextWrapped("原生宏仅保存一行入口。完整正文仍在插件资料库，由同一个执行器运行；窗口关闭后也能启动。插件需保持加载。");
        ImGui.Separator();
        ImGui.TextWrapped(target == null ? "目标条目已缺失或 ID 不唯一；请重新选择插件宏。" : $"目标：{target.Name}{(target.IsGroup ? "（整组宏）" : configuration.FindParent(target)!=null ? "（仅此子宏）" : "（独立宏）")}");
        if (target != null) ImGui.TextWrapped($"入口：/aklmacro run {target.Id}");
        ImGui.BeginDisabled(Volatile.Read(ref busy) != 0);
        if (ImGui.Combo("宏页", ref set, "个人宏\0共通宏\0"))
        {
            selectedBackupId = ""; confirmOverwrite = confirmForeignRestore = false;
            Volatile.Write(ref state, new State(null, [], "宏页已改变，请读取或选择空槽。", false));
            FindEmpty();
        }
        RecordItem("page");
        ImGui.SetNextItemWidth(140);
        if (ImGui.InputInt("槽位（0–99）", ref slot))
        {
            slot = Math.Clamp(slot, 0, 99); confirmOverwrite = confirmForeignRestore = false; selectedBackupId = "";
            Volatile.Write(ref state, new State(null, [], "槽位已改变，请读取预览。", false));
        }
        RecordItem("index");
        if (ImGui.Button("读取槽位预览"))
        {
            var selectedSet = set; var selectedSlot = slot; confirmOverwrite = confirmForeignRestore = false;
            Queue(() => LoadPreview(selectedSet, selectedSlot));
        }
        RecordItem("read"); ImGui.SameLine();
        if (ImGui.Button("选择第一个空槽")) FindEmpty();
        RecordItem("find-empty");
        ImGui.EndDisabled();

        current = Volatile.Read(ref state);
        var preview = current.Preview;
        var matchingPreview = preview != null && preview.Set == set && preview.Slot == slot;
        ImGui.Separator();
        if (matchingPreview)
        {
            ImGui.TextWrapped($"当前槽位：{(set == 0 ? "个人" : "共通")} {slot:00} · {(preview!.Content.IsEmpty ? "空槽" : preview.Content.DisplayName)} · {preview.Content.LineCount}/15 行");
            ImGui.TextWrapped($"角色身份：{preview.ContentId:X16} · 图标 {preview.Content.IconId}");
            ImGui.BeginChild("##NativeSlotPreview", new Vector2(0, 130), true);
            ImGui.TextWrapped(preview.Content.IsEmpty ? "（当前槽位为空）" : preview.Content.DisplayCommands);
            ImGui.EndChild();
        }
        else ImGui.TextWrapped("尚无当前槽位的有效预览；生成前必须读取。角色或槽位变化后会拒绝旧预览。");

        ImGui.BeginDisabled(Volatile.Read(ref busy) != 0 || target == null || !matchingPreview);
        if (matchingPreview && !preview!.Content.IsEmpty)
        {
            ImGui.Checkbox("确认覆盖此槽位（先完整备份）", ref confirmOverwrite);
            RecordItem("overwriteconfirm");
        }
        ImGui.BeginDisabled(matchingPreview && !preview!.Content.IsEmpty && !confirmOverwrite);
        if (ImGui.Button("生成一行入口宏"))
        {
            var capturedPreview = preview!; var capturedTarget = target!; var confirmed = confirmOverwrite;
            Queue(() =>
            {
                if (!service.TryGenerate(capturedPreview, capturedTarget, configuration.Macros, confirmed, out var error))
                { Volatile.Write(ref state, new State(capturedPreview, service.Backups(capturedPreview), error, true)); return; }
                LoadPreview(capturedPreview.Set, capturedPreview.Slot, "入口宏已写入并提交游戏保存，原槽位已完整备份。请在游戏宏界面将该槽位图标拖到热键栏；不自动改动热键栏。");
                confirmOverwrite = confirmForeignRestore = false;
            });
        }
        RecordItem("generate"); ImGui.EndDisabled(); ImGui.EndDisabled();

        ImGui.Separator();
        ImGui.TextUnformatted("当前角色／槽位的不可变备份");
        ImGui.BeginDisabled(Volatile.Read(ref busy) != 0 || !matchingPreview);
        var selected = current.Backups.FirstOrDefault(value => value.Id == selectedBackupId);
        if (ImGui.BeginCombo("备份", selected == null ? (current.Backups.Count == 0 ? "无备份" : "请选择备份") : BackupLabel(selected)))
        {
            foreach (var backup in current.Backups)
            {
                if (ImGui.Selectable($"{BackupLabel(backup)}##{backup.Id}", backup.Id == selectedBackupId))
                { selectedBackupId = backup.Id; confirmForeignRestore = false; }
                RecordItem("backup-" + backup.Id);
            }
            ImGui.EndCombo();
        }
        RecordItem("backupselect");
        selected = current.Backups.FirstOrDefault(value => value.Id == selectedBackupId);
        var foreign = matchingPreview && selected != null && !preview!.Content.SameAs(selected.Replacement);
        if (selected != null)
        {
            ImGui.TextWrapped($"恢复为：{(selected.Original.IsEmpty ? "空槽" : selected.Original.DisplayName)} · {selected.Original.LineCount}/15 行（包含原始 SeString 字节）");
            if (foreign)
            {
                ImGui.TextWrapped("当前槽位不再是该备份操作后的内容。恢复前会再次完整备份当前槽位。");
                ImGui.Checkbox("已检查预览，确认覆盖以恢复备份", ref confirmForeignRestore);
                RecordItem("restoreconfirm");
            }
        }
        ImGui.BeginDisabled(selected == null || (foreign && !confirmForeignRestore));
        if (ImGui.Button("恢复所选备份"))
        {
            var capturedPreview = preview!; var capturedBackup = selected!; var confirmed = confirmForeignRestore;
            Queue(() =>
            {
                if (!service.TryRestore(capturedPreview, capturedBackup, confirmed, out var error))
                { Volatile.Write(ref state, new State(capturedPreview, service.Backups(capturedPreview), error, true)); return; }
                LoadPreview(capturedPreview.Set, capturedPreview.Slot, "已恢复原槽位的原始名称、图标和全部 15 行；恢复前状态也已独立备份。");
                confirmOverwrite = confirmForeignRestore = false;
            });
        }
        RecordItem("restore"); ImGui.EndDisabled(); ImGui.EndDisabled();
        ImGui.Separator();
        current = Volatile.Read(ref state);
        ImGui.PushStyleColor(ImGuiCol.Text, configuration.Theme!=ShelfTheme.Classic
            ? current.Error ? ShelfSkin.Error(configuration.Theme) : ShelfSkin.Palette(configuration.Theme).Muted
            : current.Error ? new Vector4(1,.45f,.45f,1) : new Vector4(.65f,.84f,1,1));
        ImGui.TextWrapped(current.Message); ImGui.PopStyleColor();
        if (Volatile.Read(ref busy) != 0) ImGui.TextUnformatted("正在游戏 Framework 线程读取或处理槽位…");
        if(!embedded){if (ImGui.Button("关闭")) IsOpen = false;RecordItem("close");}
    }

    private static string BackupLabel(NativeMacroBackup backup)
        => $"{backup.CreatedUtc.ToLocalTime():yyyy-MM-dd HH:mm:ss} · {(backup.Operation == "restore" ? "恢复前" : "生成前")} · {(backup.Original.IsEmpty ? "空槽" : backup.Original.DisplayName)}";
}

