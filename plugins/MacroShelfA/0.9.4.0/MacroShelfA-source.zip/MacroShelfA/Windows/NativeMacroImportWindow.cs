using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Windowing;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class NativeMacroImportWindow : Window, IDisposable
{
    private readonly Configuration configuration;
    private readonly Action libraryChanged;
    private readonly Action save;
    private readonly INativeMacroReader reader;
    private readonly HashSet<string> selected = new(StringComparer.Ordinal);
    private NativeMacroReadSnapshot snapshot = NativeMacroReadSnapshot.Unavailable("点击刷新读取游戏原生宏。");
    private Task<NativeMacroReadSnapshot>? readPending, importPending;
    private Task<NativeMacroIdentity>? identityPending;
    private List<NativeMacroSnapshotEntry> pendingSelection = [];
    private NativeMacroReadSnapshot? pendingOriginal;
    private string pendingCategory = string.Empty;
    private string search = string.Empty, category = string.Empty, status = string.Empty;
    private string? previewKey;
    private bool statusIsError, disposed;
    private long nextIdentityPoll;
    private static float S(float value) => value * ImGuiHelpers.GlobalScale;
    private Vector4 Muted => configuration.Theme==ShelfTheme.Classic ? new(.65f,.75f,.85f,1) : ShelfSkin.Palette(configuration.Theme).Muted;
    private Vector4 ErrorColor => configuration.Theme==ShelfTheme.Needy ? new(.75f,.13f,.32f,1) : new(.94f,.45f,.46f,1);
    private Vector4 SuccessColor => configuration.Theme==ShelfTheme.Needy ? new(0,.44f,.39f,1) : new(.38f,.82f,.55f,1);
    partial void RecordItem(string key);
    private bool embedded;
    internal Action? ViewImported { get; set; }
    internal void EnterEmbedded(){IsOpen=false;Refresh();}
    internal void LeaveEmbedded()=>CancelRequests();
    internal void DrawEmbedded(){embedded=true;try{Draw();}finally{embedded=false;}}

    public NativeMacroImportWindow(Configuration configuration, Action libraryChanged,
        INativeMacroReader? reader = null, Action? save = null) : base("从游戏宏导入###MacroShelfANativeImport")
    {
        this.configuration = configuration; this.libraryChanged = libraryChanged;
        this.reader = reader ?? new NativeMacroReader(); this.save = save ?? configuration.Save;
        Size = new Vector2(940, 660); SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new WindowSizeConstraints
        { MinimumSize = new Vector2(720, 500), MaximumSize = new Vector2(1920, 1400) };
        Flags = ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse;
    }

    public void Open()
    {
        if (disposed) return;
        IsOpen = true; Refresh();
    }

    public void Dispose()
    {
        disposed = true; IsOpen = false;
        CancelRequests();
    }

    public override void OnClose() => CancelRequests();

    private void CancelRequests()
    {
        selected.Clear(); snapshot = NativeMacroReadSnapshot.Unavailable("点击刷新读取游戏原生宏。");
        readPending = null; identityPending = null; importPending = null; pendingOriginal = null;
        pendingSelection.Clear();
    }

    private void Refresh()
    {
        if (disposed || importPending != null || readPending != null) return;
        selected.Clear(); previewKey = null; status = string.Empty;
        snapshot = NativeMacroReadSnapshot.Unavailable("正在读取原生宏…");
        identityPending = null;
        try { readPending = reader.ReadAsync(); }
        catch (Exception exception) { SetStatus($"读取失败：{exception.Message}", true); }
    }

    private void SetStatus(string value, bool isError = false) { status = value; statusIsError = isError; }

    // Completed tasks are consumed on the UI thread only. Never block Framework.Update or mutate
    // configuration in an async continuation; each import is fully revalidated just before commit.
    private void PumpRequests()
    {
        if (disposed) return;
        if (readPending?.IsCompleted == true)
        {
            var completed = readPending; readPending = null;
            try
            {
                snapshot = completed.GetAwaiter().GetResult();
                if (!snapshot.Available) SetStatus(snapshot.Error.Length > 0 ? snapshot.Error : snapshot.Identity.Error, true);
                else SetStatus("已读取个人 / 共通各 100 个槽；含载荷的条目会明确标记不可导入。");
            }
            catch (Exception exception)
            { snapshot = NativeMacroReadSnapshot.Unavailable("读取失败，请重新刷新。"); SetStatus($"读取失败：{exception.Message}", true); }
            nextIdentityPoll = Environment.TickCount64 + 500;
        }
        if (importPending?.IsCompleted == true)
        {
            var completed = importPending; importPending = null;
            try
            {
                var fresh = completed.GetAwaiter().GetResult();
                var validationError = "导入请求已失效，请重新选择。";
                if (pendingOriginal == null || !NativeMacroImportModel.ValidateFreshSelection(pendingOriginal,
                    fresh, pendingSelection, out validationError))
                {
                    selected.Clear();
                    if (!fresh.Available || !snapshot.Identity.Matches(fresh.Identity))
                        snapshot = NativeMacroReadSnapshot.Unavailable("角色状态变化，请重新刷新。");
                    SetStatus(pendingOriginal == null ? "导入请求已失效，请重新选择。" : validationError, true);
                }
                else if (NativeMacroImportModel.TryImportCopies(configuration, pendingSelection, pendingCategory,
                    save, out var count, out var error))
                {
                    selected.Clear(); SetStatus($"已导入 {count} 个独立副本；同名自动加后缀。游戏原生宏未修改。");
                    libraryChanged();
                }
                else SetStatus(error, true);
            }
            catch (Exception exception) { SetStatus($"导入失败：{exception.Message}", true); }
            pendingSelection = []; pendingOriginal = null;
        }
        if (identityPending?.IsCompleted == true)
        {
            var completed = identityPending; identityPending = null;
            try
            {
                var identity = completed.GetAwaiter().GetResult();
                if (snapshot.Available && !snapshot.Identity.Matches(identity))
                {
                    selected.Clear(); previewKey = null;
                    snapshot = NativeMacroReadSnapshot.Unavailable("登录状态或角色变化，请刷新后重新选择。");
                    SetStatus(snapshot.Error, true);
                }
            }
            catch (Exception exception)
            {
                selected.Clear(); snapshot = NativeMacroReadSnapshot.Unavailable("角色状态校验失败，请刷新。");
                SetStatus($"角色状态校验失败：{exception.Message}", true);
            }
        }
        if (snapshot.Available && readPending == null && importPending == null && identityPending == null &&
            Environment.TickCount64 >= nextIdentityPoll)
        {
            nextIdentityPoll = Environment.TickCount64 + 500;
            try { identityPending = reader.ReadIdentityAsync(); }
            catch (Exception exception)
            { selected.Clear(); snapshot = NativeMacroReadSnapshot.Unavailable("角色状态校验失败。"); SetStatus(exception.Message, true); }
        }
    }

    private void StartImport()
    {
        if (disposed || !snapshot.Available || readPending != null || importPending != null) return;
        var entries = snapshot.Entries.Where(e => selected.Contains(e.Key)).ToList();
        if (!NativeMacroImportModel.TryCreateCopies(configuration, entries, category, out _, out var error))
        { SetStatus(error, true); return; }
        pendingOriginal = snapshot; pendingSelection = entries; pendingCategory = category;
        try { importPending = reader.ReadAsync(); SetStatus("正在重新校验角色及所选原生宏…"); }
        catch (Exception exception) { pendingOriginal = null; pendingSelection = []; SetStatus(exception.Message, true); }
    }

    private IDisposable? windowSkin;
    public override void PreDraw() { windowSkin = ShelfSkin.Apply(configuration.Theme, configuration.ReduceThemeMotion); }
    public override void PostDraw() { windowSkin?.Dispose(); windowSkin = null; }
    public override void Draw()
    {
        using var skin = ShelfSkin.Apply(configuration.Theme, configuration.ReduceThemeMotion);
        PumpRequests();
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(S(8), S(7)));
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(S(8), S(5)));
        try
        {
            ImGui.BeginDisabled(readPending != null || importPending != null);
            if (ImGui.Button("刷新游戏宏")) Refresh(); RecordItem("native-refresh");
            ImGui.SameLine();
            if (ImGui.Button("清空选择")) selected.Clear(); RecordItem("native-clear");
            ImGui.EndDisabled();
            if(ImGui.GetItemRectMax().X+S(8)+ImGui.CalcTextSize("只读原生宏 · 独立副本").X<ImGui.GetCurrentContext().CurrentWindow.InnerClipRect.Max.X)ImGui.SameLine();
            ImGui.TextColored(Muted, "只读原生宏 · 独立副本");
            ImGui.SetNextItemWidth(-1);
            ImGui.InputTextWithHint("##NativeSearch", "搜索名称或正文（仅筛选显示，不改变已选项）", ref search, 256);
            RecordItem("native-search");
            if (ImGui.BeginTabBar("##NativeSets"))
            {
                for (var set = 0; set < NativeMacroImportModel.Sets; set++)
                {
                    var label = set == 0 ? "个人宏（100）" : "共通宏（100）";
                    var open = ImGui.BeginTabItem(label); RecordItem($"native-tab-{set}");
                    if (!open) continue;
                    DrawBrowser(set); ImGui.EndTabItem();
                }
                ImGui.EndTabBar();
            }
            DrawFooter();
        }
        finally { ImGui.PopStyleVar(2); }
    }

    private void DrawBrowser(int set)
    {
        var available = ImGui.GetContentRegionAvail();
        // Two explicitly bounded children: no AutoResize/negative-size feedback loop on reopen.
        var footer = ImGui.GetFrameHeight() * 2 + ImGui.GetTextLineHeightWithSpacing() * 3 + S(28);
        var height = MathF.Max(S(75), available.Y - footer);
        var leftWidth = MathF.Max(S(160), (available.X - S(8)) * .46f);
        if (ImGui.BeginChild("##NativeList", new Vector2(leftWidth, height), true))
        {
            if (!snapshot.Available) ImGui.TextWrapped(snapshot.Error);
            else
            {
                var entries = snapshot.Entries.Where(e => e.Set == set && (search.Length == 0 ||
                    e.DisplayName.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                    e.Commands.Contains(search, StringComparison.OrdinalIgnoreCase))).OrderBy(e => e.Index).ToList();
                ImGui.TextColored(Muted, $"显示 {entries.Count} / 100");
                if (entries.Count == 0) ImGui.TextWrapped("没有匹配的宏。已选项仍保留，可清空选择。");
                foreach (var entry in entries)
                {
                    ImGui.PushID(entry.Key);
                    var chosen = selected.Contains(entry.Key);
                    ImGui.BeginDisabled(!entry.CanImport || importPending != null);
                    if (ImGui.Checkbox("##Select", ref chosen))
                    { if (chosen) selected.Add(entry.Key); else selected.Remove(entry.Key); }
                    RecordItem($"native-select-{entry.Key}"); ImGui.EndDisabled(); ImGui.SameLine();
                    var suffix = entry.Error.Length > 0 ? " · 不可导入" : string.Empty;
                    if (ImGui.Selectable($"{entry.Index:00}  {entry.DisplayName}{suffix}", previewKey == entry.Key))
                        previewKey = entry.Key;
                    RecordItem($"native-preview-{entry.Key}");
                    if (ImGui.IsItemHovered())
                    {
                        ImGui.BeginTooltip(); ImGui.TextUnformatted(entry.DisplayName);
                        if (entry.Error.Length > 0) ImGui.TextWrapped(entry.Error);
                        ImGui.EndTooltip();
                    }
                    ImGui.PopID();
                }
            }
        }
        ImGui.EndChild(); ImGui.SameLine();
        if (ImGui.BeginChild("##NativePreview", new Vector2(0, height), true))
        {
            var entry = snapshot.Entries.FirstOrDefault(e => e.Key == previewKey);
            if (entry == null) ImGui.TextWrapped("点击左侧条目预览正文，再勾选要导入的宏。\n\n个人 / 共通选择可以合并为一批。导入前会再次读取并检查角色及原生正文。");
            else
            {
                ImGui.TextWrapped(entry.DisplayName);
                ImGui.TextColored(Muted, $"{(entry.Set == 0 ? "个人" : "共通")} · 槽 {entry.Index:00} · {entry.LineCount} 行");
                ImGui.TextColored(Muted, $"图标 ID：{entry.IconId}");
                ImGui.Separator();
                if (entry.Error.Length > 0)
                { ImGui.TextColored(ErrorColor, "不可导入"); ImGui.TextWrapped(entry.Error); }
                else if (entry.IsEmpty) ImGui.TextWrapped("这是空槽，没有可导入的名称或正文。");
                else
                {
                    var text = entry.Commands;
                    var area = ImGui.GetContentRegionAvail();
                    ImGui.InputTextMultiline("##NativeCommands", ref text, Configuration.MaxCommandLength + 1,
                        new Vector2(area.X, MathF.Max(S(30), area.Y)), ImGuiInputTextFlags.ReadOnly);
                    RecordItem("native-command-preview");
                }
            }
        }
        ImGui.EndChild();
    }

    private void DrawFooter()
    {
        ImGui.TextUnformatted("导入分类"); ImGui.SameLine(); ImGui.SetNextItemWidth(-1);
        // ImGui's native buffer capacity is UTF-8 bytes, not Chinese-character count.
        // The pure import preflight applies the existing 24 UTF-16-character category limit.
        ImGui.InputTextWithHint("##NativeCategory", "留空为未分类", ref category, Configuration.MaxGroupLength * 4 + 1);
        RecordItem("native-category");
        var remaining = Math.Max(0, Configuration.MaxEntries - configuration.CountEntries());
        var collisionCount = NativeMacroImportModel.CountSameNames(configuration,
            snapshot.Entries.Where(e => selected.Contains(e.Key)));
        ImGui.TextColored(selected.Count > remaining ? ErrorColor : Muted,
            $"已选 {selected.Count} · 剩余 {remaining}/{Configuration.MaxEntries} · 同名 {collisionCount}");
        if (ImGui.IsItemHovered())
        {
            ImGui.BeginTooltip(); ImGui.TextUnformatted("容量包含宏组与子宏。同名条目自动添加“导入 N”后缀，不覆盖现有条目。");
            ImGui.EndTooltip();
        }
        var disabled = !snapshot.Available || selected.Count == 0 || selected.Count > remaining ||
            readPending != null || importPending != null;
        ImGui.BeginDisabled(disabled);
        if (ImGui.Button($"复制 {selected.Count} 个宏到插件")) StartImport(); RecordItem("native-import"); ImGui.EndDisabled();
        ImGui.SameLine();
        if(embedded){if(ImGui.Button("查看插件宏"))ViewImported?.Invoke();RecordItem("native-view-imported");}
        else {if (ImGui.Button("关闭")) { IsOpen = false; CancelRequests(); } RecordItem("native-close");}
        if (status.Length > 0)
        {
            // Keep the import and close controls above the status viewport even at 150% UI scale.
            if (ImGui.BeginChild("##NativeStatus", new Vector2(0, MathF.Max(S(18), ImGui.GetContentRegionAvail().Y)), false))
            { ImGui.PushStyleColor(ImGuiCol.Text, statusIsError ? ErrorColor : SuccessColor); ImGui.TextWrapped(status); ImGui.PopStyleColor(); }
            ImGui.EndChild();
        }
    }
}

