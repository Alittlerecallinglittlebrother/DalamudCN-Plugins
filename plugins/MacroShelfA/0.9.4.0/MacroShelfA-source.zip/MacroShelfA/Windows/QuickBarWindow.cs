using System;
using System.Linq;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using Dalamud.Interface.Windowing;
using Dalamud.Interface.Textures;
using Dalamud.Plugin.Services;
using MacroShelfA.Runtime;

namespace MacroShelfA.Windows;

internal sealed partial class QuickBarWindow : Window
{
    private readonly Configuration configuration;
    private readonly MacroExecutor executor;
    private readonly MainWindow mainWindow;
    private readonly ISkillDisplayProvider? skillDisplay;
    private readonly Action<MacroEntry>? openDisplaySettings;
    private readonly ITextureProvider? textureProvider;
    private string pickerSearch = string.Empty;
    private string lastError = string.Empty;
    private MacroEntry? failedMacro;
    private string failedCommands = string.Empty;
    private string failedName = string.Empty;
    private bool failedLongSetting;
    private float gridHeight;
    private float gridTop, statusTop, headerHeight, actionsWidth, buttonHeight;
    private int gridColumns;
    private bool secondHeaderRow, gridScrolls;
    private IDisposable? themeScope;
    private const string UsageHint = "左键运行，右键编辑或删除";
    private const string EmptyHint = "还没有常用宏。点击“添加”选择，或在资料库中点击收藏星标。";
    private static float S(float value) => value * ImGuiHelpers.GlobalScale;
    partial void RecordItem(string key);
    partial void RecordRegion(string key, Vector2 minimum, Vector2 maximum);
    partial void RecordSkillState(string id, SkillDisplaySnapshot snapshot);

    public QuickBarWindow(Configuration configuration, MacroExecutor executor, MainWindow mainWindow,
        ISkillDisplayProvider? skillDisplay = null, Action<MacroEntry>? openDisplaySettings = null, ITextureProvider? textureProvider = null)
        : base("Macro Shelf-A 常用宏###MacroShelfAQuickBar")
    {
        this.configuration = configuration; this.executor = executor; this.mainWindow = mainWindow;
        this.skillDisplay = skillDisplay; this.openDisplaySettings = openDisplaySettings; this.textureProvider = textureProvider;
        Flags = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove |
            ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse | ImGuiWindowFlags.NoCollapse |
            ImGuiWindowFlags.NoDocking | ImGuiWindowFlags.NoFocusOnAppearing;
        Position = new Vector2(24, 300) * ImGuiHelpers.GlobalScale;
        PositionCondition = ImGuiCond.FirstUseEver;
        IsOpen = true; ShowCloseButton = false; RespectCloseHotkey = false; DisableWindowSounds = true; ForceMainWindow = true;
    }
    public override bool DrawConditions() => configuration.ShowQuickBar && Plugin.ClientState.IsLoggedIn;
    public override void PreDraw()
    {
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(S(10)));
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(S(8), S(6)));
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(S(6)));
        ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, S(6));
        ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, S(4));
        ImGui.PushStyleColor(ImGuiCol.WindowBg, new Vector4(.075f,.115f,.165f,1));
        ImGui.PushStyleColor(ImGuiCol.Border, new Vector4(.20f,.29f,.38f,1));
        ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(.92f,.95f,.99f,1));
        ImGui.PushStyleColor(ImGuiCol.TextDisabled, new Vector4(.66f,.76f,.86f,1));
        ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(.11f,.18f,.26f,1));
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(.16f,.30f,.44f,1));
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(.11f,.38f,.72f,1));
        ImGui.PushStyleColor(ImGuiCol.FrameBg, new Vector4(.055f,.085f,.125f,1));
        ImGui.PushStyleColor(ImGuiCol.Header, new Vector4(.13f,.30f,.51f,1));
        ImGui.PushStyleColor(ImGuiCol.HeaderHovered, new Vector4(.16f,.32f,.50f,1));
        ImGui.PushStyleColor(ImGuiCol.CheckMark, new Vector4(.18f,.53f,.94f,1));
        themeScope = ShelfSkin.Apply(configuration.Theme,configuration.ReduceThemeMotion);

        var pinned = QuickBarModel.Pinned(configuration);
        ClearStaleError(pinned);
        var count = pinned.Count;
        var frameHeight = ImGui.GetFrameHeight();
        actionsWidth = new[] { "添加", "管理", "更多", configuration.QuickBarCollapsed ? "展开" : "收起" }
            .Sum(label => ImGui.CalcTextSize(label).X + ImGui.GetStyle().FramePadding.X * 2) + S(18);
        var textWidth = ImGui.CalcTextSize($"常用宏 · {count}").X + S(12) + ImGui.CalcTextSize(UsageHint).X;
        var preferredWidth = MathF.Max(S(360), S(configuration.QuickBarColumns * (configuration.QuickBarButtonWidth + 6) + 14));
        // Keep the requested hint intact. Only the action buttons wrap on narrow bars.
        preferredWidth = MathF.Max(preferredWidth, textWidth + S(20));
        if (configuration.QuickBarColumns > 1) preferredWidth = MathF.Max(preferredWidth, textWidth + actionsWidth + S(32));
        var available = MathF.Max(1, ImGui.GetMainViewport().WorkSize.X - S(16));
        var width = MathF.Min(available, preferredWidth);
        var contentWidth = width - S(20);
        secondHeaderRow = contentWidth < textWidth + actionsWidth + S(12);
        headerHeight = secondHeaderRow ? frameHeight * 2 + S(6) : frameHeight;
        buttonHeight = MathF.Max(S(38), frameHeight);
        if (skillDisplay != null && pinned.Any(e => e.Macro.DisplayActionId != 0))
            buttonHeight = MathF.Max(buttonHeight, ImGui.GetTextLineHeight() * 2 + S(12));
        gridColumns = QuickBarModel.EffectiveColumns(configuration.QuickBarColumns, contentWidth, S(configuration.QuickBarButtonWidth), S(6));
        gridScrolls = count > gridColumns * 4;
        if (gridScrolls) gridColumns = QuickBarModel.EffectiveColumns(configuration.QuickBarColumns, contentWidth - ImGui.GetStyle().ScrollbarSize, S(configuration.QuickBarButtonWidth), S(6));
        var rows = Math.Clamp((count + gridColumns - 1) / gridColumns, 1, 4);
        gridHeight = count == 0 ? ImGui.CalcTextSize(EmptyHint, false, contentWidth).Y : rows * buttonHeight + (rows - 1) * S(6);
        gridTop = S(10) + headerHeight + S(7);
        var lastContentBottom = configuration.QuickBarCollapsed ? S(10) + headerHeight : gridTop + gridHeight;
        statusTop = lastContentBottom + S(7);
        var statusHeight = executor.IsRunning ? frameHeight : lastError.Length > 0 ? ImGui.GetTextLineHeight() : 0;
        var height = lastContentBottom + S(10) + (statusHeight > 0 ? S(7) + statusHeight : 0);
        // WindowHost applies GlobalScale AFTER PreDraw. Size is logical, not already-scaled pixels.
        Size = new Vector2(width, height) / ImGuiHelpers.GlobalScale;
        SizeCondition = ImGuiCond.Always;
    }
    public override void PostDraw() { themeScope?.Dispose(); themeScope = null; ImGui.PopStyleColor(11); ImGui.PopStyleVar(5); }
    public override void Draw()
    {
        ClampToViewport();
        if(configuration.Theme!=ShelfTheme.Classic)ShelfSkin.Panel(configuration.Theme,ImGui.GetWindowPos(),ImGui.GetWindowPos()+ImGui.GetWindowSize(),true);
        if (configuration.Theme != ShelfTheme.Classic)
        {
            var p = ShelfSkin.Palette(configuration.Theme);
            var origin = ImGui.GetWindowPos();
            ImGui.GetWindowDrawList().AddLine(origin + new Vector2(S(6), S(2)),
                origin + new Vector2(ImGui.GetWindowSize().X - S(6), S(2)), ImGui.GetColorU32(p.Accent), S(3));
        }
        var pinned = QuickBarModel.Pinned(configuration);
        var headerWidth = ImGui.GetContentRegionAvail().X - (secondHeaderRow ? 0 : actionsWidth + S(12));
        ImGui.InvisibleButton("##DragQuickBar", new Vector2(headerWidth, ImGui.GetFrameHeight())); RecordItem("drag");
        var title = $"常用宏 · {pinned.Count}";
        var textPosition = ImGui.GetItemRectMin() + new Vector2(0, ImGui.GetStyle().FramePadding.Y);
        ImGui.GetWindowDrawList().AddText(textPosition, ImGui.GetColorU32(ImGuiCol.Text), title);
        var hintPosition = textPosition + new Vector2(ImGui.CalcTextSize(title).X + S(12), 0);
        ImGui.GetWindowDrawList().AddText(hintPosition, ImGui.GetColorU32(ImGuiCol.TextDisabled), UsageHint);
        RecordRegion("header-hint", hintPosition, hintPosition + ImGui.CalcTextSize(UsageHint));
        if (ImGui.IsItemActive() && !configuration.LockQuickBar && ImGui.IsMouseDragging(ImGuiMouseButton.Left, 3))
        {
            ImGui.SetWindowPos(ImGui.GetWindowPos() + ImGui.GetIO().MouseDelta, ImGuiCond.Always);
            ClampToViewport();
        }
        if (ImGui.IsItemHovered()) ImGui.SetTooltip(configuration.LockQuickBar ? "位置已锁定；在“更多”中解锁" : "拖动此处移动常用栏");
        ImGui.SetCursorPos(secondHeaderRow ? new Vector2(S(10), S(10) + ImGui.GetFrameHeight() + S(6))
            : new Vector2(ImGui.GetWindowSize().X - S(10) - actionsWidth, S(10)));
        if (ImGui.Button("添加")) { pickerSearch = string.Empty; ImGui.OpenPopup("##QuickPicker"); } RecordItem("add");
        ImGui.SameLine(); if (ImGui.Button("管理")) mainWindow.IsOpen = true; RecordItem("manage");
        ImGui.SameLine(); if (ImGui.Button("更多")) ImGui.OpenPopup("##QuickOptions"); RecordItem("options");
        ImGui.SameLine();
        if (ImGui.Button(configuration.QuickBarCollapsed ? "展开" : "收起")) { configuration.QuickBarCollapsed = !configuration.QuickBarCollapsed; configuration.Save(); }
        RecordItem("collapse");
        DrawPicker(); DrawOptions();
        if (!configuration.QuickBarCollapsed)
        {
            DrawDivider(gridTop - S(4));
            ImGui.SetCursorPos(new Vector2(S(10), gridTop));
            ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, Vector2.Zero);
            ImGui.BeginChild("##QuickGrid", new Vector2(0, gridHeight), false,
                gridScrolls ? ImGuiWindowFlags.AlwaysVerticalScrollbar : ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);
            RecordRegion("grid", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
            if (pinned.Count == 0) ImGui.TextWrapped(EmptyHint);
            else
            {
                var contentWidth = ImGui.GetContentRegionAvail().X;
                var columns = gridColumns;
                var buttonWidth = (contentWidth - (columns - 1) * S(6)) / columns;
                for (var i = 0; i < pinned.Count; i++)
                {
                    if (i % columns != 0) ImGui.SameLine();
                    DrawMacro(pinned[i], buttonWidth);
                }
            }
            ImGui.EndChild(); ImGui.PopStyleVar();
        }
        if (executor.IsRunning || lastError.Length > 0) DrawStatus();
    }
    private void ClearStaleError(System.Collections.Generic.List<QuickBarEntry> pinned)
    {
        if (lastError.Length > 0 && (failedMacro == null || !pinned.Any(e => ReferenceEquals(e.Macro, failedMacro)) ||
            failedMacro.Commands != failedCommands || failedMacro.Name != failedName || configuration.AllowLongMacros != failedLongSetting))
            lastError = string.Empty;
    }
    private static void DrawDivider(float y)
    {
        var origin = ImGui.GetWindowPos();
        ImGui.GetWindowDrawList().AddLine(origin + new Vector2(S(10), y), origin + new Vector2(ImGui.GetWindowSize().X - S(10), y), ImGui.GetColorU32(ImGuiCol.Border));
    }
    private void DrawMacro(QuickBarEntry entry, float width)
    {
        var macro = entry.Macro;
        var themed=configuration.Theme!=ShelfTheme.Classic;var editWidth=themed?S(31):0;
        ImGui.BeginGroup();
        ImGui.PushID(macro.Id);
        ImGui.BeginDisabled(executor.IsRunning);
        var clicked = ImGui.Button("##Run", new Vector2(width-editWidth, buttonHeight)); RecordItem("run-" + macro.Id);
        var visible = ImGui.IsItemVisible();
        var prefix = entry.Parent != null ? "子 · " : macro.IsGroup ? "组 · " : string.Empty;
        var snapshot = visible ? skillDisplay?.GetSnapshot(macro.DisplayActionId) ?? SkillDisplaySnapshot.Unknown : SkillDisplaySnapshot.Unknown;
        if (visible && skillDisplay != null) RecordSkillState(macro.Id, snapshot);
        var skill = skillDisplay?.GetSkill(snapshot.AdjustedActionId != 0 ? snapshot.AdjustedActionId : macro.DisplayActionId);
        var iconId = skill?.IconId ?? macro.IconId;
        var showState = skillDisplay != null && macro.DisplayActionId != 0;
        var iconWidth = themed&&width>=S(155)?MathF.Min(S(37),buttonHeight-S(10)):skillDisplay != null && iconId != 0 && textureProvider != null && width >= S(72) ? MathF.Min(S(32), buttonHeight - S(8)) : 0;
        var minimum = ImGui.GetItemRectMin();
        var textX = S(8) + (iconWidth > 0 ? iconWidth + S(6) : 0);
        var textWidth = MathF.Max(1, width - textX - S(6)-editWidth);
        if (visible && iconWidth > 0)
        {
            var iconPosition=minimum+new Vector2(S(5),(buttonHeight-iconWidth)/2);
            if(textureProvider!=null&&iconId!=0)DrawSkillIcon(iconId,iconPosition,iconWidth);
            else {var p=ShelfSkin.Palette(configuration.Theme);ImGui.GetWindowDrawList().AddRect(iconPosition,iconPosition+new Vector2(iconWidth),ImGui.GetColorU32(p.Border),S(3));ShelfDrawing.Glyph(ImGui.GetWindowDrawList(),macro.IsGroup?ShelfGlyph.Folder:ShelfGlyph.File,iconPosition+new Vector2(S(8)),iconWidth-S(16),p.Accent);}
        }
        var textY = showState ? S(5) : (buttonHeight - ImGui.GetFontSize()) / 2;
        ImGui.GetWindowDrawList().AddText(minimum + new Vector2(textX, textY), ImGui.GetColorU32(ImGuiCol.Text), MainWindow.Fit(prefix + macro.Name, textWidth));
        if (showState)
        {
            var color = configuration.Theme != ShelfTheme.Classic ? ShelfSkin.StateColor(configuration.Theme, snapshot.Availability) : snapshot.Availability switch
            {
                SkillAvailability.Ready => new Vector4(.42f, .88f, .62f, 1),
                SkillAvailability.Cooldown => new Vector4(1, .77f, .35f, 1),
                SkillAvailability.Conditions => new Vector4(1, .63f, .65f, 1),
                _ => new Vector4(.66f, .76f, .86f, 1),
            };
            ImGui.GetWindowDrawList().AddText(minimum + new Vector2(textX, S(5) + ImGui.GetTextLineHeight()),
                ImGui.GetColorU32(color), MainWindow.Fit(snapshot.Label(macro.ShowSkillCooldown, macro.ShowSkillCharges), textWidth));
        }
        if (clicked)
        {
            lastError = executor.TryStart(macro, out var error) ? string.Empty : error;
            failedMacro = macro; failedCommands = macro.Commands; failedName = macro.Name; failedLongSetting = configuration.AllowLongMacros;
        }
        ImGui.EndDisabled();
        if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
        {
            var tooltip = $"{entry.Label}\n{entry.Kind} · {MacroLibrary.Tag(entry.Parent ?? macro)}\n{(executor.IsRunning ? "已有宏运行，先中止再切换" : "左键运行；右键编辑或移出常用栏")}";
            if (showState)
            {
                tooltip += $"\n显示技能：{skill?.Name ?? "未知 / 不支持"} · #{macro.DisplayActionId}";
                if (snapshot.AdjustedActionId != 0 && snapshot.AdjustedActionId != macro.DisplayActionId) tooltip += $" → #{snapshot.AdjustedActionId}";
                tooltip += "\n" + snapshot.Label(true, true);
                if (snapshot.Availability != SkillAvailability.Unknown)
                    tooltip += $"\n原生状态={snapshot.Status}，忽略冷却/读条状态={snapshot.ConditionsStatus}";
                tooltip += "\n仅参考当前目标的单个 Action 状态；不解析 <mo>/<f>，不代表整段宏或执行结果。";
            }
            ImGui.SetTooltip(tooltip);
        }
        if (ImGui.BeginPopupContextItem("##QuickEntry"))
        {
            ImGui.TextUnformatted(entry.Label); ImGui.Separator();
            if (ImGui.MenuItem("编辑此宏")) mainWindow.EditEntry(macro); RecordItem("edit-" + macro.Id);
            if (openDisplaySettings != null)
            {
                if (ImGui.MenuItem("设置显示技能…")) openDisplaySettings(macro);
                RecordItem("display-" + macro.Id);
            }
            if (ImGui.MenuItem("移出常用栏")) SetPinned(macro, false); RecordItem("remove-" + macro.Id);
            ImGui.EndPopup();
        }
        if(themed)
        {
            ImGui.SameLine(0,0);
            if(ImGui.Button("##DirectEdit",new Vector2(editWidth,buttonHeight)))mainWindow.EditEntry(macro);
            RecordItem("direct-edit-"+macro.Id);
            ShelfDrawing.Glyph(ImGui.GetWindowDrawList(),ShelfGlyph.Edit,ImGui.GetItemRectMin()+new Vector2(S(7),(buttonHeight-S(18))/2),S(18),ShelfSkin.Palette(configuration.Theme).Text);
            if(ImGui.IsItemHovered())ImGui.SetTooltip("编辑此宏（不执行）");
        }
        ImGui.PopID();
        ImGui.EndGroup();
    }
    private void DrawSkillIcon(uint iconId, Vector2 minimum, float size)
    {
        // The provider owns these shared handles. Never dispose them; query at most one visible icon per button/frame.
        var lookup = new GameIconLookup(iconId);
        if (textureProvider!.TryGetFromGameIcon(lookup, out var texture) && texture.TryGetWrap(out var wrap, out _))
            ImGui.GetWindowDrawList().AddImage(wrap.Handle, minimum, minimum + new Vector2(size));
    }
    private void SetPinned(MacroEntry macro, bool value)
    {
        if (QuickBarModel.SetPinned(configuration, macro, value)) mainWindow.RefreshLibrary();
    }
    // The dock uses the same renderer/executor/error/picker/context actions as the floating bar.
    // It is an additional view, not a copied macro list or a second execution engine.
    internal static float MinimumDockHeight(ShelfTheme theme)
    {
        var font=ImGui.GetCurrentContext().FontBaseSize;
        var row=MathF.Max(S(theme==ShelfTheme.Needy?44:56),font*2+S(12));
        return (row+ImGui.GetStyle().ScrollbarSize+S(12+22+4)+(theme==ShelfTheme.Needy?S(42):0))/ImGuiHelpers.GlobalScale;
    }
    internal void DrawDocked(Vector2 size)
    {
        var oldHeight = buttonHeight;
        ImGui.PushID("MainQuickDock");
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(S(6)));
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(S(7), S(5)));
        try
        {
            ImGui.BeginChild("##Dock", size, false, ImGuiWindowFlags.AlwaysUseWindowPadding|ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);
            ImGui.SetWindowFontScale(1);
            RecordRegion("dock",ImGui.GetWindowPos(),ImGui.GetWindowPos()+ImGui.GetWindowSize());
            ShelfSkin.Panel(configuration.Theme,ImGui.GetWindowPos(),ImGui.GetWindowPos()+ImGui.GetWindowSize(),true);
            if(configuration.Theme==ShelfTheme.Needy)
            {
                ShelfSkin.SectionTitle(configuration.Theme,"常用栏  —  把最常用的宏，放在触手可及的地方。");
            }
            var pinned = QuickBarModel.Pinned(configuration); ClearStaleError(pinned);
            ImGui.BeginChild("##DockLabel", new Vector2(S(configuration.Theme==ShelfTheme.Needy?103:154), 0), false, ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);
            if(configuration.Theme!=ShelfTheme.Needy)ShelfSkin.SectionTitle(configuration.Theme, "常用栏");
            if (ImGui.SmallButton("添加")) { pickerSearch = string.Empty; ImGui.OpenPopup("##QuickPicker"); } RecordItem("dock-add");
            ImGui.SameLine();
            if (ImGui.SmallButton("管理")) mainWindow.ShowQuickBarPage(); RecordItem("dock-manage");
            if (lastError.Length > 0) { ImGui.SameLine(); ImGui.TextColored(new Vector4(1,.25f,.4f,1), "!"); if (ImGui.IsItemHovered()) ImGui.SetTooltip(lastError); }
            DrawPicker(); ImGui.EndChild(); ImGui.SameLine();
            ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding,Vector2.Zero);
            ImGui.BeginChild("##DockItems", Vector2.Zero, false, ImGuiWindowFlags.AlwaysHorizontalScrollbar|ImGuiWindowFlags.HorizontalScrollbar);
            ImGui.PopStyleVar();ImGui.SetWindowFontScale(1);
            RecordRegion("dock-items",ImGui.GetWindowPos(),ImGui.GetWindowPos()+ImGui.GetWindowSize()-new Vector2(0,ImGui.GetStyle().ScrollbarSize));
            buttonHeight = MathF.Max(S(configuration.Theme==ShelfTheme.Needy?44:56),ImGui.GetTextLineHeight()*2+S(12));
            var cardWidth=Math.Clamp((ImGui.GetContentRegionAvail().X-S(7)*Math.Max(0,pinned.Count-1))/Math.Max(1,Math.Min(pinned.Count,4)),S(194),S(315));
            if (pinned.Count == 0) ImGui.TextWrapped("还没有常用宏。点击“添加”，或在工作台勾选“加入常用栏”。");
            for (var i=0; i<pinned.Count; i++)
            {
                if (i>0) ImGui.SameLine();
                DrawMacro(pinned[i], cardWidth);
            }
            ImGui.EndChild(); ImGui.EndChild();
        }
        finally { buttonHeight = oldHeight; ImGui.PopStyleVar(2); ImGui.PopID(); }
    }
    private void DrawPicker()
    {
        if (!ImGui.IsPopupOpen("##QuickPicker")) return;
        var viewport = ImGui.GetMainViewport();
        var popupSize = new Vector2(MathF.Min(S(430), viewport.WorkSize.X - S(24)), MathF.Min(S(340), viewport.WorkSize.Y - S(24)));
        ImGui.SetNextWindowSize(popupSize, ImGuiCond.Always);
        // Explicit flags replace BeginPopup's default AlwaysAutoResize; child cannot grow its parent.
        if (!ImGui.BeginPopup("##QuickPicker", ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse)) return;
        RecordRegion("picker-window", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
        ImGui.TextUnformatted("选择常用宏"); ImGui.SameLine(); ImGui.TextDisabled("勾选即添加");
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##PickerSearch", "搜索名称或分类…", ref pickerSearch, 256); RecordItem("picker-search");
        ImGui.Separator();
        var all = QuickBarModel.All(configuration).Where(e => QuickBarModel.Matches(e, pickerSearch)).ToList();
        var footerY = ImGui.GetWindowSize().Y - ImGui.GetStyle().WindowPadding.Y - ImGui.GetFrameHeight();
        var listTop = ImGui.GetCursorPosY();
        ImGui.BeginChild("##PickerEntries", new Vector2(0, MathF.Max(1, footerY - S(8) - listTop)), false);
        RecordRegion("picker-list", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
        if (all.Count == 0) ImGui.TextWrapped(configuration.Macros.Count == 0 ? "还没有宏。点击底部“打开管理”创建。" : "没有匹配的宏。");
        foreach (var entry in all)
        {
            var macro = entry.Macro; var value = macro.Pinned; ImGui.PushID(macro.Id);
            if (ImGui.Checkbox("##Pin", ref value)) SetPinned(macro, value); RecordItem("pin-" + macro.Id);
            ImGui.SameLine();
            ImGui.TextUnformatted(MainWindow.Fit($"{entry.Kind} · {entry.Label}", ImGui.GetContentRegionAvail().X));
            if (ImGui.IsItemHovered()) ImGui.SetTooltip(entry.Label);
            ImGui.PopID();
        }
        ImGui.EndChild();
        DrawDivider(footerY - S(4));
        ImGui.SetCursorPos(new Vector2(ImGui.GetStyle().WindowPadding.X, footerY));
        if (ImGui.Button("完成")) ImGui.CloseCurrentPopup(); RecordItem("picker-done"); ImGui.SameLine();
        if (ImGui.Button("打开管理")) { mainWindow.IsOpen = true; ImGui.CloseCurrentPopup(); } RecordItem("picker-manage");
        ImGui.EndPopup();
    }
    private void DrawOptions()
    {
        if (!ImGui.BeginPopup("##QuickOptions")) return;
        var locked = configuration.LockQuickBar;
        if (ImGui.Checkbox("锁定位置", ref locked)) { configuration.LockQuickBar = locked; configuration.Save(); } RecordItem("lock");
        var columns = configuration.QuickBarColumns;
        ImGui.SetNextItemWidth(S(160));
        if (ImGui.SliderInt("每行按钮数", ref columns, 1, 8)) { configuration.QuickBarColumns = columns; configuration.Save(); }
        var width = configuration.QuickBarButtonWidth;
        ImGui.SetNextItemWidth(S(160));
        if (ImGui.SliderFloat("按钮宽度", ref width, 80, 200, "%.0f px")) { configuration.QuickBarButtonWidth = width; configuration.Save(); }
        ImGui.Separator();
        if (ImGui.MenuItem("隐藏常用栏")) { configuration.ShowQuickBar = false; configuration.Save(); } RecordItem("hide");
        ImGui.TextDisabled("/aklmacro bar 恢复显示");
        ImGui.EndPopup();
    }
    private void DrawStatus()
    {
        DrawDivider(statusTop - S(4));
        ImGui.SetCursorPos(new Vector2(S(10), statusTop));
        if (executor.IsRunning)
        {
            if(configuration.Theme!=ShelfTheme.Classic)
            {
                if(ShelfSkin.Button(configuration.Theme,"中止",new Vector2(S(62),ImGui.GetFrameHeight()),true))executor.Stop();RecordItem("stop");ImGui.SameLine();
            }
            else
            {
            ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(.60f,.20f,.25f,1));
            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(.68f,.24f,.28f,1));
            ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(.60f,.20f,.25f,1));
            if (ImGui.Button("中止", new Vector2(S(62), 0))) executor.Stop(); RecordItem("stop");
            ImGui.PopStyleColor(3); ImGui.SameLine();
            }
            var waitStatus = executor.IsWaitingForJobChange ? "等待职业与套装同步" : $"{executor.RemainingWait:F1}s";
            var status = $"{executor.CurrentMacroName} · {executor.ExecutedLines}/{executor.TotalLines} 行 · {waitStatus}";
            ImGui.TextUnformatted(MainWindow.Fit(status, ImGui.GetContentRegionAvail().X));
            if (ImGui.IsItemHovered()) ImGui.SetTooltip(status);
        }
        else
        {
            var text = lastError;
            if (lastError.Length > 0) ImGui.PushStyleColor(ImGuiCol.Text, configuration.Theme==ShelfTheme.Classic?new Vector4(1,.65f,.67f,1):ShelfSkin.Error(configuration.Theme));
            ImGui.TextUnformatted(MainWindow.Fit(text, ImGui.GetContentRegionAvail().X));
            if (lastError.Length > 0) ImGui.PopStyleColor();
            if (ImGui.IsItemHovered()) ImGui.SetTooltip(text);
        }
    }
    private static void ClampToViewport()
    {
        var viewport = ImGui.GetMainViewport(); var minimum = viewport.WorkPos + new Vector2(S(8));
        var maximum = Vector2.Max(minimum, viewport.WorkPos + viewport.WorkSize - ImGui.GetWindowSize() - new Vector2(S(8)));
        var position = ImGui.GetWindowPos(); var clamped = Vector2.Clamp(position, minimum, maximum);
        if (Vector2.DistanceSquared(position, clamped) > .01f) ImGui.SetWindowPos(clamped, ImGuiCond.Always);
    }
}
