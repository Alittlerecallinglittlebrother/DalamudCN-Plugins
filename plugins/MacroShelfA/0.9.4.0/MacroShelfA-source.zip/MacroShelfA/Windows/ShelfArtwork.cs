using System.Numerics;
using System.Collections.Generic;
using System.Text.Json;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Textures;
using Dalamud.Plugin.Services;

namespace MacroShelfA.Windows;

internal interface IShelfArtwork
{
    void Draw(ImDrawListPtr list, bool wordmark, Vector2 minimum, Vector2 maximum, uint tint = 0xffffffff);
    bool DrawLettering(ImDrawListPtr list,string label,Vector2 minimum,float height,uint tint=0xffffffff);
}

// Shared handles are owned by Dalamud. Do not dispose them or decode/upload images in Draw().
internal sealed class ShelfArtwork : IShelfArtwork
{
    private readonly ISharedImmediateTexture portrait;
    private readonly ISharedImmediateTexture wordmark;
    private readonly ISharedImmediateTexture lettering;
    internal readonly record struct Letter(float X,float Y,float Width,float Height);
    private static Dictionary<string,Letter>? letters;
    internal static bool TryLetter(string name,out Letter letter)
    {
        if(letters==null){using var resource=typeof(ShelfArtwork).Assembly.GetManifestResourceStream("MacroShelfA.Resources.ShelfLettering.json")!;letters=JsonSerializer.Deserialize<Dictionary<string,Letter>>(resource)!;}
        return letters.TryGetValue(name,out letter);
    }
    public ShelfArtwork(ITextureProvider provider)
    {
        var assembly = typeof(ShelfArtwork).Assembly;
        portrait = provider.GetFromManifestResource(assembly, "MacroShelfA.Resources.P3Makoto.png");
        wordmark = provider.GetFromManifestResource(assembly, "MacroShelfA.Resources.ShelfWordmark.png");
        lettering = provider.GetFromManifestResource(assembly,"MacroShelfA.Resources.ShelfLettering.png");
    }
    public void Draw(ImDrawListPtr list, bool isWordmark, Vector2 minimum, Vector2 maximum, uint tint = 0xffffffff)
    {
        var texture = isWordmark ? wordmark : portrait;
        if (texture.TryGetWrap(out var wrap, out _)) list.AddImage(wrap.Handle, minimum, maximum, Vector2.Zero, Vector2.One, tint);
    }
    public bool DrawLettering(ImDrawListPtr list,string label,Vector2 minimum,float height,uint tint=0xffffffff)
    {
        if(!TryLetter(label,out var r)||!lettering.TryGetWrap(out var wrap,out _))return false;
        list.AddImage(wrap.Handle,minimum,minimum+new Vector2(height*r.Width/r.Height,height),new Vector2(r.X/1600,r.Y/600),new Vector2((r.X+r.Width)/1600,(r.Y+r.Height)/600),tint);return true;
    }
}
