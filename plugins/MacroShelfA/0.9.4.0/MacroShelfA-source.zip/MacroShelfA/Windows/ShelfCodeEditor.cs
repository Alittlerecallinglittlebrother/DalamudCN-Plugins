using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text.RegularExpressions;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;

namespace MacroShelfA.Windows;

// Native InputText owns edits, IME, undo, selection and scrolling. The presentation layer
// reads the matching child scroll/caret state from the SDK's typed ImGui bindings only.
// It never edits ImGui memory or replaces the user's command buffer with tokenized text.
internal sealed partial class ShelfCodeEditor
{
    partial void RecordGeometry(Vector2 origin,float lineHeight,Vector2 minimum,Vector2 maximum);
    private string? cached;
    private string[] lines = [];
    private List<(string Text, int Kind)>[] tokens = [];
    private static readonly Regex Syntax = new(@"(^\s*/[^\s]+)|(<[^>\r\n]+>)|(\b\d+(?:\.\d+)?\b)", RegexOptions.Compiled | RegexOptions.CultureInvariant);
    private static float S(float n) => n * ImGuiHelpers.GlobalScale;
    private void Parse(string text)
    {
        if (ReferenceEquals(cached, text)) return;
        cached = text; lines = text.Replace("\r\n", "\n").Split('\n'); tokens = new List<(string, int)>[lines.Length];
        for (var i = 0; i < lines.Length; i++)
        {
            var row = new List<(string, int)>(); var offset = 0;
            foreach (Match match in Syntax.Matches(lines[i]))
            {
                if (match.Index > offset) row.Add((lines[i][offset..match.Index], 0));
                row.Add((match.Value, match.Groups[1].Success ? 1 : match.Groups[2].Success ? 2 : 3));
                offset = match.Index + match.Length;
            }
            if (offset < lines[i].Length) row.Add((lines[i][offset..], 0)); tokens[i] = row;
        }
    }
    internal unsafe bool Draw(string id, ref string text, int capacity, Vector2 size, ShelfTheme theme)
    {
        var p = ShelfSkin.Palette(theme); var start = ImGui.GetCursorScreenPos(); var gutter = S(37);
        var width = size.X <= 0 ? ImGui.GetContentRegionAvail().X : size.X;
        var parent = ImGui.GetCurrentContext().CurrentWindow;
        var inputId = ImGui.GetID(id); var padding = ImGui.GetStyle().FramePadding;
        var dl = ImGui.GetWindowDrawList();
        dl.AddRectFilled(start, start + new Vector2(gutter, size.Y), ImGui.GetColorU32(Vector4.Lerp(p.Code, p.Text, .04f)));
        ImGui.SetCursorScreenPos(start + new Vector2(gutter, 0));
        ImGui.PushStyleColor(ImGuiCol.FrameBg, p.Code); ImGui.PushStyleColor(ImGuiCol.Text, Vector4.Zero);
        var changed = ImGui.InputTextMultiline(id, ref text, capacity, new Vector2(MathF.Max(S(80), width - gutter), size.Y), ImGuiInputTextFlags.AllowTabInput);
        ImGui.PopStyleColor(2);
        Parse(text);
        var context = ImGui.GetCurrentContext(); ImGuiWindowPtr child = default;
        for (var i = 0; i < context.Windows.Size; i++)
        {
            var window = context.Windows[i];
            if (window.ChildId == inputId && window.ParentWindow.Handle == parent.Handle) { child = window; break; }
        }
        if (child.Handle == null)
        {
            // Keep commands visible even if a future ImGui binding changes its child identity.
            dl.PushClipRect(start+new Vector2(gutter,0),start+new Vector2(width,size.Y),true);
            dl.AddText(start+new Vector2(gutter,0)+padding,ImGui.GetColorU32(p.CodeText),text);
            dl.PopClipRect();return changed;
        }
        // ImGui 1.88 CalcFontSize uses this window AND its direct parent's scale.
        // After InputText ends we are back in the grandparent's font metrics, which
        // may differ. Never use that font size for the native input's overlay.
        var font=context.Font;var fontSize=context.FontBaseSize*child.FontWindowScale*parent.FontWindowScale;
        float TextWidth(string value)=>ImGui.CalcTextSizeA(font,fontSize,float.MaxValue,0,value,out _).X;
        var state = context.InputTextState;
        // The input child contains only this editor and its scrollbar. Dragging
        // that scrollbar retains native selection and horizontal scroll too.
        var active = state.ID == inputId && (context.ActiveId == inputId ||
            (context.ActiveId != 0 && context.ActiveIdWindow.Handle == child.Handle));
        var scrollX = active ? state.ScrollX : 0;
        var origin = child.Pos + padding - new Vector2(scrollX, child.Scroll.Y);
        var clipMin = Vector2.Max(child.InnerClipRect.Min, child.Pos + new Vector2(1));
        var clipMax = Vector2.Min(child.InnerClipRect.Max, child.Pos + child.Size - new Vector2(1));
        RecordGeometry(origin,fontSize,clipMin,clipMax);
        var paint = child.DrawList;
        paint.PushClipRect(clipMin, clipMax, true);
        var first = Math.Clamp((int)((clipMin.Y - origin.Y) / fontSize), 0, Math.Max(0, lines.Length - 1));
        var last = Math.Min(lines.Length, first + (int)(size.Y / fontSize) + 3);
        for (var line = first; line < last; line++)
        {
            var x = origin.X; var y = origin.Y + line * fontSize;
            foreach (var token in tokens[line])
            {
                var color = token.Kind switch
                { 1 => theme == ShelfTheme.Persona3 ? new Vector4(0, .91f, 1, 1) : new Vector4(.52f, .86f, 1, 1),
                  2 => new Vector4(.92f, .64f, .95f, 1), 3 => new Vector4(.83f, .94f, .58f, 1), _ => p.CodeText };
                paint.AddText(font,fontSize,new Vector2(x,y),ImGui.GetColorU32(color),token.Text);x+=TextWidth(token.Text);
            }
        }
        if (active && (!ImGui.GetIO().ConfigInputTextCursorBlink||state.CursorAnim <= 0 || state.CursorAnim % 1.2f <= .8f))
        {
            // Use the native caret/IME position instead of reinterpreting UTF-16 offsets.
            var cursor=context.PlatformImeData.InputPos+new Vector2(1,.5f);
            paint.AddLine(cursor,cursor+new Vector2(0,fontSize-2),ImGui.GetColorU32(p.CodeText),S(1));
        }
        paint.PopClipRect();
        dl.PushClipRect(start + new Vector2(1), start + new Vector2(gutter - S(5), size.Y - 1), true);
        for (var line = first; line < last; line++)
        {
            var label=(line+1).ToString();dl.AddText(font,fontSize,new Vector2(start.X+gutter-S(9)-TextWidth(label),origin.Y+line*fontSize),ImGui.GetColorU32(p.Muted),label);
        }
        dl.PopClipRect();
        dl.AddLine(start + new Vector2(gutter - S(1), 0), start + new Vector2(gutter - S(1), size.Y), ImGui.GetColorU32(p.Border), S(1));
        return changed;
    }
}
