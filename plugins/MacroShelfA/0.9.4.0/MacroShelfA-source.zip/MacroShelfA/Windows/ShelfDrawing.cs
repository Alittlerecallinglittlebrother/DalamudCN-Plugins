using System;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;

namespace MacroShelfA.Windows;

internal enum ShelfGlyph { None, Plus, File, Folder, Play, Next, Copy, Trash, Link, Upload, Download, Star, Edit, Search, Home, Gear, Bolt, Grid }

internal static class ShelfDrawing
{
    private static float S(float n) => n * ImGuiHelpers.GlobalScale;
    public static uint U(Vector4 color) => ImGui.GetColorU32(color);
    public static void Text(ImDrawListPtr dl, Vector2 pos, string text, float size, Vector4 color, float shear = 0)
    {
        // Functional text uses the same single-pass native font as ImGui settings.
        // No duplicate offset stroke, artificial slant or per-label font scaling.
        dl.AddText(ImGui.GetFont(),ImGui.GetFontSize(),pos,U(color),text);
    }
    public static void Star(ImDrawListPtr dl, Vector2 center, float radius, Vector4 color, bool fill = true)
    {
        Vector2 P(int i) { var a = -MathF.PI / 2 + i * MathF.PI / 5; return center + new Vector2(MathF.Cos(a), MathF.Sin(a)) * radius * (i % 2 == 0 ? 1 : .43f); }
        var flags = dl.Flags; dl.Flags &= ~ImDrawListFlags.AntiAliasedFill;
        for (var i = 0; i < 10; i++)
            if (fill) dl.AddTriangleFilled(center, P(i), P(i + 1), U(color)); else dl.AddLine(P(i), P(i + 1), U(color), S(1.4f));
        dl.Flags = flags;
    }
    public static void Heart(ImDrawListPtr dl, Vector2 p, float pixel, Vector4 color)
    {
        string[] rows = { "0110110", "1111111", "1111111", "0111110", "0011100", "0001000" };
        Pixels(dl, p, pixel, rows, color);
    }
    public static void Cat(ImDrawListPtr dl, Vector2 p, float pixel, Vector4 color)
    {
        string[] rows = { "110000011", "101000101", "100111001", "100000001", "100000001", "101000101", "100010001", "010000010", "001111100" };
        Pixels(dl, p, pixel, rows, color);
        Pixels(dl, p + new Vector2(2, 6) * pixel, pixel, new[] { "1100011" }, new Vector4(1, .55f, .86f, 1));
    }
    private static void Pixels(ImDrawListPtr dl, Vector2 p, float pixel, string[] rows, Vector4 color)
    {
        var flags = dl.Flags; dl.Flags &= ~ImDrawListFlags.AntiAliasedFill;
        for (var y = 0; y < rows.Length; y++) for (var x = 0; x < rows[y].Length; x++)
            if (rows[y][x] == '1') dl.AddRectFilled(p + new Vector2(x, y) * pixel, p + new Vector2(x + 1, y + 1) * pixel, U(color));
        dl.Flags = flags;
    }
    public static void Dots(ImDrawListPtr dl, Vector2 min, Vector2 max, Vector4 color, bool reverse = false)
    {
        var pitch = S(9); var rows = Math.Min(12, (int)((max.Y - min.Y) / pitch));
        for (var y = 0; y < rows; y++)
            for (var x = 0; x < Math.Min(40, (int)((max.X - min.X) / pitch)); x++)
            {
                var f = reverse ? (float)(rows - y) / Math.Max(1, rows) : (float)(y + 1) / Math.Max(1, rows);
                dl.AddCircleFilled(min + new Vector2(x + (y % 2) * .5f, y) * pitch, S(.6f + f * 1.7f), U(color), 6);
            }
    }
    public static void WaterLight(ImDrawListPtr dl,Vector2 min,Vector2 max,float time)
    {
        // Bounded, slowly refracting cells behind the UI, not a frame-sized animated texture.
        var size=(max-min)/ImGuiHelpers.GlobalScale;dl.PushClipRect(min,max,true);
        var columns=Math.Min(26,(int)(size.X/72)+2);var rows=Math.Min(22,(int)(size.Y/46)+2);
        Vector2 Node(int x,int y)=>min+new Vector2(S(x*72-45+MathF.Sin(y*1.7f+x*.43f+time*.18f)*27),S(y*46-28+MathF.Sin(x*1.45f+y*.53f+time*.13f)*18));
        for(var y=0;y<rows;y++)for(var x=0;x<columns;x++)
        {
            var a=Node(x,y);var fade=.10f+.20f*MathF.Pow(1-Math.Clamp((a.Y-min.Y)/(max.Y-min.Y),0,1),2);
            void Edge(Vector2 b){dl.AddLine(a,b,U(new Vector4(.28f,.88f,1,fade*.3f)),S(8));dl.AddLine(a,b,U(new Vector4(.75f,1,1,fade)),S(1.8f));}
            if(x+1<columns)Edge(Node(x+1,y));if(y+1<rows)Edge(Node(x,y+1));
        }
        dl.PopClipRect();
    }
    public static void Glyph(ImDrawListPtr dl, ShelfGlyph glyph, Vector2 p, float z, Vector4 color)
    {
        var c = U(color); var t = MathF.Max(S(1.5f), z * .085f);
        Vector2 P(float x, float y) => p + new Vector2(x, y) * z;
        void L(float x, float y, float xx, float yy) => dl.AddLine(P(x,y),P(xx,yy),c,t);
        switch (glyph)
        {
            case ShelfGlyph.None: return;
            case ShelfGlyph.Plus: L(.5f,.1f,.5f,.9f);L(.1f,.5f,.9f,.5f);break;
            case ShelfGlyph.Play: dl.AddTriangleFilled(P(.16f,.08f),P(.16f,.92f),P(.86f,.5f),c);break;
            case ShelfGlyph.Next: dl.AddTriangleFilled(P(0,.12f),P(0,.88f),P(.5f,.5f),c);dl.AddTriangleFilled(P(.5f,.12f),P(.5f,.88f),P(1,.5f),c);break;
            case ShelfGlyph.Star: Star(dl,P(.5f,.5f),z*.48f,color);break;
            case ShelfGlyph.Folder: L(.05f,.25f,.4f,.25f);L(.4f,.25f,.52f,.38f);L(.52f,.38f,.95f,.38f);L(.95f,.38f,.86f,.86f);L(.86f,.86f,.05f,.86f);L(.05f,.86f,.05f,.25f);break;
            case ShelfGlyph.File: L(.18f,.08f,.6f,.08f);L(.6f,.08f,.86f,.32f);L(.86f,.32f,.86f,.94f);L(.86f,.94f,.18f,.94f);L(.18f,.94f,.18f,.08f);L(.6f,.08f,.6f,.32f);L(.6f,.32f,.86f,.32f);break;
            case ShelfGlyph.Copy: dl.AddRect(P(.25f,.10f),P(.91f,.74f),c,0,ImDrawFlags.None,t);L(.09f,.27f,.09f,.92f);L(.09f,.92f,.72f,.92f);break;
            case ShelfGlyph.Trash: L(.17f,.25f,.84f,.25f);L(.3f,.08f,.7f,.08f);L(.25f,.3f,.3f,.92f);L(.3f,.92f,.75f,.92f);L(.75f,.92f,.8f,.3f);L(.45f,.4f,.45f,.78f);L(.61f,.4f,.61f,.78f);break;
            case ShelfGlyph.Upload: case ShelfGlyph.Download: var up=glyph==ShelfGlyph.Upload;var a=up?.16f:.70f;var b=up?.7f:.16f;L(.5f,a,.5f,b);L(.5f,a,.28f,up?.39f:.47f);L(.5f,a,.72f,up?.39f:.47f);L(.1f,.7f,.1f,.92f);L(.1f,.92f,.9f,.92f);L(.9f,.92f,.9f,.7f);break;
            case ShelfGlyph.Link: dl.AddCircle(P(.32f,.66f),z*.23f,c,12,t);dl.AddCircle(P(.68f,.3f),z*.23f,c,12,t);L(.34f,.63f,.64f,.34f);break;
            case ShelfGlyph.Edit: L(.2f,.78f,.73f,.19f);L(.3f,.87f,.84f,.29f);L(.73f,.19f,.84f,.29f);L(.2f,.78f,.17f,.94f);L(.17f,.94f,.3f,.87f);break;
            case ShelfGlyph.Search: dl.AddCircle(P(.43f,.4f),z*.3f,c,20,t);L(.65f,.63f,.94f,.94f);break;
            case ShelfGlyph.Home: dl.AddTriangleFilled(P(.04f,.45f),P(.5f,.02f),P(.96f,.45f),c);dl.AddRectFilled(P(.2f,.4f),P(.8f,.92f),c);break;
            case ShelfGlyph.Bolt: dl.AddTriangleFilled(P(.58f,.02f),P(.16f,.56f),P(.57f,.54f),c);dl.AddTriangleFilled(P(.45f,.45f),P(.85f,.45f),P(.34f,.98f),c);break;
            case ShelfGlyph.Grid: for(var i=0;i<9;i++){var q=P((i%3)*.34f,(i/3)*.34f);dl.AddRectFilled(q,q+new Vector2(z*.25f),c);}break;
            case ShelfGlyph.Gear: dl.AddCircle(P(.5f,.5f),z*.3f,c,12,t*2);for(var i=0;i<8;i++){var angle=i*MathF.PI/4;dl.AddLine(P(.5f,.5f)+new Vector2(MathF.Cos(angle),MathF.Sin(angle))*z*.26f,P(.5f,.5f)+new Vector2(MathF.Cos(angle),MathF.Sin(angle))*z*.46f,c,t*2);}break;
        }
    }
}
