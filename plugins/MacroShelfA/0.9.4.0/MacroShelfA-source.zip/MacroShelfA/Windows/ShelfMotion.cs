using System;
using System.Collections.Generic;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

// Animates presentation only. Hit rectangles, focus, selection and execution never interpolate.
internal static class ShelfMotion
{
    private sealed class Track { public float Value; public int Frame; public double Started; }
    private static readonly Dictionary<uint, Track> tracks = new();
    private static nint context;
    public static bool Reduced { get; set; }
    public static double Time => Reduced ? 0 : ImGui.GetTime();
    public static float Hover(uint id, bool hovered)
    {
        CheckContext();
        var frame = ImGui.GetFrameCount();
        if (!tracks.TryGetValue(id, out var track)) tracks[id] = track = new Track { Frame = frame - 1 };
        if (track.Frame != frame)
        {
            var target = hovered ? 1f : 0f;
            track.Value = Reduced ? target : track.Value + (target - track.Value) * (1 - MathF.Exp(-Math.Clamp(ImGui.GetIO().DeltaTime, 0, .1f) * 18));
            track.Frame = frame;
        }
        return track.Value;
    }
    public static float Reveal(uint id)
    {
        CheckContext();
        if (!tracks.TryGetValue(id, out var track)) tracks[id] = track = new Track { Started = ImGui.GetTime() };
        else if(ImGui.GetFrameCount()-track.Frame>1) track.Started=ImGui.GetTime();
        track.Frame = ImGui.GetFrameCount();
        return Reduced ? 1 : 1 - MathF.Exp(-(float)(ImGui.GetTime() - track.Started) * 12);
    }
    private static unsafe void CheckContext()
    {
        var current = (nint)ImGui.GetCurrentContext().Handle;
        if (context != current) { tracks.Clear(); context = current; }
        if (tracks.Count > 2048)
        {
            var frame = ImGui.GetFrameCount();
            var stale = new List<uint>();
            foreach (var item in tracks) if (frame - item.Value.Frame > 120) stale.Add(item.Key);
            foreach (var id in stale) tracks.Remove(id);
            if (tracks.Count > 4096) tracks.Clear();
        }
    }
}
