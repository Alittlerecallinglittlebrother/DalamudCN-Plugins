using System;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
namespace MacroShelfA.Windows;
internal readonly record struct ShelfPalette(Vector4 Background, Vector4 Panel, Vector4 Text, Vector4 Muted,
    Vector4 Border, Vector4 Accent, Vector4 OnAccent, Vector4 Selection, Vector4 OnSelection,
    Vector4 Frame, Vector4 Button, Vector4 Code, Vector4 CodeText);
internal static class ShelfSkin
{
    internal static IShelfArtwork? Artwork { get; set; }
    private static Vector4 C(float r,float g,float b)=>new(r,g,b,1);
    private static float S(float n)=>n*ImGuiHelpers.GlobalScale;
    public static string Name(ShelfTheme theme)=>theme switch{ShelfTheme.Needy=>"主播女孩 · 粉彩甜心",ShelfTheme.Persona5=>"女神异闻录 5",ShelfTheme.Classic=>"经典界面",_=>"女神异闻录 3 Reload"};
    public static ShelfPalette Palette(ShelfTheme theme)=>theme switch
    {
        ShelfTheme.Needy=>new(C(.12f,.12f,.21f),C(.984f,.972f,1),C(.12f,.06f,.64f),C(.46f,.38f,.75f),C(.69f,.61f,.97f),C(.94f,.18f,.65f),Vector4.One,C(1,.69f,.92f),C(.16f,.03f,.61f),C(1,.99f,1),C(.94f,.91f,1),C(.16f,.135f,.255f),C(.95f,.94f,1)),
        ShelfTheme.Persona5=>new(C(.075f,.09f,.10f),C(.035f,.043f,.047f),Vector4.One,C(.73f,.74f,.75f),C(.88f,.90f,.90f),C(.96f,.012f,.065f),Vector4.One,C(.98f,.015f,.065f),Vector4.One,C(.025f,.035f,.039f),C(.07f,.08f,.083f),C(.014f,.022f,.025f),C(.94f,.96f,.98f)),
        _=>new(C(0,.35f,.86f),C(.019f,.12f,.30f),C(.92f,.98f,1),C(.47f,.72f,.90f),C(.10f,.39f,.63f),C(0,.81f,.96f),C(.003f,.08f,.20f),C(.98f,1,1),C(.002f,.07f,.22f),C(.025f,.14f,.28f),C(.035f,.22f,.46f),C(.009f,.075f,.18f),C(.93f,.98f,1)),
    };
    public static Vector4 Error(ShelfTheme t)=>t==ShelfTheme.Needy?C(.74f,.04f,.34f):C(1,.43f,.52f);
    public static IDisposable Apply(ShelfTheme theme,bool reduced=false)=>new Scope(theme,reduced);
    private sealed class Scope:IDisposable
    {
        private int colors,vars;private readonly bool previousMotion;
        public Scope(ShelfTheme theme,bool reduced)
        {
            previousMotion=ShelfMotion.Reduced;ShelfMotion.Reduced=reduced;
            if(theme==ShelfTheme.Classic)return;
            var p=Palette(theme);
            // Own EVERY ImGui color: no inherited tab, slider, scroll, resize or modal colors.
            for(var n=0;n<(int)ImGuiCol.Count;n++)
            {
                var id=(ImGuiCol)n;
                var c=id switch
                {
                    ImGuiCol.Text=>p.Text,ImGuiCol.TextDisabled=>p.Muted,
                    ImGuiCol.WindowBg or ImGuiCol.ChildBg or ImGuiCol.PopupBg=>p.Panel,
                    ImGuiCol.FrameBg=>p.Frame,ImGuiCol.FrameBgHovered=>Vector4.Lerp(p.Frame,p.Accent,.10f),ImGuiCol.FrameBgActive=>Vector4.Lerp(p.Frame,p.Accent,.18f),
                    ImGuiCol.TitleBg or ImGuiCol.MenuBarBg=>p.Button,ImGuiCol.TitleBgActive=>theme==ShelfTheme.Needy?C(.88f,.77f,.99f):p.Panel,ImGuiCol.TitleBgCollapsed=>p.Panel,
                    ImGuiCol.Button or ImGuiCol.Tab or ImGuiCol.TabUnfocused=>p.Button,
                    ImGuiCol.ButtonHovered or ImGuiCol.TabHovered or ImGuiCol.HeaderHovered=>Vector4.Lerp(p.Button,p.Accent,.27f),
                    ImGuiCol.ButtonActive or ImGuiCol.TabActive or ImGuiCol.TabUnfocusedActive or ImGuiCol.HeaderActive=>Vector4.Lerp(p.Button,p.Accent,.40f),
                    ImGuiCol.Header=>Vector4.Lerp(p.Panel,p.Accent,.23f),
                    ImGuiCol.ScrollbarBg=>p.Panel,ImGuiCol.ScrollbarGrab=>Vector4.Lerp(p.Panel,p.Border,.63f),
                    ImGuiCol.ScrollbarGrabHovered or ImGuiCol.ScrollbarGrabActive or ImGuiCol.CheckMark or ImGuiCol.SliderGrab or ImGuiCol.SliderGrabActive=>p.Accent,
                    ImGuiCol.TableHeaderBg=>p.Button,ImGuiCol.TableRowBg=>Vector4.Zero,ImGuiCol.TableRowBgAlt=>p.Text with{W=.035f},
                    ImGuiCol.BorderShadow=>Vector4.Zero,ImGuiCol.TextSelectedBg=>p.Accent with{W=.33f},
                    ImGuiCol.ModalWindowDimBg or ImGuiCol.NavWindowingDimBg=>new Vector4(0,0,0,.48f),
                    ImGuiCol.NavHighlight or ImGuiCol.DragDropTarget or ImGuiCol.DockingPreview=>p.Accent,
                    _=>p.Border,
                };
                ImGui.PushStyleColor(id,c);colors++;
            }
            ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding,theme==ShelfTheme.Needy?S(3):0);vars++;
            ImGui.PushStyleVar(ImGuiStyleVar.ChildRounding,theme==ShelfTheme.Needy?S(3):0);vars++;
            ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding,theme==ShelfTheme.Needy?S(3):0);vars++;
            ImGui.PushStyleVar(ImGuiStyleVar.FrameBorderSize,S(1));vars++;
            ImGui.PushStyleVar(ImGuiStyleVar.PopupBorderSize,S(1));vars++;
        }
        public void Dispose(){if(colors>0)ImGui.PopStyleColor(colors);if(vars>0)ImGui.PopStyleVar(vars);colors=vars=0;ShelfMotion.Reduced=previousMotion;}
    }
    public static void Quad(ImDrawListPtr dl,Vector2 a,Vector2 b,Vector2 c,Vector2 d,uint color)=>dl.AddQuadFilled(a,b,c,d,color);
    public static void Selection(ShelfTheme theme,Vector2 min,Vector2 max,bool selected,bool hovered)
    {
        if(!selected&&!hovered)return;var p=Palette(theme);var dl=ImGui.GetWindowDrawList();
        var fill=ImGui.GetColorU32(selected?p.Selection:Vector4.Lerp(p.Panel,p.Accent,.17f));
        if(theme==ShelfTheme.Persona3)Quad(dl,min,new(max.X,min.Y),max-new Vector2(S(12),0),new(min.X+S(4),max.Y),fill);
        else dl.AddRectFilled(min,max,fill,theme==ShelfTheme.Needy?S(2):0);
        if(selected&&theme==ShelfTheme.Persona5)dl.AddLine(min,max with{Y=min.Y},ImGui.GetColorU32(new Vector4(1,.45f,.45f,1)),S(1));
    }
    public static bool Button(ShelfTheme theme,string label,Vector2 size,bool primary=false,bool selected=false,bool danger=false,ShelfGlyph glyph=ShelfGlyph.None,bool nav=false)
    {
        var p=Palette(theme);var id=ImGui.GetID(label);
        ImGui.PushStyleColor(ImGuiCol.Button,Vector4.Zero);ImGui.PushStyleColor(ImGuiCol.ButtonHovered,Vector4.Zero);ImGui.PushStyleColor(ImGuiCol.ButtonActive,Vector4.Zero);ImGui.PushStyleColor(ImGuiCol.Text,Vector4.Zero);ImGui.PushStyleVar(ImGuiStyleVar.FrameBorderSize,0);
        var hit=ImGui.Button(label,size);ImGui.PopStyleVar();ImGui.PopStyleColor(4);
        var min=ImGui.GetItemRectMin();var max=ImGui.GetItemRectMax();var dl=ImGui.GetWindowDrawList();
        var hover=ShelfMotion.Hover(id,ImGui.IsItemHovered());var active=ImGui.IsItemActive();
        var fill=primary?p.Accent:selected?p.Selection:p.Button;
        if(nav&&theme==ShelfTheme.Persona3)fill=selected?p.Button:p.Selection;
        fill=Vector4.Lerp(fill,theme==ShelfTheme.Needy?Vector4.One:p.Accent,hover*.2f+(active?.2f:0));
        var text=primary?p.OnAccent:selected?p.OnSelection:p.Text;if(danger)text=Error(theme);
        if(nav&&theme==ShelfTheme.Persona3)text=selected?p.Text:p.OnSelection;
        if(theme==ShelfTheme.Persona3)
        {
            Quad(dl,min+new Vector2(S(9),0),new(max.X,min.Y),max-new Vector2(S(9),0),new(min.X,max.Y),ImGui.GetColorU32(fill));
            if(selected||hover>.01f)dl.AddLine(new(min.X,max.Y-S(2)),new(min.X+(max.X-min.X)*(selected?1:hover),max.Y-S(2)),ImGui.GetColorU32(p.Accent),S(2));
        }
        else if(nav&&theme==ShelfTheme.Persona5)
        {
            if(selected||hover>.01f)Quad(dl,min,new(max.X-S(10),min.Y),max,new(min.X+S(10),max.Y),ImGui.GetColorU32(selected?p.Accent:Vector4.Lerp(p.Panel,p.Accent,hover*.5f)));
        }
        else
        {
            dl.AddRectFilledMultiColor(min,max,ImGui.GetColorU32(Vector4.Lerp(fill,Vector4.One,theme==ShelfTheme.Needy?.16f:.065f)),ImGui.GetColorU32(fill),ImGui.GetColorU32(fill),ImGui.GetColorU32(Vector4.Lerp(fill,Vector4.Zero,.14f) with{W=fill.W}));
            dl.AddRect(min,max,ImGui.GetColorU32(danger?p.Accent:primary?Vector4.Lerp(p.Accent,Vector4.One,.4f):p.Border),theme==ShelfTheme.Needy?S(3):0,ImDrawFlags.None,S(danger?2:1));
            dl.AddLine(min+new Vector2(S(1)),new(max.X-S(1),min.Y+S(1)),ImGui.GetColorU32(new Vector4(1,1,1,theme==ShelfTheme.Needy?.8f:.16f)),S(1));
            if(theme==ShelfTheme.Persona5&&selected)Quad(dl,min,new(max.X-S(8),min.Y),max,new(min.X+S(7),max.Y),ImGui.GetColorU32(p.Accent));
        }
        var fullLabel=label.Split("##",StringSplitOptions.None)[0];var extra=glyph==ShelfGlyph.None?0:S(25);
        // Do not resize glyphs to squeeze a label into a button. Use the same
        // native font as settings, and ellipsize only when space is exhausted.
        var shown=fullLabel.Length<=2?fullLabel:MainWindow.Fit(fullLabel,MathF.Max(0,max.X-min.X-extra-S(18)));var textSize=ImGui.CalcTextSize(shown);
        var pos=min+(max-min-textSize-new Vector2(extra,0))/2;
        if(glyph!=ShelfGlyph.None){ShelfDrawing.Glyph(dl,glyph,pos+new Vector2(0,(textSize.Y-S(18))/2),S(18),text);pos.X+=extra;}
        ShelfDrawing.Text(dl,pos,shown,ImGui.GetFontSize(),text);
        if(shown!=fullLabel&&ImGui.IsItemHovered())ImGui.SetTooltip(fullLabel);
        if(ImGui.IsItemFocused())dl.AddRect(min+new Vector2(S(2)),max-new Vector2(S(2)),ImGui.GetColorU32(p.Text),0,ImDrawFlags.None,S(1));
        return hit;
    }
    public static void Panel(ShelfTheme theme,Vector2 min,Vector2 max,bool featured=false,ImDrawListPtr? drawList=null)
    {
        var dl=drawList??ImGui.GetWindowDrawList();var p=Palette(theme);
        // Borderless children clip their normal content to inner padding; chrome belongs
        // to the full window rectangle, not that padded text clip.
        dl.PushClipRect(min,max,drawList.HasValue);
        if(theme==ShelfTheme.Needy)
        {
            dl.AddRectFilled(min,max,p.Panel.ToUint());
            dl.AddRect(min,max,ImGui.GetColorU32(p.Border),S(3));
            dl.AddLine(min+new Vector2(S(2)),new(max.X-S(2),min.Y+S(2)),ImGui.GetColorU32(Vector4.One),S(2));
            dl.AddLine(new(min.X+S(2),max.Y-S(2)),max-new Vector2(S(2)),ImGui.GetColorU32(p.Border with{W=.4f}),S(2));
        }
        else if(theme==ShelfTheme.Persona5)
        {
            dl.AddRectFilled(min,max,ImGui.GetColorU32(p.Panel));
            Quad(dl,min,min+new Vector2(max.X-min.X,S(5)),new(max.X-S(4),max.Y),new(min.X+S(3),max.Y-S(2)),ImGui.GetColorU32(Vector4.One));
            Quad(dl,min+new Vector2(S(5),S(5)),new(max.X-S(5),min.Y+S(3)),max-new Vector2(S(6),S(5)),new(min.X+S(6),max.Y-S(6)),ImGui.GetColorU32(p.Panel));
            if(featured)
            {
                Quad(dl,min+new Vector2(S(4),S(3)),min+new Vector2(S(70),S(3)),min+new Vector2(S(11),S(14)),min+new Vector2(S(4),S(40)),ImGui.GetColorU32(p.Accent));
                Quad(dl,max-new Vector2(S(4),S(3)),max-new Vector2(S(120),S(3)),max-new Vector2(S(16),S(14)),max-new Vector2(S(4),S(44)),ImGui.GetColorU32(p.Accent));
                ShelfDrawing.Dots(dl,new Vector2(max.X-S(180),max.Y-S(75)),max-new Vector2(S(8)),new Vector4(.75f,.78f,.8f,.14f));
                ShelfDrawing.Star(dl,new Vector2(max.X-S(25),min.Y+S(23)),S(12),Vector4.One,false);
            }
        }
        else
        {
            dl.AddRectFilled(min,max,ImGui.GetColorU32(featured?new Vector4(.035f,.23f,.48f,1):p.Panel));
            dl.AddRect(min,max,ImGui.GetColorU32(p.Border));
            if(featured)dl.AddLine(min,min+new Vector2(S(85),0),ImGui.GetColorU32(p.Accent),S(3));
        }
        dl.PopClipRect();
    }
    public static void SectionTitle(ShelfTheme theme,string title,string number="")
    {
        var p=Palette(theme);var min=ImGui.GetCursorScreenPos();var height=MathF.Max(S(37),ImGui.GetFontSize()+S(16));var size=new Vector2(ImGui.GetContentRegionAvail().X,height);var dl=ImGui.GetWindowDrawList();ImGui.Dummy(size);
        if(theme==ShelfTheme.Needy)
        {
            dl.AddRectFilledMultiColor(min,min+size,ImGui.GetColorU32(new Vector4(.84f,.80f,1,1)),ImGui.GetColorU32(new Vector4(1,.78f,.94f,1)),ImGui.GetColorU32(new Vector4(1,.87f,.97f,1)),ImGui.GetColorU32(new Vector4(.91f,.86f,1,1)));
            dl.AddRect(min,min+size,ImGui.GetColorU32(p.Border));ShelfDrawing.Glyph(dl,ShelfGlyph.Grid,min+new Vector2(S(9),(height-S(17))/2),S(17),p.Text);
            ShelfDrawing.Text(dl,min+new Vector2(S(34),(height-ImGui.GetFontSize())/2),MainWindow.Fit(title,size.X-S(46)),ImGui.GetFontSize(),p.Text);
        }
        else
        {
            var shown=MainWindow.Fit(title,size.X-S(42));var w=MathF.Min(size.X-S(12),ImGui.CalcTextSize(shown).X+S(30));
            Quad(dl,min+new Vector2(S(6),S(3)),min+new Vector2(w,0),min+new Vector2(w-S(12),height-S(3)),min+new Vector2(0,height),ImGui.GetColorU32(Vector4.One));
            var ink=theme==ShelfTheme.Persona5?new Vector4(.01f,.015f,.02f,1):new Vector4(.004f,.07f,.21f,1);
            ShelfDrawing.Text(dl,min+new Vector2(S(12),(height-ImGui.GetFontSize())/2),shown,ImGui.GetFontSize(),ink);
        }
        if(number.Length>0&&size.X>S(270)&&theme!=ShelfTheme.Persona5)dl.AddText(min+new Vector2(size.X-S(25),S(11)),ImGui.GetColorU32(p.Muted),number);
    }
    public static Vector4 StateColor(ShelfTheme theme,Runtime.SkillAvailability state)=>state switch
    {
        Runtime.SkillAvailability.Ready=>theme==ShelfTheme.Needy?C(0,.49f,.43f):theme==ShelfTheme.Persona5?C(.56f,.95f,.47f):C(0,.96f,.88f),
        Runtime.SkillAvailability.Cooldown=>theme==ShelfTheme.Needy?C(.88f,.08f,.45f):C(1,.67f,.24f),
        Runtime.SkillAvailability.Conditions=>theme==ShelfTheme.Needy?C(.66f,.25f,.05f):C(1,.47f,.50f),_=>Palette(theme).Muted,
    };
    private static uint ToUint(this Vector4 c)=>ImGui.GetColorU32(c);
}
