using System;
namespace MacroShelfA.Windows;
internal readonly record struct WorkbenchLayout(float Width,float Height,float ArtWidth,float HeaderHeight,float ToolbarHeight,float FooterHeight,float DockHeight,float TreeWidth,float SideWidth)
{
    public float ContentLeft=>ArtWidth+(Width>=1180?28:16);
    public float ContentWidth=>MathF.Max(1,Width-ContentLeft-(Width>=1180?28:16));
    public float BodyTop=>HeaderHeight+ToolbarHeight+9;
    public float FooterTop=>Height-DockHeight-FooterHeight-12;
    public float BodyHeight=>MathF.Max(100,FooterTop-BodyTop-7);
    public float EditorWidth=>MathF.Max(1,ContentWidth-TreeWidth-SideWidth-(SideWidth>0?24:12));
    public bool HasSide=>SideWidth>0;
    public static WorkbenchLayout Calculate(float width,float height,ShelfTheme theme,bool decoration,bool dock,bool advanced=true,float dockMinimum=0,float footerMinimum=0)
    {
        width=float.IsFinite(width)?MathF.Max(360,width):720;height=float.IsFinite(height)?MathF.Max(300,height):500;
        var wide=width>=1180&&height>=720;var spacious=width>=1400&&height>=780;
        var art=theme==ShelfTheme.Persona3&&decoration&&wide?Math.Clamp(width*.145f,145,230):0;
        var content=width-art-(width>=1180?56:32);var tree=Math.Clamp(content*(advanced?(theme==ShelfTheme.Persona3?.19f:.195f):.25f),advanced?172:210,290);
        var side=advanced&&wide&&content>=1000?Math.Clamp(content*.29f,278,410):0;
        // Compact title and navigation occupy separate rows; a 45px wordmark
        // must not overlap the tabs at the 720px minimum window size.
        var header=wide?(theme==ShelfTheme.Persona3?143:105):100;
        return new(width,height,art,header,wide?56:36,MathF.Max(58,footerMinimum),dock&&wide?MathF.Max(spacious?124:104,dockMinimum):0,tree,side);
    }
}
