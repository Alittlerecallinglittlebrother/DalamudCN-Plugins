## Current 0.9.3.0 — native alignment and beginner usability

Real game screenshots supersede prior offline approval: syntax text and native selection use different font metrics, fixed dock height crops cards, and the overall UI overwhelms a first-time user. Use the installed ImGui 1.88 input-child metrics and native caret position; reserve measured dock/footer/action heights. Default to a two-pane choose/edit/run flow, dismissible guidance and an empty-state example/import path. Move metadata and A/B/D options behind More or advanced mode without removing functionality. Preserve macro data, runtime, original assets and theme motion. Verify 33 eighth-line cases, independent font/UI scale, native scrollbar drag and novice workflows using production-linked offline UI. Do not equate those renders with game validation. No automatic local installation or online release.

## Previous 0.9.2.0 — reconstruction, not palette replacement

User rejected 0.9.1.0 as unlike the generated themes. Rebuild native composition, lettering, independent information cards, code-editor presentation and interactions against all three references. Keep Makoto a subordinate left decoration. Own and restore every ImGui color, including auxiliary window chrome. Add bounded hover/reveal/background motion with a persisted reduced-motion option. Preserve IDs, content, executor, A/B/D routes and original portrait/launcher bytes. Deliver production-code native renders and motion, distinguish them from game captures, and do not claim pixel-perfect or in-game validation without evidence. Local candidate only; no live installation or online publication.

## Previous 0.9.1.0 — three native themes

Persona 3 Reload, Needy Streamer Overload-inspired pastel, and Persona 5-inspired red/black/white are implemented as native ImGui skins and responsive workbench components, with classic fallback. P3's supplied portrait is peripheral only: a clipped left rail capped below 18% of available width, automatically removed at small sizes. All skins share data, execution, integrated quickbar and A/B/D callbacks. Theme changes are additive local appearance preferences, not a macro-data migration. No game installation, live configuration modification or online release has been performed. See THEMES.md for current implementation and verification.

## Previous 0.9.0.0 local extension — A/B/D

User requested implementation locally only, without online publication. A imports native macros as independent strict-UTF8 copies; opaque SeString payloads are explicitly blocked, not flattened. B adds an optional normal PvE Action display binding and icons to the existing common bar; read-only bounded framework snapshots show current-target state, not a whole-macro success promise. D creates a one-line exact-ID native entrance macro with durable raw-byte backup and restore; the user drags it to a game hotbar manually. No direct hotbar edits, automatic casts or action queue were approved. All entry points route to the same existing executor. Preserve original image/icon bytes and previous timing/gearset behavior. No game/config installation or game-native verification is claimed by offline fixtures.
# Macro Shelf-A

<!-- impeccable:product-schema 1 -->

## Platform
Windows native DalamudCN API 15 plugin using C# / ImGui. Not a website or mobile app.

## Users and task
The user manages many FF14 standalone macros and named sequential child-macro groups. The approved change addresses finding macros and editing long macros without global settings cluttering the library.

## Constraints
Keep identifiers, saved text and order. The ABD extension migrates configuration to v9 and exchange to v5, with old formats1–4 supported. Default line interval remains zero, explicit waits remain, one command per framework update. No timeline or audio synchronization features. Existing countdown, floating launcher, long-macro setting, CRUD and exchange remain accessible.

## Approved request
A library as main UI and B tree editor as editing UI. Native local build only, no GitHub release or automatic installation. Both plugin manifest introduction fields use the exact user text: 当我受够了FF14那糟糕的宏指令

## Evidence
design/approved-library.png and design/approved-editor.png are approved generated concepts; their sample names/counts are not user data. generation-prompts.json records their origin. Native test-host captures will be actual UI renders with synthetic test fixtures, not in-game verification.

## Historical 0.8 extension (icon superseded by 0.8.1)
User requests an icon based on their second supplied image and an independent common-macro shelf for explicit one-click execution with the main page closed. Preserve the A+B design system and existing executor. The quick bar reuses Pinned for roots and children, adds only local display preferences, and remains visible independently of the main page when logged in. User supplied image 1 shows the old launcher, not the requested character. Icon prompt and generated master are recorded in design/icon/provenance.json. Local-only scope continues; no installation or GitHub publication requested.

## Current 0.8.1 correction
User explicitly rejects regenerated artwork. Use the supplied blue-haired original IMG_8518(20260822-120523).PNG, preserve its original bytes in the source and launcher resource; only mechanically aspect-fit the catalog icon to the required512-square with transparent padding. No image generation, crop or repaint. Repair picker auto-size feedback and host double scaling, move exact hint 左键运行，右键编辑或删除 to the title row, remove idle footer space. Preserve underlying macros and execution behavior. User in-game evidence supersedes prior offline visual approval.


## 0.8.2.0 local follow-up — job-change consistency candidate

User confirmed gearset6=Astrologian: plugin actions work after manually switching, and after an explicit 3-second gearset wait; the original 0.2-second macro fails. Preserve zero default interval and previous approved UI/original image. Add a bounded read-only multi-source job/gearset consistency guard before the first following action, not a fixed global delay or action retry. This is a candidate requiring in-game 0.2-second validation: matching job/gearset observations do not prove native action-name-cache readiness. Full scope and rejected strategies are in verification/job-change-analysis.md; instructions/log markers are in README.md. No online publication or user config mutation.


## 0.8.3.0 current local investigation — native dispatch boundary

Latest user evidence: all emotes/actions after a gearset switch fail consistently while chat continues; native macros work. This supersedes treating the problem only as a first-action readiness delay. The managed guard does not cover emotes. Direct ExecuteCommandInner bypasses normal per-command error-state preparation and chat context cleanup; use ProcessChatBoxEntry without manually mutating shell state or adding waits. This discrepancy is established, but its sufficiency to explain all execution failure remains unproven. Production-linked offline ABI tests exercise the real binding against a fake unmanaged callback, not actual game code. Keep public0.8.2 unchanged, retain user text/data/UI/assets, add actual-loaded-version diagnostic, deliver only local0.8.3 candidate.


