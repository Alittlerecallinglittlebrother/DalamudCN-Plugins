# Typography assets

Bundled PNGs are already ready for compilation. Regeneration is optional: Windows with Impact, Microsoft YaHei and Courier New, Chrome and Node with Playwright available on NODE_PATH (or locally installed).

Run `node render-wordmark.cjs` and `node render-lettering.cjs`. The scripts save to ../../MacroShelfA/Resources, using transparent browser-rendered HTML text. They do not alter the supplied portrait or launcher image. Lettering JSON dimensions must match the atlas. No browser / Node runtime is required by the plugin.
