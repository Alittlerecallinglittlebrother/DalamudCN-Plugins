using System.Runtime.InteropServices;
using System.Text;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;
using FFXIVClientStructs.FFXIV.Client.UI.Shell;
using MacroShelfA.Runtime;

// Real production buffer/adapter/state helpers. Generated native bindings are redirected
// only to offline unmanaged callbacks; no host instance, game process, lookup or hook runs.
internal static unsafe class NativeMacroExecutionAbiTests
{
    private static int ctorCalls, dtorCalls, duplicateDtors, executeCalls, disableCtorAfter;
    private static nint observedShell, observedMacro;
    private static string observedName = "";
    private static string[] observedLines = [];
    private static readonly List<nint> constructedValues = [];
    private static readonly List<nint> destroyedValues = [];
    private static readonly List<byte[]> constructedBytes = [];
    private static readonly Dictionary<nint, nint> buffers = [];

    [UnmanagedCallersOnly]
    private static Utf8String* Construct(Utf8String* value, byte* source, nuint length)
    {
        // These bounded fixtures cannot throw across the unmanaged ABI. To exercise
        // partial construction failure, invalidate the NEXT generated binding call.
        ctorCalls++;
        var bytes = new ReadOnlySpan<byte>(source, (int)length).ToArray();
        var allocation = (byte*)NativeMemory.AllocZeroed(length + 1);
        bytes.CopyTo(new Span<byte>(allocation, bytes.Length));
        value->StringPtr = allocation;
        value->BufUsed = value->BufSize = (long)length + 1;
        value->StringLength = (long)length;
        constructedValues.Add((nint)value);
        constructedBytes.Add(bytes);
        buffers[(nint)value] = (nint)allocation;
        if (disableCtorAfter > 0 && ctorCalls == disableCtorAfter)
            Utf8String.Addresses.Ctor_FromSequence.Value = 0;
        return value;
    }

    [UnmanagedCallersOnly]
    private static void Destruct(Utf8String* value)
    {
        dtorCalls++;
        destroyedValues.Add((nint)value);
        if (buffers.Remove((nint)value, out var allocation)) NativeMemory.Free((void*)allocation);
        else duplicateDtors++;
        value->StringPtr = (byte*)null;
        value->BufUsed = value->BufSize = value->StringLength = 0;
    }

    [UnmanagedCallersOnly]
    private static void Execute(RaptureShellModule* shell, RaptureMacroModule.Macro* macro)
    {
        executeCalls++;
        observedShell = (nint)shell;
        observedMacro = (nint)macro;
        observedName = Encoding.UTF8.GetString(macro->Name.AsSpan());
        observedLines = new string[15];
        for (var index = 0; index < observedLines.Length; index++)
            observedLines[index] = Encoding.UTF8.GetString(macro->Lines[index].AsSpan());
    }

    private sealed class Bindings : IDisposable
    {
        private readonly nint ctor = Utf8String.Addresses.Ctor_FromSequence.Value;
        private readonly nint dtor = Utf8String.Addresses.Dtor.Value;
        private readonly nint execute = RaptureShellModule.Addresses.ExecuteMacro.Value;
        public Bindings()
        {
            ctorCalls = dtorCalls = duplicateDtors = executeCalls = disableCtorAfter = 0;
            observedShell = observedMacro = 0;
            observedName = ""; observedLines = [];
            constructedValues.Clear(); destroyedValues.Clear(); constructedBytes.Clear();
            buffers.Clear();
            Utf8String.Addresses.Ctor_FromSequence.Value =
                (nint)(delegate* unmanaged<Utf8String*, byte*, nuint, Utf8String*>)&Construct;
            Utf8String.Addresses.Dtor.Value = (nint)(delegate* unmanaged<Utf8String*, void>)&Destruct;
            RaptureShellModule.Addresses.ExecuteMacro.Value =
                (nint)(delegate* unmanaged<RaptureShellModule*, RaptureMacroModule.Macro*, void>)&Execute;
        }
        public void Dispose()
        {
            Utf8String.Addresses.Ctor_FromSequence.Value = ctor;
            Utf8String.Addresses.Dtor.Value = dtor;
            RaptureShellModule.Addresses.ExecuteMacro.Value = execute;
            // Cleanup owned fixture allocations even if an assertion exposed production
            // cleanup failure. Assertions are made BEFORE this final fixture safety net.
            foreach (var allocation in buffers.Values) NativeMemory.Free((void*)allocation);
            buffers.Clear();
        }
    }

    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "native execution ABI assertion failed") => check(value, message);
        void Test(string name, Action body) => test("native execution ABI: " + name, body);

        Test("scratch macro constructs all 16 strings and preserves original UTF8 waits", () =>
        {
            using var bindings = new Bindings();
            string[] lines = ["/gs change 4", "/sh 星辰 · 原文 <wait.2>", "/divinearm<wait.4>", "  /easternstretch <wait.0.25>  "];
            using var buffer = new NativeMacroBuffer("MSA-offline-test", lines);
            Check(buffer.Pointer != null && ctorCalls == 16 && dtorCalls == 0);
            Check(Encoding.UTF8.GetString(buffer.Pointer->Name.AsSpan()) == "MSA-offline-test");
            Check(buffer.Pointer->IconId == 0 && buffer.Pointer->MacroIconRowId == 0, "scratch storage must be zero initialized");
            for (var index = 0; index < 15; index++)
            {
                var expected = index < lines.Length ? lines[index] : "";
                Check(buffer.Pointer->Lines[index].AsSpan().SequenceEqual(Encoding.UTF8.GetBytes(expected)), "line content or padding changed");
                Check(constructedBytes[index + 1].SequenceEqual(Encoding.UTF8.GetBytes(expected)), "ctor must receive exact byte length without terminator");
            }
            Check(constructedValues.Distinct().Count() == 16, "name and 15 lines need independent initialized Utf8Strings");
            buffer.Dispose();
            Check(buffer.Pointer == null && dtorCalls == 16 && duplicateDtors == 0 && buffers.Count == 0);
            Check(destroyedValues.SequenceEqual(constructedValues.AsEnumerable().Reverse()), "destroy lines in reverse initialization order then name");
            buffer.Dispose();
            Check(dtorCalls == 16, "disposing the scratch macro twice must not double-destroy");
        });

        foreach (var constructedBeforeFailure in new[] { 0, 1, 2, 8, 15 })
            Test($"partial constructor failure cleans exactly {constructedBeforeFailure} initialized strings", () =>
            {
                using var bindings = new Bindings();
                disableCtorAfter = constructedBeforeFailure;
                if (constructedBeforeFailure == 0) Utf8String.Addresses.Ctor_FromSequence.Value = 0;
                Exception? failure = null;
                NativeMacroBuffer? unexpected = null;
                try { unexpected = new NativeMacroBuffer("MSA-partial", ["/wave"]); }
                catch (Exception exception) { failure = exception; }
                finally { unexpected?.Dispose(); }
                Check(failure != null, "next unresolved generated ctor binding must report failure");
                Check(ctorCalls == constructedBeforeFailure && dtorCalls == constructedBeforeFailure && buffers.Count == 0,
                    "all successfully initialized strings must be destroyed after a later ctor fails");
                Check(duplicateDtors == 0 && destroyedValues.SequenceEqual(constructedValues.AsEnumerable().Reverse()));
            });

        Test("invalid scratch arguments fail before invoking native constructors", () =>
        {
            using var bindings = new Bindings();
            foreach (var args in new[]
            {
                (Name: "", Lines: new[] { "/wave" }),
                (Name: new string('x', 21), Lines: new[] { "/wave" }),
                (Name: "MSA", Lines: Array.Empty<string>()),
                (Name: "MSA", Lines: Enumerable.Repeat("/wave", 16).ToArray()),
            })
            {
                Exception? failure = null;
                try { using var buffer = new NativeMacroBuffer(args.Name, args.Lines); }
                catch (Exception exception) { failure = exception; }
                Check(failure is ArgumentException && ctorCalls == 0 && dtorCalls == 0);
            }
        });

        Test("ExecuteMacro receives full scratch object once in shell-then-macro ABI order", () =>
        {
            using var bindings = new Bindings();
            using var buffer = new NativeMacroBuffer("MSA-dispatch", ["/gs change 4", "/divinearm<wait.4>", "/wait 2"]);
            var shell = (RaptureShellModule*)NativeMemory.AllocZeroed((nuint)sizeof(RaptureShellModule));
            try
            {
                NativeMacroExecutionHost.DispatchToGame(shell, buffer.Pointer);
                Check(executeCalls == 1 && observedShell == (nint)shell && observedMacro == (nint)buffer.Pointer);
                Check(observedName == "MSA-dispatch" && observedLines.Length == 15);
                Check(observedLines.Take(3).SequenceEqual(new[] { "/gs change 4", "/divinearm<wait.4>", "/wait 2" }),
                    "whole original segment must be passed without wait stripping or per-line dispatch");
                Check(observedLines.Skip(3).All(string.IsNullOrEmpty));
                buffer.Dispose();
                Check(dtorCalls == 16 && buffers.Count == 0 && executeCalls == 1);
            }
            finally { NativeMemory.Free(shell); }
        });

        Test("missing shell or macro fails before native dispatch", () =>
        {
            using var bindings = new Bindings();
            using var buffer = new NativeMacroBuffer("MSA-null", ["/wave"]);
            var shell = (RaptureShellModule*)NativeMemory.AllocZeroed((nuint)sizeof(RaptureShellModule));
            try
            {
                for (var scenario = 0; scenario < 3; scenario++)
                {
                    Exception? failure = null;
                    try { NativeMacroExecutionHost.DispatchToGame(scenario == 1 ? shell : null, scenario == 0 ? buffer.Pointer : null); }
                    catch (Exception exception) { failure = exception; }
                    Check(failure is InvalidOperationException && executeCalls == 0);
                }
            }
            finally { NativeMemory.Free(shell); }
        });

        Test("unresolved ExecuteMacro binding fails without fallback", () =>
        {
            using var bindings = new Bindings();
            using var buffer = new NativeMacroBuffer("MSA-unresolved", ["/wave<wait.3>"]);
            var shell = (RaptureShellModule*)NativeMemory.AllocZeroed((nuint)sizeof(RaptureShellModule));
            try
            {
                RaptureShellModule.Addresses.ExecuteMacro.Value = 0;
                Exception? failure = null;
                try { NativeMacroExecutionHost.DispatchToGame(shell, buffer.Pointer); }
                catch (Exception exception) { failure = exception; }
                Check(failure != null && executeCalls == 0);
            }
            finally { NativeMemory.Free(shell); }
        });

        Test("LinesMatch validates all 15 copied UTF8 lines including empty padding without mutation", () =>
        {
            using var bindings = new Bindings();
            string[] lines = ["/gs change 4", "/sh 原文 <wait.2>", "/divinearm<wait.4>"];
            using var buffer = new NativeMacroBuffer("MSA-fingerprint", lines);
            var shell = (RaptureShellModule*)NativeMemory.AllocZeroed((nuint)sizeof(RaptureShellModule));
            var expected = Enumerable.Range(0, 15).Select(index => Encoding.UTF8.GetBytes(index < lines.Length ? lines[index] : "")).ToArray();
            try
            {
                Check(!NativeMacroExecutionHost.LinesMatch(shell, expected), "uninitialized native string slots must not match");
                // Shallow fixture aliases only; buffer owns and destroys the allocations.
                // This does NOT pretend to test the game's deep copy implementation.
                for (var index = 0; index < 15; index++) shell->MacroLines[index] = buffer.Pointer->Lines[index];
                var before = new ReadOnlySpan<byte>(shell, sizeof(RaptureShellModule)).ToArray();
                Check(NativeMacroExecutionHost.LinesMatch(shell, expected));
                Check(new ReadOnlySpan<byte>(shell, sizeof(RaptureShellModule)).SequenceEqual(before), "fingerprint check must never write native storage");
                var originalByte = shell->MacroLines[1].StringPtr.Value[0];
                shell->MacroLines[1].StringPtr.Value[0] = (byte)'?';
                Check(!NativeMacroExecutionHost.LinesMatch(shell, expected), "same Name but changed command bytes must invalidate ownership");
                shell->MacroLines[1].StringPtr.Value[0] = originalByte;
                Check(NativeMacroExecutionHost.LinesMatch(shell, expected));
                expected[14] = Encoding.UTF8.GetBytes("/wave");
                Check(!NativeMacroExecutionHost.LinesMatch(shell, expected), "all 15 entries, not just nonempty prefix, participate in ownership");
                expected[14] = [];
                Check(NativeMacroExecutionHost.LinesMatch(shell, expected));
                Check(!NativeMacroExecutionHost.LinesMatch(null, expected));
                Check(!NativeMacroExecutionHost.LinesMatch(shell, []));
                Check(!NativeMacroExecutionHost.LinesMatch(shell, expected.Take(14).ToArray()));
                Check(!NativeMacroExecutionHost.LinesMatch(shell, expected.Concat(new[] { Array.Empty<byte>() }).ToArray()));
                var originalLine = shell->MacroLines[0];
                shell->MacroLines[0].StringPtr = (byte*)null;
                Check(!NativeMacroExecutionHost.LinesMatch(shell, expected));
                shell->MacroLines[0] = originalLine;
                shell->MacroLines[0].BufUsed = 0;
                Check(!NativeMacroExecutionHost.LinesMatch(shell, expected));
                shell->MacroLines[0] = originalLine;
                shell->MacroLines[0].BufUsed = NativeMacroPlan.MaximumLineUtf8Bytes + 2;
                Check(!NativeMacroExecutionHost.LinesMatch(shell, expected));
                shell->MacroLines[0] = originalLine;
                shell->MacroLines[0].BufSize = originalLine.BufUsed - 1;
                Check(!NativeMacroExecutionHost.LinesMatch(shell, expected));
                shell->MacroLines[0] = originalLine;
                Check(NativeMacroExecutionHost.LinesMatch(shell, expected));
            }
            finally { NativeMemory.Free(shell); }
        });

        Test("ReadState uses audited offsets and does not modify shell bytes", () =>
        {
            var shell = (RaptureShellModule*)NativeMemory.AllocZeroed((nuint)sizeof(RaptureShellModule));
            try
            {
                var bytes = (byte*)shell;
                shell->MacroCurrentLine = 15; shell->MacroLocked = true;
                bytes[0x2B5] = 4; bytes[0x2B6] = 7; *(float*)(bytes + 0x2B8) = 0.12f;
                shell->WaitTimeMs = 4000; shell->WaitStartTime.CpuMilliSeconds = 123000;
                var before = new ReadOnlySpan<byte>(shell, sizeof(RaptureShellModule)).ToArray();
                var state = NativeMacroExecutionHost.ReadState(shell);
                Check(state.Line == 15 && state.Locked && state.DeferredIndex == 4 && state.DeferredCount == 7);
                Check(state.DeferredCooldown == 0.12f && state.WaitMs == 4000 && state.WaitStartedMs == 123000);
                Check(state.Valid && !state.Idle, "last line dispatched is not tail-wait completion");
                Check(new ReadOnlySpan<byte>(shell, sizeof(RaptureShellModule)).SequenceEqual(before), "state observation must be read-only");
                Check(Math.Abs(state.RemainingWait(124500) - 2.5) < 0.000001);
                Check(state.RemainingWait(122000) == 4 && state.RemainingWait(128000) == 0, "remaining wait must clamp clock skew and expiry");
            }
            finally { NativeMemory.Free(shell); }
            Exception? failure = null;
            try { NativeMacroExecutionHost.ReadState(null); } catch (Exception exception) { failure = exception; }
            Check(failure is ArgumentNullException);
        });

        Test("completion waits for native end and empty queue but preserves residual cooldown", () =>
        {
            var ended = new NativeMacroShellState(-1, false, 4, 4, 0.15f, 4000, 5000);
            Check(ended.Valid && ended.Idle && ended.RemainingWait(5000) == 0,
                "ended + queue empty must not add a fixed cooldown delay; native ExecuteMacro retains it");
            Check(!(ended with { Line = 15 }).Idle, "line 15 still waits for native tail-wait completion");
            Check(!(ended with { Line = 0 }).Idle && !(ended with { Locked = true }).Idle);
            Check(!(ended with { DeferredIndex = 3 }).Idle, "native end with queued commands is not complete");
            Check((ended with { DeferredCooldown = -0.01f, WaitMs = uint.MaxValue }).Idle,
                "stale WaitMs must not block natural completion after native end");
        });

        Test("invalid line, queue and nonfinite cooldown state fail closed", () =>
        {
            var valid = new NativeMacroShellState(-1, false, 0, 0, 0, 0, 0);
            foreach (var invalid in new[]
            {
                valid with { Line = -2 }, valid with { Line = 16 },
                valid with { DeferredIndex = 1 }, valid with { DeferredCount = 16 },
                valid with { DeferredIndex = 255, DeferredCount = 255 },
                valid with { DeferredCooldown = float.NaN }, valid with { DeferredCooldown = float.PositiveInfinity },
                valid with { DeferredCooldown = float.NegativeInfinity },
            }) Check(!invalid.Valid && !invalid.Idle, "corrupt audited state must never qualify as complete/idle");
        });

        Test("exact audit hash, installed struct layout and both relocated binding RVAs are required", () =>
        {
            Check(NativeMacroExecutionHost.AuditedImageSha256 == "7BA28760BC53CBBBF66B63105FEA6C1BFE09CB6B1C6353FC8FB0FF03CC1A30F4");
            Check(NativeMacroExecutionHost.ImageIdentityMatches("ffxiv_dx11.exe", NativeMacroExecutionHost.AuditedImageSha256));
            Check(!NativeMacroExecutionHost.ImageIdentityMatches("MacroShelfA.Tests.exe", NativeMacroExecutionHost.AuditedImageSha256),
                "matching hash alone must not authorize a non-game image");
            Check(!NativeMacroExecutionHost.ImageIdentityMatches("ffxiv_dx11.exe", new string('0', 64)),
                "matching image name alone must not authorize a different client");
            Check(!NativeMacroExecutionHost.ImageIdentityMatches("ffxiv_dx11.exe", ""));
            Check(!NativeMacroExecutionHost.ImageIdentityMatches("", NativeMacroExecutionHost.AuditedImageSha256));
            Check(NativeMacroExecutionHost.BindingLayoutMatches(), "installed generated structures must match audited ABI");
            Check(sizeof(RaptureMacroModule.Macro) == 0x688 && sizeof(Utf8String) == 0x68);
            Check(Marshal.OffsetOf<RaptureMacroModule.Macro>(nameof(RaptureMacroModule.Macro.Name)) == 8);
            const long arbitraryRelocation = 0x180000000;
            var imageBase = (nint)arbitraryRelocation;
            Check(NativeMacroExecutionHost.AuditedAddressesMatch(imageBase, imageBase + 0x912150, imageBase + 0x912320));
            Check(!NativeMacroExecutionHost.AuditedAddressesMatch(0, (nint)0x912150, (nint)0x912320));
            Check(!NativeMacroExecutionHost.AuditedAddressesMatch(imageBase, imageBase + 0x912151, imageBase + 0x912320));
            Check(!NativeMacroExecutionHost.AuditedAddressesMatch(imageBase, imageBase + 0x912150, imageBase + 0x912321));
            Check(!NativeMacroExecutionHost.AuditedAddressesMatch(imageBase, imageBase + 0x912320, imageBase + 0x912150));
            Check(!NativeMacroExecutionHost.AuditedAddressesMatch(imageBase, 0, 0));
        });

        Test("CancelMacro observer preserves audited native byte return ABI rather than void binding", () =>
        {
            const System.Reflection.BindingFlags flags = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic;
            var field = typeof(NativeMacroExecutionHost).GetField("cancelHook", flags)!;
            var hookDelegate = field.FieldType.GetGenericArguments()[0];
            var invoke = hookDelegate.GetMethod("Invoke")!;
            Check(invoke.ReturnType == typeof(byte), "matched client caller tests AL; a void cancel detour would corrupt its return contract");
            var parameters = invoke.GetParameters();
            Check(parameters.Length == 1 && parameters[0].ParameterType == typeof(RaptureShellModule*));
            Check(typeof(NativeMacroExecutionHost).GetMethod("OnCancelMacro", flags)!.ReturnType == typeof(byte),
                "observer method must return the original native byte, not discard it");
            // Shape regression test only: real hook installation, Original trampoline,
            // game caller return preservation and takeover remain runtime acceptance.
        });

        Test("fixture restores generated addresses after managed failure", () =>
        {
            var oldCtor = Utf8String.Addresses.Ctor_FromSequence.Value;
            var oldDtor = Utf8String.Addresses.Dtor.Value;
            var oldExecute = RaptureShellModule.Addresses.ExecuteMacro.Value;
            var marker = new InvalidOperationException("offline ABI fixture marker");
            Exception? failure = null;
            try { using var bindings = new Bindings(); throw marker; }
            catch (Exception exception) { failure = exception; }
            Check(ReferenceEquals(marker, failure));
            Check(Utf8String.Addresses.Ctor_FromSequence.Value == oldCtor && Utf8String.Addresses.Dtor.Value == oldDtor &&
                RaptureShellModule.Addresses.ExecuteMacro.Value == oldExecute);
        });
    }
}




