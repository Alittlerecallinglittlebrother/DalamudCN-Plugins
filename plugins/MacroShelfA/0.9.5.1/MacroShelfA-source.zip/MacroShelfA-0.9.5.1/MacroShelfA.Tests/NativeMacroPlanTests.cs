using MacroShelfA;
using MacroShelfA.Runtime;

internal static class NativeMacroPlanTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "native-macro plan assertion failed") => check(value, message);
        void Test(string name, Action body) => test("native-macro-plan: " + name, body);
        MacroEntry Leaf(string commands = "/echo test", string name = "A") => new() { Name = name, Commands = commands };
        MacroEntry Group(params MacroEntry[] children) => new() { Name = "总宏", IsGroup = true, Children = [.. children] };
        string Rows(int count) => string.Join('\n', Enumerable.Range(1, count).Select(i => $"/echo {i}"));
        NativeMacroPlan Create(MacroEntry macro, bool allowLong = false)
        {
            Check(NativeMacroPlan.TryCreate(macro, allowLong, out var plan, out var error), error);
            Check(plan != null);
            return plan!;
        }
        void Reject(MacroEntry macro, bool allowLong = false, string? contains = null)
        {
            Check(!NativeMacroPlan.TryCreate(macro, allowLong, out var plan, out var error));
            Check(plan == null && error.Length > 0, "failed preflight must not expose a partial plan");
            if (contains != null) Check(error.Contains(contains, StringComparison.Ordinal), error);
        }

        Test("15 command lines accepted and 16 refused without long mode", () =>
        {
            var plan = Create(Leaf(Rows(15)));
            Check(plan.TotalLines == 15 && plan.TotalChildren == 1 && plan.Segments.Count == 1);
            Check(plan.Segments[0].FirstLineNumber == 1 && plan.Segments[0].ChildIndex == 1);
            Reject(Leaf(Rows(16)), contains: "16");
        });
        Test("long mode plans 15 plus 1 and preserves original positions", () =>
        {
            var plan = Create(Leaf(Rows(16)), true);
            Check(plan.TotalLines == 16 && plan.Segments.Count == 2);
            Check(plan.Segments[0].Lines.Length == 15 && plan.Segments[1].Lines.SequenceEqual(["/echo 16"]));
            Check(plan.Segments[1].ChildIndex == 1 && plan.Segments[1].FirstLineNumber == 16);
            var larger = Create(Leaf(Rows(31)), true);
            Check(larger.Segments.Select(s => s.Lines.Length).SequenceEqual([15, 15, 1]));
            Check(larger.Segments.Select(s => s.FirstLineNumber).SequenceEqual([1, 16, 31]));
        });
        Test("children keep order and independent segment line numbering", () =>
        {
            var plan = Create(Group(Leaf(Rows(16), "A"), Leaf("/echo B", "B")), true);
            Check(plan.Name == "总宏" && plan.TotalChildren == 2 && plan.TotalLines == 17);
            Check(plan.Segments.Select(s => s.ChildName).SequenceEqual(["A", "A", "B"]));
            Check(plan.Segments.Select(s => s.ChildIndex).SequenceEqual([1, 1, 2]));
            Check(plan.Segments.Select(s => s.FirstLineNumber).SequenceEqual([1, 16, 1]));
            Check(Create(Group(Leaf(Rows(15)), Leaf(Rows(15)))).TotalLines == 30);
        });
        Test("wait syntax decimals and command whitespace pass through unchanged", () =>
        {
            string[] original = ["/dance  motion <wait.0.25>  ", "/wait 0.1", "/wait 000.000", "/echo x <wait.999999>", "/echo x <wait.1> <wait.2>"];
            var plan = Create(Leaf(string.Join("\r\n", original)));
            Check(plan.Segments[0].Lines.SequenceEqual(original), "native plan must never reinterpret wait syntax");
        });
        Test("blanks and comments omitted to avoid native early termination with source positions retained", () =>
        {
            var macro = Leaf("\r\n# leading\r\n/echo A\r\n \t\r\n  # comment\r\n/echo B  \r\n\r\n \t\r\n# trailing");
            var raw = macro.Commands;
            var plan = Create(macro);
            Check(plan.TotalLines == 2);
            Check(plan.Segments[0].Lines.SequenceEqual(["/echo A", "/echo B  "]));
            Check(plan.Segments[0].FirstLineNumber == 3);
            Check(plan.Segments[0].SourceLineNumbers.SequenceEqual([3, 6]));
            Check(macro.Commands == raw, "preflight must not edit stored source");
        });
        Test("ignored editor lines do not consume native slots", () =>
        {
            Check(Create(Leaf(string.Join('\n', Enumerable.Repeat("", 15)) + "\n/echo A")).TotalLines == 1);
            var comments = Create(Leaf(string.Join('\n', Enumerable.Repeat("# comment", 15)) + "\n/echo A"));
            Check(comments.TotalLines == 1 && comments.Segments[0].FirstLineNumber == 16);
            Check(Create(Leaf(Rows(15) + "\n\n# end\n  ")).TotalLines == 15);
        });
        Test("segment boundary maps to true editor line after omitted lines", () =>
        {
            var commands = "# heading\n" + string.Join('\n', Enumerable.Range(1, 16).Select(i => $"/echo {i}\n# note {i}"));
            var plan = Create(Leaf(commands), true);
            Check(plan.TotalLines == 16 && plan.Segments.Count == 2);
            Check(plan.Segments[0].FirstLineNumber == 2 && plan.Segments[1].FirstLineNumber == 32);
            Check(plan.Segments[0].SourceLineNumbers.SequenceEqual(Enumerable.Range(1, 15).Select(i => i * 2)));
            Check(plan.Segments[1].SourceLineNumbers.SequenceEqual([32]));
        });
        Test("no implicit bare CR normalization or trimming", () =>
        {
            Check(Create(Leaf("/echo A\r/echo B")).Segments[0].Lines.SequenceEqual(["/echo A\r/echo B"]));
            Reject(Leaf(" /echo A"), contains: "单个 /");
            Reject(Leaf("\t/echo A"), contains: "单个 /");
            Reject(Leaf("//echo A"), contains: "单个 /");
            Reject(Leaf("not a command"), contains: "单个 /");
        });
        Test("empty child empty group nested group and missing child rejected atomically", () =>
        {
            Reject(Group());
            Reject(Leaf(""));
            Reject(Leaf("# comments\n  \t\n"));
            Reject(Group(Leaf(), Leaf("# empty", "B")), contains: "B");
            Reject(Group(Leaf(), Group(Leaf())));
            Reject(Group(Leaf(), null!));
            Reject(new MacroEntry { IsGroup = true, Children = null! });
            Reject(null!);
        });
        Test("child and command length limits checked before exposing any plan", () =>
        {
            Check(Create(Group(Enumerable.Range(0, Configuration.MaxChildren).Select(_ => Leaf()).ToArray())).TotalChildren == Configuration.MaxChildren);
            Reject(Group(Enumerable.Range(0, Configuration.MaxChildren + 1).Select(_ => Leaf()).ToArray()));
            Reject(Leaf(new string('x', Configuration.MaxCommandLength + 1)), true, "字符");
        });
        Test("UTF8 boundary accepts 1023 bytes and rejects 1024", () =>
        {
            var ascii = "/echo " + new string('a', 1017);
            Check(Create(Leaf(ascii)).Segments[0].Lines[0] == ascii);
            Reject(Leaf(ascii + "a"), contains: "1023");
            var cjk = "/echo " + new string('中', 339);
            Check(Create(Leaf(cjk)).Segments[0].Lines[0] == cjk);
            Reject(Leaf(cjk + "a"), contains: "1023");
            Check(Create(Leaf("/echo 中文😀")).TotalLines == 1);
            Reject(Leaf("/echo " + string.Concat(Enumerable.Repeat("😀", 255))), contains: "1023");
        });
        Test("NUL and malformed UTF16 refused even in comments or trailing slots", () =>
        {
            foreach (var invalid in new[] { "/echo a\0b", "/echo \uD800", "/echo \uDC00", "# comment\0\n/echo ok", "/echo ok\n# \uD800" })
                Reject(Leaf(invalid), contains: "NUL");
            Reject(Leaf("/echo ok", "bad\0name"));
            Reject(Leaf("/echo ok", "bad\uD800name"));
            var group = Group(Leaf()); group.Name = "bad\uDC00name"; Reject(group);
        });
        Test("all local state aliases allowed only in a single segment", () =>
        {
            foreach (var command in new[] { "/mlock", "/MACROLOCK", "/macroerror off", "/MeRrOr off", "/mlock<wait.1>" })
            {
                Check(Create(Leaf(command + "\n/echo ok")).Segments.Count == 1);
                Reject(Leaf(command + "\n" + Rows(15)), true, "跨段");
                Reject(Group(Leaf(command, "state"), Leaf()), contains: "跨段");
                Reject(Group(Leaf(), Leaf(command, "state")), contains: "跨段");
            }
            Check(Create(Leaf("/echo /mlock\n" + Rows(15)), true).Segments.Count == 2);
            Check(Create(Leaf("/mlockextra\n" + Rows(15)), true).Segments.Count == 2);
            Check(Create(Leaf("# /mlock\n" + Rows(15)), true).Segments.Count == 1);
        });
        Test("plan is a source snapshot unaffected by edits reorder or removal", () =>
        {
            var a = Leaf("/echo A <wait.0.25>", "A");
            var b = Leaf("/echo B", "B");
            var group = Group(a, b);
            var plan = Create(group);
            a.Name = "changed A"; a.Commands = "/echo changed";
            b.Name = "changed B"; b.Commands = "/echo replaced";
            group.Name = "changed group"; group.Children.Reverse(); group.Children.Clear();
            Check(plan.Name == "总宏" && plan.TotalChildren == 2 && plan.TotalLines == 2);
            Check(plan.Segments[0].ChildName == "A" && plan.Segments[0].Lines.SequenceEqual(["/echo A <wait.0.25>"]));
            Check(plan.Segments[1].ChildName == "B" && plan.Segments[1].Lines.SequenceEqual(["/echo B"]));
        });
    }
}
