using MacroShelfA;
using MacroShelfA.Runtime;

internal static class NativeMacroRunnerTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "native macro runner regression") => check(value, message);
        void Test(string name, Action body) => test("native-macro-runner: " + name, body);
        MacroEntry Leaf(string commands = "/echo native <wait.1>", string name = "A") => new() { Name = name, Commands = commands };
        MacroEntry Group(params MacroEntry[] children) => new() { Name = "总宏", IsGroup = true, Children = [.. children] };
        string Rows(int count) => string.Join('\n', Enumerable.Range(1, count).Select(i => $"/echo {i}"));
        void Start(NativeMacroRunner runner, MacroEntry macro, bool allowLong = false, double now = 0)
        {
            Check(runner.TryStart(macro, allowLong, now, out var error), error);
        }

        Test("start queues a snapshot without touching native host before framework tick", () =>
        {
            var host = new FakeHost(); using var runner = new NativeMacroRunner(host);
            Start(runner, Leaf());
            Check(runner.IsRunning && runner.CurrentMacroName == "A" && runner.CurrentChildName == "A");
            Check(runner.TotalChildren == 1 && runner.TotalLines == 1 && runner.ExecutedLines == 0 && runner.RemainingLines == 1);
            Check(host.Calls.Count == 0 && runner.StatusText.Contains("校验"));
            Check(!runner.TryStart(Leaf("/echo competing"), false, 0, out var error) && error.Contains("已有"));
            runner.Tick(0);
            Check(host.Calls.SequenceEqual(["prepare", "start"]) && host.Starts.Count == 1 && runner.IsRunning);
            Check(host.Starts[0].Segment.Lines.SequenceEqual(["/echo native <wait.1>"]));
        });

        Test("pending readiness stays queued until Ready and never polls early", () =>
        {
            var host = new FakeHost { Readiness = NativeMacroReadiness.Pending, PrepareDetail = "正在校验" };
            using var runner = new NativeMacroRunner(host); Start(runner, Leaf());
            runner.Tick(0); runner.Tick(12); runner.Tick(30);
            Check(runner.IsRunning && host.PrepareCalls == 3 && host.StartCalls == 0 && host.PollCalls == 0);
            Check(runner.StatusText == "正在校验" && runner.ExecutionStopReason == "");
            host.Readiness = NativeMacroReadiness.Ready;
            runner.Tick(30);
            Check(host.StartCalls == 1 && host.PollCalls == 0 && runner.IsRunning);
        });

        Test("pending preparation times out after 30 seconds without native start or retry", () =>
        {
            var host = new FakeHost { Readiness = NativeMacroReadiness.Pending };
            using var runner = new NativeMacroRunner(host); Start(runner, Leaf(), now: 100);
            runner.Tick(130); Check(runner.IsRunning && host.StartCalls == 0);
            runner.Tick(130.001);
            Check(!runner.IsRunning && runner.ExecutionStopReason.Contains("超时") && host.StartCalls == 0 && host.CancelCalls == 1);
            var count = host.Calls.Count; runner.Tick(150); Check(host.Calls.Count == count);
        });

        Test("unavailable preparation stops without fallback or subsequent retry", () =>
        {
            var host = new FakeHost { Readiness = NativeMacroReadiness.Unavailable, PrepareDetail = "未通过客户端校验" };
            using var runner = new NativeMacroRunner(host); Start(runner, Leaf());
            var sentBefore = Plugin.CommandManager.Sent.Count;
            runner.Tick(0); runner.Tick(1);
            Check(!runner.IsRunning && runner.ExecutionStopReason == "未通过客户端校验");
            Check(host.PrepareCalls == 1 && host.StartCalls == 0 && host.PollCalls == 0 && Plugin.CommandManager.Sent.Count == sentBefore);
        });

        Test("only Completed advances a segment after native tail wait and command queue drain", () =>
        {
            var host = new FakeHost(); using var runner = new NativeMacroRunner(host);
            Start(runner, Leaf(Rows(16)), allowLong: true);
            runner.Tick(0); Check(host.StartCalls == 1 && host.PollCalls == 0);
            host.Progress = new(NativeMacroRunState.Running, 15, 1.25, "尾行等待");
            runner.Tick(1);
            Check(host.StartCalls == 1 && runner.IsRunning && runner.ExecutedLines == 15 && runner.RemainingWait == 1.25);
            host.Progress = new(NativeMacroRunState.Running, 15, 0, "命令队列未排空");
            runner.Tick(2); runner.Tick(3);
            Check(host.StartCalls == 1 && host.PollCalls == 3 && runner.CurrentChildIndex == 1 && runner.RemainingLines == 1);
            host.Progress = new(NativeMacroRunState.Completed, 15, 0);
            var priorStarts = host.StartCalls; runner.Tick(4);
            Check(host.StartCalls - priorStarts == 1 && host.Starts[1].Segment.Lines.SequenceEqual(["/echo 16"]));
            Check(runner.IsRunning && runner.ExecutedLines == 15 && runner.RemainingWait == 0);
            host.Progress = new(NativeMacroRunState.Completed, 1, 0);
            runner.Tick(5); Check(!runner.IsRunning && runner.ExecutionStopReason == "" && host.StartCalls == 2);
            Check(host.CancelCalls == 0);
        });

        Test("a framework tick launches at most one segment even if every poll is Completed", () =>
        {
            var host = new FakeHost { Progress = new(NativeMacroRunState.Completed, 15, 0) };
            using var runner = new NativeMacroRunner(host); Start(runner, Leaf(Rows(46)), allowLong: true);
            for (var tick = 0; tick < 4; tick++)
            {
                var before = host.StartCalls; runner.Tick(tick);
                Check(host.StartCalls == before + 1 && runner.IsRunning);
                Check(host.PollCalls == tick);
            }
            runner.Tick(4); Check(!runner.IsRunning && host.StartCalls == 4 && host.PollCalls == 4);
            Check(host.Starts.Select(s => s.Segment.Lines.Length).SequenceEqual([15, 15, 15, 1]));
            Check(host.Starts.Select(s => s.Owner).Distinct().Count() == 4 && host.Starts.All(s => s.Owner.StartsWith("MSA", StringComparison.Ordinal)));
        });

        Test("16-line child and following child preserve group identity order and progress", () =>
        {
            var host = new FakeHost(); using var runner = new NativeMacroRunner(host);
            Start(runner, Group(Leaf(Rows(16), "长子宏"), Leaf("/echo B\n/wait 0.5", "次子宏")), allowLong: true);
            Check(runner.TotalChildren == 2 && runner.TotalLines == 18 && runner.CurrentChildIndex == 1);
            runner.Tick(0); host.Progress = new(NativeMacroRunState.Completed, 15, 0); runner.Tick(1);
            Check(runner.CurrentChildName == "长子宏" && runner.ExecutedLines == 15);
            host.Progress = new(NativeMacroRunState.Completed, 1, 0); runner.Tick(2);
            Check(runner.CurrentChildName == "次子宏" && runner.CurrentChildIndex == 2 && runner.ExecutedLines == 16 && runner.RemainingLines == 2);
            Check(host.Starts.Select(s => s.Segment.ChildName).SequenceEqual(["长子宏", "长子宏", "次子宏"]));
            Check(host.Starts.Select(s => s.Segment.FirstLineNumber).SequenceEqual([1, 16, 1]));
            Check(host.Starts[2].Segment.Lines.SequenceEqual(["/echo B", "/wait 0.5"]));
        });

        Test("first and continuation TryStart failures never fallback or retry commands", () =>
        {
            foreach (var failingAttempt in new[] { 1, 2 })
            {
                var host = new FakeHost { FailStartAttempt = failingAttempt, StartError = "原生宏已被占用" };
                using var runner = new NativeMacroRunner(host); Start(runner, Leaf(Rows(16)), allowLong: true);
                var sentBefore = Plugin.CommandManager.Sent.Count;
                runner.Tick(0);
                if (failingAttempt == 2)
                { host.Progress = new(NativeMacroRunState.Completed, 15, 0); runner.Tick(1); }
                Check(!runner.IsRunning && runner.ExecutionStopReason == "原生宏已被占用");
                var calls = host.Calls.Count; runner.Tick(100);
                Check(host.StartCalls == failingAttempt && host.Starts.Count == failingAttempt - 1 && host.Calls.Count == calls);
                Check(Plugin.CommandManager.Sent.Count == sentBefore);
            }
        });

        Test("RequestStop invalidates queued continuation immediately but cancels on Tick", () =>
        {
            foreach (var startFirstSegment in new[] { false, true })
            {
                var host = new FakeHost { Progress = new(NativeMacroRunState.Completed, 15, 0) };
                using var runner = new NativeMacroRunner(host); Start(runner, Leaf(Rows(16)), allowLong: true);
                if (startFirstSegment) runner.Tick(0);
                var calls = host.Calls.Count;
                runner.RequestStop(); runner.RequestStop();
                Check(runner.IsRunning && runner.StatusText.Contains("正在停止") && host.Calls.Count == calls);
                Check(!runner.TryStart(Leaf("/echo new"), false, 1, out _));
                runner.Tick(1);
                Check(!runner.IsRunning && runner.ExecutionStopReason == "" && host.CancelCalls == 1 && host.PollCalls == 0);
                Check(host.StartCalls == (startFirstSegment ? 1 : 0));
                calls = host.Calls.Count; runner.RequestStop(); runner.Tick(2); Check(host.Calls.Count == calls);
            }
        });

        Test("external Interrupted halts remaining chain and cancellation cannot touch external owner", () =>
        {
            var host = new FakeHost(); using var runner = new NativeMacroRunner(host);
            Start(runner, Group(Leaf(), Leaf("/echo never", "B"))); runner.Tick(0);
            host.ExternalTakeover = true;
            host.Progress = new(NativeMacroRunState.Interrupted, 1, 0, "其他宏接管");
            runner.Tick(1); runner.Tick(2);
            Check(!runner.IsRunning && runner.ExecutionStopReason == "其他宏接管" && host.StartCalls == 1);
            Check(host.CancelCalls == 1 && host.OwnedCancelCalls == 0 && host.ExternalTakeover);
        });

        Test("unavailable polling stops and clamps malformed progress without escaping", () =>
        {
            var host = new FakeHost(); using var runner = new NativeMacroRunner(host);
            Start(runner, Leaf()); runner.Tick(0);
            host.Progress = new(NativeMacroRunState.Running, -100, double.NaN);
            runner.Tick(1); Check(runner.ExecutedLines == 0 && runner.RemainingWait == 0);
            host.Progress = new(NativeMacroRunState.Running, int.MaxValue, -3);
            runner.Tick(2); Check(runner.ExecutedLines == 1 && runner.RemainingWait == 0 && runner.IsRunning);
            host.Progress = new(NativeMacroRunState.Unavailable, 1, double.PositiveInfinity, "模块不可用");
            runner.Tick(3);
            Check(!runner.IsRunning && runner.ExecutionStopReason == "模块不可用" && host.StartCalls == 1);
        });

        Test("invalid initial and running clocks stop without new command dispatch", () =>
        {
            foreach (var invalid in new[] { double.NaN, double.PositiveInfinity, double.NegativeInfinity })
            {
                var host = new FakeHost(); using var runner = new NativeMacroRunner(host);
                Check(!runner.TryStart(Leaf(), false, invalid, out var error) && error.Contains("时钟"));
                Check(!runner.IsRunning && host.Calls.Count == 0);
            }
            foreach (var invalid in new[] { double.NaN, double.PositiveInfinity, double.NegativeInfinity, 9.0 })
            {
                var host = new FakeHost(); using var runner = new NativeMacroRunner(host);
                Start(runner, Leaf(), now: 10); runner.Tick(10); runner.Tick(invalid);
                Check(!runner.IsRunning && runner.ExecutionStopReason.Contains("时钟") && host.StartCalls == 1 && host.PollCalls == 0);
                Check(host.OwnedCancelCalls == 1);
            }
        });

        Test("host exceptions are contained and remaining commands never retried", () =>
        {
            foreach (var stage in new[] { "prepare", "start", "poll" })
            {
                var host = new FakeHost { ThrowAt = stage }; using var runner = new NativeMacroRunner(host);
                Start(runner, Leaf(Rows(16)), allowLong: true); runner.Tick(0);
                if (stage == "poll") runner.Tick(1);
                Check(!runner.IsRunning && runner.ExecutionStopReason == "host-" + stage);
                var calls = host.Calls.Count; runner.Tick(2);
                Check(host.Calls.Count == calls && host.StartCalls <= 1 && host.CancelCalls == 1);
            }
            var cancelHost = new FakeHost { ThrowAt = "cancel" };
            using var cancelling = new NativeMacroRunner(cancelHost);
            Start(cancelling, Leaf()); cancelling.Tick(0); cancelling.RequestStop(); cancelling.Tick(1);
            Check(!cancelling.IsRunning && cancelling.ExecutionStopReason == "host-cancel" && cancelHost.StartCalls == 1);
        });

        Test("Dispose delegates host teardown only once and cannot restart", () =>
        {
            var host = new FakeHost(); var runner = new NativeMacroRunner(host);
            Start(runner, Leaf()); runner.Tick(0);
            runner.Dispose(); runner.Dispose();
            Check(!runner.IsRunning && host.DisposeCalls == 1 && host.OwnedCancelCalls == 1);
            var calls = host.Calls.Count;
            runner.RequestStop(); runner.Tick(100);
            Check(host.Calls.Count == calls && !runner.TryStart(Leaf(), false, 100, out var error) && error.Contains("卸载"));
        });

        Test("queued execution keeps source names membership commands and wait syntax snapshot", () =>
        {
            var first = Leaf("/echo original <wait.0.1>\n/wait 120", "original-A");
            var second = Leaf("/echo original-B", "original-B");
            var group = Group(first, second);
            var host = new FakeHost(); using var runner = new NativeMacroRunner(host); Start(runner, group);
            group.Name = "edited-group"; first.Name = "edited-A"; first.Commands = "/echo edited";
            second.Name = "edited-B"; second.Commands = "/echo changed"; group.Children.Clear();
            Check(runner.CurrentMacroName == "总宏" && runner.TotalChildren == 2 && runner.TotalLines == 3);
            runner.Tick(0);
            Check(host.Starts[0].Segment.ChildName == "original-A" && host.Starts[0].Segment.Lines.SequenceEqual(["/echo original <wait.0.1>", "/wait 120"]));
            host.Progress = new(NativeMacroRunState.Completed, 2, 0); runner.Tick(1);
            Check(runner.CurrentChildName == "original-B" && host.Starts[1].Segment.Lines.SequenceEqual(["/echo original-B"]));
            Check(group.Name == "edited-group" && group.Children.Count == 0 && first.Commands == "/echo edited");
        });
    }

    private sealed class FakeHost : INativeMacroExecutionHost
    {
        public NativeMacroReadiness Readiness = NativeMacroReadiness.Ready;
        public NativeMacroProgress Progress = new(NativeMacroRunState.Running, 0, 0);
        public string PrepareDetail = "ready", StartError = "rejected", ThrowAt = "";
        public int FailStartAttempt;
        public bool ExternalTakeover;
        public readonly List<string> Calls = [];
        public readonly List<(NativeMacroSegment Segment, string Owner)> Starts = [];
        public int PrepareCalls, StartCalls, PollCalls, CancelCalls, OwnedCancelCalls, DisposeCalls;
        private bool owned;

        public NativeMacroReadiness Prepare(out string detail)
        {
            Calls.Add("prepare"); PrepareCalls++; Throw("prepare");
            detail = PrepareDetail; return Readiness;
        }
        public bool TryStart(NativeMacroSegment segment, string ownerName, out string error)
        {
            Calls.Add("start"); StartCalls++; Throw("start");
            if (StartCalls == FailStartAttempt) { error = StartError; return false; }
            error = ""; Starts.Add((segment, ownerName)); owned = true; return true;
        }
        public NativeMacroProgress Poll()
        {
            Calls.Add("poll"); PollCalls++; Throw("poll");
            if (Progress.State is NativeMacroRunState.Completed or NativeMacroRunState.Interrupted || ExternalTakeover) owned = false;
            return Progress;
        }
        public void CancelOwned()
        {
            Calls.Add("cancel"); CancelCalls++; Throw("cancel");
            // Ownership is a host obligation: an interrupted/external macro is not ours.
            if (owned && !ExternalTakeover) { OwnedCancelCalls++; owned = false; }
        }
        public void Dispose()
        {
            Calls.Add("dispose"); DisposeCalls++;
            if (owned && !ExternalTakeover) { OwnedCancelCalls++; owned = false; }
        }
        private void Throw(string stage)
        {
            if (ThrowAt == stage) throw new InvalidOperationException("host-" + stage);
        }
    }
}
