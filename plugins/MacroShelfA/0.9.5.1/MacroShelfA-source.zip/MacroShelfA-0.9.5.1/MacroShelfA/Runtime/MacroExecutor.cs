using System;
using System.Diagnostics;
using Dalamud.Plugin.Services;

namespace MacroShelfA.Runtime;

internal sealed class MacroExecutor : IDisposable
{
    public const int MaximumLines = MacroSequence.MaximumLines;
    private readonly Configuration configuration;
    private readonly MacroSequence sequence = new();
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private readonly Func<double> now;
    private readonly JobChangeGuard jobChangeGuard;
    private readonly NativeMacroRunner nativeRunner;
    private bool activeNative;
    private readonly Func<bool> nativeWaitReady;
    public MacroExecutor(Configuration configuration, Func<double>? now = null, IJobChangeHost? jobChangeHost = null,
        INativeMacroExecutionHost? nativeHost = null, Func<bool>? nativeWaitReady = null)
    {
        this.configuration = configuration;
        this.now = now ?? (() => clock.Elapsed.TotalSeconds);
        this.nativeWaitReady = nativeWaitReady ?? (() => true);
        jobChangeGuard = new JobChangeGuard(jobChangeHost ?? new NativeJobChangeHost(),
            message => Plugin.Log.Information("{Message}", message));
        nativeRunner = new NativeMacroRunner(nativeHost ?? new NativeMacroExecutionHost());
        Plugin.Framework.Update += OnFrameworkUpdate;
    }
    public bool IsRunning => sequence.IsRunning || nativeRunner.IsRunning;
    public string CurrentMacroName => activeNative ? nativeRunner.CurrentMacroName : sequence.CurrentMacroName;
    public string CurrentChildName => activeNative ? nativeRunner.CurrentChildName : sequence.CurrentChildName;
    public int CurrentChildIndex => activeNative ? nativeRunner.CurrentChildIndex : sequence.CurrentChildIndex;
    public int TotalChildren => activeNative ? nativeRunner.TotalChildren : sequence.TotalChildren;
    public int TotalLines => activeNative ? nativeRunner.TotalLines : sequence.TotalLines;
    public int ExecutedLines => activeNative ? nativeRunner.ExecutedLines : sequence.ExecutedLines;
    public int RemainingLines => activeNative ? nativeRunner.RemainingLines : sequence.RemainingLines;
    public double RemainingWait => activeNative ? nativeRunner.RemainingWait : sequence.RemainingWait(now());
    public bool IsWaitingForJobChange => !activeNative && jobChangeGuard.IsWaiting;
    public string ExecutionBackendName => (IsRunning ? activeNative : configuration.UseNativeMacroExecution)
        ? "原生宏 ExecuteMacro（候选）" : "旧版逐行 ProcessChatBoxEntry";
    public string NativeStatusText => nativeRunner.StatusText;

    public void Start(MacroEntry macro)
    {
        if (!TryStart(macro, out var error)) Plugin.ChatGui.PrintError($"[Macro Shelf-A] {error}");
    }

    public bool TryStart(MacroEntry macro, out string error)
    {
        if (IsRunning) { error = "已有宏正在执行或停止，请先等待结束。"; return false; }
        if (!Plugin.ClientState.IsLoggedIn)
        {
            error = "请先登录角色，再执行宏。";
            return false;
        }
        activeNative = configuration.UseNativeMacroExecution;
        if (activeNative && !nativeWaitReady())
        { error = "小数与长时间等待补丁尚未成功启用；原生宏未执行，以免改变等待节拍。请检查执行设置中的等待状态。"; return false; }
        var started = activeNative
            ? nativeRunner.TryStart(macro, configuration.AllowLongMacros, now(), out error)
            : sequence.TryStart(macro, now(), out error, configuration.AllowLongMacros);
        if (started) jobChangeGuard.Reset();
        return started;
    }

    public void Stop(bool notify = true)
    {
        var name = CurrentMacroName;
        var wasRunning = IsRunning;
        sequence.Stop();
        nativeRunner.RequestStop();
        jobChangeGuard.Reset();
        if (notify && wasRunning) Plugin.ChatGui.Print($"[Macro Shelf-A] {(nativeRunner.IsRunning ? "正在中止原生宏" : "已中止")}：{name}");
    }

    public void Dispose()
    {
        Plugin.Framework.Update -= OnFrameworkUpdate;
        Stop(false);
        nativeRunner.Dispose();
        clock.Stop();
    }

    private void OnFrameworkUpdate(IFramework framework)
    {
        if (!IsRunning) return;
        if (!Plugin.ClientState.IsLoggedIn)
        {
            Stop(false);
            if (activeNative) nativeRunner.Tick(now());
            return;
        }
        try
        {
            var tickTime = now();
            if (activeNative)
            {
                nativeRunner.Tick(tickTime);
                if (!string.IsNullOrEmpty(nativeRunner.ExecutionStopReason))
                    Plugin.ChatGui.PrintError($"[Macro Shelf-A] {nativeRunner.ExecutionStopReason}");
                return;
            }
            sequence.TickDeferred(tickTime, line => jobChangeGuard.TryDispatch(line, tickTime),
                () => jobChangeGuard.TryContinue(tickTime));
            if (!IsRunning) jobChangeGuard.Reset();
            if (!string.IsNullOrEmpty(sequence.ExecutionStopReason))
                Plugin.ChatGui.PrintError($"[Macro Shelf-A] {sequence.ExecutionStopReason}");
        }
        catch (Exception exception)
        {
            jobChangeGuard.Reset();
            Plugin.Log.Error(exception, "宏组执行失败，已中止后续全部命令。");
            Plugin.ChatGui.PrintError($"[Macro Shelf-A] {exception.Message}");
        }
    }
}
