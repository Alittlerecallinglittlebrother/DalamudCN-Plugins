using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Hooking;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;
using FFXIVClientStructs.FFXIV.Client.UI.Shell;

namespace MacroShelfA.Runtime;

// Audited ONLY for the executable hash below. See NATIVE-EXECUTION.md for the
// Update/ExecuteMacro/CancelMacro disassembly evidence and the limits of that evidence.
internal readonly record struct NativeMacroShellState(int Line, bool Locked, byte DeferredIndex,
    byte DeferredCount, float DeferredCooldown, uint WaitMs, ulong WaitStartedMs)
{
    public bool Valid => Line is >= -1 and <= 15 && DeferredIndex <= DeferredCount && DeferredCount <= 15 &&
        float.IsFinite(DeferredCooldown);
    // Natural Update reaches -1 only AFTER tail wait. Deferred commands can still
    // be pending after that point; ExecuteMacro would erase them if started early.
    // ExecuteMacro preserves the remaining 0.16s throttle. Do not add a second
    // wait for that cooldown after the queue is empty; the next block inherits it.
    public bool Idle => Valid && Line == -1 && !Locked && DeferredIndex >= DeferredCount;
    public double RemainingWait(double qpcMilliseconds) => Line < 0 ? 0 :
        Math.Max(0, (WaitMs - Math.Max(0, qpcMilliseconds - WaitStartedMs)) / 1000);
}

internal sealed unsafe class NativeMacroExecutionHost : INativeMacroExecutionHost
{
    // The installed binding declares void, but this audited client returns a bool
    // in AL and a real caller tests AL. The observer MUST preserve that byte.
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate byte CancelMacroNative(RaptureShellModule* shell);
    internal const string AuditedImageSha256 = "7BA28760BC53CBBBF66B63105FEA6C1BFE09CB6B1C6353FC8FB0FF03CC1A30F4";
    private readonly Task<bool> imageVerification = Task.Run(VerifyImage);
    private Hook<RaptureShellModule.Delegates.ExecuteMacro>? executeHook;
    private Hook<CancelMacroNative>? cancelHook;
    private nint observedShell;
    private string? owner;
    private byte[][]? ownedLines;
    private ulong ownerContentId;
    private int lineCount, activeCalls;
    private bool issuing, ownCancellation, interrupted, disposed, cleanupSubscribed;
    private nint issuingMacro;
    private int issuingThread;
    private string? preparationFailure;

    public NativeMacroReadiness Prepare(out string detail)
    {
        detail = "正在校验本机客户端，尚未发送宏";
        if (disposed) { detail = "原生执行器已卸载。"; return NativeMacroReadiness.Unavailable; }
        if (!imageVerification.IsCompleted) return NativeMacroReadiness.Pending;
        if (!imageVerification.IsCompletedSuccessfully || !imageVerification.Result)
        { detail = "客户端不在本候选版的精确验证范围，未运行原生宏；没有回退旧执行器。"; return NativeMacroReadiness.Unavailable; }
        if (preparationFailure != null) { detail = preparationFailure; return NativeMacroReadiness.Unavailable; }
        try
        {
            using var process = Process.GetCurrentProcess();
            var imageBase = process.MainModule?.BaseAddress ?? 0;
            if (!BindingLayoutMatches() || !AuditedAddressesMatch(imageBase,
                    (nint)RaptureShellModule.MemberFunctionPointers.ExecuteMacro,
                    (nint)RaptureShellModule.MemberFunctionPointers.CancelMacro))
                throw new InvalidOperationException("原生宏绑定或布局与已审计客户端不匹配。");
            if (!TryContext(out var shell, out _))
            { detail = "请等待角色登录及场景载入完成，再运行原生宏。"; return NativeMacroReadiness.Unavailable; }
            observedShell = (nint)shell;
            if (executeHook == null)
            {
                executeHook = Plugin.GameInteropProvider.HookFromAddress<RaptureShellModule.Delegates.ExecuteMacro>(
                    (nint)RaptureShellModule.MemberFunctionPointers.ExecuteMacro, OnExecuteMacro);
                cancelHook = Plugin.GameInteropProvider.HookFromAddress<CancelMacroNative>(
                    (nint)RaptureShellModule.MemberFunctionPointers.CancelMacro, OnCancelMacro);
                executeHook.Enable();
                cancelHook.Enable();
            }
            var state = ReadState(shell);
            if (!state.Valid)
            { detail = "游戏原生宏状态不符合已验证范围；未启动宏。"; return NativeMacroReadiness.Unavailable; }
            if (!state.Idle)
            { detail = "等待已有原生宏 / 入口宏及延后动作结束（最多 30 秒，不抢占）"; return NativeMacroReadiness.Pending; }
            detail = "原生宏客户端校验通过";
            return NativeMacroReadiness.Ready;
        }
        catch (Exception exception)
        {
            ReleaseHooks();
            preparationFailure = detail = "原生宏执行器未能初始化，未运行宏：" + exception.Message;
            return NativeMacroReadiness.Unavailable;
        }
    }

    public bool TryStart(NativeMacroSegment segment, string ownerName, out string error)
    {
        error = "";
        if (executeHook == null || cancelHook == null || disposed || preparationFailure != null ||
            !TryContext(out var shell, out var contentId))
        { error = "原生宏执行环境不可用。"; return false; }
        if ((nint)shell != observedShell || !ReadState(shell).Idle)
        { error = "游戏原生宏或延后动作仍在运行；未抢占、未发送本段宏。"; return false; }
        if (segment.Lines.Length is < 1 or > 15)
        { error = "原生宏段必须包含 1–15 行。"; return false; }
        using var buffer = new NativeMacroBuffer(ownerName, segment.Lines);
        if (disposed) { error = "原生执行器已卸载，未发送宏。"; return false; }
        interrupted = false;
        try
        {
            issuing = true;
            issuingMacro = (nint)buffer.Pointer;
            issuingThread = Environment.CurrentManagedThreadId;
            DispatchToGame(shell, buffer.Pointer);
        }
        finally { issuing = false; issuingMacro = 0; issuingThread = 0; }
        // ExecuteMacro is void. Verify the copied owner tag and initial line instead
        // of treating a returned call as acceptance. This is NOT animation success.
        var expectedLines = new byte[15][];
        for (var i = 0; i < 15; i++) expectedLines[i] = Encoding.UTF8.GetBytes(i < segment.Lines.Length ? segment.Lines[i] : "");
        if (shell->MacroCurrentLine != 0 || ReadName(shell) != ownerName || !LinesMatch(shell, expectedLines))
        { error = "游戏没有接受本段原生宏；没有重试或回退旧执行器。"; return false; }
        owner = ownerName;
        ownedLines = expectedLines;
        ownerContentId = contentId;
        lineCount = segment.Lines.Length;
        if (disposed)
        {
            CancelOwned();
            error = "原生宏接纳期间执行器已卸载；已中止本人宏，不再续接。";
            return false;
        }
        Log($"accepted tag={ownerName} lines={lineCount}; native wait and deferred queue owned by game");
        // Matched ExecuteMacro deep-copies all 16 Utf8Strings synchronously. The
        // scratch object's lifetime ends here; it never occupies a user macro slot.
        return true;
    }

    public NativeMacroProgress Poll()
    {
        if (interrupted || owner == null)
            return new(NativeMacroRunState.Interrupted, 0, 0, "原生宏已被取消或其他原生宏接管，已停止后续宏段。");
        if (!TryContext(out var shell, out var contentId) || (nint)shell != observedShell || contentId != ownerContentId)
        { owner = null; return new(NativeMacroRunState.Unavailable, 0, 0, "角色或场景已变化，已停止后续原生宏段。"); }
        if (ReadName(shell) != owner || ownedLines == null || !LinesMatch(shell, ownedLines))
        { owner = null; interrupted = true; return new(NativeMacroRunState.Interrupted, 0, 0, "原生宏上下文已变化，已停止后续宏段。"); }
        var state = ReadState(shell);
        if (!state.Valid)
        { owner = null; interrupted = true; return new(NativeMacroRunState.Unavailable, 0, 0, "原生宏状态不符合已验证布局，已停止后续宏段。"); }
        if (state.Idle)
        {
            Log($"completed tag={owner}; final wait and deferred queue drained");
            owner = null;
            return new(NativeMacroRunState.Completed, lineCount, 0);
        }
        var done = state.Line < 0 ? lineCount : Math.Clamp(state.Line, 0, lineCount);
        return new(NativeMacroRunState.Running, done,
            state.RemainingWait(Stopwatch.GetTimestamp() * 1000.0 / Stopwatch.Frequency),
            state.Line < 0 ? "等待游戏原生延后动作队列结束" : "游戏原生宏执行中（含原始等待）");
    }

    public void CancelOwned()
    {
        if (owner == null) return;
        var tag = owner;
        owner = null; // Invalidate continuation/ownership before invoking the native cancellation hook.
        if (!TryContext(out var shell, out var contentId) || (nint)shell != observedShell ||
            contentId != ownerContentId || ReadName(shell) != tag || ownedLines == null ||
            !LinesMatch(shell, ownedLines) || !ReadState(shell).Valid) return;
        try
        {
            ownCancellation = true;
            shell->CancelMacro();
            Log($"cancelled tag={tag}; no user macro slot changed; already accepted native deferred actions are not rolled back");
        }
        finally { ownCancellation = false; }
    }

    private void OnExecuteMacro(RaptureShellModule* shell, RaptureMacroModule.Macro* macro)
    {
        Interlocked.Increment(ref activeCalls);
        var ownRequest = issuing && issuingThread == Environment.CurrentManagedThreadId && issuingMacro == (nint)macro;
        var externalAccepted = !ownRequest && (nint)shell == observedShell && !shell->MacroLocked;
        try { executeHook!.Original(shell, macro); }
        finally
        {
            // Audited function's only refusal branch is MacroLocked. Empty macros
            // are accepted too. Natural completion does not call ExecuteMacro.
            if (externalAccepted && owner != null) { owner = null; interrupted = true; }
            Interlocked.Decrement(ref activeCalls);
        }
    }

    private byte OnCancelMacro(RaptureShellModule* shell)
    {
        Interlocked.Increment(ref activeCalls);
        try { return cancelHook!.Original(shell); }
        finally
        {
            // Audited Update ends naturally via direct field writes, not CancelMacro.
            if (!ownCancellation && (nint)shell == observedShell && owner != null)
            { owner = null; interrupted = true; }
            Interlocked.Decrement(ref activeCalls);
        }
    }

    private static bool TryContext(out RaptureShellModule* shell, out ulong contentId)
    {
        shell = null; contentId = 0;
        if (!Plugin.ClientState.IsLoggedIn || Plugin.Condition[ConditionFlag.LoggingOut] ||
            Plugin.Condition[ConditionFlag.BetweenAreas] || Plugin.Condition[ConditionFlag.BetweenAreas51]) return false;
        var player = PlayerState.Instance();
        shell = RaptureShellModule.Instance();
        if (player == null || !player->IsLoaded || player->ContentId == 0 || shell == null) return false;
        contentId = player->ContentId;
        return true;
    }

    internal static NativeMacroShellState ReadState(RaptureShellModule* shell)
    {
        if (shell == null) throw new ArgumentNullException(nameof(shell));
        // ONLY called after the exact executable and installed binding gate. These
        // raw offsets are missing from the public binding, not universal FFXIV offsets.
        var bytes = (byte*)shell;
        return new(shell->MacroCurrentLine, shell->MacroLocked, bytes[0x2B5], bytes[0x2B6],
            *(float*)(bytes + 0x2B8), shell->WaitTimeMs, shell->WaitStartTime.CpuMilliSeconds);
    }

    private static string ReadName(RaptureShellModule* shell)
    {
        ref var text = ref shell->MacroName;
        if (text.StringPtr.Value == null || text.BufUsed is < 1 or > 4096 || text.BufSize < text.BufUsed)
            return "";
        return Encoding.UTF8.GetString(text.AsSpan());
    }

    internal static bool LinesMatch(RaptureShellModule* shell, byte[][] expected)
    {
        if (shell == null || expected.Length != 15) return false;
        for (var i = 0; i < 15; i++)
        {
            ref var line = ref shell->MacroLines[i];
            if (line.StringPtr.Value == null || line.BufUsed is < 1 or > NativeMacroPlan.MaximumLineUtf8Bytes + 1 ||
                line.BufSize < line.BufUsed || !line.AsSpan().SequenceEqual(expected[i])) return false;
        }
        return true;
    }

    internal static void DispatchToGame(RaptureShellModule* shell, RaptureMacroModule.Macro* macro)
    {
        if (shell == null || macro == null) throw new InvalidOperationException("原生宏或执行模块地址为空。");
        shell->ExecuteMacro(macro);
    }

    internal static bool AuditedAddressesMatch(nint imageBase, nint execute, nint cancel) => imageBase != 0 &&
        execute == imageBase + 0x912150 && cancel == imageBase + 0x912320;
    internal static bool BindingLayoutMatches() => sizeof(RaptureShellModule) == 0x1250 &&
        sizeof(RaptureMacroModule.Macro) == 0x688 && sizeof(Utf8String) == 0x68 &&
        Marshal.OffsetOf<RaptureShellModule>(nameof(RaptureShellModule.WaitStartTime)) == 0x290 &&
        Marshal.OffsetOf<RaptureShellModule>(nameof(RaptureShellModule.WaitTimeMs)) == 0x2A8 &&
        Marshal.OffsetOf<RaptureShellModule>(nameof(RaptureShellModule.MacroLocked)) == 0x2B3 &&
        Marshal.OffsetOf<RaptureShellModule>(nameof(RaptureShellModule.MacroCurrentLine)) == 0x2C0 &&
        Marshal.OffsetOf<RaptureShellModule>(nameof(RaptureShellModule.MacroName)) == 0x338 &&
        Marshal.OffsetOf<RaptureShellModule>("_macroLines") == 0x3A0 &&
        Marshal.OffsetOf<RaptureMacroModule.Macro>(nameof(RaptureMacroModule.Macro.Name)) == 0x8 &&
        Marshal.OffsetOf<RaptureMacroModule.Macro>("_lines") == 0x70;

    private static bool VerifyImage()
    {
        try
        {
            using var process = Process.GetCurrentProcess();
            var path = process.MainModule?.FileName;
            if (path == null || !string.Equals(Path.GetFileName(path), "ffxiv_dx11.exe", StringComparison.OrdinalIgnoreCase)) return false;
            using var input = File.OpenRead(path);
            return ImageIdentityMatches(Path.GetFileName(path), Convert.ToHexString(SHA256.HashData(input)));
        }
        catch { return false; }
    }

    internal static bool ImageIdentityMatches(string fileName, string sha256) =>
        string.Equals(fileName, "ffxiv_dx11.exe", StringComparison.OrdinalIgnoreCase) &&
        string.Equals(sha256, AuditedImageSha256, StringComparison.OrdinalIgnoreCase);

    private static void Log(string value)
    { try { Plugin.Log.Information("[原生宏执行] {Message}", value); } catch { } }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        // Unload/UI callbacks can be outside the Framework thread. No raw game
        // pointer is retained by this closure; cancellation checks fresh ownership.
        _ = Plugin.Framework.RunOnFrameworkThread(() =>
        {
            try { CancelOwned(); }
            finally
            {
                if (Volatile.Read(ref activeCalls) == 0) ReleaseHooks();
                else if (!cleanupSubscribed) { cleanupSubscribed = true; Plugin.Framework.Update += CleanupTick; }
            }
        });
    }

    private void CleanupTick(IFramework _)
    {
        if (Volatile.Read(ref activeCalls) != 0) return;
        Plugin.Framework.Update -= CleanupTick;
        cleanupSubscribed = false;
        try { CancelOwned(); }
        finally { ReleaseHooks(); }
    }
    private void ReleaseHooks()
    {
        Release(ref cancelHook);
        Release(ref executeHook);
    }
    private static void Release<T>(ref Hook<T>? field) where T : Delegate
    {
        var hook = field; field = null;
        if (hook == null) return;
        try { hook.Disable(); } catch { }
        try { hook.Dispose(); } catch { }
    }
}

// Independent stable storage, not an uninitialized default(Macro) and not a user slot.
internal sealed unsafe class NativeMacroBuffer : IDisposable
{
    private RaptureMacroModule.Macro* macro;
    private int constructed;
    public RaptureMacroModule.Macro* Pointer => macro;
    public NativeMacroBuffer(string ownerName, string[] lines)
    {
        if (string.IsNullOrEmpty(ownerName) || ownerName.Length > 20 || lines.Length is < 1 or > 15)
            throw new ArgumentException("原生宏临时对象参数无效。");
        macro = (RaptureMacroModule.Macro*)NativeMemory.AllocZeroed((nuint)sizeof(RaptureMacroModule.Macro));
        if (macro == null) throw new OutOfMemoryException();
        try
        {
            Construct(&macro->Name, ownerName); constructed++;
            for (var index = 0; index < 15; index++)
            {
                fixed (Utf8String* line = &macro->Lines[index])
                    Construct(line, index < lines.Length ? lines[index] : "");
                constructed++;
            }
        }
        catch { Dispose(); throw; }
    }
    private static void Construct(Utf8String* value, string text)
    {
        var bytes = Encoding.UTF8.GetBytes(text + '\0');
        fixed (byte* input = bytes) value->Ctor_FromSequence(input, (nuint)bytes.Length - 1);
    }
    public void Dispose()
    {
        var value = macro;
        if (value == null) return;
        macro = null;
        try
        {
            for (var index = constructed - 2; index >= 0; index--) value->Lines[index].Dtor();
            if (constructed > 0) value->Name.Dtor();
        }
        finally { NativeMemory.Free(value); constructed = 0; }
    }
}
