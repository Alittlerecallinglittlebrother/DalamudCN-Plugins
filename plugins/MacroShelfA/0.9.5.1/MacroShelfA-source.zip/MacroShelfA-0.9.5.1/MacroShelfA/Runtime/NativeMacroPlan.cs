using System;
using System.Collections.Generic;
using System.Text;

namespace MacroShelfA.Runtime;

internal sealed record NativeMacroSegment(string ChildName, int ChildIndex, int FirstLineNumber, string[] Lines)
{
    // One-based original editor positions, including any skipped empty/comment lines.
    public int[] SourceLineNumbers { get; init; } = [];
}

// Pure preflight only: it does not parse waits, schedule rows or access game memory.
// Segment/child/line indexes are one-based. Lines are independent snapshots of the editor text.
internal sealed class NativeMacroPlan
{
    public const int LinesPerSegment = 15;
    // Conservative executor preflight bound, not a claim about a fixed native game limit.
    public const int MaximumLineUtf8Bytes = 1023;
    private static readonly UTF8Encoding StrictUtf8 = new(false, true);

    public string Name { get; }
    public int TotalChildren { get; }
    public IReadOnlyList<NativeMacroSegment> Segments { get; }
    public int TotalLines { get; }

    private NativeMacroPlan(string name, int totalChildren, List<NativeMacroSegment> segments, int totalLines)
    {
        Name = name;
        TotalChildren = totalChildren;
        Segments = segments.AsReadOnly();
        TotalLines = totalLines;
    }

    public static bool TryCreate(MacroEntry macro, bool allowLongMacros, out NativeMacroPlan? plan, out string error)
    {
        plan = null;
        error = string.Empty;
        if (macro == null) { error = "未选择要执行的宏。"; return false; }
        if (!IsValidNativeText(macro.Name ?? string.Empty))
        { error = "宏名称包含 NUL 或未配对的 Unicode 代理字符。"; return false; }

        // Copy membership before preflight, then copy all execution text before publishing a plan.
        MacroEntry[] children;
        if (macro.IsGroup)
        {
            if (macro.Children == null || macro.Children.Count == 0)
            { error = $"宏组“{macro.Name}”没有子宏，请先添加。"; return false; }
            if (macro.Children.Count > Configuration.MaxChildren)
            { error = $"每组最多 {Configuration.MaxChildren} 个子宏。"; return false; }
            children = macro.Children.ToArray();
        }
        else children = [macro];

        var prepared = new List<NativeMacroSegment>();
        var totalLines = 0;
        string? localStateCommand = null;
        string? localStateChild = null;
        var localStateLine = 0;
        for (var childIndex = 0; childIndex < children.Length; childIndex++)
        {
            var child = children[childIndex];
            if (child == null) { error = $"第 {childIndex + 1} 个子宏为空。"; return false; }
            if (child.IsGroup) { error = "宏组内不能再嵌套宏组。"; return false; }
            var childName = child.Name ?? string.Empty;
            var commands = child.Commands ?? string.Empty;
            if (!IsValidNativeText(childName))
            { error = $"第 {childIndex + 1} 个子宏名称包含 NUL 或未配对的 Unicode 代理字符。"; return false; }
            if (commands.Length > Configuration.MaxCommandLength)
            { error = $"“{childName}”超过 {Configuration.MaxCommandLength:N0} 字符，请拆分为多个子宏。"; return false; }
            if (!IsValidNativeText(commands))
            { error = $"“{childName}”包含 NUL 或未配对的 Unicode 代理字符。"; return false; }

            // Only CRLF is normalized. Do not trim command text, strip <wait>, or
            // round fractional waits: the game owns interpretation of actual commands.
            // Native empty slots can terminate a macro; omit editor blank/comment lines
            // (matching the old executor's omission), but retain their source positions.
            var lines = commands.Replace("\r\n", "\n", StringComparison.Ordinal).Split('\n');
            var commandLines = new List<string>();
            var sourceLineNumbers = new List<int>();
            for (var lineIndex = 0; lineIndex < lines.Length; lineIndex++)
            {
                var line = lines[lineIndex];
                if (string.IsNullOrWhiteSpace(line) || line.AsSpan().TrimStart().StartsWith("#", StringComparison.Ordinal))
                    continue;
                if (StrictUtf8.GetByteCount(line) > MaximumLineUtf8Bytes)
                { error = $"“{childName}”第 {lineIndex + 1} 行超过当前执行器的 {MaximumLineUtf8Bytes} 个 UTF-8 字节保护上限。"; return false; }
                if (line[0] != '/' || line.StartsWith("//", StringComparison.Ordinal))
                { error = $"“{childName}”第 {lineIndex + 1} 行必须以单个 / 开头（不自动修剪正文）。"; return false; }
                commandLines.Add(line);
                sourceLineNumbers.Add(lineIndex + 1);
                if (localStateCommand == null && TryGetLocalStateCommand(line, out var command))
                {
                    localStateCommand = command;
                    localStateChild = childName;
                    localStateLine = lineIndex + 1;
                }
            }
            if (commandLines.Count == 0)
            { error = $"“{childName}”没有有效命令，请先填写内容。"; return false; }

            var lineCount = commandLines.Count;
            if (!allowLongMacros && lineCount > LinesPerSegment)
            { error = $"“{childName}”有 {lineCount} 行有效命令，超过 {LinesPerSegment} 行；请开启“解除 15 行限制”后再执行。"; return false; }

            for (var offset = 0; offset < lineCount; offset += LinesPerSegment)
            {
                var count = Math.Min(LinesPerSegment, lineCount - offset);
                var snapshot = new string[count];
                var sourceSnapshot = new int[count];
                commandLines.CopyTo(offset, snapshot, 0, count);
                sourceLineNumbers.CopyTo(offset, sourceSnapshot, 0, count);
                prepared.Add(new NativeMacroSegment(childName, childIndex + 1, sourceSnapshot[0], snapshot)
                { SourceLineNumbers = sourceSnapshot });
            }
            totalLines += lineCount;
        }

        // Starting another native macro may reset shell-local flags. Until the runtime
        // explicitly carries them, reject the entire chain rather than silently alter it.
        if (prepared.Count > 1 && localStateCommand != null)
        {
            error = $"“{localStateChild}”第 {localStateLine} 行含 {localStateCommand}；原生多段执行暂不支持跨段宏锁或宏错误状态。未执行，宏正文未修改。";
            return false;
        }

        plan = new NativeMacroPlan(macro.Name ?? string.Empty, children.Length, prepared, totalLines);
        return true;
    }

    private static bool IsValidNativeText(string text)
    {
        if (text.Contains('\0')) return false;
        try { _ = StrictUtf8.GetByteCount(text); return true; }
        catch (EncoderFallbackException) { return false; }
    }

    private static bool TryGetLocalStateCommand(string line, out string command)
    {
        var tokenEnd = 1;
        while (tokenEnd < line.Length && !char.IsWhiteSpace(line[tokenEnd]) && line[tokenEnd] != '<') tokenEnd++;
        var token = line.AsSpan(0, tokenEnd);
        if (token.Equals("/mlock", StringComparison.OrdinalIgnoreCase) ||
            token.Equals("/macrolock", StringComparison.OrdinalIgnoreCase) ||
            token.Equals("/macroerror", StringComparison.OrdinalIgnoreCase) ||
            token.Equals("/merror", StringComparison.OrdinalIgnoreCase))
        {
            command = line[..tokenEnd];
            return true;
        }
        command = string.Empty;
        return false;
    }
}
