using System;

namespace MacroShelfA.Runtime;

internal enum NativeMacroReadiness { Pending, Ready, Unavailable }
internal enum NativeMacroRunState { Running, Completed, Interrupted, Unavailable }
internal readonly record struct NativeMacroProgress(NativeMacroRunState State, int ExecutedLines,
    double RemainingWait, string Detail = "");

// All host methods except Dispose are called by MacroExecutor on Framework.Update.
internal interface INativeMacroExecutionHost : IDisposable
{
    NativeMacroReadiness Prepare(out string detail);
    bool TryStart(NativeMacroSegment segment, string ownerName, out string error);
    NativeMacroProgress Poll();
    void CancelOwned();
}

// Native execution is deliberately separate from MacroSequence: no stripping of waits,
// per-line chat dispatch, JobChangeGuard, action retries or emulated action acknowledgements.
internal sealed class NativeMacroRunner(INativeMacroExecutionHost host) : IDisposable
{
    private NativeMacroPlan? plan;
    private int segmentIndex;
    private int completedLines;
    private bool segmentActive, stopRequested, disposed;
    private double startedAt;
    private double lastTickAt;
    private string runToken = "";
    public bool IsRunning => plan != null;
    public string CurrentMacroName => plan?.Name ?? "";
    public string CurrentChildName => plan?.Segments[segmentIndex].ChildName ?? "";
    public int CurrentChildIndex => plan?.Segments[segmentIndex].ChildIndex ?? 0;
    public int TotalChildren => plan?.TotalChildren ?? 0;
    public int TotalLines => plan?.TotalLines ?? 0;
    public int ExecutedLines { get; private set; }
    public int RemainingLines => Math.Max(0, TotalLines - ExecutedLines);
    public double RemainingWait { get; private set; }
    public string StatusText { get; private set; } = "原生宏候选执行器";
    public string ExecutionStopReason { get; private set; } = "";

    public bool TryStart(MacroEntry macro, bool allowLongMacros, double now, out string error)
    {
        error = "";
        if (disposed) { error = "原生执行器已卸载。"; return false; }
        if (IsRunning) { error = "已有宏正在执行或停止，请先等待结束。"; return false; }
        if (!double.IsFinite(now)) { error = "执行时钟无效。"; return false; }
        if (!NativeMacroPlan.TryCreate(macro, allowLongMacros, out var compiled, out error)) return false;
        plan = compiled!;
        segmentIndex = completedLines = ExecutedLines = 0;
        segmentActive = stopRequested = false;
        RemainingWait = 0;
        startedAt = lastTickAt = now;
        runToken = "MSA" + Guid.NewGuid().ToString("N")[..12];
        ExecutionStopReason = "";
        StatusText = "等待原生客户端校验";
        return true;
    }

    // Invalidate continuation immediately; native cancellation itself runs next Framework update.
    public void RequestStop()
    {
        if (!IsRunning) return;
        stopRequested = true;
        StatusText = "正在停止原生宏";
    }

    public void Tick(double now)
    {
        if (!IsRunning || disposed) return;
        var cancellationAttempted = false;
        try
        {
            if (stopRequested) { cancellationAttempted = true; host.CancelOwned(); Finish(""); return; }
            if (!double.IsFinite(now) || now < lastTickAt)
                throw new InvalidOperationException("原生执行时钟异常，已停止后续宏段。");
            lastTickAt = now;
            if (!segmentActive)
            {
                var ready = host.Prepare(out var detail);
                StatusText = detail;
                if (ready == NativeMacroReadiness.Pending)
                {
                    if (now - startedAt > 30) throw new InvalidOperationException("等待原生执行环境就绪超时；未启动原生宏。");
                    return;
                }
                if (ready == NativeMacroReadiness.Unavailable) throw new InvalidOperationException(detail);
                StartSegment();
                return;
            }
            var progress = host.Poll();
            ExecutedLines = completedLines + Math.Clamp(progress.ExecutedLines, 0, plan!.Segments[segmentIndex].Lines.Length);
            RemainingWait = double.IsFinite(progress.RemainingWait) ? Math.Max(0, progress.RemainingWait) : 0;
            StatusText = string.IsNullOrEmpty(progress.Detail) ? "游戏原生宏执行中" : progress.Detail;
            if (progress.State is NativeMacroRunState.Interrupted or NativeMacroRunState.Unavailable)
                throw new InvalidOperationException(string.IsNullOrEmpty(progress.Detail) ? "原生宏被取消或接管，已停止后续宏段。" : progress.Detail);
            if (progress.State != NativeMacroRunState.Completed) return;
            completedLines += plan.Segments[segmentIndex].Lines.Length;
            segmentActive = false;
            if (++segmentIndex == plan.Segments.Count) { Finish(""); return; }
            // Poll.Completed includes the audited native tail wait AND deferred-command queue.
            // No extra fixed delay is inserted. A boundary is still not advertised as frame-identical.
            StartSegment();
        }
        catch (Exception exception)
        {
            if (!cancellationAttempted)
                try { host.CancelOwned(); } catch { /* Never retry a native command. */ }
            Finish(exception.Message);
        }
    }

    private void StartSegment()
    {
        var segment = plan!.Segments[segmentIndex];
        // Name is only an ephemeral ownership tag, never a saved user macro name or slot.
        if (!host.TryStart(segment, runToken + segmentIndex.ToString("X4"), out var error))
            throw new InvalidOperationException(error);
        segmentActive = true;
        ExecutedLines = completedLines;
        RemainingWait = 0;
        StatusText = $"游戏原生执行 · 第 {segmentIndex + 1}/{plan.Segments.Count} 段";
    }

    private void Finish(string reason)
    {
        plan = null;
        segmentIndex = completedLines = ExecutedLines = 0;
        segmentActive = stopRequested = false;
        RemainingWait = 0;
        ExecutionStopReason = reason;
        StatusText = string.IsNullOrEmpty(reason) ? "原生执行已结束" : reason;
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        Finish("");
        // The production host marshals cancellation and hook teardown to the Framework thread.
        host.Dispose();
    }
}
