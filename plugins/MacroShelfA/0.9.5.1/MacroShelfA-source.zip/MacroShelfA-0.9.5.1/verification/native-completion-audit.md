# 匹配客户端原生宏完成 / 所有权契约审计

日期：2026-09-28。仅离线只读分析游戏 EXE、已安装 ClientStructs DLL 和上游源码；未启动游戏、未写游戏文件、未安装 hook、未修改候选工程。本文是静态证据，不是缺失动作已恢复的游戏验收。

## 1. 精确基线

- 游戏：`D:\Program Files\上海数龙科技有限公司\最终幻想XIV\game\ffxiv_dx11.exe`
- `ffxivgame.ver`：`2026.09.15.0000.0000`
- **正确 EXE SHA256**：`7BA28760BC53CBBBF66B63105FEA6C1BFE09CB6B1C6353FC8FB0FF03CC1A30F4`
- 已装 DLL：`C:\Users\Administrator\AppData\Roaming\XIVLauncherCN\addon\Hooks\dev\FFXIVClientStructs.dll`
- DLL SHA256：`D397764C6DD787C865E7422EA12C0C4DFF1AD5B5117F4047F6E033ECE5E84E77`
- PE preferred image base：`0x140000000`，以下均为 RVA，运行时不得把 preferred VA 当实际地址。
- 当前 DLL 中 ExecuteMacro / CancelMacro 原生签名唯一匹配：ExecuteMacro `0x912150`；CancelMacro `0x912320`。
- Update：`0x911B70`（从宏字段逻辑定位，并找到 UIModule 中调用点 `0x786A59`）。Update 在当前绑定未公开，不建议增加直地址调用。

已保存 decompile：`work/native-shell-binding.cs`。反汇编来自 capstone 5.0.9、pefile 2024.8.26。PE unwind 元数据把某些函数拆成多个子区间，不能将第一条 pdata 的 EndAddress 当作完整函数末尾；结论依据拼接完整控制流，而非自动函数截断。

## 2. ExecuteMacro 接受 / 拷贝语义

依据 `work/native-execute-full.asm`：

1. `0x91215B` 检查 shell+`0x2B3`（MacroLocked）。非零时不接纳新宏，可能根据 `SuppressMacroErrors` 显示提示，然后返回；无别的“空宏拒绝”检查。
2. `0x912283–0x91229E` 从 macro 复制 icon/name；shell 中临时宏对象根为+`0x330`，Name 为+`0x338`。
3. `0x9122B0–0x9122C4` 对 15 个 Utf8String 同步调用 `0x89300`，目标+`0x3A0`，每个 0x68 字节。
4. `0x89300` 会准备目的 buffer，然后从源字符串 buffer 拷贝数据，绝非仅保留源对象指针；见 `work/native-utf8-copy.asm`。
5. `0x9122D2` 写 MacroCurrentLine=0，`0x9122DE` 写 WaitTimeMs=0，清 suppress-errors 和若干宏临时标志/队列下标。它不执行首行；首行由后续 Update 处理。
6. 因而在该已审核客户端上，完整构造独立临时 Macro，调用绑定 ExecuteMacro 后可析构 Name / 15 行；无需使用用户的宏槽位。但保存到 shell 的 Name/Lines 仍可作为辅助归属指纹。

空宏也会被复制并成为 line=0，之后 Update 以空行终止；不能把 API 的 void 返回当动作成功，更不能认为空宏会被 ExecuteMacro 同步拒绝。

## 3. 末行 wait 与自然结束

依据 `work/native-update.asm`：

- `0x911C19`：line<0 时跳过宏取行段。
- `0x911C26–0x911C67`：用 QueryPerformanceCounter 及频率算整数毫秒；读取 `WaitStartTime.CpuMilliSeconds`（shell+`0x298`），比较 `nowMs - startMs` 与 `WaitTimeMs`（+`0x2A8`）。只有 **elapsed > WaitTimeMs** 才继续，等于时仍等待。
- 等待检查发生在终止检查之前。
- `0x911C81`：line>=15 时跳终止。
- `0x911C99–0x911C9F`：当前行 Utf8String 首字节=0 时直接跳终止，**不是跳过空行**。
- `0x911CB8`：执行本行前把行号+1。
- `0x912094–0x91209E`：自然终止直接写 line=-1 和 MacroLocked=false，**不调用 CancelMacro**。
- 所以自然末行之后的等待确实由游戏执行，不能在 line 达到总行数时提前启动下一块，也不能自行只按 <wait> 文本倒计时。
- 自然终止不会清 WaitTimeMs；**WaitTimeMs==0 不是完成条件**。

当前绑定 TimePoint 大小 0x18：Timestamp+0、CpuMilliSeconds+8、CpuMicroSeconds+0x10。只为显示剩余时间时可用 Stopwatch.GetTimestamp()/Stopwatch.Frequency 对应的 QPC ms，非负差值饱和算 `max(0,wait-elapsed)`，但显示值不得驱动接块。可不显示精确秒数，避免帧/整数误差。

## 4. 关键新增：原生确有表情短间隔延后队列

这是已证明的原生机制，但尚不能把录像中的缺失动作断言为该机制导致。

### Update 状态

已核实但当前绑定未命名字段（只能在精确 EXE/layout gate 之后只读）：

| offset | 类型 | 观察到的语义 |
|---|---|---|
| 0x2AF | byte | 本行执行时已有延后冷却，因此某些命令应跳过当前派发 |
| 0x2B0 | byte | 本行属于参与该延后节流机制的命令 |
| 0x2B5 | signed byte | SkippedMacroLines 当前消费下标 |
| 0x2B6 | signed byte | SkippedMacroLines 已写入条数，最多15 |
| 0x2B8 | float | 队列/节流冷却，常量0.16秒 |

- 取行后 `0x911CC6–0x911CE4`：若2B8>0，令2AF=1；每行先将2B0=0。
- 派发后 `0x91201B–0x912079`：若2B0=1且2AF=0，设置冷却0.16f；若2B0=1且2AF=1，将 MacroLineText 拷贝到 +0x9B8 的 SkippedMacroLines[count++]；2AF 在行末清零。
- `0x9120AD–0x9120FE`：冷却倒计时跨过0且 index<count 时，调用绑定 ExecuteCommandInner 对队列[index]派发，index++，再置0.16f。
- **该队列消费发生在自然 line=-1 之后也会执行的代码区**。line=-1 不能独立证明所有原生派发已经完成。
- ExecuteMacro 会清0x2B5/0x2B6；若未排空就启动下一块，会抹掉尚未消费的队列索引。

### 已定位表情使用此机制

`work/native-emote-caller-0x92b919.asm`：

- `0x92B86F` 无条件置 shell+2B0=1；
- `0x92B87C–0x92B883` 若 shell+2AF!=0，在进入 AgentEmote 前返回；
- 否则 `0x92B919` 调用 `AgentEmote.ExecuteEmote`，其 RVA `0xF3AF20` 与现有诊断审计一致。

**这是某类命令的原生短间隔节流/延后，不是一般性“失败后自动重试”。** 不应给插件增加盲目失败重试。逐行 ProcessChatBoxEntry 不会驱动这段 native Update 取行/队列逻辑；改成完整 ExecuteMacro 是有实证依据的兼容方向。仍需 A/B 录像/运行时追踪证明这支舞恢复。

## 5. CancelMacro 与归属

依据 `work/native-CancelMacro.asm` 开头（真实 CancelMacro 范围仅 0x912320–0x91233F）：

- line=-1；清 `MacroLocked` 和+0x2B4。
- 不清 WaitTimeMs、Name、Lines；不清 skipped queue 的 index/count/cooldown。
- 原生取消因此与自然结束都可留下相同的 Name/Lines 和 line=-1。
- 仅用 Name 或 line=-1 **不能识别外部取消**。
- **CancelMacro 已装生成绑定误标为 void，但匹配客户端实际返回 C++ bool（AL）且调用方使用它。** 0x912320读取旧line，shr eax,31后xor al,1；0x78169A调用后0x78169F执行 `test al,al`，条件控制取消提示。调用方证据：`work/native-caller-0x78169a.asm`。主动调用可沿用void绑定而忽略返回；**观察hook必须定义返回byte的精确native delegate，调用Original一次并原样return返回值**，否则void detour可能破坏游戏调用方的判断。函数地址仍从生成绑定获取并按已审计RVA校验，不按裸RVA直接调用。

可实现观察契约：

1. 精确进程EXE哈希 + 绑定layout + resolved Execute/Cancel RVA校验均通过后，才启用原生runner。函数调用使用现有绑定，不按RVA直调。
2. 观察 ExecuteMacro 与 CancelMacro，detour 每次只调 Original 一次，不改参数/返回。Execute采用生成void delegate；Cancel需按上段已证实际ABI使用自定义byte返回delegate，原样返回Original的byte。
3. OwnExecute/OwnCancel 使用作用域标记，且确认目标shell、线程/重入状态，防止把本人调用误判为外部。
4. 外部 Execute 只有在进入时 MacroLocked=false 才接受（本体唯一拒绝条件已证）；调用后确认归属指纹/line重置。锁住时的拒绝尝试不必判为接管。
5. 外部接受的 Execute 或外部 Cancel 使本次会话 ownership epoch 失效；runner 放弃后续块，**不得为清理自己的旧状态而 CancelMacro 别人的宏**。
6. 每次 Poll/Stop 还核对 shell 地址、独特 Name+15行内容、有效字段范围；不匹配则放弃所有权。这是旁路直接改字段的额外防护，不是防御任意第三方原始内存写入的完整证明。
7. 任意异常/脱离登录场景/布局不匹配 fail closed，不自动回退到旧逐行路径伪称原生。

## 6. 可实现完成谓词与长宏边界

完成判定前置：当前会话仍持有 ownership epoch，未观察外部 Cancel/接受的 Execute，指纹仍匹配，本轮已经成功接纳。

最终采用的最小边界完成谓词（与候选实现一致）：

```
MacroCurrentLine == -1
&& MacroLocked == false
&& 0 <= skippedIndex <= skippedCount <= 15
&& skippedIndex == skippedCount
&& float.IsFinite(cooldown)
```

该谓词的“末行wait到期”不是猜测：有第3节明确控制流证据；“最后延后队列已排空”由第4节补足。只有在此谓词成立后启动下一块。

自然块完成后从主线程后续tick启动下一块，在所有权/idle重新检查后执行。分段会额外引入帧边界，且每次 ExecuteMacro 重置 /macroerror、锁、宏上下文等；**多块长宏不是游戏原生存在的无限行单宏，不能承诺完全无缝等价**。无需偷偷写原生字段以维持跨块状态；可在插件规划层明确限制/提示特殊跨块宏状态。

本机静态证明可支持“≤15行原生块 + 末行wait及延后队列完整排空后续块”的实现与单元测试，不支持宣称已在游戏内稳定跑完整舞曲。

取消契约可定义为“停止本人当前原生宏和后续块；已提交/原生延后的动作不回滚”。CancelMacro 不清延后队列是游戏行为，不应为了表现为即时停止而直接清未知游戏字段。

## 7. 验证清单

- 本机已有 EXE 和 DLL hash、唯一签名匹配、同步 copy、Update自然结束和Cancel对比、队列写入/消费、实际表情入口均已静态核对。
- 需要自动化 tests：15行末行wait仍line=15不能续；line=-1但pending队列不能续；line=-1且队列已空时残余cooldown可自然继承、不额外等0.16秒；外部Cancel不续；拒绝的locked Execute不误判接管；接受的外部Execute后Stop不能取消其宏；invalid范围/NaN/corrupt指纹拒绝；空行原生终止；临时macro构造/析构异常恢复。
- 游戏验收仍未执行：相同宏文本、同BetterWait状态、同初始职业、同FPS条件下，原生槽位宏 vs 新runner、相同短片段A/B，确认蹦跳和前后动作并保留trace。

### 6.1 冷却继承的节拍取舍补充

本次候选最终采用**最小边界版**，不要求 `cooldown<=0`。它只是一种更保守的 idle 定义，不是“不丢待执行队列”的必要条件。ExecuteMacro 清队列下标但不清2B8；在 index==count（确无未派发队列）时，可接下一块并让游戏保留2B8，下一块的受节流命令会自行进入原生队列。这比强等冷却清零更接近连续原生取行时序。

因此可提供两种明确契约：
- 保守完全idle：末行等待完成、队列空、冷却<=0后接；每块边界可能增加约0.16秒。
- 最小接块：末行等待完成、队列空且各字段有效后接；自然继承2B8，不写任何计时字段。**本次实际舞蹈runner选定此种**，以免无必要加长节拍。

无论选择哪种，都不能在 index<count 时接块；必须处理外部取消/接管，且不能声称分块时间轴与无限原生宏严格等同。


