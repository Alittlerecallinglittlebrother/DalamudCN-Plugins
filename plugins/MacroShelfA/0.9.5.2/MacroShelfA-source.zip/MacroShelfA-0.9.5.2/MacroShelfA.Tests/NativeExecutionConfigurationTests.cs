using System.Text.Json;
using MacroShelfA;

internal static class NativeExecutionConfigurationTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool condition, string reason = "native execution configuration regression") => check(condition, reason);

        test("native execution defaults on for new and missing-field legacy configurations", () =>
        {
            Check(new Configuration().UseNativeMacroExecution && Configuration.CreateDefault().UseNativeMacroExecution);
            foreach (var version in new[] { 4, 8, 9 })
            {
                var json = $$"""{"Version":{{version}},"Macros":[{"Id":"old-id","Name":"旧宏","Commands":"/echo 原文 <wait.0.1>"}]}""";
                var systemText = JsonSerializer.Deserialize<Configuration>(json)!;
                var newtonsoft = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(json)!;
                systemText.Normalize(); newtonsoft.Normalize();
                Check(systemText.UseNativeMacroExecution && newtonsoft.UseNativeMacroExecution);
                Check(systemText.Version == 9 && systemText.Macros[0].Id == "old-id");
                Check(systemText.Macros[0].Commands == "/echo 原文 <wait.0.1>" && newtonsoft.Macros[0].Commands == systemText.Macros[0].Commands);
            }
        });

        test("explicit saved native opt-out survives load normalize save and reload", () =>
        {
            foreach (var version in new[] { 4, 8, 9 })
            foreach (var selected in new[] { false, true })
            {
                var json = JsonSerializer.Serialize(new { Version = version, UseNativeMacroExecution = selected,
                    Macros = new[] { new { Id = "saved-id", Name = "已保存", Commands = "/echo unchanged" } } });
                var systemText = JsonSerializer.Deserialize<Configuration>(json)!;
                var newtonsoft = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(json)!;
                systemText.Normalize(); newtonsoft.Normalize();
                Check(systemText.UseNativeMacroExecution == selected && newtonsoft.UseNativeMacroExecution == selected);
                newtonsoft.Save();
                var reloaded = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
                reloaded.Normalize();
                Check(reloaded.UseNativeMacroExecution == selected && reloaded.Macros[0].Id == "saved-id" &&
                    reloaded.Macros[0].Commands == "/echo unchanged");
            }
        });

        test("native execution selection persists without changing wait or macro data", () =>
        {
            var entry = new MacroEntry { Name = "持久化", Commands = "/echo A <wait.0.1>\n\n/wait 120\n/echo B" };
            foreach (var selected in new[] { true, false })
            {
                var configuration = new Configuration { UseNativeMacroExecution = selected, BetterWaitEnabled = false, AllowLongMacros = true, Macros = [entry] };
                configuration.Save();
                var restored = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
                restored.Normalize();
                Check(restored.UseNativeMacroExecution == selected && !restored.BetterWaitEnabled && restored.AllowLongMacros);
                Check(restored.Macros[0].Id == entry.Id && restored.Macros[0].Commands == entry.Commands);
            }
        });

        test("native execution optional v5 exchange field round trips both values", () =>
        {
            foreach (var selected in new[] { true, false })
            {
                var entry = new MacroEntry { Name = "交换", Commands = "/echo A <wait.0.5>\n/wait 120" };
                var configuration = new Configuration { UseNativeMacroExecution = selected, BetterWaitEnabled = true, Macros = [entry] };
                var json = ConfigurationExchange.Export(configuration);
                Check(json.Contains("\"Version\": 5") && json.Contains("\"UseNativeMacroExecution\":"));
                Check(ConfigurationExchange.TryImport(json, out var imported, out var error), error);
                Check(imported.UseNativeMacroExecution == selected && imported.BetterWaitEnabled);
                Check(imported.Macros[0].Commands == entry.Commands && imported.Macros[0].Id != entry.Id);
            }
        });

        test("missing exchange settings use native default while pre-v5 unknown fields stay ignored", () =>
        {
            for (var version = 1; version <= 5; version++)
            {
                var json = $$"""{"Format":"MacroShelfA","Version":{{version}},"Macros":[{"Name":"旧备份","Commands":"/echo old"}]}""";
                Check(ConfigurationExchange.TryImport(json, out var imported, out var error), error);
                Check(imported.UseNativeMacroExecution);
                if (version == 5) continue;
                json = $$"""{"Format":"MacroShelfA","Version":{{version}},"UseNativeMacroExecution":false,"Macros":[{"Name":"旧备份","Commands":"/echo old"}]}""";
                Check(ConfigurationExchange.TryImport(json, out imported, out error), error);
                Check(imported.UseNativeMacroExecution, "pre-v5 documents use the current default, not an unknown field");
            }
        });

        test("configuration snapshot backup includes native selection and remains immutable", () =>
        {
            var directory = Path.Combine(AppContext.BaseDirectory, "native-execution-backup-fixture", Guid.NewGuid().ToString("N"));
            var configuration = new Configuration { Version = 8, UseNativeMacroExecution = true, Macros = [new() { Name = "备份", Commands = "/echo original" }] };
            ConfigurationBackup.BeforeNativeIntegrationMigration(configuration, directory);
            var path = Path.Combine(directory, "config-before-native-integration-v9.json");
            var bytes = File.ReadAllBytes(path);
            var restored = JsonSerializer.Deserialize<Configuration>(bytes)!;
            Check(restored.UseNativeMacroExecution && restored.Version == 8 && restored.Macros[0].Commands == "/echo original");
            configuration.UseNativeMacroExecution = false;
            ConfigurationBackup.BeforeNativeIntegrationMigration(configuration, directory);
            Check(File.ReadAllBytes(path).SequenceEqual(bytes));
        });
    }
}
