using System.Numerics;
using System.Text.Json;
using System.Text.RegularExpressions;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

// Uses the real Classic settings page and themed task page, not recreated widgets.
internal static unsafe class NativeExecutionSettingsUi
{
    private const int Width = 1536, Height = 1024;
    private static int checks;

    public static void Run(string output)
    {
        Directory.CreateDirectory(output);
        checks = 0;
        var wasLoggedIn = Plugin.ClientState.IsLoggedIn;
        var previousScale = ImGuiHelpers.GlobalScale;
        Plugin.ClientState.IsLoggedIn = true;
        ImGuiHelpers.GlobalScale = 1;
        using var native = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory, "cimgui.dll"));
        ImGui.InitApi(native);
        var context = ImGui.CreateContext();
        try
        {
            var io = ImGui.GetIO();
            io.IniFilename = null;
            io.DeltaTime = 1f / 60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 17, default, io.Fonts.GetGlyphRangesChineseFull());
            Check(io.Fonts.Build(), "native execution settings font atlas");
            ImGui.StyleColorsDark();
            foreach (var theme in new[] { ShelfTheme.Classic, ShelfTheme.Persona3, ShelfTheme.Needy, ShelfTheme.Persona5 })
            {
                var entry = new MacroEntry { Name = "设置保护测试", Commands = "/wait 60\n/echo finished" };
                var configuration = new Configuration { Theme = theme, Macros = [entry], ReduceThemeMotion = true };
                using var executor = new MacroExecutor(configuration, () => 0);
                using var window = new MainWindow(configuration, executor, new BetterWaitPatch()) { Artwork = new ThemeUi.Artwork() };
                window.TestShowNativeExecutionSettings();
                Frame(window); Frame(window);
                Check(configuration.UseNativeMacroExecution, theme + ": new configuration must default to native execution");
                CheckExactNativeCopy(window, output, theme + "-default-enabled");
                SoftwareRenderer.Save(Path.Combine(output, $"native-default-{theme}-settings.png"));
                Click(window, "setting-native-execution");
                Check(!configuration.UseNativeMacroExecution, theme + ": explicit opt-out did not disable native execution");
                var reloaded = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
                reloaded.Normalize();
                Check(!reloaded.UseNativeMacroExecution, theme + ": explicit opt-out was not persisted across reload");
                CheckExactNativeCopy(window, output, theme + "-disabled");

                Click(window, "setting-native-execution");
                Check(configuration.UseNativeMacroExecution, theme + ": native toggle did not enable");
                Check(Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!.UseNativeMacroExecution,
                    theme + ": native toggle was not persisted");
                CheckExactNativeCopy(window, output, theme + "-enabled");
                Frame(window); Frame(window);
                SoftwareRenderer.Save(Path.Combine(output, $"native-execution-{theme}-settings.png"));
                Click(window, "setting-native-execution");
                Check(!configuration.UseNativeMacroExecution, theme + ": native toggle did not disable");
                Click(window, "setting-wait");
                Check(!configuration.BetterWaitEnabled, theme + ": wait toggle did not disable");
                Click(window, "setting-wait");
                Check(configuration.BetterWaitEnabled, theme + ": wait toggle did not enable");

                Check(executor.TryStart(entry, out var error), error);
                Click(window, "setting-native-execution");
                Click(window, "setting-wait");
                Check(executor.IsRunning && !configuration.UseNativeMacroExecution && configuration.BetterWaitEnabled,
                    theme + ": active execution allowed engine or wait settings to change");
                CheckExactNativeCopy(window, output, theme + "-running");
                Check(entry.Commands == "/wait 60\n/echo finished", theme + ": settings rewrote commands");
                executor.Stop(false);
                Click(window, "setting-native-execution");
                Check(configuration.UseNativeMacroExecution, theme + ": stopped execution left native toggle disabled");

                // Imported settings apply only to replace, never append.
                var backup = new Configuration
                {
                    UseNativeMacroExecution = false, BetterWaitEnabled = false, AllowLongMacros = true,
                    Macros = [new() { Name = "恢复测试", Commands = "/echo restored <wait.0.5>" }],
                };
                window.TestImport(ConfigurationExchange.Export(backup), false);
                Check(configuration.UseNativeMacroExecution && configuration.BetterWaitEnabled && !configuration.AllowLongMacros,
                    theme + ": append changed local engine/wait/line settings");
                Check(configuration.Macros.Count == 2 && configuration.Macros[0] == entry,
                    theme + ": append replaced existing macro contents");

                // Replacement stops the current sequence before applying global settings.
                configuration.UseNativeMacroExecution = false;
                Check(executor.TryStart(entry, out error), error);
                backup.UseNativeMacroExecution = true;
                window.TestImport(ConfigurationExchange.Export(backup), true);
                Check(!executor.IsRunning && configuration.UseNativeMacroExecution && !configuration.BetterWaitEnabled && configuration.AllowLongMacros,
                    theme + ": replacement did not stop and apply engine/wait/line settings");
                Check(configuration.Macros.Count == 1 && configuration.Macros[0].Commands == backup.Macros[0].Commands,
                    theme + ": replacement changed restored command text");

                const string legacy = """{"Format":"MacroShelfA","Version":5,"BetterWaitEnabled":true,"Macros":[{"Name":"旧备份","Commands":"/echo legacy"}]}""";
                window.TestImport(legacy, true);
                Check(configuration.UseNativeMacroExecution && configuration.BetterWaitEnabled,
                    theme + ": old replacement backup must use the current native default");
                window.TestShowNativeExecutionSettings(); Frame(window); Frame(window);
                Check(window.UiItems.ContainsKey("setting-native-execution"), theme + ": settings no longer reachable after replacement");
            }

            File.WriteAllText(Path.Combine(output, "native-execution-settings-ui-report.json"),
                JsonSerializer.Serialize(new { checks, themes = 4, nativeImGui = ImGui.GetVersion(), gameVerified = false }, new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine($"PASS native execution settings UI: {checks} assertions; Classic and 3 themed pages, toggle persistence, active-run lock, append/replace. Offline host, not game verification.");
        }
        catch
        {
            SoftwareRenderer.Save(Path.Combine(output, "native-execution-settings-ui-failure.png"));
            throw;
        }
        finally
        {
            SoftwareRenderer.ClearTextures();
            ImGui.DestroyContext(context);
            ImGuiHelpers.GlobalScale = previousScale;
            Plugin.ClientState.IsLoggedIn = wasLoggedIn;
        }
    }

    private static void Check(bool value, string message)
    {
        if (!value) throw new Exception(message);
        checks++;
    }

    private static void Frame(MainWindow window)
    {
        var io = ImGui.GetIO(); io.DisplaySize = new(Width, Height); io.DeltaTime = 1f / 60;
        window.UiItems.Clear(); window.ThemeRegions.Clear();
        ImGui.NewFrame(); window.PreDraw();
        ImGui.SetNextWindowPos(Vector2.Zero, ImGuiCond.Always);
        ImGui.SetNextWindowSize(new(Width, Height), ImGuiCond.Always);
        ImGui.Begin("NativeExecutionSettingsHost", window.Flags | ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoResize);
        window.Draw(); ImGui.End(); window.PostDraw(); ImGui.Render();
    }

    private static void CheckExactNativeCopy(MainWindow window, string output, string state)
    {
        // Record text emitted by the actual production widget, including enabled/running branches.
        var path = Path.GetFullPath(Path.Combine(output, "native-copy-" + state + ".txt"));
        File.WriteAllText(path, string.Empty);
        var io = ImGui.GetIO(); io.DisplaySize = new(Width, Height); io.DeltaTime = 1f / 60;
        ImGui.NewFrame();
        ImGui.SetNextWindowPos(Vector2.Zero, ImGuiCond.Always);
        ImGui.SetNextWindowSize(new(Width, Height), ImGuiCond.Always);
        ImGui.Begin("NativeExecutionCopyHost", ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoResize);
        ImGui.LogToFile(-1, path);
        window.TestDrawNativeExecutionSetting();
        ImGui.LogFinish();
        ImGui.End(); ImGui.Render();
        var actual = Regex.Replace(File.ReadAllText(path), @"\s+", string.Empty)
            .Replace("[x]", string.Empty).Replace("[ ]", string.Empty).Replace("[]", string.Empty);
        Check(actual == "原生宏执行整段交给游戏执行。", state + ": native settings text was not exactly the requested label and sentence: " + actual);
    }

    private static void Click(MainWindow window, string key)
    {
        var regionKey = window.ThemeRegions.ContainsKey("classic-settings") ? "classic-settings" : "task-body";
        for (var n = 0; n < 20; n++)
        {
            window.ScrollRequests[regionKey] = n * 65; Frame(window); Frame(window);
            if (window.UiItems.TryGetValue(key, out var candidate) && window.ThemeRegions.TryGetValue(regionKey, out var clip) &&
                candidate.Min.Y >= clip.Min.Y && candidate.Max.Y <= clip.Max.Y) break;
        }
        Check(window.UiItems.TryGetValue(key, out var rect), "native settings control unavailable: " + key);
        var point = (rect.Min + rect.Max) / 2;
        Check(point.X >= 0 && point.X < Width && point.Y >= 0 && point.Y < Height, "native settings control outside viewport: " + key);
        var io = ImGui.GetIO(); io.AddMousePosEvent(point.X, point.Y); Frame(window);
        io.AddMouseButtonEvent(0, true); Frame(window);
        io.AddMouseButtonEvent(0, false); Frame(window); Frame(window);
    }
}

namespace MacroShelfA.Windows
{
    // Test-only access to existing navigation, never included in the shipped plugin.
    internal sealed partial class MainWindow
    {
        internal void TestShowNativeExecutionSettings()
        {
            page = Page.Settings;
            NavigateTask(TaskPage.Execution);
        }

        internal void TestDrawNativeExecutionSetting() => DrawNativeMacroExecutionSetting();
    }
}
