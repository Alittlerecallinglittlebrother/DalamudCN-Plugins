using MacroShelfA;
using MacroShelfA.Runtime;

// Exercises production MacroExecutor through its actual Framework.Update subscription.
// Only the native shell and job-change boundaries are faked; no native game function runs.
internal static class NativeExecutorIntegrationTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        void Check(bool value, string message = "native executor integration regression") => check(value, message);
        void Test(string name, Action body) => test("native-executor: " + name, () =>
        {
            var subscribers = Plugin.Framework.Subscribers;
            var loggedIn = Plugin.ClientState.IsLoggedIn;
            Plugin.ClientState.IsLoggedIn = true;
            try { body(); }
            finally
            {
                Plugin.ClientState.IsLoggedIn = loggedIn;
                Check(Plugin.Framework.Subscribers == subscribers, "executor leaked its Framework.Update subscription");
            }
        });
        MacroEntry Leaf(string text = "/echo original <wait.0.5>", string name = "原生测试") => new() { Name = name, Commands = text };
        void Start(MacroExecutor executor, MacroEntry entry) => Check(executor.TryStart(entry, out var error), error);

        Test("default native execution queues original macro until framework and bypasses every legacy host call", () =>
        {
            var configuration = new Configuration();
            var native = new NativeHost(); var legacyTrap = new JobHost { RejectCalls = true };
            using var executor = new MacroExecutor(configuration, () => 0, legacyTrap, native);
            const string text = "/gs change 6<wait.0.2>\n/ac 即刻咏唱<wait.1.5>\n/victorypose<wait.4>";
            var sent = Plugin.CommandManager.Sent.Count; var errors = Plugin.ChatGui.Errors.Count;
            Start(executor, Leaf(text));
            Check(executor.IsRunning && executor.TotalLines == 3 && !executor.IsWaitingForJobChange);
            Check(native.Calls.Count == 0 && legacyTrap.Calls.Count == 0 && executor.ExecutionBackendName.Contains("ExecuteMacro"));
            Plugin.Framework.Tick();
            Check(native.Prepares == 1 && native.StartAttempts == 1 && native.Polls == 0);
            Check(native.Starts[0].Lines.SequenceEqual(text.Split('\n')), "native executor changed original waits or command text");
            native.Progress = new(NativeMacroRunState.Running, 1, 0.2); Plugin.Framework.Tick();
            Check(executor.IsRunning && executor.ExecutedLines == 1 && executor.RemainingWait == 0.2 && !executor.IsWaitingForJobChange);
            Check(legacyTrap.Calls.Count == 0 && Plugin.CommandManager.Sent.Count == sent && Plugin.ChatGui.Errors.Count == errors);
        });

        Test("selected native backend and long-macro plan remain frozen despite config edits", () =>
        {
            var configuration = new Configuration { UseNativeMacroExecution = true, AllowLongMacros = true };
            var native = new NativeHost(); var legacyTrap = new JobHost { RejectCalls = true };
            using var executor = new MacroExecutor(configuration, () => 0, legacyTrap, native);
            var entry = Leaf(string.Join('\n', Enumerable.Range(1, 16).Select(i => $"/echo {i}")));
            Start(executor, entry);
            configuration.UseNativeMacroExecution = false; configuration.AllowLongMacros = false;
            entry.Commands = "/echo edited"; entry.Name = "已编辑";
            Plugin.Framework.Tick();
            Check(native.StartAttempts == 1 && executor.CurrentMacroName == "原生测试" && executor.TotalLines == 16);
            Check(executor.ExecutionBackendName.Contains("ExecuteMacro") && native.Starts[0].Lines.Length == 15);
            native.Progress = new(NativeMacroRunState.Completed, 15, 0); Plugin.Framework.Tick();
            Check(native.StartAttempts == 2 && native.Starts[1].Lines.SequenceEqual(["/echo 16"]) && executor.IsRunning);
            native.Progress = new(NativeMacroRunState.Completed, 1, 0); Plugin.Framework.Tick();
            Check(!executor.IsRunning && legacyTrap.Calls.Count == 0 && executor.ExecutionBackendName.Contains("ProcessChatBoxEntry"));
        });

        Test("explicit legacy opt-out freezes backend while using existing wait stripping", () =>
        {
            var configuration = new Configuration { UseNativeMacroExecution = false }; var native = new NativeHost { RejectCalls = true }; var legacy = new JobHost();
            var now = 0.0; var waitChecks = 0;
            using var executor = new MacroExecutor(configuration, () => now, legacy, native, () => { waitChecks++; return false; });
            Check(!configuration.UseNativeMacroExecution);
            Start(executor, Leaf("/echo A <wait.1>\n/echo B"));
            configuration.UseNativeMacroExecution = true;
            Plugin.Framework.Tick();
            Check(legacy.Sent.SequenceEqual(["/echo A"]) && executor.IsRunning && executor.ExecutionBackendName.Contains("ProcessChatBoxEntry"));
            now = 0.9; Plugin.Framework.Tick(); Check(legacy.Sent.Count == 1);
            now = 1; Plugin.Framework.Tick();
            Check(legacy.Sent.SequenceEqual(["/echo A", "/echo B"]) && !executor.IsRunning);
            Check(native.Calls.Count == 0 && waitChecks == 0, "legacy execution must not require native preparation or wait-patch readiness");
        });

        Test("unavailable native host reports once without falling back to legacy dispatch", () =>
        {
            var configuration = new Configuration { UseNativeMacroExecution = true };
            var native = new NativeHost { Readiness = NativeMacroReadiness.Unavailable, Detail = "候选客户端校验失败" };
            var legacyTrap = new JobHost { RejectCalls = true };
            using var executor = new MacroExecutor(configuration, () => 0, legacyTrap, native);
            var sent = Plugin.CommandManager.Sent.Count; var errors = Plugin.ChatGui.Errors.Count;
            Start(executor, Leaf()); Plugin.Framework.Tick();
            Check(!executor.IsRunning && native.StartAttempts == 0 && legacyTrap.Calls.Count == 0);
            Check(Plugin.ChatGui.Errors.Count == errors + 1 && Plugin.ChatGui.Errors[^1].Contains("候选客户端校验失败"));
            var calls = native.Calls.Count; Plugin.Framework.Tick();
            Check(native.Calls.Count == calls && Plugin.ChatGui.Errors.Count == errors + 1 && Plugin.CommandManager.Sent.Count == sent);
        });

        Test("Stop keeps queued and active native work busy until framework cancellation", () =>
        {
            foreach (var alreadyStarted in new[] { false, true })
            {
                var configuration = new Configuration { UseNativeMacroExecution = true, AllowLongMacros = true };
                var native = new NativeHost { Progress = new(NativeMacroRunState.Completed, 15, 0) };
                var legacyTrap = new JobHost { RejectCalls = true };
                using var executor = new MacroExecutor(configuration, () => 0, legacyTrap, native);
                Start(executor, Leaf(string.Join('\n', Enumerable.Repeat("/echo line", 16))));
                if (alreadyStarted) Plugin.Framework.Tick();
                var calls = native.Calls.Count;
                executor.Stop(false); configuration.UseNativeMacroExecution = false;
                Check(executor.IsRunning && executor.NativeStatusText.Contains("正在停止") && native.Calls.Count == calls);
                Check(!executor.TryStart(Leaf("/echo must-not-start"), out var error) && error.Contains("已有"));
                Plugin.Framework.Tick();
                Check(!executor.IsRunning && native.Cancels == 1 && native.Polls == 0 && native.StartAttempts == (alreadyStarted ? 1 : 0));
                Check(legacyTrap.Calls.Count == 0);
            }
        });

        Test("logout cancels native work on framework and cannot start another macro", () =>
        {
            foreach (var alreadyStarted in new[] { false, true })
            {
                Plugin.ClientState.IsLoggedIn = true;
                var native = new NativeHost(); var legacyTrap = new JobHost { RejectCalls = true };
                using var executor = new MacroExecutor(new Configuration { UseNativeMacroExecution = true }, () => 0, legacyTrap, native);
                Start(executor, Leaf()); if (alreadyStarted) Plugin.Framework.Tick();
                Plugin.ClientState.IsLoggedIn = false; Plugin.Framework.Tick();
                Check(!executor.IsRunning && native.Cancels == 1 && native.StartAttempts == (alreadyStarted ? 1 : 0) && native.Polls == 0);
                Check(!executor.TryStart(Leaf(), out var error) && error.Contains("登录"));
                Check(legacyTrap.Calls.Count == 0);
            }
        });

        Test("failed wait-patch readiness rejects native preflight but not legacy mode", () =>
        {
            var configuration = new Configuration { UseNativeMacroExecution = true };
            var native = new NativeHost(); var legacy = new JobHost(); var readiness = false; var waitChecks = 0;
            using var executor = new MacroExecutor(configuration, () => 0, legacy, native, () => { waitChecks++; return readiness; });
            Check(!executor.TryStart(Leaf(), out var error) && error.Contains("等待补丁"));
            Plugin.Framework.Tick();
            Check(!executor.IsRunning && waitChecks == 1 && native.Calls.Count == 0 && legacy.Calls.Count == 0);
            configuration.UseNativeMacroExecution = false;
            Start(executor, Leaf("/echo legacy")); Plugin.Framework.Tick();
            Check(!executor.IsRunning && legacy.Sent.SequenceEqual(["/echo legacy"]) && waitChecks == 1 && native.Calls.Count == 0);
            configuration.UseNativeMacroExecution = true; readiness = true;
            Start(executor, Leaf()); Plugin.Framework.Tick();
            Check(executor.IsRunning && waitChecks == 2 && native.StartAttempts == 1 && legacy.Sent.Count == 1);
        });

        Test("saved hotbar run command resolves group and child through same native executor", () =>
        {
            var child = Leaf("/echo child <wait.0.1>", "目标子宏");
            var group = new MacroEntry { Name = "入口宏组", IsGroup = true, Children = [Leaf("/echo first", "首段"), child] };
            var configuration = new Configuration { UseNativeMacroExecution = true, Macros = [group] };
            var native = new NativeHost(); var legacyTrap = new JobHost { RejectCalls = true };
            using var executor = new MacroExecutor(configuration, () => 0, legacyTrap, native);
            Check(MacroRunCommand.TryRun("run " + child.Id, configuration.Macros, executor.TryStart, out var error), error);
            Check(executor.CurrentMacroName == "目标子宏" && executor.TotalChildren == 1 && native.StartAttempts == 0);
            Plugin.Framework.Tick(); Check(native.Starts[0].Lines.SequenceEqual(["/echo child <wait.0.1>"]));
            Check(!MacroRunCommand.TryRun("run " + group.Id, configuration.Macros, executor.TryStart, out error) && error.Contains("已有"));
            native.Progress = new(NativeMacroRunState.Completed, 1, 0); Plugin.Framework.Tick();
            Check(MacroRunCommand.TryRun("run " + group.Id, configuration.Macros, executor.TryStart, out error), error);
            Check(executor.CurrentMacroName == "入口宏组" && executor.TotalChildren == 2);
            Plugin.Framework.Tick(); Check(native.Starts[1].ChildName == "首段");
            Plugin.Framework.Tick(); Check(native.Starts[2].ChildName == "目标子宏" && legacyTrap.Calls.Count == 0);
        });

        Test("long native macro waits for tail wait and queue drain before continuation", () =>
        {
            var rows = Enumerable.Range(1, 16).Select(i => i == 15 ? "/dance <wait.0.7>" : $"/echo {i}").ToArray();
            var native = new NativeHost(); var legacyTrap = new JobHost { RejectCalls = true }; var now = 0.0;
            using var executor = new MacroExecutor(new Configuration { UseNativeMacroExecution = true, AllowLongMacros = true }, () => now, legacyTrap, native);
            Start(executor, Leaf(string.Join('\n', rows))); Plugin.Framework.Tick();
            Check(native.Starts[0].Lines[^1] == "/dance <wait.0.7>" && native.StartAttempts == 1);
            native.Progress = new(NativeMacroRunState.Running, 15, 0.7, "尾行等待"); now = 1; Plugin.Framework.Tick();
            Check(executor.ExecutedLines == 15 && executor.RemainingWait == 0.7 && native.StartAttempts == 1);
            native.Progress = new(NativeMacroRunState.Running, 15, 0, "队列仍有动作"); now = 2; Plugin.Framework.Tick();
            now = 100; Plugin.Framework.Tick();
            Check(executor.IsRunning && native.StartAttempts == 1 && executor.NativeStatusText == "队列仍有动作");
            native.Progress = new(NativeMacroRunState.Completed, 15, 0); Plugin.Framework.Tick();
            Check(native.StartAttempts == 2 && native.Starts[1].Lines.SequenceEqual(["/echo 16"]) && executor.ExecutedLines == 15);
            Check(legacyTrap.Calls.Count == 0);
        });

        Test("native host start exception terminates without legacy fallback or command retry", () =>
        {
            var native = new NativeHost { ThrowOnStart = true }; var legacyTrap = new JobHost { RejectCalls = true };
            using var executor = new MacroExecutor(new Configuration { UseNativeMacroExecution = true }, () => 0, legacyTrap, native);
            var errors = Plugin.ChatGui.Errors.Count; var sent = Plugin.CommandManager.Sent.Count;
            Start(executor, Leaf()); Plugin.Framework.Tick(); Plugin.Framework.Tick();
            Check(!executor.IsRunning && native.StartAttempts == 1 && native.Cancels == 1 && legacyTrap.Calls.Count == 0);
            Check(Plugin.ChatGui.Errors.Count == errors + 1 && Plugin.ChatGui.Errors[^1].Contains("native-start-error") && Plugin.CommandManager.Sent.Count == sent);
        });

        Test("dispose unregisters framework event and disposes native host exactly once", () =>
        {
            var subscribers = Plugin.Framework.Subscribers;
            var native = new NativeHost(); var legacyTrap = new JobHost { RejectCalls = true };
            using var executor = new MacroExecutor(new Configuration { UseNativeMacroExecution = true }, () => 0, legacyTrap, native);
            Check(Plugin.Framework.Subscribers == subscribers + 1);
            Start(executor, Leaf()); Plugin.Framework.Tick();
            executor.Dispose(); executor.Dispose();
            Check(!executor.IsRunning && native.Disposals == 1 && Plugin.Framework.Subscribers == subscribers);
            var calls = native.Calls.Count; Plugin.Framework.Tick();
            Check(native.Calls.Count == calls && legacyTrap.Calls.Count == 0);
        });
    }

    private sealed class JobHost : IJobChangeHost
    {
        public bool RejectCalls;
        public readonly List<string> Calls = [];
        public readonly List<string> Sent = [];
        public JobChangeSnapshot ReadState()
        {
            Touch("read");
            return new(true, 123, 0x10203040, 33, 33, 33, 5);
        }
        public byte? GetGearsetJob(int zeroBasedIndex) { Touch("lookup"); return 33; }
        public bool SendCommand(string command) { Touch("send"); Sent.Add(command); return true; }
        private void Touch(string call)
        {
            Calls.Add(call);
            if (RejectCalls) throw new InvalidOperationException("native execution entered legacy JobChangeGuard/dispatch: " + call);
        }
    }

    private sealed class NativeHost : INativeMacroExecutionHost
    {
        public NativeMacroReadiness Readiness = NativeMacroReadiness.Ready;
        public NativeMacroProgress Progress = new(NativeMacroRunState.Running, 0, 0);
        public string Detail = "ready";
        public bool RejectCalls, ThrowOnStart;
        public readonly List<string> Calls = [];
        public readonly List<NativeMacroSegment> Starts = [];
        public int Prepares, StartAttempts, Polls, Cancels, Disposals;
        public NativeMacroReadiness Prepare(out string detail)
        {
            Touch("prepare"); Prepares++; detail = Detail; return Readiness;
        }
        public bool TryStart(NativeMacroSegment segment, string ownerName, out string error)
        {
            Touch("start"); StartAttempts++;
            if (ThrowOnStart) throw new InvalidOperationException("native-start-error");
            Starts.Add(segment); error = ""; return true;
        }
        public NativeMacroProgress Poll() { Touch("poll"); Polls++; return Progress; }
        public void CancelOwned() { Touch("cancel"); Cancels++; }
        public void Dispose() { Calls.Add("dispose"); Disposals++; }
        private void Touch(string call)
        {
            Calls.Add(call);
            if (RejectCalls) throw new InvalidOperationException("legacy execution entered native shell: " + call);
        }
    }
}
