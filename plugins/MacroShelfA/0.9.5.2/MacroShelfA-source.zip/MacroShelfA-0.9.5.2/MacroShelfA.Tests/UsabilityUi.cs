using System.Numerics;
using System.Text.Json;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

internal static unsafe class UsabilityUi
{
    private static int width=1536,height=1024,checks;
    private static string output="";
    private static MainWindow window=null!;
    private static QuickBarWindow bar=null!;
    private static void Check(bool value,string message){if(!value)throw new Exception(message);checks++;}
    private sealed class Display:ISkillDisplayProvider
    {
        public SkillDisplaySnapshot GetSnapshot(uint id)=>id==0?SkillDisplaySnapshot.Unknown:new(SkillAvailability.Ready,id,0,0,1,2,0,100);
        public SkillCatalogEntry? GetSkill(uint id)=>id==0?null:new(id,"示例技能",0);
    }
    public static void Run(string directory)
    {
        output=directory;Directory.CreateDirectory(output);checks=0;
        using var native=new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory,"cimgui.dll"));ImGui.InitApi(native);var context=ImGui.CreateContext();
        try
        {
            var io=ImGui.GetIO();io.IniFilename=null;io.DeltaTime=1f/60;io.ConfigInputTextCursorBlink=false;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc",17,default,io.Fonts.GetGlyphRangesChineseFull());Check(io.Fonts.Build(),"font atlas");ImGui.StyleColorsDark();
            var config=new Configuration{UseNativeMacroExecution=false,Theme=ShelfTheme.Needy,AllowLongMacros=true};config.Normalize();
            Check(!config.AdvancedWorkbench&&config.ShowGettingStarted,"beginner defaults not additive");
            using var executor=new MacroExecutor(config,()=>0);
            using var main=new MainWindow(config,executor,new BetterWaitPatch()){Artwork=new ThemeUi.Artwork(),SkillDisplay=new Display()};window=main;
            bar=new QuickBarWindow(config,executor,window,window.SkillDisplay,_=>{});window.DrawQuickDock=bar.DrawDocked;
            var imports=0;MacroEntry? display=null,bridge=null;window.OpenNativeMacroImport=()=>imports++;window.OpenDisplaySettings=m=>display=m;window.OpenNativeMacroBridge=m=>bridge=m;
            Capture("beginner-empty-needy.png",1536,1024);
            Check(window.UiItems.ContainsKey("welcome-example")&&!window.UiItems.ContainsKey("edit-run"),"empty state has no onboarding or can run");
            Click("welcome-import");Check(imports==1&&config.Macros.Count==0&&!executor.IsRunning,"welcome import automatically writes/runs");
            Click("welcome-example");var entry=window.TestSelected!;
            Check(config.Macros.Count==1&&entry.Commands.StartsWith("/echo")&&!executor.IsRunning,"example creation did not open an editable, idle macro");
            Check(window.ThemeRegions.ContainsKey("guide")&&!window.TestLayout.HasSide,"simple mode still exposes advanced cards");
            Click("guide-dismiss");Check(!config.ShowGettingStarted&&!Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!.ShowGettingStarted,"guide dismissal not saved");
            Click("nav-help");Check(window.ThemeRegions.ContainsKey("guide"),"help cannot be reopened");
            Click("guide-dismiss");
            Click("filter-favorites");Click("new-macro");var created=window.TestSelected!;
            Check(created!=entry&&window.UiItems.ContainsKey("tree-"+created.Id),"new macro hidden by favorites filter");
            Check(!executor.IsRunning&&config.Macros.Count==2,"new macro automatically ran or replaced existing content");
            config.Macros.Remove(created);window.TestRefresh();window.TestOpen(entry);Frame();
            foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})
            {
                SelectTheme(theme);Capture($"beginner-{theme}-1536.png",1536,1024);
                Check(!window.UiItems.ContainsKey("direct-display")&&!window.UiItems.ContainsKey("direct-bridge")&&!window.UiItems.ContainsKey("delete"),"advanced tasks or delete crowd the main simple screen");
                Click("entry-more");Click("direct-display");Check(display==entry&&!executor.IsRunning,"simple optional skill lost target");
                Click("entry-more");Click("direct-bridge");Check(bridge==entry&&!executor.IsRunning,"simple optional hotbar lost target");
                Click("edit-run");Check(executor.IsRunning,"simple run not connected");Click("stop");Check(!executor.IsRunning,"simple stop not connected");
                Capture($"beginner-{theme}-720.png",720,500);CheckCompact();
                Click("nav-help");Capture($"beginner-guide-{theme}-1536.png",1536,1024);Capture($"beginner-guide-{theme}-720.png",720,500);CheckCompact();
                io.FontGlobalScale=1.3f;Capture($"beginner-font130-{theme}-720.png",720,500);CheckCompact();
                Click("guide-dismiss");io.FontGlobalScale=1;
                Resize(1536,1024);var before=JsonSerializer.Serialize(config.Macros);Click("mode-advanced");
                Check(config.AdvancedWorkbench&&window.UiItems.ContainsKey("direct-display"),"advanced panel cannot be reached");
                Check(JsonSerializer.Serialize(config.Macros)==before,"switch to advanced changed data");
                Click("mode-simple");Check(!config.AdvancedWorkbench&&JsonSerializer.Serialize(config.Macros)==before,"return to simple changed data");
            }
            // Reproduce the reported eighth-line selection, including independent font/UI scaling.
            var lines=Enumerable.Range(1,8).Select(i=>$"/echo 第{i}行中文 · 最后一行对齐测试 123 <wait.0.2> "+new string('长',80)).ToArray();entry.Commands=string.Join('\n',lines);
            var lastOffset=lines.Take(7).Sum(l=>l.Length+1);
            foreach(var advanced in new[]{false,true})foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})
            foreach(var scale in new[]{(Ui:1f,Font:1f),(Ui:1f,Font:1.3f),(Ui:1.25f,Font:1.25f),(Ui:1.5f,Font:1.5f),(Ui:2f,Font:2f)})
            {
                config.AdvancedWorkbench=advanced;config.Theme=theme;ImGuiHelpers.GlobalScale=scale.Ui;io.FontGlobalScale=scale.Font;
                Resize((int)(1536*scale.Ui),(int)(1024*scale.Ui));window.TestOpen(entry);for(var n=0;n<25;n++)Frame();
                var editor=window.TestCodeEditor;var point=editor.TestOrigin+new Vector2(1,editor.TestLineHeight*7.5f);
                Check(point.Y<editor.TestMaximum.Y,"eighth line must fit alignment fixture");ClickAt(point);
                var state=ImGui.GetCurrentContext().InputTextState;
                Check(state.Stb.Cursor==lastOffset,$"mouse eighth-line start mismatch: advanced={advanced}, {theme}, {scale}, actual={state.Stb.Cursor}, expected={lastOffset}");
                Check(MathF.Abs(ImGui.GetCurrentContext().PlatformImeData.InputLineHeight-editor.TestLineHeight)<.01f,"overlay and native selection have different line height");
                Key(ImGuiKey.End,shift:true);state=ImGui.GetCurrentContext().InputTextState;
                var lo=Math.Min(state.Stb.SelectStart,state.Stb.SelectEnd);var hi=Math.Max(state.Stb.SelectStart,state.Stb.SelectEnd);
                Check(lo==lastOffset&&hi==entry.Commands.Length,"select last line includes penultimate line");
                Check(state.ScrollX>0,"long line did not scroll horizontally");
                if(advanced&&scale==(1f,1f))SoftwareRenderer.Save(Path.Combine(output,$"selection-last-line-{theme}.png"));
                Key(ImGuiKey.Home,ctrl:true);io.AddInputCharacter('中');Frame();Check(entry.Commands.StartsWith("中/echo"),"CJK caret insertion offset");
                Key(ImGuiKey.Z,ctrl:true);Check(entry.Commands==string.Join('\n',lines),"native undo lost source");
                Click("nav-settings");Click("nav-editor");
            }
            ImGuiHelpers.GlobalScale=1;io.FontGlobalScale=1;config.AdvancedWorkbench=false;config.Theme=ShelfTheme.Needy;config.ShowGettingStarted=false;
            // Drag the native vertical scrollbar while horizontally scrolled. It
            // owns ActiveId during the drag but must retain the same text origin.
            entry.Commands=string.Join('\n',Enumerable.Range(1,120).Select(i=>lines[i%8]));window.TestOpen(entry);Resize(1536,1024);
            ClickAt(window.TestCodeEditor.TestOrigin+new Vector2(2,8));Key(ImGuiKey.End);
            var horizontalOrigin=window.TestCodeEditor.TestOrigin.X;var scrollbar=new Vector2(window.TestCodeEditor.TestMaximum.X+7,window.TestCodeEditor.TestMinimum.Y+10);
            io.AddMousePosEvent(scrollbar.X,scrollbar.Y);Frame();io.AddMouseButtonEvent(0,true);Frame();
            Check(ImGui.GetCurrentContext().ActiveId!=ImGui.GetCurrentContext().InputTextState.ID,"scrollbar drag fixture did not transfer native active ID");
            Check(MathF.Abs(window.TestCodeEditor.TestOrigin.X-horizontalOrigin)<.01f,"dragging vertical scrollbar reset highlighted horizontal origin");
            io.AddMousePosEvent(scrollbar.X,scrollbar.Y+65);Frame();
            Check(MathF.Abs(window.TestCodeEditor.TestOrigin.X-horizontalOrigin)<.01f,"scroll drag separated native selection and painted text");
            io.AddMouseButtonEvent(0,false);Frame();Click("nav-settings");Click("nav-editor");
            // A readable reproduction of the user's eight-line selection, not
            // private screenshot content and not a mock-up of the editor.
            var readable=Enumerable.Range(1,8).Select(i=>$"/echo 第 {i} 行：编辑自动保存；只选中当前这一行").ToArray();
            entry.Commands=string.Join('\n',readable);
            foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})
            {
                config.Theme=theme;window.TestOpen(entry);Resize(1536,1024);for(var n=0;n<25;n++)Frame();
                ClickAt(window.TestCodeEditor.TestOrigin+new Vector2(1,window.TestCodeEditor.TestLineHeight*7.5f));Key(ImGuiKey.End,shift:true);
                var selected=ImGui.GetCurrentContext().InputTextState.Stb;
                Check(Math.Min(selected.SelectStart,selected.SelectEnd)==readable.Take(7).Sum(l=>l.Length+1)&&Math.Max(selected.SelectStart,selected.SelectEnd)==entry.Commands.Length,"readable last-line selection includes another line");
                SoftwareRenderer.Save(Path.Combine(output,$"last-line-aligned-{theme}.png"));Click("nav-settings");Click("nav-editor");
            }
            config.Theme=ShelfTheme.Needy;
            entry.Commands="/echo 原始内容";
            for(var i=1;i<=24;i++)config.Macros.Add(new MacroEntry{Name=$"宏 {i:00} · 列表滚动测试",Commands="/echo test",Pinned=true,DisplayActionId=1});config.Normalize();
            var last=config.Macros[^1];window.TestOpen(last);Resize(1280,800);for(var i=0;i<8;i++)Frame();
            Check(window.UiItems.TryGetValue("tree-"+last.Id,out var lastRow),"last macro was not revealed");
            var tree=window.ThemeRegions["tree-list"];Check(lastRow.Min.Y>=tree.Min.Y-1&&lastRow.Max.Y<=tree.Max.Y+1,"last macro row clipped after reveal");
            Check(window.TestSelected==last&&!executor.IsRunning,"last-row selection changed target or ran");Capture("beginner-last-macro.png",1280,800);
            foreach(var theme in new[]{ShelfTheme.Persona3,ShelfTheme.Needy,ShelfTheme.Persona5})foreach(var sample in new[]{(W:1280,H:800,Scale:1f,Font:1f),(W:1280,H:800,Scale:1f,Font:1.3f),(W:1920,H:1200,Scale:1.5f,Font:1.5f)})
            {
                config.Theme=theme;ImGuiHelpers.GlobalScale=sample.Scale;io.FontGlobalScale=sample.Font;Resize(sample.W,sample.H);for(var n=0;n<12;n++)Frame();
                Check(bar.Regions.TryGetValue("dock-items",out var dock),"common bar missing in roomy viewport");
                foreach(var r in bar.UiItems.Where(p=>p.Key.StartsWith("run-")).Select(p=>p.Value))Check(r.Min.Y>=dock.Min.Y-.5f&&r.Max.Y<=dock.Max.Y+.5f,$"common-bar button vertically cropped: {theme}/{sample}");
                io.AddMousePosEvent(dock.Min.X+20,(dock.Min.Y+dock.Max.Y)/2);Frame();for(var n=0;n<8;n++){io.AddMouseWheelEvent(-50,0);Frame();}
                Check(bar.UiItems.ContainsKey("run-"+last.Id),"last pinned macro unreachable horizontally");
                if(sample==(1280,800,1f,1f))Capture($"dock-scroll-{theme}.png",1280,800);
            }
            ImGuiHelpers.GlobalScale=1;io.FontGlobalScale=1;config.Theme=ShelfTheme.Needy;Resize(1280,800);
            Check(entry.Commands=="/echo 原始内容"&&!executor.IsRunning,"layout regression mutated original command or execution");
            File.WriteAllText(Path.Combine(output,"usability-report.json"),JsonSerializer.Serialize(new{checks,nativeImGui=ImGui.GetVersion(),lastLineCases=33,scales=new[]{"100%","font 130% / UI 100%","125%","150%","200%"},gameVerified=false},new JsonSerializerOptions{WriteIndented=true}));
            Console.WriteLine($"PASS usability UI: {checks} assertions; novice creation/import/edit/run, help persistence, simple/advanced data isolation, 33 native eighth-line selection cases, CJK undo, long-line and scrollbar-drag alignment, narrow font scaling, last macro reveal, full-height dock and final pinned entry. Offline host, not game verification.");
        }
        catch{SoftwareRenderer.Save(Path.Combine(output,"usability-failure.png"));throw;}
        finally{SoftwareRenderer.ClearTextures();ImGuiHelpers.GlobalScale=1;ImGui.DestroyContext(context);}
    }
    private static void Frame()
    {
        var io=ImGui.GetIO();io.DisplaySize=new(width,height);io.DeltaTime=1f/60;window.UiItems.Clear();window.ThemeRegions.Clear();bar.UiItems.Clear();bar.Regions.Clear();
        ImGui.NewFrame();window.PreDraw();ImGui.SetNextWindowPos(Vector2.Zero,ImGuiCond.Always);ImGui.SetNextWindowSize(new(width,height),ImGuiCond.Always);
        ImGui.Begin("UsabilityHost",window.Flags|ImGuiWindowFlags.NoMove|ImGuiWindowFlags.NoResize);window.Draw();ImGui.End();window.PostDraw();ImGui.Render();
    }
    private static void Resize(int w,int h){width=w;height=h;Frame();Frame();}
    private static void Capture(string file,int w,int h){Resize(w,h);ImGui.GetIO().AddMousePosEvent(-100,-100);for(var i=0;i<25;i++)Frame();SoftwareRenderer.Save(Path.Combine(output,file));}
    private static void Inside(string key){Check(window.UiItems.TryGetValue(key,out var r)&&r.Min.X>=0&&r.Min.Y>=0&&r.Max.X<=width&&r.Max.Y<=height,"clipped main control: "+key);}
    private static void CheckCompact()
    {
        foreach(var key in new[]{"edit-run","edit-name","edit-favorite","edit-commands","stop","nav-editor","nav-quickbar","nav-settings","nav-help","mode-advanced"})Inside(key);
        var panel=window.ThemeRegions["editor-panel"];
        foreach(var key in new[]{"edit-run","edit-name","edit-favorite"})
        {var r=window.UiItems[key];Check(r.Min.X>=panel.Min.X-1&&r.Min.Y>=panel.Min.Y-1&&r.Max.X<=panel.Max.X+1&&r.Max.Y<=panel.Max.Y+1,"control crosses editor clip: "+key);}
        var footer=window.ThemeRegions["footer"];var stop=window.UiItems["stop"];
        Check(stop.Min.Y>=footer.Min.Y-1&&stop.Max.Y<=footer.Max.Y+1,"stop control crosses footer clip");
        Check(window.UiItems["nav-editor"].Min.Y>=54,"compact navigation overlaps wordmark");
    }
    private static void Click(string key){Frame();if(!window.UiItems.TryGetValue(key,out var r))throw new Exception("missing control: "+key);ClickAt((r.Min+r.Max)/2);}
    private static void ClickAt(Vector2 point){var io=ImGui.GetIO();io.AddMousePosEvent(point.X,point.Y);Frame();io.AddMouseButtonEvent(0,true);Frame();io.AddMouseButtonEvent(0,false);Frame();Frame();}
    private static void Key(ImGuiKey key,bool ctrl=false,bool shift=false){var io=ImGui.GetIO();if(ctrl)io.AddKeyEvent(ImGuiKey.ModCtrl,true);if(shift)io.AddKeyEvent(ImGuiKey.ModShift,true);io.AddKeyEvent(key,true);Frame();io.AddKeyEvent(key,false);if(ctrl)io.AddKeyEvent(ImGuiKey.ModCtrl,false);if(shift)io.AddKeyEvent(ImGuiKey.ModShift,false);Frame();Frame();}
    private static void SelectTheme(ShelfTheme theme){Click("theme-selector");Click("theme-"+theme);Frame();}
}
