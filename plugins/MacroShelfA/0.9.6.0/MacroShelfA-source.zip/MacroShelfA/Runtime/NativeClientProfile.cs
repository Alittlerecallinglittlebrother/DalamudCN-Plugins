// Audited CN client 2026.10.06.0000.0000; see evidence/native-audit.
// Unsupported clients remain disabled; these are identity checks, not raw call targets.
namespace MacroShelfA.Runtime;
internal static class NativeClientProfile
{
    internal const string GameVersion = "2026.10.06.0000.0000";
    internal const string ExeSha256 = "958B78E278AD896493C484EB313FF605AB41EDEFEF74F92B0EE078E69B281BF9";
    internal const int ExecuteMacroRva = 0x913150, CancelMacroRva = 0x913320;
    internal const int AgentExecuteEmoteRva = 0xF3C580, CanExecuteEmoteRva = 0x1968B80, ExecuteEmoteRva = 0x19682C0;
}
