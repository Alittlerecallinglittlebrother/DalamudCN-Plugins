# Macro Shelf-A 0.9.6.1

Dalamud CN API 15 / .NET 10 / Windows x64，国服客户端 `2026.10.06.0000.0000`。

## 本次修订：恢复原生宏默认开启

- 新配置，以及缺少 `UseNativeMacroExecution` 字段的旧配置，默认开启。
- 已明确保存的开启/关闭选择均保留；即使之前保存为关闭，也不强制修改。
- 备份替换导入：v1–v4 与缺少字段的 v5 默认开启；v5 明确保存为关闭的仍关闭。
- 追加导入不改变当前执行方式、等待和长宏设置。
- 默认开启仅选择后端，不会自动执行任何宏。

保留 0.9.6.0 的精确客户端核验、布局检查、取消 ABI、归属保护和等待队列机制。全部 Runtime 源文件未改动。公告、主题、宏正文及宏槽位均未因默认值修订改变。

## 使用

在卫月添加仓库：https://raw.githubusercontent.com/Alittlerecallinglittlebrother/DalamudCN-Plugins/main/repo.json

刷新安装器更新。只启用一个在线版或开发版，建议完全退出游戏后更新。`/aklmacro version` 应显示 0.9.6.1。

已保存为关闭的配置若需要原生执行，在“行数与等待设置”开启一次，或使用 `/aklmacro engine native`；`/aklmacro engine status` 查看模式。长宏/小数等待仍需各自设置与补丁成功启用。

## 构建与测试

设置 `DALAMUD_HOME` 指向 API 15 开发程序集目录，然后使用 PowerShell 7：

```powershell
./build.ps1 -Configuration Release -Test
```

构建输出：`MacroShelfA/bin/x64/Release`。测试是离线宿主，不是游戏内验收。游戏动作、外部接管等仍需实机回归；历史录像不能替代当前版本验收。

历史设计与变更见 `CHANGELOG.md`、`NATIVE-EXECUTION.md`。较早文档中的“候选/默认关闭/未发布”只描述对应历史版本，当前默认值以本页及 0.9.6.1 发布说明为准。
