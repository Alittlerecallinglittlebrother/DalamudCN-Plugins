using System.Numerics;
using System.Text.Json;
using System.Text.RegularExpressions;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

// Actual production Draw and cimgui input. WindowHost lifecycle is mirrored here;
// no game, remote announcement service, user configuration or native macro calls.
internal static unsafe class AnnouncementUi
{
    private const string Message = "推荐打开左侧“行数与等待设置”“原生宏执行”  否则可能会出现切换职业后部分宏指令或动作失效的偶发性bug";
    private static int checks, width = 1536, height = 1024;
    private static bool lastOpen, openOther, closeOther, otherVisible;
    private static MainWindow window = null!;
    private static string output = "";

    public static void Run(string directory)
    {
        output = directory; Directory.CreateDirectory(output); checks = 0;
        var oldScale = ImGuiHelpers.GlobalScale;
        var oldLoggedIn = Plugin.ClientState.IsLoggedIn;
        Plugin.ClientState.IsLoggedIn = true;
        using var native = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory, "cimgui.dll"));
        ImGui.InitApi(native);
        var context = ImGui.CreateContext();
        try
        {
            var io = ImGui.GetIO(); io.IniFilename = null; io.DeltaTime = 1f / 60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 17, default, io.Fonts.GetGlyphRangesChineseFull());
            Check(io.Fonts.Build(), "announcement font atlas"); ImGui.StyleColorsDark();
            foreach (var theme in new[] { ShelfTheme.Classic, ShelfTheme.Persona3, ShelfTheme.Needy, ShelfTheme.Persona5 })
            foreach (var nativeSelection in new[] { false, true })
            {
                width = 1536; height = 1024; ImGuiHelpers.GlobalScale = 1;
                io.FontGlobalScale = 1; lastOpen = false; openOther = closeOther = otherVisible = false;
                var entry = new MacroEntry { Name = "公告回归", Commands = "/wait 60", Pinned = true };
                var config = new Configuration { Theme = theme, Macros = [entry], ReduceThemeMotion = true };
                if (!nativeSelection) config.UseNativeMacroExecution = false; // Also cover a persisted opt-out, not just the new default.
                Check(config.UseNativeMacroExecution == nativeSelection, theme + ": fixture default/explicit choice mismatch");
                var nativeHost = new NoNativeCallsHost();
                using var executor = new MacroExecutor(config, () => 0, nativeHost: nativeHost);
                using var main = new MainWindow(config, executor, new BetterWaitPatch()) { Artwork = new ThemeUi.Artwork() };
                window = main;
                var before = ConfigurationExchange.Export(config);
                Check(config.AcknowledgedAnnouncementVersion == 0, "fresh notice must be unread");

                // Running without a main-window open (quickbar / entry / countdown
                // all share this executor) must never queue or create a dialog.
                Check(executor.TryStart(entry, out var error), error);
                Frame();
                Check(!window.IsOpen && !window.TestAnnouncementPending && PopupCount == 0, theme + ": background run opened announcement");
                executor.Stop(false);
                // Native Stop is a Framework request, not an immediate legacy stop. This UI host otherwise only pumps Draw.
                Plugin.Framework.Tick();
                Check(!executor.IsRunning && nativeHost.UnexpectedCalls == 0, theme + ": queued background run did not cancel before native preparation");

                window.Toggle(); Frame(); Frame();
                CheckVisible(theme + "-open");
                CaptureText(theme + "-normal");
                SoftwareRenderer.Save(Path.Combine(output, $"announcement-{theme}.png"));
                Click("announcement-dismiss");
                Check(PopupCount == 0 && !window.TestAnnouncementPending, theme + ": acknowledgement did not dismiss");
                var saved = Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!;
                Check(saved.AcknowledgedAnnouncementVersion == MainWindow.CurrentAnnouncementVersion, theme + ": read state not saved");
                using (var reloaded = new MainWindow(saved, executor, new BetterWaitPatch()))
                {
                    reloaded.OnOpen();
                    Check(!reloaded.TestAnnouncementPending, theme + ": plugin reload repeated read notice");
                }
                for (var i = 0; i < 4; i++) Frame();
                Check(PopupCount == 0, theme + ": announcement repeated each frame");

                // Both UiBuilder OpenMainUi/OpenConfigUi set IsOpen=true; repeating
                // that request while already visible must not invoke a new OnOpen.
                window.IsOpen = true; Frame(); window.IsOpen = true; Frame();
                Check(PopupCount == 0, theme + ": repeated open request reopened announcement");

                window.Toggle(); Frame(); window.IsOpen = true; Frame(); Frame();
                Check(PopupCount == 0 && !window.TestAnnouncementPending, theme + ": close/reopen repeated read notice");
                window.ShowAnnouncement(); Frame(); Frame();
                CheckVisible(theme + "-manual-review");
                // Exercise settings acknowledgement for a fresh announcement too.
                config.AcknowledgedAnnouncementVersion = 0;
                Click("announcement-settings");
                Check(window.TestAnnouncementAtSettings && PopupCount == 0, theme + ": settings button did not navigate/dismiss");
                Check(config.UseNativeMacroExecution == nativeSelection && !executor.IsRunning, theme + ": announcement changed engine selection or executed a macro");
                Check(ConfigurationExchange.Export(config) == before && config.AcknowledgedAnnouncementVersion == MainWindow.CurrentAnnouncementVersion,
                    theme + ": acknowledgement changed macros/execution or failed to save read state");

                // Quickbar edit has its own production open route.
                Close(); window.EditEntry(entry); Frame(); Frame();
                Check(PopupCount == 0, theme + ": quickbar edit repeated read notice");
                config.AcknowledgedAnnouncementVersion = 0;
                window.ShowAnnouncement(); Frame(); Frame();
                CheckVisible(theme + "-unread-manual-review");
                window.IsOpen = false; Frame();
                Check(PopupCount == 0, theme + ": closing main window left a blocking modal");
                window.IsOpen = true; Frame(); Frame();
                CheckVisible(theme + "-unacknowledged-reopen");

                // UiBuilder.HideUi skips WindowSystem.Draw entirely; removing this
                // modal must preserve the pending notice until UI visibility resumes.
                window.HideAnnouncement(); Frame(hidden: true);
                Check(PopupCount == 0 && window.TestAnnouncementPending, theme + ": hidden UI left modal or lost unacknowledged notice");
                Frame(); Frame(); CheckVisible(theme + "-resume");
                Click("announcement-dismiss");
                window.HideAnnouncement(); Frame(hidden: true); Frame();
                Check(PopupCount == 0 && !window.TestAnnouncementPending, theme + ": hidden acknowledged notice reopened");

                foreach (var scale in new[] { 1f, 1.5f })
                {
                    Close(); width = 720; height = 500; ImGuiHelpers.GlobalScale = scale; io.FontGlobalScale = scale;
                    config.AcknowledgedAnnouncementVersion = 0;
                    window.IsOpen = true; Frame(); Frame();
                    CheckVisible(theme + "-narrow-" + scale);
                    CaptureText(theme + "-narrow-" + scale);
                    SoftwareRenderer.Save(Path.Combine(output, $"announcement-{theme}-720-{(int)(scale * 100)}.png"));
                    Click("announcement-dismiss"); Check(PopupCount == 0, theme + ": narrow dismiss unreachable");
                }

                Close(); width = 1536; height = 1024; ImGuiHelpers.GlobalScale = 1; io.FontGlobalScale = 1;
                config.AcknowledgedAnnouncementVersion = 0;
                window.IsOpen = true; openOther = true; Frame(); Frame();
                Check(otherVisible && window.TestAnnouncementPending && !window.UiItems.ContainsKey("announcement-dismiss"),
                    theme + ": announcement stole another modal");
                closeOther = true; Frame(); Frame();
                CheckVisible(theme + "-after-other-modal");

                // Switching theme is not closing the main window. In particular,
                // the old Classic cleanup path must not clear/re-arm the notice.
                config.Theme = ShelfTheme.Persona3; Frame();
                config.Theme = ShelfTheme.Classic; Frame(); Frame();
                CheckVisible(theme + "-theme-switch-open");
                Click("announcement-dismiss");
                config.Theme = ShelfTheme.Persona5; Frame(); config.Theme = ShelfTheme.Classic; Frame();
                Check(PopupCount == 0, theme + ": theme switching repeated acknowledged notice");

                // Close via the title-bar X, not just the two content buttons.
                window.ShowAnnouncement(); Frame(); Frame();
                config.AcknowledgedAnnouncementVersion = 0;
                var modal = window.ThemeRegions["announcement-modal"];
                ClickAt(new Vector2(modal.Max.X - ImGui.GetFontSize() * .85f, modal.Min.Y + ImGui.GetFontSize() * .65f));
                Check(PopupCount == 0 && config.AcknowledgedAnnouncementVersion == MainWindow.CurrentAnnouncementVersion,
                    theme + ": X did not dismiss/persist acknowledgement");
                Close(); window.IsOpen = true; Frame(); Frame();
                Check(PopupCount == 0, theme + ": X acknowledgement repeated on reopen");
                config.AcknowledgedAnnouncementVersion = 0;
                window.ShowAnnouncement(); Frame(); Frame();
                Check(PopupCount == 1, theme + ": dispose fixture missing popup");
                window.Dispose();
                Check(PopupCount == 0 && !window.TestAnnouncementPending, theme + ": dispose left a blocking modal");
                window.IsOpen = false; Frame();

                // Disposing while our notice is merely queued must not close a
                // different window's existing modal.
                window.IsOpen = true; openOther = true; Frame(); Frame();
                Check(otherVisible && window.TestAnnouncementPending, theme + ": deferred-dispose fixture missing modal");
                window.Dispose();
                Check(PopupCount == 1 && !window.TestAnnouncementPending, theme + ": dispose closed someone else's modal");
                closeOther = true; Frame(); Close();
                Check(PopupCount == 0, theme + ": fixture retained popup");
            }
            File.WriteAllText(Path.Combine(output, "announcement-ui-report.json"), JsonSerializer.Serialize(new
            {
                checks, themes = 4, nativeSelections = new[] { false, true }, layouts = new[] { "1536x1024/100%", "720x500/100%", "720x500/150%" },
                exactMessage = Message, nativeImGui = ImGui.GetVersion(), lifecycle = "Mirrors audited WindowHost callbacks", gameVerified = false,
            }, new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine($"PASS announcement UI: {checks} assertions; exact text, 4 themes with default-on/explicit-off, 720x500/150%, open lifecycle, dismiss/settings, HideUi, theme changes, other modals and disposal. Offline host, not game verification.");
        }
        catch { SoftwareRenderer.Save(Path.Combine(output, "announcement-failure.png")); throw; }
        finally
        {
            SoftwareRenderer.ClearTextures(); ImGui.DestroyContext(context);
            ImGuiHelpers.GlobalScale = oldScale; Plugin.ClientState.IsLoggedIn = oldLoggedIn;
        }
    }

    private sealed class NoNativeCallsHost : INativeMacroExecutionHost
    {
        public int UnexpectedCalls;
        private Exception Unexpected() { UnexpectedCalls++; return new InvalidOperationException("Announcement fixture must not execute a native macro"); }
        public NativeMacroReadiness Prepare(out string detail) => throw Unexpected();
        public bool TryStart(NativeMacroSegment segment, string ownerName, out string error) => throw Unexpected();
        public NativeMacroProgress Poll() => throw Unexpected();
        public void CancelOwned() { }
        public void Dispose() { }
    }

    private static int PopupCount => ImGui.GetCurrentContext().OpenPopupStack.Size;
    private static void Check(bool value, string message) { if (!value) throw new Exception(message); checks++; }
    private static void Close() { window.IsOpen = false; Frame(); }
    private static void CheckVisible(string state)
    {
        Check(window.UiItems.ContainsKey("announcement-dismiss") && window.UiItems.ContainsKey("announcement-settings"), state + ": announcement controls missing");
        var rect = window.ThemeRegions["announcement-modal"];
        foreach (var key in new[] { "announcement-message", "announcement-dismiss", "announcement-settings" })
        {
            var colors = window.UiColors[key];
            foreach (var background in colors.Skip(1))
                Check(Contrast(colors[0], background) >= 4.5, state + ": insufficient text contrast: " + key);
        }
        Check(rect.Min.X >= 0 && rect.Min.Y >= 0 && rect.Max.X <= width + 1 && rect.Max.Y <= height + 1, state + ": modal outside viewport");
        Check(Vector2.Distance((rect.Min + rect.Max) / 2, new Vector2(width, height) / 2) < 2, state + ": modal not centered");
        foreach (var key in new[] { "announcement-message", "announcement-dismiss", "announcement-settings" })
        {
            var item = window.UiItems[key];
            Check(item.Min.X >= rect.Min.X && item.Max.X <= rect.Max.X && item.Min.Y >= rect.Min.Y && item.Max.Y <= rect.Max.Y,
                state + ": text/button unreachable: " + key);
        }
    }
    internal static double Contrast(Vector4 a, Vector4 b)
    {
        static double Channel(float v) => v <= .04045f ? v / 12.92 : Math.Pow((v + .055) / 1.055, 2.4);
        static double L(Vector4 v) => .2126 * Channel(v.X) + .7152 * Channel(v.Y) + .0722 * Channel(v.Z);
        var x = L(a); var y = L(b); return (Math.Max(x, y) + .05) / (Math.Min(x, y) + .05);
    }
    private static void CaptureText(string state)
    {
        var path = Path.GetFullPath(Path.Combine(output, "announcement-text-" + state + ".txt")); File.WriteAllText(path, "");
        Frame(logPath: path);
        Check(Regex.Replace(File.ReadAllText(path), @"\s+", "").Contains(Regex.Replace(Message, @"\s+", ""), StringComparison.Ordinal), state + ": announcement text changed/truncated");
    }
    private static void Click(string key)
    {
        Check(window.UiItems.TryGetValue(key, out var rect), "control missing: " + key);
        ClickAt((rect.Min + rect.Max) / 2);
    }
    private static void ClickAt(Vector2 p)
    {
        var io = ImGui.GetIO();
        io.AddMousePosEvent(p.X, p.Y); Frame(); io.AddMouseButtonEvent(0, true); Frame();
        io.AddMouseButtonEvent(0, false); Frame(); Frame();
    }
    private static void Frame(bool hidden = false, string? logPath = null)
    {
        var io = ImGui.GetIO(); io.DisplaySize = new(width, height); io.DeltaTime = 1f / 60;
        window.UiItems.Clear(); window.ThemeRegions.Clear(); ImGui.NewFrame();
        if (!hidden)
        {
            if (window.IsOpen != lastOpen) { if (window.IsOpen) window.OnOpen(); else window.OnClose(); lastOpen = window.IsOpen; }
            if (window.IsOpen)
            {
                window.PreDraw(); ImGui.SetNextWindowPos(Vector2.Zero, ImGuiCond.Always);
                ImGui.SetNextWindowSize(new(width, height), ImGuiCond.Always);
                ImGui.Begin(window.WindowName, window.Flags | ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoResize);
                if (openOther) { ImGui.OpenPopup("OtherModal"); openOther = false; }
                otherVisible = false;
                if (ImGui.BeginPopupModal("OtherModal", ImGuiWindowFlags.AlwaysAutoResize))
                {
                    otherVisible = true; ImGui.TextUnformatted("Existing modal");
                    if (closeOther) { ImGui.CloseCurrentPopup(); closeOther = false; }
                    ImGui.EndPopup();
                }
                if (logPath != null) ImGui.LogToFile(-1, logPath);
                window.Draw();
                if (logPath != null) ImGui.LogFinish();
                ImGui.End(); window.PostDraw();
            }
        }
        ImGui.Render();
    }
}

namespace MacroShelfA.Windows
{
    internal sealed partial class MainWindow
    {
        internal bool TestAnnouncementPending => announcementPending;
        internal bool TestAnnouncementAtSettings => page == Page.Settings && taskPage == TaskPage.Execution;
    }
}
