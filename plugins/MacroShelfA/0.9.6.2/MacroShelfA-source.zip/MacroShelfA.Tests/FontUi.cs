using System.Numerics;
using System.Reflection;
using System.Text.Json;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.ManagedFontAtlas;
using Dalamud.Interface.Utility;
using HexaGen.Runtime;
using MacroShelfA;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

// Production font owner, UI and native ImGui. Only the asynchronous Dalamud font
// handle boundary is simulated, backed by real separately rasterized CJK fonts.
internal static unsafe class FontUi
{
    private static int checks, width = 1536, height = 1024;
    private static Configuration config = null!;
    private static MainWindow window = null!;
    private static QuickBarWindow bar = null!;
    private static ShelfFont font = null!;
    private static readonly Dictionary<float, ImFontPtr> fonts = [];
    private static readonly List<FontHandleProxy> handles = [];
    private static bool ready = true;
    private static string output = "";

    public static void Run(string directory)
    {
        output = directory; Directory.CreateDirectory(output); checks = 0; handles.Clear(); fonts.Clear();
        var oldScale = ImGuiHelpers.GlobalScale;
        using var native = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory, "cimgui.dll"));
        ImGui.InitApi(native); var context = ImGui.CreateContext();
        try
        {
            var io = ImGui.GetIO(); io.IniFilename = null; io.DeltaTime = 1f / 60;
            foreach (var scale in new[] { 1f, .8f, 1.25f, 1.5f })
                fonts[scale] = io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 17 * scale, default, io.Fonts.GetGlyphRangesChineseFull());
            Check(io.Fonts.Build(), "font atlas");
            Check(SoftwareRenderer.RegisterFontAtlas() > 0, "font atlas texture pages");
            ImGui.StyleColorsDark();
            VerifyFontOwner();
            foreach (var theme in Enum.GetValues<ShelfTheme>())
            {
                width = 1536; height = 1024; ImGuiHelpers.GlobalScale = 1; io.FontGlobalScale = 1;
                var entry = new MacroEntry { Name = "字体测试", Commands = "/echo 中文字号预览\n/wait 1\n/echo 结束", Pinned = true };
                config = new Configuration { Theme = theme, ReduceThemeMotion = true, ShowThemeDecoration = false,
                    UseNativeMacroExecution = false, AcknowledgedAnnouncementVersion = MainWindow.CurrentAnnouncementVersion, Macros = [entry] };
                using var executor = new MacroExecutor(config, () => 0);
                using var main = new MainWindow(config, executor, new BetterWaitPatch()) { Artwork = new ThemeUi.Artwork() };
                using var owner = new ShelfFont(CreateFont, () => 17); font = owner; window = main;
                bar = new QuickBarWindow(config, executor, main);
                window.TestShowAppearance(); Frame(); Frame();
                Check(window.UiItems.ContainsKey("setting-font-size") && window.UiItems.ContainsKey("setting-font-reset"), theme + ": font controls missing");
                var slider = window.UiItems["setting-font-size"];
                ClickAt(new Vector2(slider.Max.X - 3, (slider.Min.Y + slider.Max.Y) / 2));
                Check(config.UiFontScale == 1.5f, theme + ": slider did not commit 150% on release");
                Check(Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!.UiFontScale == 1.5f,
                    theme + ": slider not persisted");
                CheckSize("setting-font-preview", 25.5f);
                SoftwareRenderer.Save(Path.Combine(output, $"font-{theme}-settings-150.png"));
                Seek("setting-font-reset"); Click("setting-font-reset");
                Check(config.UiFontScale == 1 && Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)!.UiFontScale == 1,
                    theme + ": reset not applied/saved");
                CheckSize("setting-font-preview", 17);
                io.AddKeyEvent(ImGuiKey.ModCtrl, true); Frame(); Click("setting-font-size");
                io.AddKeyEvent(ImGuiKey.ModCtrl, false); Frame(); Key(ImGuiKey.A, ctrl: true);
                foreach (var c in "125") io.AddInputCharacter(c);
                Frame(); Frame();
                Check(config.UiFontScale == 1, theme + ": typed draft rebuilt font before commit");
                Key(ImGuiKey.Enter);
                Check(config.UiFontScale == 1.25f, theme + ": typed font size did not commit on Enter");
                CheckSize("setting-font-preview", 21.25f);
                Seek("setting-font-reset"); Click("setting-font-reset");
                Seek("announcement-review"); Click("announcement-review");
                Check(window.UiItems.ContainsKey("announcement-dismiss"), theme + ": review entry did not open notice");
                Click("announcement-dismiss");
                Check(config.AcknowledgedAnnouncementVersion == MainWindow.CurrentAnnouncementVersion, theme + ": review erased read state");

                foreach (var global in new[] { 1f, 1.5f })
                foreach (var scale in new[] { .8f, 1f, 1.25f, 1.5f })
                {
                    config.UiFontScale = scale; ImGuiHelpers.GlobalScale = global; io.FontGlobalScale = global;
                    var expected = 17 * global * scale;
                    width = 1536; height = 1024; window.TestOpen(entry); Frame(); Frame();
                    CheckSize("edit-commands", expected);
                    // The syntax overlay must use exactly the native input's line/caret metrics.
                    if (theme != ShelfTheme.Classic)
                        Check(Math.Abs(window.TestCodeEditor.TestLineHeight - expected) < .05f, theme + ": editor overlay font drift");
                    Check(Math.Abs(bar.TestFontSize - expected) < .05f, theme + ": floating quickbar size not applied");
                    if (scale == 1.5f && global == 1.5f)
                    {
                        Click("edit-commands"); Key(ImGuiKey.Home, ctrl: true);
                        var original = entry.Commands; io.AddInputCharacter('中'); Frame();
                        Check(entry.Commands == "中" + original, theme + ": scaled CJK insertion misplaced");
                        Check(Math.Abs(ImGui.GetCurrentContext().PlatformImeData.InputLineHeight - expected) < .05f,
                            theme + ": scaled caret/IME line height drift");
                        Key(ImGuiKey.Z, ctrl: true); Check(entry.Commands == original, theme + ": scaled editor undo changed text");
                    }
                    if (scale == 1.5f && global == 1)
                        SoftwareRenderer.Save(Path.Combine(output, $"font-{theme}-editor-150.png"));
                    width = 720; height = 500; window.ShowAnnouncement(); Frame(); Frame();
                    CheckSize("announcement-message", expected); CheckSize("announcement-dismiss", expected);
                    var modal = window.ThemeRegions["announcement-modal"];
                    var dismiss = window.UiItems["announcement-dismiss"];
                    Check(modal.Min.X >= 0 && modal.Min.Y >= 0 && modal.Max.X <= width && modal.Max.Y <= height, "scaled modal outside viewport");
                    Check(dismiss.Min.Y >= modal.Min.Y && dismiss.Max.Y <= modal.Max.Y, "scaled modal dismiss inaccessible");
                    if (scale == 1.5f)
                        SoftwareRenderer.Save(Path.Combine(output, $"font-{theme}-announcement-720-global-{(int)(global * 100)}.png"));
                    Click("announcement-dismiss");
                    Check(ImGui.GetCurrentContext().OpenPopupStack.Size == 0, "scaled dismiss failed");
                }
                width = 1536; height = 1024; ImGuiHelpers.GlobalScale = 1; io.FontGlobalScale = 1; config.UiFontScale = 1.25f;
                // Both import modes leave local preferences intact.
                foreach (var replace in new[] { false, true })
                {
                    window.TestImport(ConfigurationExchange.Export(new Configuration { Macros = [new() { Commands = "/echo imported" }] }), replace);
                    Check(config.UiFontScale == 1.25f && config.AcknowledgedAnnouncementVersion == MainWindow.CurrentAnnouncementVersion,
                        "macro import replaced local font/read settings");
                }
                window.OnOpen(); Check(!window.TestAnnouncementPending, "read notice rearmed after import/font change");
            }
            Check(handles.All(h => h.Disposed), "font handle leaked after windows disposed");
            File.WriteAllText(Path.Combine(output, "font-ui-report.json"), JsonSerializer.Serialize(new
            {
                checks, themes = 4, fontPercentages = new[] { 80, 100, 125, 150 }, globalPercentages = new[] { 100, 150 },
                gameVerified = false, fontBoundary = "IFontHandle simulated with native rasterized CJK fonts; production ShelfFont used",
            }, new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine($"PASS font UI: {checks} assertions; 4 themes, 80/100/125/150%, global 100/150%, persistence, scopes, resource lifecycle, editor, quickbar and narrow announcements. Offline host, not game verification.");
        }
        catch { SoftwareRenderer.Save(Path.Combine(output, "font-failure.png")); throw; }
        finally { SoftwareRenderer.ClearTextures(); ImGui.DestroyContext(context); ImGuiHelpers.GlobalScale = oldScale; }
    }

    private static IFontHandle CreateFont(float size)
    {
        var result = DispatchProxy.Create<IFontHandle, FontHandleProxy>();
        var proxy = (FontHandleProxy)(object)result;
        proxy.Font = fonts.MinBy(kv => Math.Abs(kv.Key * 17 - size)).Value;
        proxy.Ready = ready; handles.Add(proxy); return result;
    }
    private static void VerifyFontOwner()
    {
        ImGuiHelpers.GlobalScale = 1; var io = ImGui.GetIO(); io.FontGlobalScale = 1; io.DisplaySize = new(1536, 1024);
        ImGui.NewFrame();
        var before = handles.Count;
        using (var owner = new ShelfFont(CreateFont, () => 17))
        {
            void Size(float value) => Check(Math.Abs(ImGui.GetFontSize() - value) < .05f, "font owner rendered wrong size");
            owner.Draw(1, () => Size(17)); Check(handles.Count == before, "default creates custom font");
            owner.Draw(1.25f, () => Size(21.25f)); var first = handles[^1];
            owner.Draw(1.25f, () => Size(21.25f)); Check(handles.Count == before + 1, "stable size rebuilds every frame");
            ready = false; owner.Draw(1.5f, () => Size(21.25f)); var pending = handles[^1];
            Check(!first.Disposed && !pending.Disposed, "pending build discarded active font");
            owner.Draw(.8f, () => Size(21.25f)); Check(pending.Disposed, "superseded pending handle leaked");
            handles[^1].Ready = true; owner.Draw(.8f, () => Size(13.6f)); Check(first.Disposed, "old active handle leaked");
            try { owner.Draw(.8f, () => throw new ApplicationException("scope test")); } catch (ApplicationException) { }
            Size(17); Check(ImGui.GetCurrentContext().FontStack.Size == 0, "exception leaked font stack");
            owner.Draw(1, () => Size(17)); Check(handles[^1].Disposed, "reset leaked font");
            ready = true; owner.Draw(1.5f, () => Size(25.5f));
            owner.Dispose(); owner.Dispose(); Check(handles[^1].Disposed, "dispose not idempotent");
            owner.Draw(float.NaN, () => Size(17));
        }
        Check(handles.All(h => h.Disposed), "font lifecycle leaked resources");
        ImGui.Render();
    }
    private static void Check(bool value, string message) { if (!value) throw new Exception(message); checks++; }
    private static void CheckSize(string key, float expected) => Check(window.UiFontSizes.TryGetValue(key, out var actual) && Math.Abs(actual - expected) < .05f,
        $"{config.Theme}/{key}: font expected {expected}, got {actual}");
    private static void Click(string key)
    {
        Check(window.UiItems.TryGetValue(key, out var rect), "control missing: " + key);
        ClickAt((rect.Min + rect.Max) / 2);
    }
    private static void ClickAt(Vector2 p)
    {
        var io = ImGui.GetIO(); io.AddMousePosEvent(p.X, p.Y); Frame();
        io.AddMouseButtonEvent(0, true); Frame(); io.AddMouseButtonEvent(0, false); Frame(); Frame();
    }
    private static void Key(ImGuiKey key, bool ctrl = false)
    {
        var io = ImGui.GetIO(); if (ctrl) io.AddKeyEvent(ImGuiKey.ModCtrl, true);
        io.AddKeyEvent(key, true); Frame(); io.AddKeyEvent(key, false);
        if (ctrl) io.AddKeyEvent(ImGuiKey.ModCtrl, false); Frame(); Frame();
    }
    private static void Seek(string key)
    {
        for (var n = 0; n < 20 && !window.UiItems.ContainsKey(key); n++)
        {
            window.ScrollRequests[config.Theme == ShelfTheme.Classic ? "classic-settings" : "task-body"] = n * 90;
            Frame(); Frame();
        }
        Check(window.UiItems.ContainsKey(key), "unreachable control: " + key);
    }
    private static void Frame()
    {
        var io = ImGui.GetIO(); io.DisplaySize = new(width, height); io.DeltaTime = 1f / 60;
        window.UiItems.Clear(); window.ThemeRegions.Clear(); ImGui.NewFrame();
        var originalFont = ImGui.GetFont(); var originalScale = io.FontGlobalScale;
        font.Draw(config.UiFontScale, () =>
        {
            // The plugin wraps WindowSystem.Draw, before any Begin or PreDraw.
            window.PreDraw(); ImGui.SetNextWindowPos(Vector2.Zero, ImGuiCond.Always);
            ImGui.SetNextWindowSize(new(width, height), ImGuiCond.Always);
            ImGui.Begin(window.WindowName, window.Flags | ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoResize);
            window.Draw(); ImGui.End(); window.PostDraw();
            bar.PreDraw();
            ImGui.SetNextWindowPos(new Vector2(-1000, -1000), ImGuiCond.Always);
            ImGui.SetNextWindowSize(new Vector2(600, 350), ImGuiCond.Always);
            ImGui.Begin("FontQuickbarProbe"); bar.Draw(); ImGui.End(); bar.PostDraw();
        });
        Check(ImGui.GetFont().Handle == originalFont.Handle && io.FontGlobalScale == originalScale && ImGui.GetCurrentContext().FontStack.Size == 0,
            "font scope affected another plugin / global scale");
        ImGui.Render();
    }
}

public class FontHandleProxy : DispatchProxy
{
    public ImFontPtr Font;
    public bool Ready, Disposed;
    protected override object? Invoke(MethodInfo? method, object?[]? args)
    {
        switch (method?.Name)
        {
            case "get_Available": return Ready && !Disposed;
            case "Dispose": Disposed = true; return null;
            case "Push":
                if (Disposed || !Ready) throw new Exception("Invalid font handle push");
                ImGui.PushFont(Font); return new PopFont();
            default: throw new Exception("Unexpected font boundary call: " + method?.Name);
        }
    }
    private sealed class PopFont : IDisposable { public void Dispose() => ImGui.PopFont(); }
}

namespace MacroShelfA.Windows
{
    internal sealed partial class MainWindow
    {
        internal void TestShowAppearance() { page = Page.Settings; NavigateTask(TaskPage.Appearance); }
    }
}
