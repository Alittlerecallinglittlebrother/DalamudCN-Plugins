using System.Text.Json;
using MacroShelfA;
using MacroShelfA.Windows;

internal static class PresentationConfigurationTests
{
    public static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        test("presentation: legacy configs default to 100% and unread without changing macros", () =>
        {
            const string json = "{\"Version\":9,\"UseNativeMacroExecution\":false,\"Macros\":[{\"Id\":\"keep\",\"Name\":\"原文\",\"Commands\":\"/echo untouched\"}]}";
            foreach (var config in new[] { JsonSerializer.Deserialize<Configuration>(json)!, Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(json)! })
            {
                config.Normalize();
                check(config.UiFontScale == 1 && config.AcknowledgedAnnouncementVersion == 0, "legacy defaults");
                check(!config.UseNativeMacroExecution && config.Macros[0].Id == "keep" && config.Macros[0].Commands == "/echo untouched", "presentation migrated execution/macros");
            }
        });
        test("presentation: both serializers and save/reload preserve size and announcement version", () =>
        {
            foreach (var scale in new[] { .8f, 1f, 1.25f, 1.5f })
            {
                var config = new Configuration { UiFontScale = scale, AcknowledgedAnnouncementVersion = MainWindow.CurrentAnnouncementVersion };
                config.Save();
                foreach (var saved in new[] { JsonSerializer.Deserialize<Configuration>(Plugin.PluginInterface.Json)!, Newtonsoft.Json.JsonConvert.DeserializeObject<Configuration>(Plugin.PluginInterface.Json)! })
                {
                    saved.Normalize();
                    check(saved.UiFontScale == scale && saved.AcknowledgedAnnouncementVersion == MainWindow.CurrentAnnouncementVersion, "presentation persistence");
                }
            }
        });
        test("presentation: invalid font scales normalize safely and future read markers survive", () =>
        {
            foreach (var (value, expected) in new[] { (float.NaN, 1f), (float.PositiveInfinity, 1f), (float.NegativeInfinity, 1f), (-100f, .8f), (0f, .8f), (4f, 1.5f) })
            {
                var config = new Configuration { UiFontScale = value, AcknowledgedAnnouncementVersion = -1 };
                config.Normalize();
                check(config.UiFontScale == expected && config.AcknowledgedAnnouncementVersion == 0, "invalid presentation setting");
            }
            var future = new Configuration { AcknowledgedAnnouncementVersion = 999 };
            future.Normalize();
            check(future.AcknowledgedAnnouncementVersion == 999, "downgrade erased future acknowledgement");
        });
        test("presentation: macro exchange does not export machine-local font/read preferences", () =>
        {
            var config = new Configuration { UiFontScale = 1.5f, AcknowledgedAnnouncementVersion = 10, Macros = [new() { Commands = "/echo keep" }] };
            var json = ConfigurationExchange.Export(config);
            check(!json.Contains("UiFontScale") && !json.Contains("AcknowledgedAnnouncementVersion"), "local settings leaked into exchange");
        });
    }
}
