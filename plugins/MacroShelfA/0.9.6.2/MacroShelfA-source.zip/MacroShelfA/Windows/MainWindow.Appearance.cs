using System;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow
{
    private int? fontPercentDraft;

    private void DrawFontAndAnnouncementSettings()
    {
        ImGui.Spacing();
        ImGui.TextUnformatted("界面字体大小");
        var percent = fontPercentDraft ?? (int)MathF.Round(configuration.UiFontScale * 100);
        ImGui.SetNextItemWidth(-1);
        if (ImGui.SliderInt("##UiFontSize", ref percent, (int)(Configuration.MinUiFontScale * 100),
                (int)(Configuration.MaxUiFontScale * 100), "%d%%", ImGuiSliderFlags.AlwaysClamp))
            fontPercentDraft = percent;
        RecordItem("setting-font-size");
        // Commit on release/Enter: do not rebuild the CJK font atlas on every drag frame.
        if (ImGui.IsItemDeactivatedAfterEdit() && fontPercentDraft.HasValue)
        {
            configuration.UiFontScale = fontPercentDraft.Value / 100f;
            fontPercentDraft = null;
            SaveConfiguration();
        }
        if (ImGui.Button("恢复默认字号（100%）"))
        {
            fontPercentDraft = null;
            configuration.UiFontScale = 1f;
            SaveConfiguration();
        }
        RecordItem("setting-font-reset");
        ImGui.TextWrapped("范围 80%–150%；松开滑块或结束输入后生效并自动保存。影响插件正文、编辑器、公告与常用栏，不改变游戏和其他插件的字号。");
        ImGui.TextWrapped("字号预览：让每一个宏，都成为你游戏中的小小魔法。");
        RecordItem("setting-font-preview");
        if (ImGui.Button("查看公告")) ShowAnnouncement();
        RecordItem("announcement-review");
        ImGui.TextWrapped("同一条公告确认后不再自动弹出；新公告仍会提示。");
        ImGui.Separator();
    }
}
