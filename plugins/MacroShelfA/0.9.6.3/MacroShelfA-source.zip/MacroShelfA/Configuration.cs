using System;
using System.Collections.Generic;
using System.Linq;
using Dalamud.Configuration;

namespace MacroShelfA;

[Serializable]
public sealed class Configuration : IPluginConfiguration
{
    private const int CurrentVersion = 9;
    public const int MaxEntries = 200;
    public const int MaxChildren = 64;
    public const int MaxNameLength = 32;
    public const int MaxGroupLength = 24;
    public const int MaxCommandLength = 64_000;
    public const float MinUiFontScale = .8f;
    public const float MaxUiFontScale = 1.5f;

    public int Version { get; set; } = CurrentVersion;
    // Additive presentation settings; no macro/config-format migration is required.
    public ShelfTheme Theme { get; set; } = ShelfTheme.Persona3;
    public float UiFontScale { get; set; } = 1f;
    // Local preferences, intentionally not transferred with exported macros.
    public int AcknowledgedAnnouncementVersion { get; set; }
    public bool ShowThemeDecoration { get; set; } = true;
    public bool ShowWorkbenchQuickBar { get; set; } = true;
    public bool ReduceThemeMotion { get; set; }
    public bool AdvancedWorkbench { get; set; }
    public bool ShowGettingStarted { get; set; } = true;
    // New/missing settings use native execution. Explicit saved false remains an opt-out.
    public bool UseNativeMacroExecution { get; set; } = true;
    public bool BetterWaitEnabled { get; set; } = true;
    public bool AllowLongMacros { get; set; }
    public bool CountdownTriggerEnabled { get; set; }
    public string CountdownMacroId { get; set; } = string.Empty;
    public bool ShowFloatingLauncher { get; set; } = true;
    public bool LockFloatingLauncher { get; set; }
    public float FloatingLauncherSize { get; set; } = 56f;
    public bool ShowQuickBar { get; set; } = true;
    public bool LockQuickBar { get; set; }
    public bool QuickBarCollapsed { get; set; }
    public int QuickBarColumns { get; set; } = 4;
    public float QuickBarButtonWidth { get; set; } = 112f;
    public List<MacroEntry> Macros { get; set; } = [];

    public int CountEntries() => Macros.Sum(m => 1 + (m.IsGroup ? m.Children.Count : 0));

    public MacroEntry? FindCountdownMacro() => Macros.FirstOrDefault(m => m.Id == CountdownMacroId);

    public IEnumerable<MacroEntry> AllEntries()
    {
        foreach (var root in Macros)
        {
            if (root == null) continue;
            yield return root;
            if (!root.IsGroup || root.Children == null) continue;
            foreach (var child in root.Children) if (child != null) yield return child;
        }
    }

    // Never bind a missing or ambiguous entrance to a similarly named macro.
    public MacroEntry? FindEntryById(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return null;
        var matches = AllEntries().Where(entry => string.Equals(entry.Id, id, StringComparison.Ordinal)).Take(2).ToArray();
        return matches.Length == 1 ? matches[0] : null;
    }

    public void ClearCountdownBinding()
    {
        CountdownTriggerEnabled = false;
        CountdownMacroId = string.Empty;
    }

    internal static Configuration CreateDefault() => new()
    {
        Macros = [new MacroEntry
        {
            Name = "示例宏", Group = "示例",
            Commands = "/echo Macro Shelf-A 已就绪 <wait.1>\n/echo 请在编辑宏页面修改内容",
        }],
    };

    public void Normalize() => NormalizeForLoad();

    // The caller must publish newly assigned identities before exposing them to native entrances.
    internal bool NormalizeForLoad()
    {
        if (Version > CurrentVersion)
            throw new NotSupportedException($"配置版本 {Version} 高于当前支持的 {CurrentVersion}，请使用较新版本的 Macro Shelf-A 打开。");
        var migrated = Version < CurrentVersion;
        if (!Enum.IsDefined(Theme)) Theme = ShelfTheme.Persona3;
        UiFontScale = NormalizeUiFontScale(UiFontScale);
        AcknowledgedAnnouncementVersion = Math.Max(0, AcknowledgedAnnouncementVersion);
        if (Version < 6) ClearCountdownBinding();
        if (Version < 3)
        {
            ShowFloatingLauncher = true;
            FloatingLauncherSize = 56f;
        }
        var repairedIds = NormalizeLibrary();
        FloatingLauncherSize = float.IsFinite(FloatingLauncherSize)
            ? Math.Clamp(FloatingLauncherSize, 32f, 96f) : 56f;
        QuickBarColumns = Math.Clamp(QuickBarColumns, 1, 8);
        QuickBarButtonWidth = float.IsFinite(QuickBarButtonWidth)
            ? Math.Clamp(QuickBarButtonWidth, 80f, 200f) : 112f;
        if (string.IsNullOrEmpty(CountdownMacroId) || FindCountdownMacro() == null) ClearCountdownBinding();
        Version = CurrentVersion;
        return migrated || repairedIds;
    }

    private bool NormalizeLibrary()
    {
        Macros ??= [];
        Macros.RemoveAll(m => m == null);
        // Retire every occurrence of an ambiguous saved ID. Keeping the first one
        // would silently redirect existing hotbar and countdown bindings to it.
        var ids = AllEntries().GroupBy(entry => entry.Id, StringComparer.Ordinal)
            .Where(group => group.Count() > 1).Select(group => group.Key).ToHashSet(StringComparer.Ordinal);
        var repaired = false;
        foreach (var macro in Macros)
        {
            repaired |= NormalizeEntry(macro, ids);
            macro.Children ??= [];
            macro.Children.RemoveAll(c => c == null);
            foreach (var child in macro.Children) repaired |= NormalizeEntry(child, ids);
        }
        return repaired;
    }

    internal static float NormalizeUiFontScale(float scale) => float.IsFinite(scale)
        ? Math.Clamp(scale, MinUiFontScale, MaxUiFontScale) : 1f;

    private static bool NormalizeEntry(MacroEntry macro, HashSet<string> ids)
    {
        var missingOrDuplicate = string.IsNullOrWhiteSpace(macro.Id) || !ids.Add(macro.Id);
        if (missingOrDuplicate)
        {
            do { macro.Id = Guid.NewGuid().ToString("N"); } while (!ids.Add(macro.Id));
        }
        macro.Name = Limit(macro.Name, MaxNameLength, macro.IsGroup ? "未命名宏组" : "未命名宏");
        macro.Group = Limit(macro.Group, MaxGroupLength, string.Empty);
        var commands = (macro.Commands ?? string.Empty).Replace("\r\n", "\n").Replace('\r', '\n');
        // Never silently discard saved commands, especially when the line-limit toggle is off.
        // Execution and import validate the size; oversized existing text remains editable.
        macro.Commands = commands;
        if (macro.NativeSourceSet is not (0 or 1) || macro.NativeSourceIndex is < 0 or > 99)
        {
            macro.NativeSourceSet = -1;
            macro.NativeSourceIndex = -1;
        }
        return missingOrDuplicate;
    }

    public MacroEntry? AddMacro(bool isGroup = false)
    {
        if (CountEntries() + (isGroup ? 2 : 1) > MaxEntries) return null;
        var macro = new MacroEntry { IsGroup = isGroup, Name = isGroup ? "新宏组" : "新宏" };
        if (isGroup) macro.Children.Add(new MacroEntry { Name = "宏A" });
        return TryEdit(Macros, () => Macros.Add(macro)) ? macro : null;
    }

    public MacroEntry? AddChild(MacroEntry parent, MacroEntry? source = null)
    {
        if (!Macros.Contains(parent) || !parent.IsGroup || source?.IsGroup == true ||
            CountEntries() >= MaxEntries || parent.Children.Count >= MaxChildren) return null;
        var child = source?.Copy() ?? new MacroEntry
        {
            Name = parent.Children.Count < 26 ? $"宏{(char)('A' + parent.Children.Count)}" : $"子宏 {parent.Children.Count + 1}",
        };
        return TryEdit(parent.Children, () => parent.Children.Add(child)) ? child : null;
    }

    public MacroEntry? FindParent(MacroEntry entry) => Macros.FirstOrDefault(m => m.IsGroup && m.Children.Contains(entry));
    private List<MacroEntry>? FindSiblings(MacroEntry entry) => Macros.Contains(entry) ? Macros : FindParent(entry)?.Children;

    public MacroEntry? Duplicate(MacroEntry source)
    {
        var siblings = FindSiblings(source);
        var cost = 1 + (source.IsGroup ? source.Children.Count : 0);
        if (siblings == null || CountEntries() + cost > MaxEntries ||
            (siblings != Macros && siblings.Count >= MaxChildren)) return null;
        var copy = source.Clone();
        return TryEdit(siblings, () => siblings.Insert(siblings.IndexOf(source) + 1, copy)) ? copy : null;
    }

    public bool Remove(MacroEntry entry)
    {
        var siblings = FindSiblings(entry);
        return siblings != null && TryEdit(siblings, () => siblings.Remove(entry));
    }

    public void Move(MacroEntry entry, int offset)
    {
        var siblings = FindSiblings(entry);
        if (siblings == null) return;
        var index = siblings.IndexOf(entry);
        var destination = index + offset;
        if (destination < 0 || destination >= siblings.Count) return;
        TryEdit(siblings, () => { siblings.RemoveAt(index); siblings.Insert(destination, entry); });
    }

    private bool TryEdit(List<MacroEntry> siblings, Action edit)
    {
        var previous = siblings.ToArray();
        var binding = (CountdownTriggerEnabled, CountdownMacroId);
        edit();
        try { Save(); return true; }
        catch (Exception exception)
        {
            siblings.Clear();
            siblings.AddRange(previous);
            (CountdownTriggerEnabled, CountdownMacroId) = binding;
            Plugin.ChatGui.PrintError($"[Macro Shelf-A] 保存资料库失败，已撤销本次操作。{exception.Message}");
            return false;
        }
    }

    public void Save()
    {
        Normalize();
        Plugin.PluginInterface.SavePluginConfig(this);
    }

    internal bool TrySaveExecutionSettings(bool useNative, bool betterWait)
    {
        var next = (Configuration)MemberwiseClone();
        next.UseNativeMacroExecution = useNative;
        next.BetterWaitEnabled = betterWait;
        try { Plugin.PluginInterface.SavePluginConfig(next); }
        catch (Exception exception)
        {
            Plugin.ChatGui.PrintError($"[Macro Shelf-A] 保存执行设置失败。{exception.Message}");
            return false;
        }
        UseNativeMacroExecution = useNative;
        BetterWaitEnabled = betterWait;
        return true;
    }

    internal void SaveImport(ConfigurationExchange.ImportedConfiguration imported, bool replace)
    {
        // Imported entries have already been validated and normalized. Keep live
        // entries and their UI references untouched until the host accepts the save.
        var next = (Configuration)MemberwiseClone();
        next.Macros = replace ? imported.Macros : [.. Macros, .. imported.Macros];
        if (replace) next.ApplyImportSettings(imported);
        Plugin.PluginInterface.SavePluginConfig(next);

        Macros = next.Macros;
        if (replace) ApplyImportSettings(imported);
    }

    private void ApplyImportSettings(ConfigurationExchange.ImportedConfiguration imported)
    {
        ClearCountdownBinding();
        UseNativeMacroExecution = imported.UseNativeMacroExecution;
        BetterWaitEnabled = imported.BetterWaitEnabled;
        AllowLongMacros = imported.AllowLongMacros;
    }

    private static string Limit(string? value, int maxLength, string fallback)
    {
        var normalized = value?.Trim() ?? string.Empty;
        return normalized.Length == 0 ? fallback : TruncateLabel(normalized, maxLength);
    }

    internal static string TruncateLabel(string value, int maxLength)
    {
        if (value.Length <= maxLength) return value;
        if (maxLength > 0 && char.IsSurrogatePair(value[maxLength - 1], value[maxLength])) maxLength--;
        return value[..maxLength];
    }
}
