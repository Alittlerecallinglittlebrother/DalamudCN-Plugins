using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MacroShelfA;

internal static class ConfigurationBackup
{
    public static void BeforeNativeIntegrationMigration(Configuration configuration, string directory)
    {
        if (configuration.Version >= 9) return;
        SaveOnce(configuration, directory, "config-before-native-integration-v9.json");
    }

    // A one-time pre-migration snapshot; never replace an earlier backup.
    public static void BeforeGroupMigration(Configuration configuration, string directory)
    {
        if (configuration.Version >= 4) return;
        SaveOnce(configuration, directory, "config-before-groups-v4.json");
    }

    public static void BeforeLongMacroMigration(Configuration configuration, string directory)
    {
        if (configuration.Version >= 5) return;
        SaveOnce(configuration, directory, "config-before-long-macros-v5.json");
    }

    public static void BeforeCountdownMigration(Configuration configuration, string directory)
    {
        if (configuration.Version >= 6) return;
        SaveOnce(configuration, directory, "config-before-countdown-v6.json");
    }

    public static void BeforeZeroIntervalMigration(Configuration configuration, string directory)
    {
        if (configuration.Version >= 8) return;
        SaveOnce(configuration, directory, "config-before-zero-interval-v8.json");
    }

    private static void SaveOnce(Configuration configuration, string directory, string filename)
    {
        Directory.CreateDirectory(directory);
        var path = Path.Combine(directory, filename);
        if (File.Exists(path)) { CheckExisting(path); return; }

        var temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                JsonSerializer.Serialize(stream, configuration, SnapshotOptions);
                stream.Flush(true);
            }
            try { File.Move(temporary, path); }
            catch (IOException) when (File.Exists(path)) { CheckExisting(path); }
        }
        finally { File.Delete(temporary); }
    }

    private static readonly JsonSerializerOptions SnapshotOptions = new()
    {
        WriteIndented = true, NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals,
    };

    private static void CheckExisting(string path)
    {
        using var stream = File.OpenRead(path);
        try
        {
            using var json = JsonDocument.Parse(stream);
            var root = json.RootElement;
            if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty("Version", out var version) &&
                version.ValueKind == JsonValueKind.Number && version.TryGetInt32(out _) && root.TryGetProperty("Macros", out var macros) &&
                macros.ValueKind is JsonValueKind.Array or JsonValueKind.Null) return;
        }
        catch (JsonException) { /* An interrupted snapshot from an older release may still exist. */ }
        throw new InvalidDataException($"旧迁移备份不完整。请先将该文件移至其他位置，再重新加载插件：{path}");
    }
}
