using System;
using System.Collections.Generic;
using Dalamud.Game.Command;
using Dalamud.Interface;
using Dalamud.Interface.ManagedFontAtlas;
using Dalamud.Interface.Textures;
using Dalamud.Interface.Windowing;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using MacroShelfA.Runtime;
using MacroShelfA.Windows;

namespace MacroShelfA;

public sealed class Plugin : IDalamudPlugin
{
    private const string CommandName = "/aklmacro";

    [PluginService]
    internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;

    [PluginService]
    internal static ICommandManager CommandManager { get; private set; } = null!;

    [PluginService]
    internal static IFramework Framework { get; private set; } = null!;

    [PluginService]
    internal static IClientState ClientState { get; private set; } = null!;

    [PluginService]
    internal static ICondition Condition { get; private set; } = null!;

    [PluginService]
    internal static ISigScanner SigScanner { get; private set; } = null!;

    [PluginService]
    internal static IGameInteropProvider GameInteropProvider { get; private set; } = null!;

    [PluginService]
    internal static IChatGui ChatGui { get; private set; } = null!;

    [PluginService]
    internal static IPluginLog Log { get; private set; } = null!;

    [PluginService]
    internal static ITextureProvider TextureProvider { get; private set; } = null!;

    [PluginService]
    internal static IDataManager DataManager { get; private set; } = null!;

    private readonly WindowSystem windowSystem = new("MacroShelfA");
    private readonly Stack<Action> cleanup = new();
    private bool disposed;
    private readonly ShelfFont shelfFont;
    private readonly MacroExecutor macroExecutor;
    private readonly CountdownTrigger countdownTrigger;
    private readonly BetterWaitPatch betterWaitPatch;
    private readonly MainWindow mainWindow;
    private readonly FloatingLauncherWindow floatingLauncherWindow;
    private readonly QuickBarWindow quickBarWindow;
    private readonly NativeEmoteTrace nativeEmoteTrace;
    private readonly NativeMacroImportWindow nativeMacroImportWindow;
    private readonly MacroDisplayWindow macroDisplayWindow;
    private readonly SkillDisplayService skillDisplayService;
    private readonly NativeMacroBridgeWindow nativeMacroBridgeWindow;

    internal Configuration Configuration { get; }

    public Plugin()
    {
        var saved = PluginInterface.GetPluginConfig() as Configuration;
        Configuration = saved ?? Configuration.CreateDefault();
        var configDirectory = PluginInterface.GetPluginConfigDirectory();
        try
        {
            ConfigurationBackup.BeforeGroupMigration(Configuration, configDirectory);
            ConfigurationBackup.BeforeLongMacroMigration(Configuration, configDirectory);
            ConfigurationBackup.BeforeCountdownMigration(Configuration, configDirectory);
            ConfigurationBackup.BeforeZeroIntervalMigration(Configuration, configDirectory);
            ConfigurationBackup.BeforeNativeIntegrationMigration(Configuration, configDirectory);
            // Persist canonical IDs before a bridge can write them into game slots.
            if (Configuration.NormalizeForLoad() || saved == null) PluginInterface.SavePluginConfig(Configuration);
        }
        catch (Exception exception)
        {
            Log.Error(exception, "初始化资料库失败，已停止加载。");
            ChatGui.PrintError($"[Macro Shelf-A] 初始化资料库失败，已停止加载。{exception.Message}");
            throw;
        }
        try
        {
            shelfFont = Own(new ShelfFont(
                size => PluginInterface.UiBuilder.FontAtlas.NewDelegateFontHandle(e => e.OnPreBuild(tk => tk.AddDalamudDefaultFont(size))),
                () => UiBuilder.DefaultFontSizePx));

            nativeEmoteTrace = Own(new NativeEmoteTrace(GameInteropProvider, Framework, Condition, Log,
                () => NativeCommandTrace.Enabled, () => NativeCommandTrace.RawLayoutVerified,
                () => NativeCommandTrace.CurrentSource, () => NativeCommandTrace.SessionGeneration,
                message => ChatGui.Print($"[Macro Shelf-A] {message}")));
            cleanup.Push(NativeCommandTrace.End);
            betterWaitPatch = Own(new BetterWaitPatch(SigScanner, Log));
            betterWaitPatch.SetEnabled(Configuration.BetterWaitEnabled);
            macroExecutor = Own(new MacroExecutor(Configuration,
                nativeWaitReady: () => !Configuration.BetterWaitEnabled || betterWaitPatch.IsEnabled));
            countdownTrigger = Own(new CountdownTrigger(Configuration, macroExecutor));
            mainWindow = Own(new MainWindow(Configuration, macroExecutor, betterWaitPatch, countdownTrigger));
            var skillCatalog = new SkillCatalog(DataManager);
            skillDisplayService = Own(new SkillDisplayService(Configuration, Framework, ClientState, Condition, skillCatalog));
            mainWindow.Artwork = new ShelfArtwork(TextureProvider);
            mainWindow.SkillDisplay = skillDisplayService;
            mainWindow.Textures = TextureProvider;
            macroDisplayWindow = new MacroDisplayWindow(Configuration, skillCatalog, skillDisplayService);
            nativeMacroImportWindow = Own(new NativeMacroImportWindow(Configuration, mainWindow.RefreshLibrary));
            var nativeBackups = new NativeMacroBridgeBackups(configDirectory);
            var bridgeService = new NativeMacroBridgeService(new NativeMacroBridgeHost(), nativeBackups);
            nativeMacroBridgeWindow = Own(new NativeMacroBridgeWindow(Configuration, bridgeService,
                action => Framework.RunOnFrameworkThread(action)));
            mainWindow.OpenNativeMacroImport = nativeMacroImportWindow.Open;
            mainWindow.OpenDisplaySettings = macroDisplayWindow.Open;
            mainWindow.OpenNativeMacroBridge = nativeMacroBridgeWindow.OpenFor;
            // Inline task pages must not share transient target/draft state with
            // standalone dialogs opened from the classic UI or quickbar.
            mainWindow.ImportPage=new NativeMacroImportWindow(Configuration, mainWindow.RefreshLibrary);
            mainWindow.DisplayPage=new MacroDisplayWindow(Configuration, skillCatalog, skillDisplayService){Textures=TextureProvider};
            mainWindow.BridgePage=new NativeMacroBridgeWindow(Configuration, bridgeService,
                action => Framework.RunOnFrameworkThread(action));
            mainWindow.ImportPage.ViewImported=mainWindow.ShowImportedMacros;
            floatingLauncherWindow = new FloatingLauncherWindow(Configuration, mainWindow);
            quickBarWindow = new QuickBarWindow(Configuration, macroExecutor, mainWindow,
                skillDisplayService, macroDisplayWindow.Open, TextureProvider);
            mainWindow.DrawQuickDock = quickBarWindow.DrawDocked;
            cleanup.Push(windowSystem.RemoveAllWindows);
            windowSystem.AddWindow(mainWindow);
            windowSystem.AddWindow(floatingLauncherWindow);
            windowSystem.AddWindow(quickBarWindow);
            windowSystem.AddWindow(nativeMacroImportWindow);
            windowSystem.AddWindow(macroDisplayWindow);
            windowSystem.AddWindow(nativeMacroBridgeWindow);

            if (!CommandManager.AddHandler(CommandName, new CommandInfo(OnCommand)
            {
                HelpMessage = "打开或关闭 Macro Shelf-A。run <条目ID> 运行入口宏；bar 切换常用宏栏；stop 中止运行；version 查看版本；engine native / legacy / status 切换或查看执行器。",
            })) throw new InvalidOperationException($"命令 {CommandName} 已被占用。");
            cleanup.Push(() => CommandManager.RemoveHandler(CommandName));

            var ui = PluginInterface.UiBuilder;
            ui.Draw += DrawUi;
            cleanup.Push(() => ui.Draw -= DrawUi);
            ui.OpenMainUi += OpenMainUi;
            cleanup.Push(() => ui.OpenMainUi -= OpenMainUi);
            ui.OpenConfigUi += OpenMainUi;
            cleanup.Push(() => ui.OpenConfigUi -= OpenMainUi);
            ui.HideUi += mainWindow.HideAnnouncement;
            cleanup.Push(() => ui.HideUi -= mainWindow.HideAnnouncement);
            Log.Information("Macro Shelf-A {Version} 已加载。当前执行器：{Engine}。使用 {Command} 打开窗口。",
                typeof(Plugin).Assembly.GetName().Version?.ToString() ?? "未知", macroExecutor.ExecutionBackendName, CommandName);
        }
        catch { ReleaseResources(); throw; }
    }

    private T Own<T>(T resource) where T : IDisposable
    {
        cleanup.Push(resource.Dispose);
        return resource;
    }

    private void ReleaseResources()
    {
        while (cleanup.TryPop(out var release))
        {
            try { release(); }
            catch (Exception exception) { Log.Error(exception, "释放插件资源失败。"); }
        }
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        ReleaseResources();
        Configuration.Save();
    }

    private void DrawUi() => shelfFont.Draw(Configuration.UiFontScale, windowSystem.Draw);

    private void OnCommand(string command, string arguments)
    {
        var engineCommand = arguments.Trim();
        if (engineCommand.StartsWith("engine", StringComparison.OrdinalIgnoreCase))
        {
            if (string.Equals(engineCommand, "engine status", StringComparison.OrdinalIgnoreCase))
                ChatGui.Print($"[Macro Shelf-A] 执行器：{macroExecutor.ExecutionBackendName}；{macroExecutor.NativeStatusText}");
            else if (string.Equals(engineCommand, "engine native", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(engineCommand, "engine legacy", StringComparison.OrdinalIgnoreCase))
            {
                if (macroExecutor.IsRunning) { ChatGui.PrintError("[Macro Shelf-A] 请先停止当前宏，再切换执行器。"); return; }
                var useNative = engineCommand.EndsWith("native", StringComparison.OrdinalIgnoreCase);
                if (!Configuration.TrySaveExecutionSettings(useNative, Configuration.BetterWaitEnabled)) return;
                ChatGui.Print($"[Macro Shelf-A] 已选择：{macroExecutor.ExecutionBackendName}。原生候选按最多 15 行分段，保留等待，尚待游戏动画验收。");
            }
            else ChatGui.PrintError("[Macro Shelf-A] 用法：/aklmacro engine native | legacy | status");
            return;
        }
        if (MacroRunCommand.IsRunCommand(arguments))
        {
            if (!MacroRunCommand.TryRun(arguments, Configuration.Macros, macroExecutor.TryStart, out var error))
                ChatGui.PrintError($"[Macro Shelf-A] {error}");
            return;
        }
        if (string.Equals(arguments.Trim(), "trace on", StringComparison.OrdinalIgnoreCase))
        {
            NativeCommandTrace.Begin();
            ChatGui.Print("[Macro Shelf-A] 本地动作诊断已开启；请等到“动作诊断已就绪”再运行三行复现宏。只记录命令名、动作编号、实际调用结果与状态，不记录聊天正文；/aklmacro trace status 查看状态，trace off 关闭。");
            return;
        }
        if (string.Equals(arguments.Trim(), "trace status", StringComparison.OrdinalIgnoreCase))
        {
            ChatGui.Print($"[Macro Shelf-A] 诊断开启={NativeCommandTrace.Enabled}，客户端校验={NativeCommandTrace.RawLayoutVerified}；{nativeEmoteTrace.StatusText}。");
            return;
        }
        if (string.Equals(arguments.Trim(), "trace off", StringComparison.OrdinalIgnoreCase))
        {
            NativeCommandTrace.End();
            ChatGui.Print("[Macro Shelf-A] 命令链路诊断已关闭。");
            return;
        }
        if (string.Equals(arguments.Trim(), "version", StringComparison.OrdinalIgnoreCase))
        {
            ChatGui.Print($"[Macro Shelf-A] 当前加载版本：{typeof(Plugin).Assembly.GetName().Version}（原生宏执行本地候选版）；当前主题：{ShelfSkin.Name(Configuration.Theme)}；执行器：{macroExecutor.ExecutionBackendName}。");
            return;
        }
        if (string.Equals(arguments.Trim(), "bar", StringComparison.OrdinalIgnoreCase))
        {
            Configuration.ShowQuickBar = !Configuration.ShowQuickBar;
            Configuration.Save();
            return;
        }
        if (string.Equals(arguments.Trim(), "stop", StringComparison.OrdinalIgnoreCase))
        {
            macroExecutor.Stop();
            return;
        }
        mainWindow.Toggle();
    }

    private void OpenMainUi()
    {
        mainWindow.IsOpen = true;
    }
}
