# Macro Shelf-A

本仓库维护插件源码。当前发行版为 **0.9.6.3**，基于总库提交 `c879a4e` 对应的 0.9.6.2 公开源码。刷新国服卫月插件安装器即可更新，游戏内输入 `/aklmacro version` 可查看实际加载版本。[在线仓库](https://github.com/Alittlerecallinglittlebrother/DalamudCN-Plugins/tree/main/plugins/MacroShelfA) · [安装器订阅](https://raw.githubusercontent.com/Alittlerecallinglittlebrother/DalamudCN-Plugins/main/repo.json)

本版修复宏导入或编辑保存失败后丢失、重复和移动错位的问题，并修复重复 ID 导致旧热键运行错误条目的问题。受重复 ID 影响的旧入口需在“生成游戏热键入口”中重新生成。[完整发布说明](RELEASE.md)

## 开发与复审

在 Windows x64 安装 PowerShell 7 和 .NET 10 SDK，将 `DALAMUD_HOME` 指向包含 `Dalamud.dll` 的国服 API 15 程序集目录。使用下列命令构建插件，运行逻辑、原生接口边界和真实 ImGui 的离线用例。测试输出在 `verification/`。本机默认使用微软雅黑，可通过 `MACROSHELFA_TEST_FONT` 指向可读的中文字体文件。

```powershell
./build.ps1 -Configuration Release -Test
```

每个 push 和 PR 都会在 Windows 上执行同一命令。固定的程序集归档、开源中文字体及其 SHA-256 位于 `.github/workflows/verify.yml`。升级游戏适配时，在开发环境更新并验证 `Runtime/NativeClientProfile.cs` 对应的可执行文件、绑定和离线 ABI，再在游戏里核对取消、跨段等待和宏槽位写入／恢复。发布另行通过总库办理。

排查缺陷时先在 `MacroShelfA.Tests` 的对应入口复现，用保存后重开、失败后重试或宿主接管等情形固定行为，再改生产代码。资料库保存与配置交换在 `Configuration*.cs`，启动、取消及原生接口在 `Runtime/`，经典与主题界面共用的导入处理在 `Windows/MainWindow.Settings.cs`。

安装本地 Harness² Codex 适配器后，可对任意已提交版本重新审查。将下列路径替换为本机适配器和新的实验目录。`-BaseRevision` 可省略，也可指定要比较的 Git 提交。每轮一个候选，最多 12 个会话，实验只读取该提交的源码和测试。`-DryRun` 可先检查清单。维护者用可执行回归验证评审发现，原始评审和阶段记录保存在指定目录。

```powershell
./tools/review.ps1 -HarnessPath 'D:/tools/harness2/Harness2-Codex.ps1' -OutputDirectory '../macro-review' -BaseRevision ee59e69
```

## 0.9.6.2 历史记录

Dalamud CN API 15 / .NET 10 / Windows x64，沿用 0.9.6.1 的国服客户端适配。

### 0.9.6.2 更新

- 公告跟随主题配色，修复主播女孩主题的白字叠浅色正文、按钮的问题。
- 点击“知道了”“前往设置”或公告右上角 × 后保存已读状态。相同公告不再随主窗口重开或插件重载重复弹出。
- “主题与悬浮入口”新增 **界面字体大小**：80%–150%，默认 100%，支持滑块、Ctrl+点击输入和恢复默认。经典界面在“设置”中调整。
- 松开滑块或结束输入后保存并生效；保留字体构建所需的短暂等待。正文、编辑器、公告和常用栏使用插件私有的原生字体，不改变游戏或其他插件字号。
- 同一设置区域可点击“查看公告”手动重看。未来只有公告内容版本更新才再次自动提示。

旧配置不需要迁移，字号缺省为 100%。升级后首次需确认一次公告；此后已读状态持续保存。仅隐藏游戏 UI 或关闭整个主窗口不会把未读公告标为已读。宏备份追加/替换不覆盖本机字号和公告已读状态。

本次不改宏正文、执行方式选择、Runtime 源文件或游戏宏槽位。

### 0.9.6.2 构建与验证记录

设置 `DALAMUD_HOME` 指向 API 15 开发程序集目录，使用 PowerShell 7：

```powershell
./build.ps1 -Configuration Release -Test
```

输出：`MacroShelfA/bin/x64/Release`。测试报告/截图：`verification`。

离线测试调用真实 ImGui 和生产 UI 源码；字号测试的 Dalamud 异步字体句柄由真实中文字体支撑的测试边界模拟。**不等于游戏内验证**，仍需游戏内检查字体构建、显示和重载。

历史安装包、源码及该版校验值见 [0.9.6.2 在线存档](https://github.com/Alittlerecallinglittlebrother/DalamudCN-Plugins/tree/main/plugins/MacroShelfA/0.9.6.2)。
