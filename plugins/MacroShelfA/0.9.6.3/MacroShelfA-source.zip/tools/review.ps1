#requires -Version 7.0
param(
    [Parameter(Mandatory)][string]$HarnessPath,
    [Parameter(Mandatory)][string]$OutputDirectory,
    [string]$BaseRevision,
    [ValidateRange(8, 12)][int]$MaxSessions = 12,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$runner = (Resolve-Path -LiteralPath $HarnessPath).Path
$output = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputDirectory)
if (Test-Path -LiteralPath $output) { throw "Choose a new experiment directory: $output" }

# Only tracked project source, tests and build instructions enter the review.
# Read blobs from the commit so local configuration and edits cannot leak in.
$revision = git -C $root rev-parse --verify HEAD
if ($LASTEXITCODE) { throw 'A Git checkout of Macro Shelf-A is required.' }
$paths = git -C $root ls-tree -r --name-only $revision -- MacroShelfA MacroShelfA.Tests build.ps1 README.md .github/workflows
if ($LASTEXITCODE) { throw 'Could not enumerate source files.' }
$bundles = @{}
foreach ($path in $paths) {
    if ($path -notmatch '\.(cs|csproj|ps1|md|yml)$') { continue }
    $name = switch -Wildcard ($path) {
        'MacroShelfA.Tests/*' { 'tests.txt'; break }
        'MacroShelfA/Windows/*' { 'windows.txt'; break }
        'MacroShelfA/Runtime/*' { 'runtime.txt'; break }
        'MacroShelfA/*.cs' { 'library.txt'; break }
        default { 'maintenance.txt' }
    }
    if (!$bundles.ContainsKey($name)) { $bundles[$name] = [Text.StringBuilder]::new() }
    $lines = git -C $root show "${revision}:$path"
    if ($LASTEXITCODE) { throw "Could not read $path" }
    $null = $bundles[$name].AppendLine("### FILE $path")
    $number = 0
    foreach ($line in $lines) { $null = $bundles[$name].AppendLine(("{0}: {1}" -f (++$number), $line)) }
}
$files = @{ 'revision.txt' = "$revision" }
foreach ($name in $bundles.Keys) { $files[$name] = $bundles[$name].ToString() }
if ($BaseRevision) {
    $base = git -C $root rev-parse --verify --end-of-options "$BaseRevision^{commit}"
    if ($LASTEXITCODE) { throw "Unknown base revision: $BaseRevision" }
    $diff = git -C $root diff --no-ext-diff --no-color $base $revision -- '*.cs' '*.csproj' '*.ps1' '*.yml'
    if ($LASTEXITCODE) { throw 'Could not read the review diff.' }
    $files['changes.txt'] = $diff -join "`n"
}
foreach ($name in $files.Keys) {
    if ([Text.Encoding]::UTF8.GetByteCount($files[$name]) -gt 2MB) { throw "Review input exceeds the adapter limit: $name" }
}
$prompt = @'
Audit the committed C# source and the executable test sources. If changes.txt exists, first challenge each change and its regression tests. Trace real command, window, startup or unload paths. Prioritize persistence failures, retries, identities, cancellation and native slot ownership. For each actionable issue give source, method, triggering sequence, expected and actual consequence, and the failing regression a maintainer can run. Check whether stubs actually exercise production behavior. Distinguish hypotheses from executed checks. Write audit.md with at most five prioritized findings, coverage boundaries and live-game checks. Do not edit inputs. Do not give a numerical pass score.
'@
if ($BaseRevision) {
    $prompt += "`nThis is a change review. Bound findings to changed behavior and its directly affected callers. For each previously fixed failure, trace the fail/retry path in the current implementation. Report a clean result when the evidence supports it."
}
$manifest = @{
    work = 'independent, evidence-based review of Macro Shelf-A'
    instructions = 'Read the supplied UTF-8 files and write only the audit deliverable. Never access a live game.'
    allow_shell = $false; allow_extensions = $false; allow_subagents = $false
    tasks = @(@{ id = 'source-audit'; domain = 'code-review'; prompt = $prompt; files = $files; outputs = @('audit.md') })
}
$null = New-Item -ItemType Directory -Path $output
$taskFile = Join-Path $output 'tasks.json'
$manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $taskFile -Encoding utf8NoBOM
$runOptions = @('run', $taskFile, '--output', (Join-Path $output 'experiment'), '--mode', 'parallel', '--k', '1', '--max-sessions', "$MaxSessions", '--max-tool-calls', '100', '--timeout', '600')
if ($DryRun) { $runOptions += '--dry-run' }
& $runner @runOptions
exit $LASTEXITCODE
