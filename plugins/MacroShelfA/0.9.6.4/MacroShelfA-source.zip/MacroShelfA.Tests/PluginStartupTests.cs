extern alias shipping;
using System.Reflection;
using Live = shipping::MacroShelfA;

// Exercise the shipping constructor. Service proxies count subscriptions and
// fail artwork acquisition after the real runtime services have subscribed.
internal static class PluginStartupTests
{
    internal static void Run(Action<string, Action> test, Action<bool, string> check)
    {
        test("shipping constructor releases subscriptions after a late load failure", () =>
        {
            var host = new StartupHost();
            host.AttemptLoad();
            check(host.Added >= 4 && host.Listeners.Count == 0, "failed production startup leaked live event subscriptions");
            host.AttemptLoad();
            check(host.Listeners.Count == 0, "a failed reload accumulated event subscriptions");
        });
        test("shipping startup persists repaired IDs before native resources can expose them", () =>
        {
            var host = new StartupHost();
            host.AttemptLoad();
            var first = host.ReadIds();
            check(first.Distinct().Count() == 2 && !first.Contains("duplicate"), "repaired IDs were lost without an ordinary save");
            host.AttemptLoad();
            check(first.SequenceEqual(host.ReadIds()), "reload changed a previously repaired entrance ID");
            check(host.Saves == 1, "an already canonical library was rewritten at startup");
        });
        test("an omitted legacy ID is persisted once before any bridge can use it", () =>
        {
            var host = new StartupHost { Config = """{"Version":9,"BetterWaitEnabled":false,"Macros":[{"Name":"old"}]}""" };
            host.AttemptLoad();
            var id = host.ReadIds().Single();
            host.AttemptLoad();
            check(id.Length > 0 && host.ReadIds().Single() == id && host.Saves == 1, "missing legacy identity was not durable");
        });
        test("a partially constructed countdown subscription is removed on startup failure", () =>
        {
            var host = new StartupHost { Failure = "add_LogMessage" };
            host.AttemptLoad();
            check(host.Added > 0 && host.Listeners.Count == 0, "partial countdown constructor leaked its framework subscription");
        });
    }

    private sealed class StartupHost
    {
        public string Config = """{"Version":9,"BetterWaitEnabled":false,"Macros":[{"Id":"duplicate"},{"Id":"duplicate"}]}""";
        public int Saves;
        public readonly List<Delegate> Listeners = [];
        public int Added;
        public string Failure = "GetFromManifestResource";
        public string[] ReadIds() => Newtonsoft.Json.JsonConvert.DeserializeObject<Live.Configuration>(Config)!.Macros.Select(m => m.Id).ToArray();

        public void AttemptLoad()
        {
            var properties = typeof(Live.Plugin).GetProperties(BindingFlags.Static | BindingFlags.NonPublic)
                .Where(p => p.GetCustomAttributesData().Any(a => a.AttributeType.Name == "PluginServiceAttribute")).ToArray();
            try
            {
                foreach (var property in properties)
                {
                    var proxy = DispatchProxy.Create(property.PropertyType, typeof(StartupServiceProxy));
                    ((StartupServiceProxy)proxy).Call = Respond;
                    property.SetValue(null, proxy);
                }
                try { using var plugin = new Live.Plugin(); }
                catch (IOException e) when (e.Message == Failure) { return; }
                throw new InvalidOperationException("production constructor never reached the injected failure");
            }
            finally { foreach (var property in properties) property.SetValue(null, null); }
        }

        private object? Respond(MethodInfo method, object?[] args)
        {
            if (method.Name == Failure) throw new IOException(Failure);
            if (method.Name.StartsWith("add_")) { Added++; Listeners.Add((Delegate)args[0]!); return null; }
            if (method.Name.StartsWith("remove_")) { Listeners.Remove((Delegate)args[0]!); return null; }
            switch (method.Name)
            {
                case "GetPluginConfig": return Newtonsoft.Json.JsonConvert.DeserializeObject<Live.Configuration>(Config);
                case "GetPluginConfigDirectory": return AppContext.BaseDirectory;
                case "SavePluginConfig": Saves++; Config = Newtonsoft.Json.JsonConvert.SerializeObject(args[0]); return null;
                case "RunOnFrameworkThread" when args[0] is Action action: action(); return Task.CompletedTask;
            }
            return method.ReturnType.IsValueType && method.ReturnType != typeof(void) ? Activator.CreateInstance(method.ReturnType) : null;
        }
    }
}

public class StartupServiceProxy : DispatchProxy
{
    public Func<MethodInfo, object?[], object?> Call { get; set; } = null!;
    protected override object? Invoke(MethodInfo? method, object?[]? args) => Call(method!, args ?? []);
}
