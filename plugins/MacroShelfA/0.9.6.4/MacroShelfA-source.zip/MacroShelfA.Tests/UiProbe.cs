using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

// Compiled only by the test host, never shipped in MacroShelfA.dll.
internal sealed partial class MainWindow
{
    internal readonly Dictionary<string, (Vector2 Min, Vector2 Max)> UiItems = [];
    internal readonly Dictionary<string, (Vector2 Min, Vector2 Max)> ThemeRegions = [];
    internal readonly Dictionary<string, float> UiFontSizes = [];
    internal readonly Dictionary<string, Vector4[]> UiColors = [];
    internal WorkbenchLayout TestLayout => themedLayout;
    internal readonly Dictionary<string,float> ScrollRequests=[];
    internal TaskPage TestTaskPage=>taskPage;
    partial void RecordRegion(string key, Vector2 minimum, Vector2 maximum)
    {ThemeRegions[key]=(minimum,maximum);if(ScrollRequests.Remove(key,out var scroll))ImGui.SetScrollY(scroll);}
    partial void RecordItem(string key)
    {
        if (ImGui.IsItemVisible()) UiItems[key] = (ImGui.GetItemRectMin(), ImGui.GetItemRectMax());
        UiFontSizes[key] = ImGui.GetFontSize();
        if (key.StartsWith("announcement-"))
        {
            var colors = ImGui.GetStyle().Colors;
            UiColors[key] = key == "announcement-message"
                ? [colors[(int)ImGuiCol.Text], colors[(int)ImGuiCol.ChildBg], colors[(int)ImGuiCol.PopupBg], colors[(int)ImGuiCol.TitleBgActive]]
                : [colors[(int)ImGuiCol.Text], colors[(int)ImGuiCol.Button], colors[(int)ImGuiCol.ButtonHovered], colors[(int)ImGuiCol.ButtonActive]];
        }
    }
    internal MacroEntry? TestSelected => selectedMacro;
    internal int TestVisibleCount => VisibleRoots().Count;
    internal void TestRefresh() => InvalidateLibrary();
    internal void TestOpen(MacroEntry entry) => OpenEditor(entry);
    internal void TestImport(string json, bool replace) { importText = json; ImportConfiguration(replace); }
    internal bool TestImportFailed => transferStatusIsError && transferStatus.Contains("fixture write failure");
    internal ShelfCodeEditor TestCodeEditor => codeEditor;
}

internal sealed partial class ShelfCodeEditor
{
    internal Vector2 TestOrigin,TestMinimum,TestMaximum;
    internal float TestLineHeight;
    partial void RecordGeometry(Vector2 origin,float lineHeight,Vector2 minimum,Vector2 maximum)
    {TestOrigin=origin;TestLineHeight=lineHeight;TestMinimum=minimum;TestMaximum=maximum;}
}
