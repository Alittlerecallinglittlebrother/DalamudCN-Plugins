// Audited CN client 2026.11.03.0000.0000 (7.58).
// Unsupported clients remain disabled; these are identity checks, not raw call targets.
namespace MacroShelfA.Runtime;
internal static class NativeClientProfile
{
    internal const string GameVersion = "2026.11.03.0000.0000";
    internal const string ExeSha256 = "52042B60631CF2C48851B3AAEE36E9EC4FEDD6D7F2C68F0E9A8C3BEFB0AF9F98";
    internal const int ExecuteMacroRva = 0x912F10, CancelMacroRva = 0x9130E0;
    internal const int AgentExecuteEmoteRva = 0xF3BE60, CanExecuteEmoteRva = 0x1968D30, ExecuteEmoteRva = 0x1968470;
}
