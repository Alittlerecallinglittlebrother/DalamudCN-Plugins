using System;
using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace MacroShelfA.Windows;

internal sealed partial class MainWindow
{
    // Advance only when the notice content changes, not on every plugin release.
    internal const int CurrentAnnouncementVersion = 1;
    private const string AnnouncementTitle = "舞者提示###MacroShelfADanceAnnouncement";
    private const string AnnouncementMessage = "推荐打开左侧“行数与等待设置”“原生宏执行”  否则可能会出现切换职业后部分宏指令或动作失效的偶发性bug";
    private bool announcementPending;
    private uint announcementPopupId;

    // WindowHost calls OnOpen before PreDraw/Begin, once per actual open transition.
    // Do not call ImGui.OpenPopup here: the main window's ID scope does not exist yet.
    public override void OnOpen() => announcementPending =
        configuration.AcknowledgedAnnouncementVersion < CurrentAnnouncementVersion;

    internal void ShowAnnouncement() => announcementPending = true;

    private void AcknowledgeAnnouncement()
    {
        announcementPending = false;
        if (configuration.AcknowledgedAnnouncementVersion >= CurrentAnnouncementVersion) return;
        configuration.AcknowledgedAnnouncementVersion = CurrentAnnouncementVersion;
        configuration.Save();
    }

    internal unsafe void HideAnnouncement()
    {
        var resume = announcementPending;
        var context = ImGui.GetCurrentContext();
        if (announcementPopupId != 0 && context.Handle != null)
            for (var i = 0; i < context.OpenPopupStack.Size; i++)
                resume |= context.OpenPopupStack[i].PopupId == announcementPopupId;
        ClearAnnouncement();
        announcementPending = resume;
    }

    private void DrawAnnouncement()
    {
        if (announcementPending && !ImGuiP.IsPopupOpen(0u, ImGuiPopupFlags.AnyPopupId | ImGuiPopupFlags.AnyPopupLevel))
        {
            announcementPopupId = ImGui.GetID(AnnouncementTitle);
            ImGui.OpenPopup(AnnouncementTitle);
            announcementPending = false;
        }
        if (announcementPopupId == 0 || !ImGui.IsPopupOpen(AnnouncementTitle)) return;

        var viewport = ImGui.GetWindowViewport();
        var size = new Vector2(MathF.Min(S(560) * Configuration.NormalizeUiFontScale(configuration.UiFontScale), MathF.Max(1, viewport.WorkSize.X - 32)),
            MathF.Min(MathF.Max(S(245), ImGui.GetTextLineHeightWithSpacing() * 8 + S(72)), MathF.Max(1, viewport.WorkSize.Y - 32)));
        var center = ImGui.GetWindowPos() + ImGui.GetWindowSize() / 2;
        center = Vector2.Clamp(center, viewport.WorkPos + size / 2, viewport.WorkPos + viewport.WorkSize - size / 2);
        ImGui.SetNextWindowPos(center, ImGuiCond.Always, new Vector2(.5f));
        ImGui.SetNextWindowSize(size, ImGuiCond.Always);
        // Own the whole palette, not just white text over inherited light children/buttons.
        using var skin = ShelfSkin.Apply(CurrentTheme == ShelfTheme.Classic ? ShelfTheme.Persona3 : CurrentTheme,
            configuration.ReduceThemeMotion);
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(S(18)));
        var open = true;
        if (ImGui.BeginPopupModal(AnnouncementTitle, ref open,
                ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoSavedSettings))
        {
            RecordRegion("announcement-modal", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
            var buttonHeight = MathF.Max(S(34), ImGui.GetFrameHeight());
            var bodyHeight = MathF.Max(1, ImGui.GetContentRegionAvail().Y - buttonHeight - ImGui.GetStyle().ItemSpacing.Y);
            ImGui.BeginChild("##AnnouncementBody", new Vector2(0, bodyHeight), false);
            ImGui.TextWrapped(AnnouncementMessage);
            RecordItem("announcement-message");
            ImGui.EndChild();
            var buttonWidth = MathF.Max(1, (ImGui.GetContentRegionAvail().X - ImGui.GetStyle().ItemSpacing.X) / 2);
            if (ImGui.Button("知道了", new Vector2(buttonWidth, buttonHeight)))
            {
                AcknowledgeAnnouncement();
                ImGui.CloseCurrentPopup();
            }
            RecordItem("announcement-dismiss");
            ImGui.SameLine();
            if (ImGui.Button("前往设置", new Vector2(buttonWidth, buttonHeight)))
            {
                page = Page.Settings;
                NavigateTask(TaskPage.Execution);
                AcknowledgeAnnouncement();
                ImGui.CloseCurrentPopup();
            }
            RecordItem("announcement-settings");
            ImGui.EndPopup();
        }
        // The modal's own X is also an explicit dismissal. Closing/hiding the main
        // window uses ClearAnnouncement instead and must not mark an unread notice.
        if (!open) AcknowledgeAnnouncement();
        ImGui.PopStyleVar();
    }

    private unsafe void ClearAnnouncement()
    {
        announcementPending = false;
        if (announcementPopupId == 0) return;
        var context = ImGui.GetCurrentContext();
        if (context.Handle != null)
        {
            // Closing the parent window bypasses BeginPopupModal, so remove only our
            // own popup (and its children), never a different plugin's modal.
            for (var i = 0; i < context.OpenPopupStack.Size; i++)
            {
                if (context.OpenPopupStack[i].PopupId != announcementPopupId) continue;
                ImGuiP.ClosePopupToLevel(i, false);
                break;
            }
        }
        announcementPopupId = 0;
    }
}
