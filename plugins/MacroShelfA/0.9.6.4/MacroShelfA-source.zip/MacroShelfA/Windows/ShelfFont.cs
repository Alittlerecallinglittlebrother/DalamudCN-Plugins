using System;
using Dalamud.Interface.ManagedFontAtlas;

namespace MacroShelfA.Windows;

// A plugin-owned, rebuilt default font. Never mutate FontGlobalScale, shared ImFont
// state or window scales: nested children and InputText must use the same metrics.
internal sealed class ShelfFont(Func<float, IFontHandle> createFont, Func<float> defaultSize) : IDisposable
{
    private IFontHandle? active, pending;
    private float requestedSize;

    public void Draw(float scale, Action draw)
    {
        scale = Configuration.NormalizeUiFontScale(scale);
        if (scale == 1f)
        {
            Dispose();
            draw();
            return;
        }

        var size = defaultSize() * scale;
        if (size != requestedSize)
        {
            pending?.Dispose();
            pending = createFont(size);
            requestedSize = size;
        }
        // Keep the previous font until the asynchronous build is ready.
        if (pending?.Available == true)
        {
            active?.Dispose();
            active = pending;
            pending = null;
        }
        using var scope = active?.Push();
        draw();
    }

    public void Dispose()
    {
        pending?.Dispose();
        active?.Dispose();
        pending = active = null;
        requestedSize = 0;
    }
}
