using System.Numerics;

using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility;

using MidiBard2.Resources;

namespace MidiBard;

public partial class PluginUI
{
    private bool showSettingsWindow = false;
    public bool SettingsWindowOpened => showSettingsWindow;
    private bool showCompensationEditWindow = false;
    private bool showInstrumentNameReferenceWindow = false;

    public void ToggleSettingsWindow()
    {
        if (showSettingsWindow)
            CloseSettingsWindow();
        else
            OpenSettingsWindow();
    }

    public void OpenSettingsWindow()
    {
        showSettingsWindow = true;
    }

    public void CloseSettingsWindow()
    {
        showSettingsWindow = false;
    }

    private void DrawSettigsWindow()
    {
        if (!showSettingsWindow) return;

        ImGui.SetNextWindowSizeConstraints(new Vector2(350, 100) * ImGuiHelpers.GlobalScale, ImGuiHelpers.MainViewport.Size);
        ImGui.Begin("MidiBard Settings", ref showSettingsWindow);

        if (ImGui.BeginTabBar("ConfigTabs"))
        {
            if (ImGui.BeginTabItem($"{Language.setting_group_label_general_settings}##GeneralSettingsTab"))
            {
                DrawGeneralSettings();
                ImGui.EndTabItem();
            }

            if (ImGui.BeginTabItem($"{Language.setting_group_label_performance_settings}##PerformanceSettingsTab"))
            {
                DrawPerformanceSettings();
                ImGui.EndTabItem();
            }

            if (ImGui.BeginTabItem($"{Language.setting_group_label_ensemble_settings}##EnsembleSettingsTab"))
            {
                DrawEnsembleSettings();
                ImGui.EndTabItem();
            }
            if (ImGui.BeginTabItem("欢迎语音"))
            {
                if (MidiBard.WelcomeVoice != null) MidiBard.WelcomeVoice.DrawSettings();
                else ImGui.TextWrapped("欢迎语音初始化失败，请查看卫月日志；其他功能可继续使用。");
                ImGui.EndTabItem();
            }
            ImGui.EndTabBar();
        }

        ImGui.End();


    }



}
