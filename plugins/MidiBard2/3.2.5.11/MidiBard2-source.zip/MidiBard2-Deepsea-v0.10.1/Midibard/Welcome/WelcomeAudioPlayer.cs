#nullable enable
using System;
using System.Collections.Concurrent;
using System.IO;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace MidiBard.Welcome;

public sealed class WelcomeAudioPlayer(string assetDirectory) : IWelcomeAudio
{
    private readonly ConcurrentQueue<(object? Sender, Exception? Error)> stopped = new();
    private WaveOutEvent? output;
    private WaveFileReader? reader;
    private VolumeSampleProvider? samples;
    private bool disposed;
    public string Error { get; private set; } = "";
    public bool IsPlaying => output?.PlaybackState == PlaybackState.Playing;

    public bool TryPlay(WelcomeClip clip, float volume)
    {
        if (disposed) return false;
        Stop();
        Error = "";
        try
        {
            reader = new WaveFileReader(Path.Combine(assetDirectory, WelcomeClips.FileName(clip)));
            samples = CreateSamples(reader, volume);
            output = new WaveOutEvent { DesiredLatency = 100, NumberOfBuffers = 2 };
            output.PlaybackStopped += PlaybackStopped;
            output.Init(samples.ToWaveProvider16());
            output.Play();
            return true;
        }
        catch (Exception ex)
        {
            Error = ex.Message;
            Stop();
            return false;
        }
    }

    public static VolumeSampleProvider CreateSamples(WaveFileReader source, float volume) =>
        new(source.ToSampleProvider()) { Volume = WelcomeClips.Volume(volume) };

    public void SetVolume(float volume)
    {
        // Scale this stream only; never change the game's or Windows device volume.
        if (samples != null) samples.Volume = WelcomeClips.Volume(volume);
    }

    private void PlaybackStopped(object? sender, StoppedEventArgs args) => stopped.Enqueue((sender, args.Exception));

    public void Poll()
    {
        while (stopped.TryDequeue(out var item))
        {
            if (!ReferenceEquals(item.Sender, output)) continue;
            if (item.Error != null) Error = item.Error.Message;
            Stop();
        }
    }

    public void Stop()
    {
        var previous = output;
        output = null;
        try
        {
            if (previous != null)
            {
                previous.PlaybackStopped -= PlaybackStopped;
                previous.Dispose();
            }
        }
        catch (Exception ex) { Error = ex.Message; }
        finally
        {
            try { reader?.Dispose(); }
            catch (Exception ex) { Error = ex.Message; }
            reader = null; samples = null;
        }
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        Stop();
        while (stopped.TryDequeue(out _)) { }
    }
}
