#nullable enable
using System;
using System.IO;
using Dalamud.Utility;

namespace MidiBard.Welcome;

internal sealed class WelcomeVoiceFeature : IDisposable
{
    private readonly WelcomeVoicePanel panel = new();
    private readonly WelcomeVoiceSession session;
    private string lastError = "";

    public WelcomeVoiceFeature(FileInfo pluginAssemblyLocation)
    {
        // Dalamud loads plugin assemblies from memory, so Assembly.Location is empty.
        var directory = pluginAssemblyLocation.Directory ?? throw new ArgumentException("Plugin directory is unavailable.", nameof(pluginAssemblyLocation));
        session = new WelcomeVoiceSession(new WelcomeAudioPlayer(Path.Combine(directory.FullName, "Assets", "Welcome")));
    }

    private static bool Busy => MidiBard.AgentPerformance?.InPerformanceMode == true || MidiBard.IsPlaying
        || MidiBard.AgentMetronome?.EnsembleModeRunning == true || MidiBard.AgentMetronome?.MetronomeRunning == true
        || MidiBard.Stage?.IsPreparingOrPerforming == true;

    public void Tick(bool visible)
    {
        var loggedIn = api.ClientState.IsLoggedIn;
        WelcomeIdentity? identity = loggedIn ? new WelcomeIdentity(api.Player.ContentId, api.Player.CharacterName,
            api.Player.HomeWorld.ValueNullable?.Name.ToDalamudString().TextValue ?? "") : null;
        session.Tick(loggedIn, identity, visible, loggedIn && Busy, MidiBard.config.WelcomeVoiceEnabled, MidiBard.config.WelcomeVoiceVolume);
        if (session.Error.Length > 0 && session.Error != lastError) api.PluginLog.Warning("Welcome voice: " + session.Error);
        lastError = session.Error;
    }

    public void DrawSettings()
    {
        if (panel.Draw(session, api.ClientState.IsLoggedIn && Busy, ref MidiBard.config.WelcomeVoiceEnabled, ref MidiBard.config.WelcomeVoiceVolume))
            MidiBard.SaveConfig();
    }

    public void Dispose() => session.Dispose();
}
