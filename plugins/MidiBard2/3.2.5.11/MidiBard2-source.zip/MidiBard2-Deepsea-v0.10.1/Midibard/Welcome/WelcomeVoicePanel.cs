#nullable enable
using System;
using BardStage.Windows;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;

namespace MidiBard.Welcome;

public sealed class WelcomeVoicePanel
{
    private int selection;
    private static readonly string[] choices = ["自动匹配", "七猫", "悼亡录", "其他玩家"];

    public bool Draw(WelcomeVoiceSession session, bool busy, ref bool enabled, ref float volume)
    {
        var changed = ImGui.Checkbox("打开时播放欢迎语音", ref enabled);
        UiKit.Tip("每次登录首次打开时播放。\n演奏或准备期间跳过。\n仅在本机播放。");
        if (!enabled) session.Stop();
        var percent = WelcomeClips.Volume(volume) * 100;
        ImGui.SetNextItemWidth(Math.Max(100, ImGui.GetContentRegionAvail().X - 55 * UiKit.Scale));
        if (ImGui.SliderFloat("音量", ref percent, 0, 100, "%.0f%%"))
        {
            volume = percent / 100;
        }
        changed |= ImGui.IsItemDeactivatedAfterEdit();
        var identity = session.Identity;
        ImGui.TextWrapped(identity.HasValue ? "当前欢迎：" + WelcomeClips.Label(WelcomeClips.Match(identity.Value)) : "等待角色信息");
        ImGui.Separator();
        ImGui.SetNextItemWidth(Math.Max(100, ImGui.GetContentRegionAvail().X - 85 * UiKit.Scale));
        ImGui.Combo("##welcomeVoiceChoice", ref selection, choices, choices.Length);
        var clip = selection switch
        {
            1 => WelcomeClip.Qimao,
            2 => WelcomeClip.Daowanglu,
            3 => WelcomeClip.General,
            _ => identity.HasValue ? WelcomeClips.Match(identity.Value) : WelcomeClip.General,
        };
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.Play, "previewWelcomeVoice", "试听", enabled && !busy && identity.HasValue && volume > 0))
            session.Preview(clip, busy, enabled, volume);
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.Stop, "stopWelcomeVoice", "停止", session.IsPlaying)) session.Stop();
        if (session.Error.Length > 0) ImGui.TextWrapped("播放失败：" + session.Error);
        else if (busy) UiKit.MutedText("演奏中，欢迎语音已停止");
        else if (session.IsPlaying) UiKit.MutedText(session.Status);
        return changed;
    }
}
