#nullable enable
using System;

namespace MidiBard.Welcome;

public enum WelcomeClip { General, Qimao, Daowanglu }

public readonly record struct WelcomeIdentity(ulong ContentId, string Name, string HomeWorld)
{
    public bool IsReady => ContentId != 0 && !string.IsNullOrWhiteSpace(Name) && !string.IsNullOrWhiteSpace(HomeWorld);
}

public static class WelcomeClips
{
    public static WelcomeClip Match(WelcomeIdentity identity) => (identity.Name, identity.HomeWorld) switch
    {
        ("七猫猫猫猫", "伊修加德") => WelcomeClip.Qimao,
        ("悼亡录", "红茶川") => WelcomeClip.Daowanglu,
        _ => WelcomeClip.General,
    };

    public static string FileName(WelcomeClip clip) => clip switch
    {
        WelcomeClip.Qimao => "qimao.wav",
        WelcomeClip.Daowanglu => "daowanglu.wav",
        _ => "general.wav",
    };

    public static string Label(WelcomeClip clip) => clip switch
    {
        WelcomeClip.Qimao => "七猫",
        WelcomeClip.Daowanglu => "悼亡录",
        _ => "其他玩家",
    };

    public static float Volume(float value) => float.IsFinite(value) ? Math.Clamp(value, 0, 1) : 0.55f;
}

public interface IWelcomeAudio : IDisposable
{
    bool IsPlaying { get; }
    string Error { get; }
    bool TryPlay(WelcomeClip clip, float volume);
    void SetVolume(float volume);
    void Stop();
    void Poll();
}

public sealed class WelcomeVoiceSession(IWelcomeAudio audio) : IDisposable
{
    private ulong contentId;
    private bool greeted, wasVisible, disposed;
    public WelcomeIdentity? Identity { get; private set; }
    public string Status { get; private set; } = "";
    public string Error => audio.Error;
    public bool IsPlaying => audio.IsPlaying;

    public void Tick(bool loggedIn, WelcomeIdentity? identity, bool visible, bool busy, bool enabled, float volume)
    {
        if (disposed) return;
        audio.Poll();
        audio.SetVolume(WelcomeClips.Volume(volume));
        if (!loggedIn)
        {
            Stop(); contentId = 0; greeted = false; wasVisible = false; Identity = null;
            return;
        }
        if (identity is not { IsReady: true } player)
        {
            Stop(); Identity = null;
            return;
        }
        Identity = player;
        if (contentId != player.ContentId)
        {
            Stop(); contentId = player.ContentId; greeted = false; wasVisible = false;
        }
        var opened = visible && !wasVisible;
        wasVisible = visible;
        if (!visible || busy || !enabled || WelcomeClips.Volume(volume) == 0) Stop();
        if (!opened || greeted) return;
        // Consume the opening even when skipped, so a welcome cannot start between songs.
        greeted = true;
        if (busy) { Status = "演奏期间已跳过欢迎语音"; return; }
        if (!enabled || WelcomeClips.Volume(volume) == 0) return;
        Play(WelcomeClips.Match(player), volume);
    }

    public bool Preview(WelcomeClip clip, bool busy, bool enabled, float volume)
    {
        if (disposed || Identity == null || !enabled || WelcomeClips.Volume(volume) == 0) return false;
        if (busy) { Stop(); Status = "演奏期间无法试听"; return false; }
        return Play(clip, volume);
    }

    private bool Play(WelcomeClip clip, float volume)
    {
        var played = audio.TryPlay(clip, WelcomeClips.Volume(volume));
        Status = played ? "欢迎语音：" + WelcomeClips.Label(clip) : "欢迎语音播放失败";
        return played;
    }

    public void Stop() => audio.Stop();

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        audio.Dispose();
    }
}
