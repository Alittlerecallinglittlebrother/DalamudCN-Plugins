using MidiBard.Welcome;
using Xunit;

public sealed class WelcomeVoiceTests
{
    private static readonly WelcomeIdentity Qimao = new(1, "七猫猫猫猫", "伊修加德");

    [Theory]
    [InlineData("七猫猫猫猫", "伊修加德", WelcomeClip.Qimao)]
    [InlineData("七猫猫猫猫", "红茶川", WelcomeClip.General)]
    [InlineData("七猫", "伊修加德", WelcomeClip.General)]
    [InlineData("悼亡录", "红茶川", WelcomeClip.Daowanglu)]
    [InlineData("悼亡录", "伊修加德", WelcomeClip.General)]
    [InlineData("普通玩家", "红茶川", WelcomeClip.General)]
    public void FullNameAndHomeWorldMustMatch(string name, string world, WelcomeClip expected) =>
        Assert.Equal(expected, WelcomeClips.Match(new(1, name, world)));

    [Fact]
    public void OpeningBeforeLoginWaitsForCompleteIdentity()
    {
        using var audio = new Audio(); using var session = new WelcomeVoiceSession(audio);
        session.Tick(false, null, true, false, true, 0.55f);
        session.Tick(true, new(1, Qimao.Name, ""), true, false, true, 0.55f);
        Assert.Empty(audio.Plays);
        session.Tick(true, Qimao, true, false, true, 0.55f);
        Assert.Equal(WelcomeClip.Qimao, Assert.Single(audio.Plays));
    }

    [Fact]
    public void ReopeningAndTemporaryIdentityLossDoNotRepeatGreeting()
    {
        using var audio = new Audio(); using var session = new WelcomeVoiceSession(audio);
        Tick(session); Tick(session, visible: false); Tick(session);
        session.Tick(true, null, true, false, true, 0.55f);
        Tick(session);
        Assert.Single(audio.Plays);
    }

    [Fact]
    public void LogoutAndSwitchingCharactersStartNewWelcomeSessions()
    {
        using var audio = new Audio(); using var session = new WelcomeVoiceSession(audio);
        Tick(session);
        session.Tick(false, null, true, false, true, 0.55f);
        Assert.False(audio.IsPlaying);
        Tick(session);
        session.Tick(true, new(2, "悼亡录", "红茶川"), true, false, true, 0.55f);
        Assert.Equal(new[] { WelcomeClip.Qimao, WelcomeClip.Qimao, WelcomeClip.Daowanglu }, audio.Plays);
    }

    [Fact]
    public void BusyOpeningIsNotDeferredUntilBetweenSongs()
    {
        using var audio = new Audio(); using var session = new WelcomeVoiceSession(audio);
        Tick(session, busy: true); Tick(session); Tick(session, visible: false); Tick(session);
        Assert.Empty(audio.Plays);
    }

    [Fact]
    public void PerformanceStartingOrWindowClosingStopsVoice()
    {
        using var audio = new Audio(); using var session = new WelcomeVoiceSession(audio);
        Tick(session); Assert.True(audio.IsPlaying);
        Tick(session, busy: true); Assert.False(audio.IsPlaying);
        Assert.False(session.Preview(WelcomeClip.General, true, true, 0.5f));
        Assert.True(session.Preview(WelcomeClip.Daowanglu, false, true, 0.5f));
        Tick(session, visible: false); Assert.False(audio.IsPlaying);
    }

    [Theory]
    [InlineData(false, 0.55f)]
    [InlineData(true, 0f)]
    public void DisabledOrMutedOpeningDoesNotPlayLater(bool enabled, float volume)
    {
        using var audio = new Audio(); using var session = new WelcomeVoiceSession(audio);
        session.Tick(true, Qimao, true, false, enabled, volume);
        Tick(session); Tick(session, visible: false); Tick(session);
        Assert.Empty(audio.Plays);
    }

    [Fact]
    public void FailedDeviceDoesNotRetryEveryFrameButAllowsManualRetry()
    {
        using var audio = new Audio { Fail = true }; using var session = new WelcomeVoiceSession(audio);
        Tick(session); Tick(session); Tick(session);
        Assert.Single(audio.Plays); Assert.False(audio.IsPlaying);
        audio.Fail = false;
        Assert.True(session.Preview(WelcomeClip.Qimao, false, true, 0.5f));
        Assert.Equal(2, audio.Plays.Count);
    }

    [Fact]
    public void MutingAndUnloadingStopAudioWithoutRetriggering()
    {
        using var audio = new Audio(); var session = new WelcomeVoiceSession(audio);
        Tick(session);
        session.Tick(true, Qimao, true, false, true, 0);
        Assert.False(audio.IsPlaying);
        session.Dispose(); Tick(session);
        Assert.Single(audio.Plays); Assert.True(audio.Disposed);
    }

    private static void Tick(WelcomeVoiceSession session, bool visible = true, bool busy = false) =>
        session.Tick(true, Qimao, visible, busy, true, 0.55f);

    private sealed class Audio : IWelcomeAudio
    {
        public List<WelcomeClip> Plays { get; } = [];
        public bool IsPlaying { get; private set; }
        public bool Disposed { get; private set; }
        public bool Fail { get; set; }
        public string Error => Fail ? "test device unavailable" : "";
        public bool TryPlay(WelcomeClip clip, float volume) { Plays.Add(clip); IsPlaying = !Fail; return IsPlaying; }
        public void SetVolume(float volume) { }
        public void Stop() => IsPlaying = false;
        public void Poll() { }
        public void Dispose() { Stop(); Disposed = true; }
    }
}
