using System.Numerics;
using BardStage;
using BardStage.Core;
using BardStage.Windows;
using Dalamud.Bindings.ImGui;

internal static unsafe partial class RuntimeUi
{
    private static void RenderCleanup(StageController source, string output)
    {
        using var controller = new StageController(Path.Combine(Path.GetTempPath(), "cleanup-ui-" + Guid.NewGuid()));
        controller.Change(s => s.Songs = StageController.Clone(source.State.Songs));
        controller.EnsureAutomaticQueue();
        var start = DateTimeOffset.UtcNow.AddMinutes(-5);
        controller.Change(s =>
        {
            var show = s.Setlists[0]; show.Name = "观众点歌";
            RequestOperations.Submit(s, show.Id, "观众甲", "", s.Songs[0].Title, RequestChannel.Manual, start);
            RequestOperations.Submit(s, show.Id, "观众乙", "", s.Songs[1].Title, RequestChannel.Manual, start);
            SetlistOperations.AddSong(show, s.Songs[2]);
        });
        var show = controller.CurrentSetlist!;
        var first = show.Entries[0].Id; var second = show.Entries[1].Id;
        controller.Change(s => SetlistOperations.Start(s.Setlists[0], first, start), atUtc: start);
        controller.Change(s => SetlistOperations.Finish(s.Setlists[0], first, start.AddSeconds(30)), atUtc: start.AddSeconds(30));
        controller.Change(s => SetlistOperations.Skip(s.Setlists[0], second, start.AddSeconds(40)), atUtc: start.AddSeconds(40));
        using var window = new MainWindow(controller);
        Set(window, "requestFilter", 1);
        foreach (var (method, name) in new[] { ("DrawAutomaticQueue", "cleanup-queue"), ("DrawSetlists", "cleanup-setlist"), ("DrawRequests", "cleanup-requests"), ("DrawSessions", "cleanup-sessions") })
        {
            CleanupFrame(window, method); CleanupFrame(window, method);
            if (method == "DrawAutomaticQueue") { CleanupClick(window, method, 70, 201); CleanupFrame(window, method); }
            SoftwareRenderer.Save(Path.Combine(output, name + ".png"));
            ImGui.GetIO().FontGlobalScale = 1.4f;
            CleanupFrame(window, method, 760, 540); CleanupFrame(window, method, 760, 540);
            SoftwareRenderer.Save(Path.Combine(output, name + "-small-scaled.png"));
            ImGui.GetIO().FontGlobalScale = 1;
        }
        Console.WriteLine("PASS: cleanup views render at desktop and 140% compact window using native ImGui");
        CleanupFrame(window, "DrawSessions"); CleanupFrame(window, "DrawSessions");
        CleanupClick(window, "DrawSessions", 21, 142);
        CleanupFrame(window, "DrawSessions");
        SoftwareRenderer.Save(Path.Combine(output, "cleanup-export-menu.png"));
        var popup = CleanupPopupBounds();
        CleanupClick(window, "DrawSessions", popup.X + 20, popup.Y + 12);
        CleanupFrame(window, "DrawSessions"); CleanupFrame(window, "DrawSessions");
        SoftwareRenderer.Save(Path.Combine(output, "cleanup-export-result.png"));
        CleanupCheck(!controller.StatusIsError && File.Exists(controller.LastSessionExportPath)
            && Path.GetExtension(controller.LastSessionExportPath) == ".json" && controller.State.Sessions.Single().EndedAtUtc == null,
            "native unarchived export menu writes a real JSON file without archiving");
        var jsonPath = controller.LastSessionExportPath;
        CleanupClick(window, "DrawSessions", 21, 142);
        CleanupFrame(window, "DrawSessions");
        popup = CleanupPopupBounds();
        CleanupClick(window, "DrawSessions", popup.X + 20, popup.Y + 12 + ImGui.GetTextLineHeightWithSpacing());
        CleanupFrame(window, "DrawSessions");
        CleanupCheck(!controller.StatusIsError && File.Exists(controller.LastSessionExportPath)
            && Path.GetExtension(controller.LastSessionExportPath) == ".csv" && File.Exists(jsonPath)
            && File.ReadAllBytes(controller.LastSessionExportPath).Take(3).SequenceEqual(new byte[] { 0xef, 0xbb, 0xbf })
            && controller.State.Sessions.Single().EndedAtUtc == null,
            "native CSV export writes an Excel-compatible file and preserves the prior JSON export");

        CleanupFrame(window, "DrawAutomaticQueue"); CleanupFrame(window, "DrawAutomaticQueue");
        CleanupClick(window, "DrawAutomaticQueue", 1001, 280);
        ConfirmCleanup(window, "DrawAutomaticQueue");
        CleanupCheck(controller.CurrentSetlist!.Entries.Count == 2, "native ended-row trash removes a finished program");
        CleanupClick(window, "DrawAutomaticQueue", 22, 230);
        ConfirmCleanup(window, "DrawAutomaticQueue");
        CleanupCheck(controller.CurrentSetlist.Entries.Count == 1 && controller.CurrentSetlist.Entries[0].Status == EntryStatus.Queued,
            "native clear-ended button preserves the waiting queue");

        CleanupFrame(window, "DrawSetlists"); CleanupFrame(window, "DrawSetlists");
        CleanupClick(window, "DrawSetlists", 700, 190);
        ConfirmCleanup(window, "DrawSetlists");
        CleanupCheck(controller.CurrentSetlist.Entries.Count == 0 && controller.State.Songs.Count > 0, "native program row deletion preserves the song library");

        CleanupFrame(window, "DrawRequests"); CleanupFrame(window, "DrawRequests");
        CleanupClick(window, "DrawRequests", 611, 152);
        ConfirmCleanup(window, "DrawRequests");
        CleanupCheck(controller.State.Requests.Count == 1, "native request-row trash deletes the selected request record");

        CleanupFrame(window, "DrawSessions"); CleanupFrame(window, "DrawSessions");
        CleanupClick(window, "DrawSessions", 1072, 193);
        ConfirmCleanup(window, "DrawSessions");
        CleanupCheck(controller.State.Sessions.Single().Attempts.Count == 1, "native attempt-row trash removes one performance detail");
        CleanupClick(window, "DrawSessions", 96, 142);
        ConfirmCleanup(window, "DrawSessions");
        CleanupCheck(controller.State.Sessions.Count == 0 && controller.State.Songs.Count > 0, "native session trash deletes an idle unarchived session");
    }

    private static void ConfirmCleanup(MainWindow window, string method)
    {
        if (Get<Action?>(window, "confirmAction") == null) throw new InvalidOperationException("delete button did not open confirmation: " + method);
        CleanupFrame(window, method); CleanupFrame(window, method);
        var popup = CleanupPopupBounds();
        CleanupClick(window, method, popup.X + 45, popup.W - 20);
        CleanupFrame(window, method);
        if (Get<Action?>(window, "confirmAction") != null)
        {
            var path = Path.Combine(Path.GetTempPath(), "cleanup-confirm-failure.png");
            SoftwareRenderer.Save(path);
            throw new InvalidOperationException($"native confirmation button missed; bounds={popup}; screenshot={path}");
        }
    }

    private static Vector4 CleanupPopupBounds()
    {
        var draw = ImGui.GetDrawData();
        if (draw.CmdListsCount < 2) throw new InvalidOperationException("cleanup popup did not open");
        var size = ImGui.GetIO().DisplaySize;
        // Modal dimming uses a full-screen command after the popup's own content.
        for (var i = draw.CmdListsCount - 1; i >= 0; i--)
        {
            ImDrawListPtr list = draw.CmdLists[i];
            for (var j = list.CmdBuffer.Size - 1; j >= 0; j--)
            {
                var bounds = list.CmdBuffer[j].ClipRect;
                if (bounds.Z > bounds.X && bounds.W > bounds.Y
                    && bounds.Z - bounds.X < size.X - 1 && bounds.W - bounds.Y < size.Y - 1) return bounds;
            }
        }
        throw new InvalidOperationException("cleanup popup has no content bounds");
    }

    private static void CleanupCheck(bool value, string message)
    { if (!value) throw new InvalidOperationException(message); Console.WriteLine("PASS: " + message); }

    private static void CleanupFrame(MainWindow window, string method, int width = 1100, int height = 740)
    {
        ImGui.GetIO().DisplaySize = new Vector2(width, height);
        ImGui.NewFrame(); ImGui.SetNextWindowPos(Vector2.Zero); ImGui.SetNextWindowSize(new Vector2(width, height));
        ImGui.Begin("midibard2-深海回响特供版 · 记录管理##Cleanup", ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove);
        Invoke(window, method); Invoke(window, "DrawModals");
        ImGui.End(); window.DrawDialogs(); ImGui.Render();
        if (ImGui.GetDrawData().TotalVtxCount == 0) throw new InvalidOperationException("blank cleanup view");
    }

    private static void CleanupClick(MainWindow window, string method, float x, float y)
    {
        var io = ImGui.GetIO(); io.AddMousePosEvent(x, y); CleanupFrame(window, method);
        io.AddMouseButtonEvent(0, true); CleanupFrame(window, method);
        io.AddMouseButtonEvent(0, false); CleanupFrame(window, method);
    }
}
