using System.Numerics;
using BardStage;
using BardStage.Core;
using BardStage.Windows;
using Dalamud.Bindings.ImGui;
using HexaGen.Runtime;

internal static unsafe partial class RuntimeUi
{
    public static void Run(StageController source, string output)
    {
        using var controller = new StageController(Path.Combine(Path.GetTempPath(), "queue-ui-" + Guid.NewGuid())) { SyncAvailable = true };
        controller.Change(s =>
        {
            s.Songs = StageController.Clone(source.State.Songs);
            s.Setlists[0].Name = "观众点歌";
        });
        controller.EnsureAutomaticQueue(); controller.SetReception(true);
        controller.Change(s =>
        {
            var show = s.Setlists[0];
            RequestOperations.Submit(s, show.Id, "观众甲", "海幻沙", "开场序曲", RequestChannel.Say, DateTimeOffset.UtcNow);
            RequestOperations.Submit(s, show.Id, "观众乙", "红玉海", "月下华尔兹", RequestChannel.Tell, DateTimeOffset.UtcNow);
            RequestOperations.Submit(s, show.Id, "观众丙", "", "归途", RequestChannel.Say, DateTimeOffset.UtcNow);
            RequestOperations.Submit(s, show.Id, "观众丁", "", "未收录歌曲", RequestChannel.Say, DateTimeOffset.UtcNow);
        });
        using var port = new AutoQueueRuntimeChecks.EnginePort(controller);
        using var player = new AutoQueuePlayer(controller, port);
        controller.QueuePlayer = player;
        using var native = new NativeLibraryContext(Path.Combine(AppContext.BaseDirectory, "cimgui.dll"));
        ImGui.InitApi(native);
        var context = ImGui.CreateContext();
        try
        {
            var io = ImGui.GetIO(); io.IniFilename = null; io.DeltaTime = 1f / 60;
            io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 17, default, io.Fonts.GetGlyphRangesChineseFull());
            var iconsPath = Path.Combine(output, "..", "fa-solid-900.ttf");
            if (!File.Exists(iconsPath)) iconsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "XIVLauncherCN/dalamudAssets/dev/UIRes/FontAwesomeFreeSolid.otf");
            if (File.Exists(iconsPath))
            {
                ushort* range = (ushort*)System.Runtime.InteropServices.NativeMemory.Alloc(3, sizeof(ushort));
                range[0] = 0xE000; range[1] = 0xF8FF; range[2] = 0;
                var iconFont = io.Fonts.AddFontFromFileTTF(iconsPath, 17, default, range);
                UiKit.IconFont = () => iconFont;
                if (!io.Fonts.Build()) throw new InvalidOperationException("font atlas failed");
                System.Runtime.InteropServices.NativeMemory.Free(range);
            }
            else if (!io.Fonts.Build()) throw new InvalidOperationException("font atlas failed");
            ImGui.StyleColorsDark();
            ImGui.GetStyle().WindowRounding = 0; ImGui.GetStyle().FrameRounding = 3;
            using var window = new MainWindow(controller);
            Frame(window, 1100, 740); Frame(window, 1100, 740);
            SoftwareRenderer.Save(Path.Combine(output, "queue.png"));
            Frame(window, 760, 540); Frame(window, 760, 540);
            SoftwareRenderer.Save(Path.Combine(output, "queue-small.png"));
            io.FontGlobalScale = 1.4f;
            Frame(window, 760, 540); Frame(window, 760, 540);
            SoftwareRenderer.Save(Path.Combine(output, "queue-small-scaled.png"));
            io.FontGlobalScale = 1;
            Frame(window, 1100, 740); Frame(window, 1100, 740);
            Click(window, 42, 131);
            if (!player.Enabled) throw new InvalidOperationException("queue start button failed");
            Click(window, 90, 131);
            if (player.Enabled) throw new InvalidOperationException("queue pause button failed");
            Console.WriteLine("PASS: native queue start and pause controls work without a preflight or archive step");
            Click(window, 207, 131); Frame(window, 1100, 740); Frame(window, 1100, 740);
            SoftwareRenderer.Save(Path.Combine(output, "queue-picker.png"));
            Set(window, "queueSearch", "归途"); Frame(window, 1100, 740); Frame(window, 1100, 740);
            var bounds = PickerBounds();
            var count = controller.QueueShow!.Entries.Count;
            Click(window, bounds.X + 25, bounds.Y + 10);
            if (controller.QueueShow.Entries.Count != count + 1 || controller.QueueShow.Entries.Last().Title != "归途") throw new InvalidOperationException("search picker did not add filtered song");
            Console.WriteLine("PASS: native mouse chooses a searched song directly into the queue");
            foreach (var scale in new[] { 1f, 1.4f })
            {
                io.FontGlobalScale = scale;
                Frame(window, 760, 540); Frame(window, 760, 540);
                Click(window, scale == 1 ? 201 : 264, scale == 1 ? 131 : 161, 760, 540);
                Frame(window, 760, 540); Frame(window, 760, 540);
                SoftwareRenderer.Save(Path.Combine(output, scale == 1 ? "queue-picker-small.png" : "queue-picker-small-scaled.png"));
                bounds = PickerBounds();
                if (bounds.W - bounds.Y < 200 || bounds.Z - bounds.X < 200) throw new InvalidOperationException("song picker collapsed");
                count = controller.QueueShow.Entries.Count;
                Click(window, bounds.X + 25, bounds.Y + 12, 760, 540);
                if (controller.QueueShow.Entries.Count != count + 1) throw new InvalidOperationException("small song picker row not clickable");
            }
            Console.WriteLine("PASS: small song picker has visible clickable rows at 100% and 140% font scale");
            io.FontGlobalScale = 1;
            Frame(window, 1100, 740); Frame(window, 1100, 740);
            controller.Change(s =>
            {
                var alternate = StageController.Clone(s.Songs[1]); alternate.Id = Guid.NewGuid(); alternate.Sha256 = new string('A', 64); alternate.Arranger = "六人版"; s.Songs.Add(alternate);
                RequestOperations.Submit(s, s.Setlists[0].Id, "观众戊", "", alternate.Title, RequestChannel.Say, DateTimeOffset.UtcNow);
            });
            // Keep the pending rows near the top while exercising the native resolution popup.
            controller.Change(s => { foreach (var e in s.Setlists[0].Entries) SetlistOperations.Skip(s.Setlists[0], e.Id, DateTimeOffset.UtcNow); });
            Frame(window, 1100, 740); Frame(window, 1100, 740);
            SoftwareRenderer.Save(Path.Combine(output, "queue-unresolved.png"));
            Click(window, 35, 365); Frame(window, 1100, 740); Frame(window, 1100, 740);
            SoftwareRenderer.Save(Path.Combine(output, "queue-versions.png"));
            bounds = PickerBounds();
            Click(window, bounds.X + 25, bounds.Y + 10);
            if (controller.State.Requests.Last().Status != RequestStatus.Arranged || controller.QueueShow.Entries.Last().Title != "月下华尔兹")
                throw new InvalidOperationException("version selection did not arrange the pending audience request");
            Console.WriteLine("PASS: native version selection directly arranges an ambiguous audience request");
            Set(window, "selectSetlistTab", true);
            Frame(window, 1100, 740); Frame(window, 1100, 740); Frame(window, 1100, 740);
            SoftwareRenderer.Save(Path.Combine(output, "advanced-setlist.png"));
            Frame(window, 760, 540); Frame(window, 760, 540);
            Click(window, 23, 221, 760, 540); Frame(window, 760, 540); Frame(window, 760, 540);
            SoftwareRenderer.Save(Path.Combine(output, "advanced-picker-small.png"));
            bounds = PickerBounds(); count = controller.CurrentSetlist!.Entries.Count;
            if (bounds.W - bounds.Y < 200) throw new InvalidOperationException("legacy search popup still collapsed");
            Click(window, bounds.X + 25, bounds.Y + 10, 760, 540);
            if (controller.CurrentSetlist.Entries.Count != count + 1) throw new InvalidOperationException("legacy search popup song not selectable");
            Console.WriteLine("PASS: original setlist search popup regression fixed and selected song persists");
            Click(window, 89, 73, 760, 540); Invoke(window, "SelectSong", controller.State.Songs[0]);
            Frame(window, 760, 540); Frame(window, 760, 540);
            SoftwareRenderer.Save(Path.Combine(output, "library-small.png"));
            Console.WriteLine("PASS: default queue rendered at 1100x740, 760x540 and 140% font scale");
            RenderRooms(source.State.Songs[0].FilePath, output);
            RenderCleanup(source, output);
            RenderWelcome(output);
        }
        finally { UiKit.IconFont = null; ImGui.DestroyContext(context); }
    }

    private static Vector4 PickerBounds()
    {
        var draw = ImGui.GetDrawData();
        if (draw.CmdListsCount < 3) throw new InvalidOperationException("picker did not open");
        ImDrawListPtr list = draw.CmdLists[draw.CmdListsCount - 1];
        return list.CmdBuffer[list.CmdBuffer.Size - 1].ClipRect;
    }
}
