using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;

internal static class WelcomeLoadChecks
{
    public static void Run(string pluginPath, bool expectOldFailure)
    {
        pluginPath = Path.GetFullPath(pluginPath);
        var context = new MemoryPluginContext(Path.GetDirectoryName(pluginPath)!);
        try
        {
            using var stream = File.OpenRead(pluginPath);
            var assembly = context.LoadFromStream(stream);
            Check(assembly.Location.Length == 0, "integrated plugin loaded from memory with empty Assembly.Location");
            var featureType = assembly.GetType("MidiBard.Welcome.WelcomeVoiceFeature", true)!;
            if (expectOldFailure)
            {
                try { Activator.CreateInstance(featureType); }
                catch (TargetInvocationException ex) when (ex.InnerException is ArgumentNullException { ParamName: "path1" })
                {
                    Console.WriteLine("PASS: reproduced original welcome constructor path1 failure from the shipped 3.2.5.10 DLL");
                    return;
                }
                throw new InvalidOperationException("The old shipped DLL did not reproduce the reported failure.");
            }

            using var feature = (IDisposable)Activator.CreateInstance(featureType, new FileInfo(pluginPath))!;
            Check(true, "production welcome feature initializes using the host-provided plugin path");
            var session = featureType.GetField("session", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(feature)!;
            var audio = session.GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance)
                .Single(f => f.FieldType.Name == "IWelcomeAudio").GetValue(session)!;
            var audioType = audio.GetType();
            var clipType = assembly.GetType("MidiBard.Welcome.WelcomeClip", true)!;
            var clip = Enum.Parse(clipType, "Qimao");
            Check((bool)audioType.GetMethod("TryPlay")!.Invoke(audio, [clip, 0.08f])!, "memory-loaded production feature finds the bundled WAV and starts Windows output");
            var timer = Stopwatch.StartNew();
            while ((bool)audioType.GetProperty("IsPlaying")!.GetValue(audio)! && timer.Elapsed < TimeSpan.FromSeconds(10))
            {
                Thread.Sleep(10);
                audioType.GetMethod("Poll")!.Invoke(audio, null);
            }
            Check(!(bool)audioType.GetProperty("IsPlaying")!.GetValue(audio)!
                && (string)audioType.GetProperty("Error")!.GetValue(audio)! == "" && timer.Elapsed.TotalSeconds >= 5.8,
                "memory-loaded welcome completes full audio without error");

            var missingPath = Path.Combine(Path.GetTempPath(), "welcome-no-assets-" + Guid.NewGuid(), "MidiBard2.dll");
            using var missingFeature = (IDisposable)Activator.CreateInstance(featureType, new FileInfo(missingPath))!;
            var missingSession = featureType.GetField("session", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(missingFeature)!;
            var missingAudio = missingSession.GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance)
                .Single(f => f.FieldType.Name == "IWelcomeAudio").GetValue(missingSession)!;
            Check(!(bool)audioType.GetMethod("TryPlay")!.Invoke(missingAudio, [clip, 0.1f])!, "missing assets do not prevent welcome feature construction and fail playback gracefully");
        }
        finally { context.Unload(); }
    }

    private static void Check(bool value, string message)
    {
        if (!value) throw new InvalidOperationException(message);
        Console.WriteLine("PASS: " + message);
    }

    private sealed class MemoryPluginContext(string directory) : AssemblyLoadContext(isCollectible: true)
    {
        protected override Assembly? Load(AssemblyName name)
        {
            var path = Path.Combine(directory, name.Name + ".dll");
            if (!File.Exists(path)) return null;
            using var stream = File.OpenRead(path);
            return LoadFromStream(stream);
        }
    }
}
