using System.Diagnostics;
using System.Security.Cryptography;
using MidiBard.Welcome;
using NAudio.Wave;

internal static class WelcomeRuntimeChecks
{
    public static void Run(bool playDevice = false)
    {
        var assets = Path.Combine(AppContext.BaseDirectory, "Assets", "Welcome");
        var expected = new Dictionary<WelcomeClip, string>
        {
            [WelcomeClip.General] = "DE4DBD4112F5B4063A1A7CF7A44D3CC0F19B36CBE4E2B432F83600CE9CBCF34E",
            [WelcomeClip.Qimao] = "D7C815E89035EAA45C63999DC9497A6DF1A8E4ECD70F45A0D09554969176D04E",
            [WelcomeClip.Daowanglu] = "6A4DE6E2BBE3350408FE451856C50AA1FC0750EB0C42C48B88766E53399E73A3",
        };
        foreach (var (clip, hash) in expected)
        {
            var path = Path.Combine(assets, WelcomeClips.FileName(clip));
            Check(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))) == hash, "welcome asset matches user original: " + clip);
            using var source = new WaveFileReader(path);
            var samples = WelcomeAudioPlayer.CreateSamples(source, 1);
            var full = new float[(int)source.SampleCount];
            var count = samples.Read(full, 0, full.Length);
            source.Position = 0;
            samples.Volume = 0.25f;
            var quarter = new float[count];
            Check(samples.Read(quarter, 0, count) == count && full.Any(v => Math.Abs(v) > 0.05f)
                && full.Take(count).Zip(quarter).All(pair => Math.Abs(pair.First * 0.25f - pair.Second) < 0.000001f),
                "welcome software volume preserves voice and scales only its samples: " + clip);
            if (playDevice)
            {
                using var player = new WelcomeAudioPlayer(assets);
                var timer = Stopwatch.StartNew();
                Check(player.TryPlay(clip, 0.15f) && player.IsPlaying, "real Windows output starts: " + clip + " " + player.Error);
                while (player.IsPlaying && timer.Elapsed < source.TotalTime + TimeSpan.FromSeconds(3)) { Thread.Sleep(10); player.Poll(); }
                player.Poll();
                Check(!player.IsPlaying && player.Error.Length == 0 && timer.Elapsed >= source.TotalTime - TimeSpan.FromMilliseconds(200),
                    "real Windows output completes full welcome: " + clip);
            }
        }
        using (var missing = new WelcomeAudioPlayer(Path.Combine(assets, "missing")))
            Check(!missing.TryPlay(WelcomeClip.General, 0.5f) && !missing.IsPlaying && missing.Error.Length > 0, "missing welcome asset fails without throwing or starting playback");
        if (!playDevice) return;
        using (var player = new WelcomeAudioPlayer(assets))
        {
            Check(player.TryPlay(WelcomeClip.Qimao, 0.1f) && player.TryPlay(WelcomeClip.General, 0.1f), "replacing welcome playback stops the earlier stream");
            Thread.Sleep(100); player.Poll();
            Check(player.IsPlaying, "old completion event cannot stop the replacement welcome");
            player.SetVolume(0); player.Stop(); player.Poll();
            Check(!player.IsPlaying, "welcome stop and software mute take effect");
            using var file = File.Open(Path.Combine(assets, "general.wav"), FileMode.Open, FileAccess.Read, FileShare.None);
            Check(file.Length > 0, "stopping welcome releases its audio file handle");
        }
        Console.WriteLine("PASS: real Windows welcome playback checks complete; no game process or game audio settings modified");
    }

    private static void Check(bool valid, string message)
    {
        if (!valid) throw new InvalidOperationException(message);
        Console.WriteLine("PASS: " + message);
    }
}
