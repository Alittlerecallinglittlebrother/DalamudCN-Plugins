using System.Numerics;
using Dalamud.Bindings.ImGui;
using MidiBard.Welcome;

internal static unsafe partial class RuntimeUi
{
    private static void RenderWelcome(string output)
    {
        using var audio = new WelcomeUiAudio();
        using var session = new WelcomeVoiceSession(audio);
        session.Tick(true, new(1, "七猫猫猫猫", "伊修加德"), false, false, true, 0.55f);
        var panel = new WelcomeVoicePanel();
        var enabled = true; var volume = 0.55f;
        var saved = 0;
        Vector4 Frame(int width = 520, int height = 320)
        {
            ImGui.GetIO().DisplaySize = new Vector2(width, height);
            ImGui.NewFrame(); ImGui.SetNextWindowPos(Vector2.Zero); ImGui.SetNextWindowSize(new Vector2(width, height));
            ImGui.Begin("欢迎语音##WelcomeCheck", ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove);
            if (panel.Draw(session, false, ref enabled, ref volume)) saved++;
            var min = ImGui.GetItemRectMin(); var max = ImGui.GetItemRectMax();
            ImGui.End(); ImGui.Render();
            if (ImGui.GetDrawData().TotalVtxCount == 0) throw new InvalidOperationException("blank welcome panel");
            return new(min.X, min.Y, max.X, max.Y);
        }
        void Click(float x, float y)
        {
            var io = ImGui.GetIO(); io.AddMousePosEvent(x, y); Frame();
            io.AddMouseButtonEvent(0, true); Frame(); io.AddMouseButtonEvent(0, false); Frame();
        }
        Frame(); var stop = Frame();
        SoftwareRenderer.Save(Path.Combine(output, "welcome-settings.png"));
        var center = new Vector2((stop.X + stop.Z) / 2, (stop.Y + stop.W) / 2);
        Click(center.X - (stop.Z - stop.X) - ImGui.GetStyle().ItemSpacing.X, center.Y);
        if (audio.Plays != 1 || !audio.IsPlaying || audio.Clip != WelcomeClip.Qimao) throw new InvalidOperationException("welcome native preview button failed");
        Click(center.X, center.Y);
        if (audio.IsPlaying) throw new InvalidOperationException("welcome native stop button failed");
        Click(18, 37);
        if (enabled) throw new InvalidOperationException("welcome native enable checkbox failed");
        enabled = true;
        var beforeSlider = saved;
        Click(350, 70);
        if (volume <= 0.65f || saved != beforeSlider + 1) throw new InvalidOperationException("welcome volume did not persist once on slider release");
        volume = 0.55f;
        ImGui.GetIO().AddMousePosEvent(-100, -100);
        Frame(350, 320); Frame(350, 320);
        SoftwareRenderer.Save(Path.Combine(output, "welcome-settings-small.png"));
        ImGui.GetIO().FontGlobalScale = 1.4f;
        Frame(490, 350); Frame(490, 350);
        SoftwareRenderer.Save(Path.Combine(output, "welcome-settings-small-scaled.png"));
        ImGui.GetIO().FontGlobalScale = 1;
        Console.WriteLine("PASS: native welcome preview, stop, enable and volume controls work; slider saves on release; compact and 140% views render");
    }

    private sealed class WelcomeUiAudio : IWelcomeAudio
    {
        public bool IsPlaying { get; private set; }
        public int Plays { get; private set; }
        public WelcomeClip Clip { get; private set; }
        public string Error => "";
        public bool TryPlay(WelcomeClip clip, float volume) { Clip = clip; Plays++; IsPlaying = true; return true; }
        public void Stop() => IsPlaying = false;
        public void SetVolume(float volume) { }
        public void Poll() { }
        public void Dispose() => Stop();
    }
}
