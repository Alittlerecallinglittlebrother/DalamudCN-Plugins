param([string]$DalamudLibPath = '', [switch]$SkipChecks)
$ErrorActionPreference = 'Stop'
if ($DalamudLibPath) {
    $DalamudLibPath = [IO.Path]::GetFullPath($DalamudLibPath).Replace('\', '/').TrimEnd('/') + '/'
    $env:DALAMUD_HOME = $DalamudLibPath
}
$buildOptions = @('-c', 'Release', '--nologo')
if ($DalamudLibPath) { $buildOptions += "-p:DalamudLibPath=$DalamudLibPath" }
if (-not $SkipChecks) {
    dotnet test (Join-Path $PSScriptRoot 'Stage/BardStage.Core.Tests/BardStage.Core.Tests.csproj') @buildOptions
    if ($LASTEXITCODE -ne 0) { throw 'Core tests failed.' }
    $runOptions = @($buildOptions | Where-Object { $_ -ne '--nologo' })
    dotnet run --project (Join-Path $PSScriptRoot 'Stage/BardStage.RuntimeTests/BardStage.RuntimeTests.csproj') @runOptions -- (Join-Path $PSScriptRoot 'verification')
    if ($LASTEXITCODE -ne 0) { throw 'Runtime checks failed.' }
}
dotnet build (Join-Path $PSScriptRoot 'Midibard/MidiBard2.csproj') @buildOptions
if ($LASTEXITCODE -ne 0) { throw 'Integrated plugin build failed.' }
if (-not $SkipChecks) {
    dotnet run --project (Join-Path $PSScriptRoot 'Stage/BardStage.RuntimeTests/BardStage.RuntimeTests.csproj') @runOptions --no-build -- --welcome-load (Join-Path $PSScriptRoot 'Midibard/bin/Release/MidiBard2.dll')
    if ($LASTEXITCODE -ne 0) { throw 'Memory-loaded welcome check failed.' }
}
Write-Output 'Build completed. In-game verification is still required.'
