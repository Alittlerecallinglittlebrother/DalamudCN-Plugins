#nullable enable
using System;
using System.IO;
using System.Linq;
using BardStage;
using BardStage.Windows;
using Dalamud.Interface;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin.Services;
using Melanchall.DryWetMidi.Multimedia;

namespace MidiBard.StageIntegration;

internal sealed class StageFeature : IDisposable
{
    private readonly StageController controller;
    private readonly MainWindow window;
    private readonly WindowSystem windows = new("MidiBard.Stage");
    private readonly ChatRequestReceiver requests;
    private readonly PlaybackObserver playback;
    private readonly StagePlaybackIpc ipc;
    private readonly MidiBardQueuePort queuePort;
    private readonly AutoQueuePlayer queue;
    private int requestIssueCount;

    public StageFeature()
    {
        controller = new StageController(Path.Combine(api.PluginInterface.GetPluginConfigDirectory(), "Stage")) { SyncAvailable = true };
        controller.EnsureAutomaticQueue();
        queuePort = new MidiBardQueuePort();
        queue = new AutoQueuePlayer(controller, queuePort);
        controller.QueuePlayer = queue;
        controller.ImportPlayerLibrary = ImportPlaylist;
        if (controller.State.Songs.Count == 0) ImportPlaylist();
        window = new MainWindow(controller);
        UiKit.IconFont = () => UiBuilder.IconFont;
        windows.AddWindow(window);
        requests = new ChatRequestReceiver(api.ChatGui, api.Framework, () => controller.ReceptionSettings, controller.ReceiveChat);
        ipc = new StagePlaybackIpc(api.PluginInterface, ex => api.PluginLog.Warning(ex, "Stage playback status subscriber failed."));
        playback = new PlaybackObserver(signal => { controller.ReceivePlayback(signal); ipc.Receive(signal); });
        api.Framework.Update += Update;
        api.PluginInterface.UiBuilder.Draw += Draw;
    }

    public void Open() => window.IsOpen = true;
    public void Attach(Playback value, string? path) => playback.Attach(value, path);
    public void StopPlayback() => playback.Stop();
    public bool OwnsPlayback(object value) => queuePort.OwnsPlayback(value);
    public void PartyPlaybackLoaded(string path, bool success) => queuePort.OnPartyLoaded(path, success);

    private void ImportPlaylist()
    {
        var paths = PlaylistManager.FilePathList.Select(s => s.FilePath).Where(File.Exists)
            .Where(p => Path.GetExtension(p).Equals(".mid", StringComparison.OrdinalIgnoreCase) || Path.GetExtension(p).Equals(".midi", StringComparison.OrdinalIgnoreCase)).ToArray();
        if (paths.Length > 0) controller.Import(paths);
        else controller.SetStatus("MidiBard 当前播放列表没有可导入的 MIDI 文件", true);
    }

    private void Update(IFramework framework)
    {
        controller.Poll();
        queue.Tick();
        queuePort.Tick();
        if (requests.IssueCount != requestIssueCount) { requestIssueCount = requests.IssueCount; controller.SetStatus(requests.LastIssue, true); }
        ipc.Poll();
    }

    private void Draw() { windows.Draw(); window.DrawDialogs(); }

    public void Dispose()
    {
        api.Framework.Update -= Update;
        api.PluginInterface.UiBuilder.Draw -= Draw;
        queue.Dispose(); playback.Dispose(); requests.Dispose(); ipc.Dispose();
        windows.RemoveAllWindows(); window.Dispose(); controller.Dispose(); UiKit.IconFont = null;
    }
}
