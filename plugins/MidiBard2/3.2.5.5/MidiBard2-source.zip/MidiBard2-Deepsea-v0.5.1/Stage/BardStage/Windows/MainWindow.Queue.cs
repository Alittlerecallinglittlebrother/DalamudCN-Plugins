using System.Numerics;
using BardStage.Core;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;

namespace BardStage.Windows;

public sealed partial class MainWindow
{
    private string queueSearch = "";
    private Guid? resolveRequestId;
    private bool openQueueSettings;
    private int queueGap;

    private void DrawAutomaticQueue()
    {
        var player = controller.QueuePlayer;
        var show = controller.QueueShow;
        var reception = controller.State.RequestSettings.IsOpen;
        if (ImGui.Checkbox("接收点歌", ref reception)) controller.SetReception(reception);
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.Cog, "queueSettings", "点歌频道、口令与限制"))
        {
            settingsDraft = StageController.Clone(controller.State.RequestSettings);
            queueGap = show?.GapSeconds ?? 3;
            openQueueSettings = true;
        }
        ImGui.SameLine();
        ImGui.BeginDisabled(player?.Enabled == true || player?.ActiveEntryId != null || player?.IsLoading == true);
        ImGui.SetNextItemWidth(125 * UiKit.Scale);
        var mode = controller.State.RequestSettings.PlaybackMode;
        if (ImGui.BeginCombo("##queueMode", mode == QueuePlaybackMode.Solo ? "单人演奏" : "合奏主控"))
        {
            foreach (var value in Enum.GetValues<QueuePlaybackMode>())
                if (ImGui.Selectable(value == QueuePlaybackMode.Solo ? "单人演奏" : "合奏主控", mode == value))
                    controller.Change(s => s.RequestSettings.PlaybackMode = value);
            ImGui.EndCombo();
        }
        ImGui.EndDisabled();
        ImGui.SameLine();
        UiKit.MutedText("口令：" + controller.State.RequestSettings.Prefix + " 曲名");
        ImGui.Spacing();
        ImGui.BeginDisabled(player == null || player.Enabled || player.IsLoading);
        if (ImGui.Button(player?.IsPaused == true ? "继续演奏" : "开始连播")) player?.Start();
        ImGui.EndDisabled();
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.Pause, "queuePause", "暂停连播", player?.Enabled == true)) player?.Pause();
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.Stop, "queueStop", "停止演奏与连播", player?.Enabled == true || player?.ActiveEntryId != null || player?.IsLoading == true)) player?.Stop();
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.StepForward, "queueNext", "跳过当前曲目", player != null && show?.Entries.Any(e => e.Status is EntryStatus.Queued or EntryStatus.InProgress) == true)) player?.Skip();
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.Plus, "queueAdd", "从曲库加歌")) { queueSearch = ""; resolveRequestId = null; ImGui.OpenPopup("加歌##QueuePicker"); }
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.Sync, "queueImport", "导入 MidiBard 当前播放列表", controller.ImportPlayerLibrary != null)) controller.ImportPlayerLibrary?.Invoke();
        ImGui.TextWrapped(player?.Status ?? "播放控制未连接");
        if (controller.SyncBlocked || controller.ChatWriteBlocked)
            if (ImGui.Button("重试保存")) { controller.RetryPlayback(); controller.RetryPendingChat(); }
        ImGui.Separator();

        var height = Math.Max(80, ImGui.GetContentRegionAvail().Y - 65 * UiKit.Scale);
        if (ImGui.BeginChild("QueueContent", new Vector2(0, height), false))
        {
            show = controller.QueueShow;
            var active = controller.State.Setlists.SelectMany(s => s.Entries).FirstOrDefault(e => e.Status == EntryStatus.InProgress);
            if (active != null && player?.ActiveEntryId != active.Id)
            {
                ImGui.TextColored(UiKit.Warning, "上次未结束：" + active.Title);
                if (ImGui.Button("重新排队##recover")) controller.Requeue(active.Id);
            }
            var entries = show?.Entries.Where(e => e.Status is EntryStatus.Queued or EntryStatus.InProgress).ToArray() ?? [];
            ImGui.TextUnformatted($"待演队列  {entries.Length} 首");
            if (entries.Length == 0) UiKit.MutedText("暂无待演曲目");
            else DrawQueueRows(show!, entries, false);

            var unresolved = controller.State.Requests.Where(r => r.SetlistId == show?.Id && r.Status is RequestStatus.Pending or RequestStatus.Deferred)
                .OrderBy(r => r.ReceivedAtUtc).ToArray();
            if (unresolved.Length > 0)
            {
                ImGui.Spacing(); ImGui.Separator();
                ImGui.TextColored(UiKit.Warning, $"需要处理  {unresolved.Length} 条");
                foreach (var request in unresolved)
                {
                    ImGui.PushID(request.Id.ToString());
                    ImGui.TextWrapped(request.Query + "  /  " + RequesterLabel(request));
                    var matches = RequestOperations.FindMatches(controller.State, request.Query);
                    UiKit.MutedText(matches.Count == 0 ? "曲库未匹配" : $"{matches.Count} 个候选版本");
                    if (ImGui.Button("选择歌曲"))
                    { queueSearch = request.Query; resolveRequestId = request.Id; ImGui.OpenPopup("加歌##QueuePicker"); }
                    ImGui.SameLine();
                    if (UiKit.Icon(FontAwesomeIcon.Times, "reject", "取消这条点歌"))
                        controller.Change(s => RequestOperations.Reject(s, request.Id, "本次不演奏"));
                    DrawQueuePicker();
                    ImGui.PopID();
                }
            }
            var history = show?.Entries.Where(e => e.Status is EntryStatus.Completed or EntryStatus.Skipped).Reverse().ToArray() ?? [];
            ImGui.Spacing();
            if (ImGui.CollapsingHeader($"已结束  {history.Length} 首")) DrawQueueRows(show!, history, true);
        }
        ImGui.EndChild();
        DrawQueuePicker();
        DrawQueueSettings();
    }

    private void DrawQueueRows(ShowSetlist show, SetlistEntry[] entries, bool history)
    {
        if (!ImGui.BeginTable(history ? "QueueHistory" : "QueueRows", 5, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.SizingStretchProp)) return;
        ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 30 * UiKit.Scale);
        ImGui.TableSetupColumn("歌曲", ImGuiTableColumnFlags.WidthStretch, 2);
        ImGui.TableSetupColumn("观众", ImGuiTableColumnFlags.WidthStretch, 1);
        ImGui.TableSetupColumn("状态", ImGuiTableColumnFlags.WidthFixed, 65 * UiKit.Scale);
        ImGui.TableSetupColumn("操作", ImGuiTableColumnFlags.WidthFixed, 110 * UiKit.Scale);
        ImGui.TableHeadersRow();
        for (var i = 0; i < entries.Length; i++)
        {
            var entry = entries[i];
            ImGui.PushID(entry.Id.ToString());
            ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.TextUnformatted((i + 1).ToString());
            ImGui.TableNextColumn(); ImGui.TextWrapped(entry.Title);
            ImGui.TableNextColumn();
            var names = controller.State.Requests.Where(r => r.SetlistEntryId == entry.Id).Select(RequesterLabel).ToArray();
            ImGui.TextWrapped(names.Length == 0 ? "手动加歌" : string.Join("、", names));
            ImGui.TableNextColumn(); ImGui.TextUnformatted(StatusLabel(entry.Status));
            ImGui.TableNextColumn();
            var mutable = entry.Status == EntryStatus.Queued && controller.QueuePlayer?.ActiveEntryId != entry.Id;
            if (history)
            {
                if (UiKit.Icon(FontAwesomeIcon.Redo, "requeue", "重新排队")) controller.Requeue(entry.Id);
            }
            else
            {
                var before = entries.Take(i).LastOrDefault(e => e.Status == EntryStatus.Queued);
                var after = entries.Skip(i + 1).FirstOrDefault(e => e.Status == EntryStatus.Queued);
                if (UiKit.Icon(FontAwesomeIcon.ArrowUp, "up", "上移", mutable && before != null && controller.QueuePlayer?.ActiveEntryId != before.Id))
                    controller.Change(s => { var target = s.Setlists.Single(x => x.Id == show.Id); SetlistOperations.Move(target, entry.Id, target.Entries.FindIndex(e => e.Id == before!.Id)); });
                ImGui.SameLine(0, 2 * UiKit.Scale);
                if (UiKit.Icon(FontAwesomeIcon.ArrowDown, "down", "下移", mutable && after != null && controller.QueuePlayer?.ActiveEntryId != after.Id))
                    controller.Change(s => { var target = s.Setlists.Single(x => x.Id == show.Id); SetlistOperations.Move(target, entry.Id, target.Entries.FindIndex(e => e.Id == after!.Id)); });
                ImGui.SameLine(0, 2 * UiKit.Scale);
                if (UiKit.Icon(FontAwesomeIcon.Times, "cancel", "取消排队", mutable))
                    controller.Change(s => SetlistOperations.Skip(s.Setlists.Single(x => x.Id == show.Id), entry.Id, DateTimeOffset.UtcNow));
            }
            ImGui.PopID();
        }
        ImGui.EndTable();
    }

    private void DrawQueuePicker()
    {
        var size = new Vector2(Math.Min(550 * UiKit.Scale, ImGui.GetIO().DisplaySize.X - 32), Math.Min(420 * UiKit.Scale, ImGui.GetIO().DisplaySize.Y - 50));
        ImGui.SetNextWindowSize(size, ImGuiCond.Always);
        if (!ImGui.BeginPopup("加歌##QueuePicker")) return;
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##queueSearch", "搜索曲名或别名", ref queueSearch, 256);
        var songs = string.IsNullOrWhiteSpace(queueSearch) ? controller.State.Songs.ToArray() : RequestOperations.FindMatches(controller.State, queueSearch).ToArray();
        if (ImGui.BeginChild("QueueSongPicker", new Vector2(0, Math.Max(80, size.Y - ImGui.GetFrameHeightWithSpacing() - 30 * UiKit.Scale)), false))
        {
            if (songs.Length == 0) UiKit.MutedText("没有匹配的曲目");
            foreach (var song in songs)
            {
                ImGui.PushID(song.Id.ToString());
                if (ImGui.Selectable(song.Title + "##song"))
                {
                    if (resolveRequestId is { } requestId)
                        controller.Change(s => AutoQueueOperations.ArrangeInOrder(s, requestId, song.Id), "已按点歌时间排入队列");
                    else controller.AddToQueue(song.Id);
                    if (!controller.StatusIsError) ImGui.CloseCurrentPopup();
                }
                UiKit.Tip(song.FilePath);
                ImGui.TextWrapped(VersionLabel(song));
                ImGui.Separator(); ImGui.PopID();
            }
        }
        ImGui.EndChild(); ImGui.EndPopup();
    }

    private void DrawQueueSettings()
    {
        if (openQueueSettings) { ImGui.OpenPopup("点歌设置##Queue"); openQueueSettings = false; }
        var size = new Vector2(Math.Min(480 * UiKit.Scale, ImGui.GetIO().DisplaySize.X - 32), Math.Min(430 * UiKit.Scale, ImGui.GetIO().DisplaySize.Y - 50));
        ImGui.SetNextWindowSize(size, ImGuiCond.Always);
        if (!ImGui.BeginPopup("点歌设置##Queue")) return;
        ImGui.TextUnformatted("接收频道");
        foreach (var channel in new[] { RequestChannel.Say, RequestChannel.Tell, RequestChannel.Party, RequestChannel.Shout, RequestChannel.Yell })
        {
            var enabled = settingsDraft.Channels.Contains(channel);
            if (ImGui.Checkbox(ChannelLabel(channel), ref enabled))
            { if (enabled) settingsDraft.Channels.Add(channel); else settingsDraft.Channels.Remove(channel); }
            if (channel != RequestChannel.Yell) ImGui.SameLine();
        }
        var prefix = settingsDraft.Prefix;
        Field("点歌口令", "queuePrefix", ref prefix, 32); settingsDraft.Prefix = prefix;
        var limit = settingsDraft.MaxOutstandingPerPerson;
        var cooldown = settingsDraft.DuplicateCooldownSeconds;
        var capacity = settingsDraft.MaxQueueSize;
        ImGui.SetNextItemWidth(110 * UiKit.Scale); ImGui.InputInt("每人待演上限", ref limit);
        ImGui.SetNextItemWidth(110 * UiKit.Scale); ImGui.InputInt("重复点歌间隔（秒）", ref cooldown);
        ImGui.SetNextItemWidth(110 * UiKit.Scale); ImGui.InputInt("队列上限", ref capacity);
        ImGui.SetNextItemWidth(110 * UiKit.Scale); ImGui.InputInt("歌曲间隔（秒）", ref queueGap);
        settingsDraft.MaxOutstandingPerPerson = limit; settingsDraft.DuplicateCooldownSeconds = cooldown; settingsDraft.MaxQueueSize = capacity;
        if (ImGui.Button("保存设置"))
            if (controller.Change(s =>
            {
                var settings = StageController.Clone(settingsDraft);
                settings.IsOpen = s.RequestSettings.IsOpen; settings.TargetSetlistId = s.RequestSettings.TargetSetlistId;
                settings.PlaybackMode = s.RequestSettings.PlaybackMode; settings.AutoArrange = true; settings.Prefix = settings.Prefix.Trim();
                s.RequestSettings = settings;
                var show = s.Setlists.FirstOrDefault(x => x.Id == settings.TargetSetlistId);
                if (show != null) show.GapSeconds = queueGap;
            }, "点歌设置已保存")) ImGui.CloseCurrentPopup();
        if (controller.StatusIsError) ImGui.TextWrapped(controller.StatusMessage);
        ImGui.EndPopup();
    }
}
