using System.Globalization;
using System.Numerics;
using BardStage.Core;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using Dalamud.Interface.ImGuiFileDialog;
using Dalamud.Interface.Windowing;

namespace BardStage.Windows;

public sealed partial class MainWindow : Window, IDisposable
{
    private readonly StageController controller;
    private readonly FileDialogManager dialogs = new();
    private string search = "";
    private int performerFilter = -1;
    private Guid? selectedSongId;
    private Guid? selectedEntryId;
    private Guid? previousShowId;
    private string songTitle = "", songAliases = "", songArranger = "", songNotes = "";
    private int songPerformers;
    private string entryTitle = "", entryNotes = "";
    private int entryMinutes, entrySeconds;
    private float entrySpeed = 1;
    private string createName = "";
    private string createMode = "";
    private bool openCreate;
    private bool openConfirm;
    private string confirmText = "";
    private Action? confirmAction;
    private bool selectSetlistTab;
    private bool selectRequestTab;
    private bool selectStageTab;
    private string targetEnd = "";
    private int gapSeconds;
    private string pathDraft = "";

    public MainWindow(StageController controller)
        : base("midibard2-深海回响特供版 · 自动点歌##BardStage", ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse)
    {
        this.controller = controller;
        Size = new Vector2(1100, 740);
        SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new WindowSizeConstraints { MinimumSize = new Vector2(760, 540), MaximumSize = new Vector2(2400, 1600) };
    }

    public void DrawDialogs() => dialogs.Draw();
    public void Dispose() => dialogs.Reset();

    public override void Draw()
    {
        var scale = UiKit.Scale;
        ImGui.TextUnformatted("midibard2-深海回响特供版 / 自动点歌");
        ImGui.SameLine();
        UiKit.MutedText($"曲库 {controller.State.Songs.Count} 首");
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.FolderOpen, "data", "打开数据目录")) controller.OpenPath(controller.DataDirectory);
        if (controller.IsReadOnly) ImGui.TextColored(UiKit.Warning, "当前只读");
        ImGui.Separator();
        if (ImGui.BeginTabBar("MainTabs"))
        {
            if (ImGui.BeginTabItem("点歌队列"))
            {
                ImGui.BeginDisabled(controller.IsReadOnly || controller.IsBusy);
                DrawAutomaticQueue();
                ImGui.EndDisabled();
                ImGui.EndTabItem();
            }
            if (ImGui.BeginTabItem("曲库"))
            {
                ImGui.BeginDisabled(controller.IsReadOnly || controller.IsBusy);
                DrawLibrary();
                ImGui.EndDisabled();
                ImGui.EndTabItem();
            }
            if (ImGui.BeginTabItem("更多", selectSetlistTab || selectRequestTab || selectStageTab ? ImGuiTabItemFlags.SetSelected : ImGuiTabItemFlags.None))
            {
                ImGui.BeginDisabled(controller.IsReadOnly || controller.IsBusy);
                if (ImGui.BeginTabBar("AdvancedTabs"))
                {
                    if (ImGui.BeginTabItem("节目单", selectSetlistTab ? ImGuiTabItemFlags.SetSelected : ImGuiTabItemFlags.None))
                    { selectSetlistTab = false; DrawSetlists(); ImGui.EndTabItem(); }
                    if (ImGui.BeginTabItem("点歌记录", selectRequestTab ? ImGuiTabItemFlags.SetSelected : ImGuiTabItemFlags.None))
                    { selectRequestTab = false; DrawRequests(); ImGui.EndTabItem(); }
                    if (ImGui.BeginTabItem("手动场控", selectStageTab ? ImGuiTabItemFlags.SetSelected : ImGuiTabItemFlags.None))
                    { selectStageTab = false; DrawStage(); ImGui.EndTabItem(); }
                    if (ImGui.BeginTabItem("开演检查")) { DrawPreflight(); ImGui.EndTabItem(); }
                    if (ImGui.BeginTabItem("演出记录")) { DrawSessions(); ImGui.EndTabItem(); }
                    ImGui.EndTabBar();
                }
                ImGui.EndDisabled();
                ImGui.EndTabItem();
            }
            ImGui.EndTabBar();
        }
        var footerHeight = 55 * scale;
        var targetY = ImGui.GetWindowHeight() - footerHeight;
        if (ImGui.GetCursorPosY() < targetY) ImGui.SetCursorPosY(targetY);
        ImGui.Separator();
        if (ImGui.BeginChild("Status", new Vector2(0, 42 * scale), false))
        {
            if (!string.IsNullOrEmpty(controller.StatusMessage))
            {
                ImGui.PushStyleColor(ImGuiCol.Text, controller.StatusIsError ? UiKit.Warning : UiKit.Muted);
                ImGui.TextWrapped(controller.StatusMessage);
                ImGui.PopStyleColor();
            }
            else UiKit.MutedText("已保存至本地");
        }
        ImGui.EndChild();
        DrawModals();
        DrawRequestModals();
        DrawStageModals();
    }

    private void DrawLibrary()
    {
        if (UiKit.Icon(FontAwesomeIcon.FileImport, "importFiles", "导入 MIDI 文件"))
            dialogs.OpenFileDialog("导入 MIDI", ".mid,.midi", (ok, paths) => { if (ok) controller.Import(paths); }, 9999, null!, false);
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.FolderPlus, "importFolder", "导入文件夹及子文件夹"))
            dialogs.OpenFolderDialog("导入 MIDI 文件夹", (ok, path) => { if (ok) controller.Import([path]); });
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.Sync, "importPlayer", "导入 MidiBard 当前播放列表", controller.ImportPlayerLibrary != null)) controller.ImportPlayerLibrary?.Invoke();
        ImGui.SameLine();
        ImGui.SetNextItemWidth(Math.Max(120, Math.Min(230 * UiKit.Scale, ImGui.GetContentRegionAvail().X - 140 * UiKit.Scale)));
        ImGui.InputTextWithHint("##search", "搜索曲名、别名、编曲者", ref search, 256);
        ImGui.SameLine();
        ImGui.SetNextItemWidth(120 * UiKit.Scale);
        if (ImGui.BeginCombo("##performerFilter", performerFilter < 0 ? "全部人数" : performerFilter == 0 ? "人数未填写" : $"{performerFilter} 人"))
        {
            for (var i = -1; i <= 8; i++)
                if (ImGui.Selectable(i < 0 ? "全部人数" : i == 0 ? "人数未填写" : $"{i} 人", performerFilter == i)) performerFilter = i;
            ImGui.EndCombo();
        }
        ImGui.Spacing();
        var height = Math.Max(200, ImGui.GetContentRegionAvail().Y - 65 * UiKit.Scale);
        if (ImGui.BeginTable("LibraryLayout", 2, ImGuiTableFlags.Resizable | ImGuiTableFlags.BordersInnerV))
        {
            ImGui.TableSetupColumn("list", ImGuiTableColumnFlags.WidthStretch, 0.62f);
            ImGui.TableSetupColumn("editor", ImGuiTableColumnFlags.WidthStretch, 0.38f);
            ImGui.TableNextRow();
            ImGui.TableNextColumn();
            if (ImGui.BeginChild("SongList", new Vector2(0, height), false)) DrawSongTable();
            ImGui.EndChild();
            ImGui.TableNextColumn();
            if (ImGui.BeginChild("SongInspector", new Vector2(0, height), false)) DrawSongInspector();
            ImGui.EndChild();
            ImGui.EndTable();
        }
    }

    private void DrawSongTable()
    {
        var filter = search.Trim();
        var songs = controller.State.Songs.Where(s =>
            (performerFilter < 0 || s.PerformerCount == performerFilter) &&
            (filter.Length == 0 || s.Title.Contains(filter, StringComparison.OrdinalIgnoreCase) ||
             s.Arranger.Contains(filter, StringComparison.OrdinalIgnoreCase) || s.Aliases.Any(a => a.Contains(filter, StringComparison.OrdinalIgnoreCase))))
            .OrderBy(s => s.Title, StringComparer.CurrentCultureIgnoreCase).ToArray();
        if (songs.Length == 0)
        {
            UiKit.MutedText(controller.State.Songs.Count == 0 ? "曲库为空" : "没有匹配的曲目");
            return;
        }
        if (!ImGui.BeginTable("Songs", 4, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.ScrollY | ImGuiTableFlags.Resizable, new Vector2(0, -1))) return;
        ImGui.TableSetupScrollFreeze(0, 1);
        ImGui.TableSetupColumn("曲目", ImGuiTableColumnFlags.WidthStretch);
        ImGui.TableSetupColumn("人数", ImGuiTableColumnFlags.WidthFixed, 42 * UiKit.Scale);
        ImGui.TableSetupColumn("时长", ImGuiTableColumnFlags.WidthFixed, 64 * UiKit.Scale);
        ImGui.TableSetupColumn("编曲", ImGuiTableColumnFlags.WidthStretch, 0.5f);
        ImGui.TableHeadersRow();
        foreach (var song in songs)
        {
            ImGui.PushID(song.Id.ToString());
            ImGui.TableNextRow();
            ImGui.TableNextColumn();
            if (ImGui.Selectable(song.Title + "##select", selectedSongId == song.Id)) SelectSong(song);
            UiKit.Tip(song.FilePath);
            ImGui.TableNextColumn(); ImGui.TextUnformatted(song.PerformerCount == 0 ? "未填" : song.PerformerCount.ToString());
            ImGui.TableNextColumn(); ImGui.TextUnformatted(UiKit.Duration(song.DurationSeconds));
            ImGui.TableNextColumn(); ImGui.TextUnformatted(song.Arranger);
            ImGui.PopID();
        }
        ImGui.EndTable();
    }

    private void SelectSong(SongEntry song)
    {
        selectedSongId = song.Id;
        songTitle = song.Title;
        songAliases = string.Join("; ", song.Aliases);
        songArranger = song.Arranger;
        songPerformers = song.PerformerCount;
        songNotes = song.Notes;
    }

    private void DrawSongInspector()
    {
        var song = controller.State.Songs.FirstOrDefault(s => s.Id == selectedSongId);
        if (song == null) { UiKit.MutedText("未选择曲目"); return; }
        ImGui.TextUnformatted("曲目资料");
        ImGui.Separator();
        Field("展示曲名", "songTitle", ref songTitle, 256);
        Field("别名（分号分隔）", "aliases", ref songAliases, 1024);
        Field("编曲者 / 版本", "arranger", ref songArranger, 256);
        ImGui.TextUnformatted("演奏人数");
        ImGui.SetNextItemWidth(-1);
        if (ImGui.BeginCombo("##songPerformers", songPerformers == 0 ? "未填写" : $"{songPerformers} 人"))
        {
            for (var i = 0; i <= 8; i++)
                if (ImGui.Selectable(i == 0 ? "未填写" : $"{i} 人", songPerformers == i)) songPerformers = i;
            ImGui.EndCombo();
        }
        ImGui.TextUnformatted("演奏备注");
        ImGui.InputTextMultiline("##songNotes", ref songNotes, 4096, new Vector2(-1, 85 * UiKit.Scale));
        if (ImGui.Button("保存资料"))
        {
            var id = song.Id;
            controller.Change(state =>
            {
                var target = state.Songs.Single(s => s.Id == id);
                target.Title = songTitle.Trim();
                target.Aliases = songAliases.Split([';', '；', '\n'], StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).Distinct().ToList();
                target.Arranger = songArranger.Trim();
                target.PerformerCount = songPerformers;
                target.Notes = songNotes.Trim();
            }, "曲目资料已保存");
        }
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.Undo, "resetSongDraft", "撤销未保存的资料编辑")) SelectSong(song);
        ImGui.Spacing();
        ImGui.Separator();
        ImGui.TextUnformatted($"{song.TrackCount} 音轨  ·  {UiKit.Duration(song.DurationSeconds)}");
        var exists = File.Exists(song.FilePath);
        ImGui.TextColored(exists ? UiKit.Accent : UiKit.Warning, exists ? "文件可用" : "文件缺失");
        ImGui.TextWrapped(song.FilePath);
        UiKit.MutedText("SHA256 " + (song.Sha256.Length > 16 ? song.Sha256[..16] : song.Sha256));
        UiKit.Tip(song.Sha256);
        if (UiKit.Icon(FontAwesomeIcon.Copy, "copyPath", "复制 MIDI 路径")) ImGui.SetClipboardText(song.FilePath);
        ImGui.SameLine();
        if (UiKit.Icon(FontAwesomeIcon.FolderOpen, "revealSong", "在文件夹中显示", exists)) controller.OpenPath(song.FilePath, true);
        ImGui.SameLine();
        var referenced = controller.State.Setlists.Any(s => s.Entries.Any(e => e.SongId == song.Id));
        if (UiKit.Icon(FontAwesomeIcon.Trash, "deleteSong", referenced ? "曲目正在节目单中使用" : "从曲库移除（保留 MIDI 文件）", !referenced))
        {
            var id = song.Id;
            Confirm($"从曲库移除《{song.Title}》？原始 MIDI 文件会保留。", () => controller.Change(state =>
            {
                if (state.Setlists.Any(s => s.Entries.Any(e => e.SongId == id))) throw new InvalidOperationException("曲目正在节目单中使用。");
                state.Songs.RemoveAll(s => s.Id == id);
                selectedSongId = null;
            }, "已从曲库移除"));
        }
        ImGui.Spacing();
        ImGui.Separator();
        if (ImGui.Button("加入点歌队列", new Vector2(-1, 0))) controller.AddToQueue(song.Id);
    }

    private void DrawShowCombo(string id)
    {
        ImGui.SetNextItemWidth(-1);
        if (!ImGui.BeginCombo("##" + id, controller.CurrentSetlist?.Name ?? "选择节目单")) return;
        foreach (var show in controller.State.Setlists.ToArray())
            if (ImGui.Selectable(show.Name + "##" + show.Id, controller.State.SelectedSetlistId == show.Id))
                controller.Change(state => state.SelectedSetlistId = show.Id);
        ImGui.EndCombo();
    }

    private void Confirm(string text, Action action)
    {
        confirmText = text;
        confirmAction = action;
        openConfirm = true;
    }

    private void DrawModals()
    {
        if (openConfirm) { ImGui.OpenPopup("确认操作##BardStage"); openConfirm = false; }
        ImGui.SetNextWindowSizeConstraints(new Vector2(440 * UiKit.Scale, 0), new Vector2(440 * UiKit.Scale, float.MaxValue));
        ImGui.SetNextWindowSize(new Vector2(440 * UiKit.Scale, 0), ImGuiCond.Appearing);
        if (ImGui.BeginPopupModal("确认操作##BardStage", ImGuiWindowFlags.AlwaysAutoResize))
        {
            ImGui.TextWrapped(confirmText);
            ImGui.Spacing();
            if (ImGui.Button("确认", new Vector2(90 * UiKit.Scale, 0)))
            {
                confirmAction?.Invoke(); confirmAction = null; ImGui.CloseCurrentPopup();
            }
            ImGui.SameLine();
            if (ImGui.Button("取消", new Vector2(90 * UiKit.Scale, 0))) { confirmAction = null; ImGui.CloseCurrentPopup(); }
            ImGui.EndPopup();
        }
        if (openCreate) { ImGui.OpenPopup("节目单名称##BardStage"); openCreate = false; }
        ImGui.SetNextWindowSizeConstraints(new Vector2(420 * UiKit.Scale, 0), new Vector2(420 * UiKit.Scale, float.MaxValue));
        ImGui.SetNextWindowSize(new Vector2(420 * UiKit.Scale, 0), ImGuiCond.Appearing);
        if (ImGui.BeginPopupModal("节目单名称##BardStage", ImGuiWindowFlags.AlwaysAutoResize))
        {
            ImGui.SetNextItemWidth(-1);
            ImGui.InputText("##createName", ref createName, 128);
            ImGui.BeginDisabled(string.IsNullOrWhiteSpace(createName));
            if (ImGui.Button("保存", new Vector2(90 * UiKit.Scale, 0)))
            {
                var currentId = controller.CurrentSetlist?.Id;
                controller.Change(state =>
                {
                    if (createMode == "rename") state.Setlists.Single(s => s.Id == currentId).Name = createName.Trim();
                    else
                    {
                        var created = createMode == "clone" && currentId.HasValue
                            ? StageController.Clone(state.Setlists.Single(s => s.Id == currentId)) : new ShowSetlist();
                        created.Id = Guid.NewGuid(); created.Name = createName.Trim(); created.LockedNextEntryId = null; created.TargetEndUtc = null;
                        foreach (var entry in created.Entries)
                        {
                            entry.Id = Guid.NewGuid(); entry.Status = EntryStatus.Queued; entry.StartedAtUtc = null; entry.EndedAtUtc = null;
                        }
                        state.Setlists.Add(created); state.SelectedSetlistId = created.Id;
                    }
                });
                ImGui.CloseCurrentPopup();
            }
            ImGui.EndDisabled();
            ImGui.SameLine();
            if (ImGui.Button("取消", new Vector2(90 * UiKit.Scale, 0))) ImGui.CloseCurrentPopup();
            ImGui.EndPopup();
        }
    }

    private static void Field(string label, string id, ref string value, int maxLength)
    {
        ImGui.TextUnformatted(label);
        ImGui.SetNextItemWidth(-1);
        ImGui.InputText("##" + id, ref value, maxLength);
    }
}
