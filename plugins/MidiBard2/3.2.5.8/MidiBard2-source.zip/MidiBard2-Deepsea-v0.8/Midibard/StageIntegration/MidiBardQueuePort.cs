#nullable enable
using System;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using BardStage;
using BardStage.Core;
using Dalamud.Utility;
using Melanchall.DryWetMidi.Multimedia;
using MidiBard.Control.CharacterControl;
using MidiBard.Control.MidiControl;
using MidiBard.IPC;
using MidiBard.Managers;
using MidiBard.Managers.Ipc;
using MidiBard.Util;

namespace MidiBard.StageIntegration;

internal sealed class MidiBardQueuePort : IStagePlaybackPort
{
    private readonly ConditionalWeakTable<Playback, object> owned = new();
    private Playback? expected;
    private TaskCompletionSource<bool>? partyLoad;
    private string? partyPath;
    private bool pendingReady;
    private DateTimeOffset readyAfter;
    public bool IsPlaying => MidiBard.IsPlaying;
    public bool OwnsPlayback(object value) => value is Playback playback && owned.TryGetValue(playback, out _);

    public string? BlockReason(QueuePlaybackMode mode)
    {
        if (!api.ClientState.IsLoggedIn) return "等待登录游戏";
        if (MidiBard.SlaveMode) return "当前是从控，请在主控端开启连播";
        if (PlaylistManager.IsLoading) return "等待 MidiBard 完成载入";
        if (SwitchInstrument.SwitchingInstrument) return "等待乐器切换完成";
        if (MidiBard.AgentMetronome.EnsembleModeRunning) return "等待上一首合奏结束";
        if (!MidiBard.AgentPerformance.InPerformanceMode) return "等待进入乐器演奏模式";
        if (mode == QueuePlaybackMode.Ensemble)
        {
            if (api.PartyList.Length < 2 || !api.PartyList.IsPartyLeader()) return "合奏连播需要由小队队长启动";
            if (!MidiBard.config.MonitorOnEnsemble) return "请在 MidiBard 开启合奏监听";
            if (!MidiBard.config.playOnMultipleDevices && !MidiBard.config.SyncClients) return "请在 MidiBard 开启客户端同步";
        }
        return null;
    }

    public async Task LoadAsync(string filePath, QueuePlaybackMode mode, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var index = PlaylistManager.FilePathList.FindIndex(s => SamePath(s.FilePath, filePath));
        var remote = mode == QueuePlaybackMode.Ensemble && MidiBard.config.playOnMultipleDevices;
        if (index < 0)
        {
            if (remote) throw new InvalidOperationException("多设备合奏的歌曲必须已在各端同序播放列表中");
            await PlaylistManager.AddAsync(new[] { filePath });
            index = PlaylistManager.FilePathList.FindIndex(s => SamePath(s.FilePath, filePath));
        }
        cancellationToken.ThrowIfCancellationRequested();
        if (index < 0) throw new InvalidOperationException("无法导入 MIDI 文件");
        bool loaded;
        if (remote)
        {
            // The native party command also loads on its sender. Await that load instead of loading twice.
            var completion = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            partyPath = filePath; partyLoad = completion;
            try
            {
                PartyChatCommand.SendSwitchTo(index);
                loaded = await completion.Task.WaitAsync(TimeSpan.FromSeconds(30), cancellationToken);
            }
            finally { partyLoad = null; partyPath = null; }
        }
        else loaded = await PlaylistManager.LoadPlayback(index, false, mode == QueuePlaybackMode.Ensemble);
        if (!loaded || MidiBard.CurrentPlayback == null || !SamePath(MidiBard.CurrentPlayback.FilePath, filePath))
            throw new InvalidOperationException("MidiBard 未能载入所选歌曲");
        expected = MidiBard.CurrentPlayback;
        owned.GetValue(expected, _ => new object());
        cancellationToken.ThrowIfCancellationRequested();
    }

    public void OnPartyLoaded(string path, bool success)
    {
        if (partyPath != null && SamePath(path, partyPath)) partyLoad?.TrySetResult(success);
    }

    public void Start(QueuePlaybackMode mode)
    {
        RequireLoaded();
        if (mode == QueuePlaybackMode.Solo) { MidiPlayerControl.DoPlay(); return; }
        if (MidiBard.config.UpdateInstrumentBeforeReadyCheck)
        {
            if (MidiBard.CurrentPlayback?.MidiFileConfig is { } config) IPCHandles.UpdateMidiFileConfig(config);
            if (MidiBard.config.playOnMultipleDevices) PartyChatCommand.SendUpdateInstrument();
            else IPCHandles.UpdateInstrument(true);
        }
        pendingReady = true;
        readyAfter = DateTimeOffset.UtcNow.AddSeconds(1);
    }

    public void Tick()
    {
        if (!pendingReady || DateTimeOffset.UtcNow < readyAfter) return;
        if (!ReferenceEquals(expected, MidiBard.CurrentPlayback)) { pendingReady = false; return; }
        if (BlockReason(QueuePlaybackMode.Ensemble) != null) return;
        pendingReady = false;
        EnsembleManager.BeginEnsembleReadyCheck();
    }

    public void Pause() { RequireLoaded(); MidiPlayerControl.Pause(); }
    public void Resume() { RequireLoaded(); MidiPlayerControl.Play(); }
    public void Finish(QueuePlaybackMode mode)
    {
        if (mode == QueuePlaybackMode.Ensemble && ReferenceEquals(expected, MidiBard.CurrentPlayback) && MidiBard.AgentMetronome.EnsembleModeRunning)
            EnsembleManager.StopEnsemble();
    }
    public void Stop(QueuePlaybackMode mode, bool keepInstruments = false)
    {
        pendingReady = false;
        if (!ReferenceEquals(expected, MidiBard.CurrentPlayback) || expected == null) return;
        if (mode == QueuePlaybackMode.Ensemble)
        {
            if (MidiBard.AgentMetronome.EnsembleModeRunning) EnsembleManager.StopEnsemble();
            if (!keepInstruments)
            {
                if (MidiBard.config.playOnMultipleDevices) PartyChatCommand.SendClose();
                else IPCHandles.UpdateInstrument(false);
            }
        }
        MidiPlayerControl.Stop();
    }
    private void RequireLoaded()
    {
        if (expected == null || !ReferenceEquals(expected, MidiBard.CurrentPlayback)) throw new InvalidOperationException("播放文件已被切换，请重新开始连播");
    }
    private static bool SamePath(string a, string b) => Path.GetFullPath(a).Equals(Path.GetFullPath(b), StringComparison.OrdinalIgnoreCase);
}
