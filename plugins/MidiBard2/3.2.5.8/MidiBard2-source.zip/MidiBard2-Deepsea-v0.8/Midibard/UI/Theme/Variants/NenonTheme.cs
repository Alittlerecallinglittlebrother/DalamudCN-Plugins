using System.Numerics;

namespace MidiBard;

public class NeonTheme : UITheme
{
    // rgb(65, 4, 69)
    // rgb(165, 21, 140)
    // rgb(255, 45, 241)
    // rgb(246, 220, 67)
    public Vector4 Text { get; init; } = new Vector4(0.96f, 0.86f, 0.26f, 1f); // rgb(246, 220, 67)
    public Vector4 TextDisabled { get; init; } = new Vector4(0.612f, 0.541f, 0.145f, 1f); // rgba(156, 138, 37, 1)
    public Vector4 WindowBg { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 1f); // rgb(65, 4, 69)
    public Vector4 ChildBg { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 1f);
    public Vector4 PopupBg { get; init; } = new Vector4(0.15f, 0.04f, 0.18f, 1f);
    public Vector4 Border { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f); // rgb(165, 21, 140)
    public Vector4 BorderShadow { get; init; } = new Vector4(0f, 0f, 0f, 0f);
    public Vector4 FrameBg { get; init; } = new Vector4(0.25f, 0.08f, 0.22f, 1f); // mix of base colors
    public Vector4 FrameBgHovered { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f); // rgb(255, 45, 241)
    public Vector4 FrameBgActive { get; init; } = new Vector4(0.26f, 0.02f, 0.27f, 1f);
    public Vector4 TitleBg { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 1f);
    public Vector4 TitleBgActive { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 TitleBgCollapsed { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 1f);
    public Vector4 MenuBarBg { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 1f);
    public Vector4 ScrollbarBg { get; init; } = new Vector4(0.08f, 0.01f, 0.09f, 1f);
    public Vector4 ScrollbarGrab { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 ScrollbarGrabHovered { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 ScrollbarGrabActive { get; init; } = new Vector4(0.96f, 0.86f, 0.26f, 1f);
    public Vector4 CheckMark { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 SliderGrab { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 SliderGrabActive { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 Button { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 ButtonHovered { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 ButtonActive { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 Header { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 HeaderHovered { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 HeaderActive { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 Separator { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 SeparatorHovered { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 SeparatorActive { get; init; } = new Vector4(0.96f, 0.86f, 0.26f, 1f);
    public Vector4 ResizeGrip { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 ResizeGripHovered { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 ResizeGripActive { get; init; } = new Vector4(0.96f, 0.86f, 0.26f, 1f);
    public Vector4 Tab { get; init; } = new Vector4(0.25f, 0.08f, 0.22f, 1f);
    public Vector4 TabHovered { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 TabActive { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 TabUnfocused { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 1f);
    public Vector4 TabUnfocusedActive { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 DockingPreview { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 0.4f);
    public Vector4 DockingEmptyBg { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 1f);
    public Vector4 PlotLines { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 PlotLinesHovered { get; init; } = new Vector4(0.96f, 0.86f, 0.26f, 1f);
    public Vector4 PlotHistogram { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 PlotHistogramHovered { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 TableHeaderBg { get; init; } = new Vector4(0.65f, 0.08f, 0.55f, 1f);
    public Vector4 TableBorderStrong { get; init; } = new Vector4(0.35f, 0.05f, 0.4f, 1f);
    public Vector4 TableBorderLight { get; init; } = new Vector4(0.25f, 0.04f, 0.3f, 1f);
    public Vector4 TableRowBg { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 1f);
    public Vector4 TableRowBgAlt { get; init; } = new Vector4(0.15f, 0.04f, 0.18f, 1f);
    public Vector4 TextSelectedBg { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 0.7f);
    public Vector4 DragDropTarget { get; init; } = new Vector4(0.96f, 0.86f, 0.26f, 1f);
    public Vector4 NavHighlight { get; init; } = new Vector4(1.0f, 0.18f, 0.95f, 1f);
    public Vector4 NavWindowingHighlight { get; init; } = new Vector4(0.96f, 0.86f, 0.26f, 1f);
    public Vector4 NavWindowingDimBg { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 0.7f);
    public Vector4 ModalWindowDimBg { get; init; } = new Vector4(0.10f, 0.02f, 0.12f, 0.7f);
}
