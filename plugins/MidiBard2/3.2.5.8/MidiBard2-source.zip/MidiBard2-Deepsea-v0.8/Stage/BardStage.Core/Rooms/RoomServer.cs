using System.Collections.Concurrent;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace BardStage.Core.Rooms;

public sealed class RoomServer : IDisposable
{
    public const int MaxViewers = 7;
    private readonly TcpListener listener;
    private readonly CancellationTokenSource lifetime = new();
    private readonly X509Certificate2 certificate;
    private readonly byte[] secret = RandomNumberGenerator.GetBytes(32);
    private readonly byte[] viewerSecret = RandomNumberGenerator.GetBytes(32);
    private readonly SemaphoreSlim handshakes = new(MaxViewers + 1 + 4);
    private readonly SemaphoreSlim viewerSlots = new(MaxViewers);
    private readonly ConcurrentDictionary<RoomPeer, byte> viewers = new();
    private readonly ConcurrentDictionary<TcpClient, Task> connections = new();
    private readonly ConcurrentQueue<(RoomPeer Peer, RoomCommand Command)> commands = new();
    private RoomPeer? presenter;
    private RoomSnapshot? snapshot;
    private RoomSnapshot? viewerSnapshot;
    private int queued, disposed;
    private string? lastConnectionError;
    public Guid RoomId { get; } = Guid.NewGuid();
    public int Port => ((IPEndPoint)listener.LocalEndpoint).Port;
    public bool HasPresenter => Volatile.Read(ref presenter)?.IsAlive == true;
    public int ViewerCount => viewers.Keys.Count(p => p.IsAlive);
    public Task Completion { get; }
    public string? LastConnectionError => Volatile.Read(ref lastConnectionError);

    public RoomServer(int port = 28765)
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var request = new CertificateRequest("CN=MidiBard-Room", key, HashAlgorithmName.SHA256);
        using var generated = request.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-1), DateTimeOffset.UtcNow.AddDays(7));
        // Windows Schannel needs an imported user key; the temporary key container is deleted on disposal.
        var pfx = generated.Export(X509ContentType.Pfx);
        try { certificate = X509CertificateLoader.LoadPkcs12(pfx, null, X509KeyStorageFlags.UserKeySet); }
        finally { CryptographicOperations.ZeroMemory(pfx); }
        listener = new TcpListener(IPAddress.Loopback, port);
        try { listener.Start(MaxViewers + 4); }
        catch { certificate.Dispose(); throw; }
        Completion = AcceptLoop();
    }

    public RoomInvite Invite(string publicHost, int publicPort, RoomRole role = RoomRole.Presenter)
    {
        if (!Enum.IsDefined(role)) throw new ArgumentOutOfRangeException(nameof(role));
        return new(publicHost.Trim(), publicPort, certificate.GetCertHashString(HashAlgorithmName.SHA256),
            Convert.ToHexString(role == RoomRole.Viewer ? viewerSecret : secret), RoomId, role);
    }

    public bool TryRead(out (RoomPeer Peer, RoomCommand Command) value)
    {
        if (!commands.TryDequeue(out value)) return false;
        Interlocked.Decrement(ref queued);
        return true;
    }

    public void Publish(RoomSnapshot value)
    {
        Volatile.Write(ref snapshot, value);
        var view = value.ForViewer();
        Volatile.Write(ref viewerSnapshot, view);
        Volatile.Read(ref presenter)?.Send(new RoomPacket { Type = "snapshot", Snapshot = value });
        foreach (var viewer in viewers.Keys) viewer.Send(new RoomPacket { Type = "snapshot", Snapshot = view, Role = RoomRole.Viewer });
    }

    private async Task AcceptLoop()
    {
        try
        {
            while (!lifetime.IsCancellationRequested)
            {
                var socket = await listener.AcceptTcpClientAsync(lifetime.Token);
                socket.NoDelay = true;
                if (!handshakes.Wait(0)) { socket.Dispose(); continue; }
                var task = Serve(socket);
                connections[socket] = task;
                _ = task.ContinueWith(_ => { connections.TryRemove(socket, out var ignored); }, TaskScheduler.Default);
            }
        }
        catch (Exception ex) when (ex is OperationCanceledException or SocketException or ObjectDisposedException) { }
        finally
        {
            foreach (var socket in connections.Keys) socket.Dispose();
            await Task.WhenAll(connections.Values);
            certificate.Dispose();
        }
    }

    private async Task Serve(TcpClient socket)
    {
        RoomPeer? peer = null;
        var viewerSlot = false;
        try
        {
            using var stream = new SslStream(socket.GetStream(), false);
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);
            timeout.CancelAfter(TimeSpan.FromSeconds(10));
            await stream.AuthenticateAsServerAsync(new SslServerAuthenticationOptions
            {
                ServerCertificate = certificate, EnabledSslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13,
                ClientCertificateRequired = false,
            }, timeout.Token);
            var hello = await RoomWire.Read(stream, timeout.Token, 4096);
            if (hello.Type != "hello" || hello.RoomId != RoomId || hello.Key?.Length != 64 || !Enum.IsDefined(hello.Role)
                || !CryptographicOperations.FixedTimeEquals(Convert.FromHexString(hello.Key), hello.Role == RoomRole.Viewer ? viewerSecret : secret)) return;
            peer = new RoomPeer(socket, stream, lifetime.Token, 16 * 1024);
            if (hello.Role == RoomRole.Viewer)
            {
                if (!viewerSlots.Wait(0)) return;
                viewerSlot = true; viewers.TryAdd(peer, 0);
            }
            else if (Interlocked.CompareExchange(ref presenter, peer, null) != null) return;
            var current = hello.Role == RoomRole.Viewer ? Volatile.Read(ref viewerSnapshot) : Volatile.Read(ref snapshot);
            if (current != null) peer.Send(new RoomPacket { Type = "snapshot", Snapshot = current, Role = hello.Role });
            await peer.Run(packet =>
            {
                // The authenticated role gates commands here, before the framework queue.
                if (hello.Role != RoomRole.Presenter) { peer.Dispose(); return; }
                if (packet.Type != "command" || packet.Command == null) { peer.Dispose(); return; }
                if (Interlocked.Increment(ref queued) > 128)
                { Interlocked.Decrement(ref queued); peer.Dispose(); return; }
                commands.Enqueue((peer, packet.Command));
            });
        }
        catch (Exception ex) when (ex is IOException or AuthenticationException or OperationCanceledException or ObjectDisposedException
            or SocketException or System.Text.Json.JsonException or FormatException or CryptographicException or ArgumentException)
        { Volatile.Write(ref lastConnectionError, ex.ToString()); }
        finally
        {
            if (peer != null) { Interlocked.CompareExchange(ref presenter, null, peer); viewers.TryRemove(peer, out _); peer.Dispose(); }
            if (viewerSlot) viewerSlots.Release();
            socket.Dispose();
            handshakes.Release();
        }
    }

    public void Dispose()
    {
        if (Interlocked.Exchange(ref disposed, 1) != 0) return;
        lifetime.Cancel(); listener.Stop();
        Volatile.Read(ref presenter)?.Dispose();
        foreach (var socket in connections.Keys) socket.Dispose();
    }
}
