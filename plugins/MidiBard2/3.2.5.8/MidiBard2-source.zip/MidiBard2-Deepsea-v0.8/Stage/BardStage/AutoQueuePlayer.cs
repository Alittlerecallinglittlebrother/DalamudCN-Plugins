using BardStage.Core;

namespace BardStage;

public interface IStagePlaybackPort
{
    bool IsPlaying { get; }
    string? BlockReason(QueuePlaybackMode mode);
    Task LoadAsync(string filePath, QueuePlaybackMode mode, CancellationToken cancellationToken);
    void Start(QueuePlaybackMode mode);
    void Pause();
    void Resume();
    void Finish(QueuePlaybackMode mode);
    void Stop(QueuePlaybackMode mode, bool keepInstruments = false);
}

public sealed class AutoQueuePlayer(StageController controller, IStagePlaybackPort port, Func<DateTimeOffset>? clock = null) : IDisposable
{
    private readonly Func<DateTimeOffset> now = clock ?? (() => DateTimeOffset.UtcNow);
    private Task? loadTask;
    private CancellationTokenSource? cancellation;
    private Guid? showId, entryId;
    private QueuePlaybackMode mode;
    private DateTimeOffset deadline, notBefore;
    private bool waitingForStart, sawStart, disposed;
    public bool Enabled { get; private set; }
    public bool IsLoading => loadTask != null;
    public bool IsEnginePlaying => port.IsPlaying;
    public bool IsPaused => Entry?.PausedAtUtc.HasValue == true;
    public Guid? ActiveEntryId => entryId;
    public string Status { get; private set; } = "自动演奏未开始";
    public bool StatusIsError { get; private set; }
    private SetlistEntry? Entry => controller.State.Setlists.FirstOrDefault(s => s.Id == showId)?.Entries.FirstOrDefault(e => e.Id == entryId);

    public void Start()
    {
        if (disposed || Enabled || controller.IsBusy || controller.IsReadOnly || loadTask != null || controller.Room?.IsRemote == true) return;
        StatusIsError = false;
        controller.Poll();
        if (IsPaused && mode == QueuePlaybackMode.Solo)
        {
            try { port.Resume(); Enabled = true; Status = "正在继续演奏"; }
            catch (Exception ex) { Fail(ex.Message); }
            return;
        }
        if (Entry?.Status == EntryStatus.InProgress && (mode == QueuePlaybackMode.Ensemble || port.IsPlaying))
        { Enabled = true; Status = "本曲结束后继续连播"; return; }
        if (!controller.EnsureAutomaticQueue()) return;
        var show = controller.QueueShow!;
        if (controller.State.Setlists.Any(s => StageOperations.Current(s) != null) || port.IsPlaying)
        { Status = "有未结束的演奏，请先停止或重新排队"; return; }
        if (!controller.Change(s => s.RequestSettings.IsOpen = true)) return;
        showId = show.Id; mode = controller.State.RequestSettings.PlaybackMode;
        controller.ConfigureSync(show.Id, true);
        Enabled = true; entryId = null; sawStart = waitingForStart = false; notBefore = now(); Status = "等待点歌";
    }

    public void Pause()
    {
        if (disposed) return;
        StatusIsError = false;
        Enabled = false;
        if (waitingForStart) { Stop(); return; }
        if (loadTask != null) cancellation?.Cancel();
        try { if (Entry?.Status == EntryStatus.InProgress && mode == QueuePlaybackMode.Solo) port.Pause(); }
        catch (Exception ex) { Fail(ex.Message); return; }
        Status = mode == QueuePlaybackMode.Ensemble && Entry?.Status == EntryStatus.InProgress ? "本曲结束后暂停连播" : "连播已暂停";
    }

    public void Stop()
    {
        if (disposed) return;
        StatusIsError = false;
        Enabled = false; cancellation?.Cancel();
        try { if (entryId.HasValue) port.Stop(mode); }
        catch (Exception ex) { Fail(ex.Message); return; }
        waitingForStart = false; Status = "演奏已停止";
    }

    public void Skip()
    {
        if (disposed || controller.IsBusy || controller.SyncBlocked) return;
        StatusIsError = false;
        var show = controller.State.Setlists.FirstOrDefault(s => s.Id == showId) ?? controller.QueueShow;
        var entry = Entry ?? (show == null ? null : StageOperations.Next(show));
        if (show == null || entry == null) return;
        if (!controller.Change(s => SetlistOperations.Skip(s.Setlists.Single(x => x.Id == show.Id), entry.Id, now()), "已跳过")) return;
        cancellation?.Cancel();
        var cancelReady = waitingForStart && mode == QueuePlaybackMode.Ensemble;
        try { if (entryId.HasValue) port.Stop(mode, !cancelReady); }
        catch (Exception ex) { Fail(ex.Message); return; }
        if (cancelReady) Enabled = false;
        entryId = null; waitingForStart = false; sawStart = false; notBefore = now().AddSeconds(show.GapSeconds);
        Status = cancelReady ? "合奏准备已取消，连播已暂停" : "已跳过，等待下一首";
    }

    public void Tick()
    {
        if (disposed) return;
        if (controller.SyncBlocked || controller.ChatWriteBlocked) { Status = "记录保存失败，等待重试"; return; }
        if (loadTask != null)
        {
            if (!loadTask.IsCompleted) return;
            var completed = loadTask; loadTask = null;
            var cancelled = cancellation?.IsCancellationRequested == true;
            cancellation?.Dispose(); cancellation = null;
            try { completed.GetAwaiter().GetResult(); }
            catch (OperationCanceledException) { StopLoaded(); return; }
            catch (Exception ex) { Fail("载入失败：" + ex.Message); entryId = null; return; }
            if (cancelled || !Enabled) { StopLoaded(); return; }
            var loadedShow = controller.QueueShow;
            if (Entry?.Status != EntryStatus.Queued || loadedShow?.Id != showId || StageOperations.Next(loadedShow!)?.Id != entryId)
            { StopLoaded(); Status = "队列已改变，重新选择下一首"; return; }
            try
            {
                if (port.BlockReason(mode) is { } reason) { Fail(reason); entryId = null; return; }
                waitingForStart = true; deadline = now().AddSeconds(mode == QueuePlaybackMode.Ensemble ? 90 : 15);
                port.Start(mode); Status = mode == QueuePlaybackMode.Ensemble ? "等待合奏准备与倒计时" : "正在开始演奏";
            }
            catch (Exception ex) { Fail(ex.Message); }
            return;
        }
        if (entryId.HasValue)
        {
            var entry = Entry;
            if (entry?.Status == EntryStatus.InProgress)
            {
                sawStart = true; waitingForStart = false;
                if (entry.PausedAtUtc.HasValue) Enabled = false;
                Status = entry.PausedAtUtc.HasValue ? "演奏已暂停" : "正在演奏：" + entry.Title;
                return;
            }
            if (entry?.Status is EntryStatus.Completed or EntryStatus.Skipped)
            {
                if (entry.Status == EntryStatus.Completed)
                    try { port.Finish(mode); } catch (Exception ex) { Fail(ex.Message); entryId = null; return; }
                if (entry.Status == EntryStatus.Skipped) { Enabled = false; Status = "演奏被停止，连播已暂停"; }
                notBefore = now().AddSeconds(controller.QueueShow?.GapSeconds ?? 3);
                entryId = null; sawStart = waitingForStart = false;
            }
            else if (waitingForStart)
            {
                if (now() > deadline) { Stop(); Fail("未收到演奏开始，请检查乐器或合奏准备后重试"); entryId = null; }
                return;
            }
            else if (sawStart) { Fail("当前曲目被手动修改，连播已暂停"); entryId = null; return; }
            else entryId = null;
        }
        if (!Enabled || controller.IsBusy) return;
        if (!controller.SyncEnabled || controller.SyncShowId != showId) { Fail("状态同步已关闭，请重新开始连播"); return; }
        var show = controller.State.Setlists.FirstOrDefault(s => s.Id == showId);
        if (show == null || controller.QueueShow?.Id != showId) { Fail("点歌队列已切换，请重新开始连播"); return; }
        if (now() < notBefore) { Status = $"下一首倒计时 {Math.Ceiling((notBefore - now()).TotalSeconds)} 秒"; return; }
        if (controller.State.Setlists.Any(s => StageOperations.Current(s) != null) || port.IsPlaying)
        { Status = "等待当前演奏结束"; return; }
        var next = StageOperations.Next(show);
        if (next == null) { Status = "等待观众点歌"; return; }
        if (next.Kind != EntryKind.Song)
        {
            if (!controller.Change(s => SetlistOperations.Skip(s.Setlists.Single(x => x.Id == show.Id), next.Id, now()), "自动队列已略过非歌曲环节")) Fail(controller.StatusMessage);
            return;
        }
        if (port.BlockReason(mode) is { } blocked) { Status = blocked; return; }
        var song = controller.State.Songs.FirstOrDefault(s => s.Id == next.SongId);
        if (song == null || !File.Exists(song.FilePath)) { Fail("MIDI 文件不存在：" + next.Title); return; }
        entryId = next.Id; cancellation = new CancellationTokenSource();
        try { loadTask = port.LoadAsync(song.FilePath, mode, cancellation.Token); Status = "正在载入：" + next.Title; }
        catch (Exception ex) { Fail(ex.Message); entryId = null; cancellation.Dispose(); cancellation = null; }
    }

    private void Fail(string message) { Enabled = false; waitingForStart = false; StatusIsError = true; Status = message; }
    private void StopLoaded()
    {
        try { port.Stop(mode, Enabled); } catch (Exception ex) { Fail(ex.Message); }
        entryId = null; waitingForStart = sawStart = false;
    }
    public void Dispose()
    {
        disposed = true; Enabled = false; cancellation?.Cancel();
        if (loadTask != null) _ = loadTask.ContinueWith(t => { _ = t.Exception; cancellation?.Dispose(); }, TaskScheduler.Default);
        else cancellation?.Dispose();
    }
}
