using System.Collections.ObjectModel;
using System.Reflection;
using System.Runtime.Loader;
using Dalamud.Game.Command;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using PluginShelf;
using PluginShelf.Core;

var sdk = Environment.GetEnvironmentVariable("DALAMUD_HOME") ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "XIVLauncherCN", "addon", "Hooks", "dev");
AssemblyLoadContext.Default.Resolving += (_, name) =>
{
    var path = Path.Combine(sdk, name.Name + ".dll");
    return File.Exists(path) ? AssemblyLoadContext.Default.LoadFromAssemblyPath(path) : null;
};
return BackendTests.Run();

static class BackendTests
{
    public static int Run()
    {
        Console.WriteLine("OFFLINE BACKEND CONTRACT TESTS — real SDK interfaces, fake implementations, linked production backend.");
        Console.WriteLine($"Dalamud assembly: {typeof(IDalamudPluginInterface).Assembly.GetName()}");
        Console.WriteLine("No game process, native API, live plugin, chat service, or user configuration accessed.");
        var tests = new List<(string Name, Action Run)>();
        var assertions = 0;
        void Check(bool condition, string message = "Assertion failed")
        {
            assertions++;
            if (!condition) throw new InvalidOperationException(message);
        }
        void Throws<T>(Action action) where T : Exception
        {
            assertions++;
            try { action(); }
            catch (T) { return; }
            throw new InvalidOperationException($"Expected {typeof(T).Name}");
        }
        void Test(string name, Action body) => tests.Add((name, body));

        Test("Snapshot excludes self and empty ids and is sorted", () =>
        {
            var env = new FakeEnvironment();
            env.Plugins = [new FakePlugin("PluginShelf"), new FakePlugin(""), new FakePlugin("  "),
                new FakePlugin("B") { Name = "beta" }, new FakePlugin("A") { Name = "Alpha" }];
            var entries = env.Backend.Snapshot();
            Check(entries.Count == 2);
            Check(entries.Select(x => x.InternalName).SequenceEqual(new[] { "A", "B" }));
            Check(env.DirectoryReads == 1 && env.CommandCalls.Count == 0);
        });
        Test("Duplicate InternalName prefers loaded, then non-outdated", () =>
        {
            var env = new FakeEnvironment();
            env.Plugins = [new FakePlugin("Same") { Loaded = false, Name = "unloaded" },
                new FakePlugin("Same") { Loaded = true, Outdated = true, Name = "loaded-old" },
                new FakePlugin("Same") { Loaded = true, Outdated = false, Name = "loaded-current" }];
            Check(env.Backend.Snapshot().Single().Name == "loaded-current");
            Check(env.Backend.Find("Same")?.Name == "loaded-current");
            env.Backend.OpenMainUi("Same");
            Check(env.Plugins[2].MainCalls == 1 && env.Plugins.Take(2).All(x => x.TotalCalls == 0));
        });
        Test("Snapshot values and collection do not change with live objects", () =>
        {
            var env = new FakeEnvironment();
            var plugin = new FakePlugin("A") { Name = "Before", Version = new Version(1, 2, 3) };
            env.Plugins = [plugin];
            var snapshot = env.Backend.Snapshot();
            plugin.Name = "After"; plugin.Loaded = false; plugin.Version = new Version(9, 0);
            env.Plugins = [];
            Check(snapshot.Count == 1 && snapshot[0].Name == "Before" && snapshot[0].IsLoaded && snapshot[0].Version == "1.2.3");
            Throws<NotSupportedException>(() => ((IList<PluginEntry>)snapshot)[0] = new("X", "X", "1", false, false, false, false));
            Check(env.Backend.Snapshot().Count == 0);
        });
        Test("Find excludes self, blank and missing ids", () =>
        {
            var env = new FakeEnvironment { Plugins = [new FakePlugin("PluginShelf"), new FakePlugin("A")] };
            Check(env.Backend.Find("PluginShelf") is null);
            Check(env.Backend.Find("") is null);
            Check(env.Backend.Find("  ") is null);
            Check(env.Backend.Find("missing") is null);
            Check(env.Backend.Find("a") is null);
        });
        Test("Find returns newly loaded replacement each time", () =>
        {
            var old = new FakePlugin("A") { Name = "Old" };
            var current = new FakePlugin("A") { Name = "New" };
            var env = new FakeEnvironment { Plugins = [old] };
            var before = env.Backend.Find("A");
            env.Plugins = [current];
            var after = env.Backend.Find("A");
            Check(before?.Name == "Old" && after?.Name == "New");
            Check(env.DirectoryReads == 2);
        });
        Test("UI invocation re-resolves after previous Find and previous open", () =>
        {
            var old = new FakePlugin("A");
            var replacement = new FakePlugin("A");
            var newest = new FakePlugin("A");
            var env = new FakeEnvironment { Plugins = [old] };
            env.Backend.Find("A");
            env.Plugins = [replacement];
            env.Backend.OpenMainUi("A");
            env.Plugins = [newest];
            env.Backend.OpenConfigUi("A");
            Check(old.TotalCalls == 0 && replacement.MainCalls == 1 && replacement.ConfigCalls == 0);
            Check(newest.ConfigCalls == 1 && newest.MainCalls == 0);
            Check(env.DirectoryReads == 3);
        });
        Test("LaunchService to backend reload between preflight and dispatch uses replacement", () =>
        {
            var old = new FakePlugin("A");
            var replacement = new FakePlugin("A");
            var env = new FakeEnvironment();
            env.DirectoryProvider = () => env.DirectoryReads == 1 ? [old.Instance] : [replacement.Instance];
            var result = new LaunchService(env.Backend).Launch(new Shortcut { PluginId = "A", Kind = LaunchKind.MainUi });
            Check(result.Dispatched && old.TotalCalls == 0 && replacement.MainCalls == 1);
            Check(env.DirectoryReads == 2);
        });
        Test("Reload between preflight and dispatch to unavailable plugin does not invoke stale object", () =>
        {
            var old = new FakePlugin("A");
            var replacement = new FakePlugin("A") { Loaded = false };
            var env = new FakeEnvironment();
            env.DirectoryProvider = () => env.DirectoryReads == 1 ? [old.Instance] : [replacement.Instance];
            var result = new LaunchService(env.Backend).Launch(new Shortcut { PluginId = "A", Kind = LaunchKind.MainUi });
            Check(!result.Dispatched && old.TotalCalls == 0 && replacement.TotalCalls == 0);
            Check(env.CommandCalls.Count == 0);
        });
        Test("Direct UI calls reject missing, unloaded, outdated or self", () =>
        {
            foreach (var invalid in new[] { "missing", "off", "old", "PluginShelf" })
            {
                var env = new FakeEnvironment { Plugins = [new FakePlugin("off") { Loaded = false },
                    new FakePlugin("old") { Outdated = true }, new FakePlugin("PluginShelf")] };
                Throws<InvalidOperationException>(() => env.Backend.OpenMainUi(invalid));
                Throws<InvalidOperationException>(() => env.Backend.OpenConfigUi(invalid));
                Check(env.Plugins.All(x => x.TotalCalls == 0) && env.CommandCalls.Count == 0);
            }
        });
        Test("No main capability does not fallback to config, and vice versa", () =>
        {
            var a = new FakePlugin("A") { MainAvailable = false };
            var b = new FakePlugin("B") { ConfigAvailable = false };
            var env = new FakeEnvironment { Plugins = [a, b] };
            Throws<InvalidOperationException>(() => env.Backend.OpenMainUi("A"));
            Throws<InvalidOperationException>(() => env.Backend.OpenConfigUi("B"));
            Check(a.TotalCalls == 0 && b.TotalCalls == 0 && env.CommandCalls.Count == 0);
        });
        Test("UI exceptions are logged and not retried or downgraded", () =>
        {
            foreach (var main in new[] { true, false })
            {
                var target = new FakePlugin("A") { ThrowAction = true };
                var env = new FakeEnvironment { Plugins = [target] };
                Throws<InvalidOperationException>(() => { if (main) env.Backend.OpenMainUi("A"); else env.Backend.OpenConfigUi("A"); });
                Check(target.TotalCalls == 1 && env.CommandCalls.Count == 0 && env.LogCalls.Count == 1);
            }
        });
        Test("Backend and core agree on invalid command boundaries", () =>
        {
            string?[] invalid = [null, "", "example", " /example", "/", "/ arg", "/example\n/foo", "/example\r",
                "/example\t", "/example\0", "/example\u007f", "/example\u2028foo", "/example\u2029foo", "/example\u00a0foo", "/" + new string('x', 512)];
            foreach (var command in invalid)
            {
                var env = new FakeEnvironment();
                env.Register("/example");
                Check(LaunchService.ValidateCommand(command) is not null);
                Check(!env.Backend.IsCommandRegistered(command!) && !env.Backend.ProcessCommand(command!));
                Check(env.CommandCalls.Count == 0 && env.DirectoryReads == 0 && env.LogCalls.Count == 0);
            }
        });
        Test("Only registered ASCII-space command token is dispatched once with original args", () =>
        {
            foreach (var command in new[] { "/example", "/example 中文 private-argument", "/example  double space", "/example \u00a0parameter" })
            {
                var env = new FakeEnvironment();
                env.Register("/example");
                Check(env.Backend.IsCommandRegistered(command));
                Check(env.Backend.ProcessCommand(command));
                Check(env.ProcessedCommands.SequenceEqual(new[] { command }));
                Check(env.CommandCalls.SequenceEqual(new[] { "get_Commands", "get_Commands", "ProcessCommand" }));
                Check(env.DirectoryReads == 0);
            }
        });
        Test("Maximum 512-character command is accepted unchanged", () =>
        {
            var command = "/example " + new string('x', 503);
            Check(command.Length == 512);
            var env = new FakeEnvironment(); env.Register("/example");
            Check(env.Backend.ProcessCommand(command));
            Check(env.ProcessedCommands.Single() == command);
        });
        Test("Unregistered command does not reach ProcessCommand or any alternative", () =>
        {
            var target = new FakePlugin("A");
            var env = new FakeEnvironment { Plugins = [target] };
            Check(!env.Backend.IsCommandRegistered("/missing"));
            Check(!env.Backend.ProcessCommand("/missing args"));
            Check(env.ProcessedCommands.Count == 0 && target.TotalCalls == 0 && env.DirectoryReads == 0);
            Check(env.CommandCalls.All(x => x == "get_Commands"));
        });
        Test("Command registration is rechecked at invocation", () =>
        {
            var env = new FakeEnvironment(); env.Register("/example");
            Check(env.Backend.IsCommandRegistered("/example"));
            env.Registered.Clear();
            Check(!env.Backend.ProcessCommand("/example"));
            Check(env.ProcessedCommands.Count == 0);
        });
        Test("False command result propagates with no fallback", () =>
        {
            var target = new FakePlugin("A");
            var env = new FakeEnvironment { ProcessResult = false, Plugins = [target] };
            env.Register("/example");
            Check(!env.Backend.ProcessCommand("/example private"));
            Check(env.ProcessedCommands.Count == 1 && target.TotalCalls == 0 && env.LogCalls.Count == 0);
            Check(env.CommandCalls.All(x => x is "get_Commands" or "ProcessCommand"));
        });
        Test("Command exception logs token only and never retries", () =>
        {
            var target = new FakePlugin("A");
            var env = new FakeEnvironment { ThrowCommand = true, Plugins = [target] };
            env.Register("/example");
            Throws<InvalidOperationException>(() => env.Backend.ProcessCommand("/example secret-argument"));
            Check(env.ProcessedCommands.Count == 1 && target.TotalCalls == 0 && env.LogCalls.Count == 1);
            Check(env.LogCalls[0].Method == "Error");
            Check(((object?[])env.LogCalls[0].Arguments[2]!).SequenceEqual(new object?[] { "/example" }));
            Check(env.CommandCalls.All(x => x is "get_Commands" or "ProcessCommand"));
        });
        Test("LaunchService command through real backend dispatches once and no UI fallback", () =>
        {
            var target = new FakePlugin("A");
            var env = new FakeEnvironment { Plugins = [target] }; env.Register("/example");
            var result = new LaunchService(env.Backend).Launch(new Shortcut { PluginId = "A", Kind = LaunchKind.Command, Command = "/example argument" });
            Check(result.Dispatched && result.Message.Contains("已发送打开请求"));
            Check(env.ProcessedCommands.Count == 1 && target.TotalCalls == 0);
            Check(env.PluginInterfaceCalls.All(x => x == "get_InstalledPlugins"));
            Check(env.CommandCalls.All(x => x is "get_Commands" or "ProcessCommand"));
        });
        Test("Live directory errors are contained by launch service, never substitute action", () =>
        {
            var env = new FakeEnvironment { DirectoryProvider = () => throw new InvalidOperationException("fake directory unavailable") };
            var result = new LaunchService(env.Backend).Launch(new Shortcut { PluginId = "A" });
            Check(!result.Dispatched && env.DirectoryReads == 1 && env.CommandCalls.Count == 0);
        });

        var failures = 0;
        foreach (var (name, test) in tests)
        {
            try { test(); Console.WriteLine("PASS " + name); }
            catch (Exception exception) { failures++; Console.Error.WriteLine($"FAIL {name}: {exception}"); }
        }
        Console.WriteLine($"RESULT: {tests.Count - failures}/{tests.Count} cases passed; {assertions} assertions; {failures} failures.");
        Console.WriteLine("Evidence boundary: verifies managed dispatch contracts with fakes only; not native plugin loading, actual window visibility, or in-game acceptance.");
        return failures == 0 ? 0 : 1;
    }
}

public class HandlerProxy : DispatchProxy
{
    public Func<MethodInfo, object?[], object?> Handler { get; set; } = null!;
    protected override object? Invoke(MethodInfo? targetMethod, object?[]? args) => Handler(targetMethod!, args ?? []);
    public static T Create<T>(Func<MethodInfo, object?[], object?> handler) where T : class
    {
        var instance = Create<T, HandlerProxy>();
        ((HandlerProxy)(object)instance).Handler = handler;
        return instance;
    }
}

sealed class FakePlugin
{
    public string Id { get; }
    public string Name { get; set; }
    public Version Version { get; set; } = new(1, 0, 0);
    public bool Loaded { get; set; } = true;
    public bool Outdated { get; set; }
    public bool MainAvailable { get; set; } = true;
    public bool ConfigAvailable { get; set; } = true;
    public bool ThrowAction { get; set; }
    public int MainCalls { get; private set; }
    public int ConfigCalls { get; private set; }
    public int TotalCalls => MainCalls + ConfigCalls;
    public IExposedPlugin Instance { get; }

    public FakePlugin(string id)
    {
        Id = Name = id;
        Instance = HandlerProxy.Create<IExposedPlugin>((method, _) => method.Name switch
        {
            "get_InternalName" => Id,
            "get_Name" => Name,
            "get_Version" => Version,
            "get_IsLoaded" => Loaded,
            "get_IsOutdated" => Outdated,
            "get_HasMainUi" => MainAvailable,
            "get_HasConfigUi" => ConfigAvailable,
            "OpenMainUi" => Open(true),
            "OpenConfigUi" => Open(false),
            _ => throw new InvalidOperationException("Unexpected target API call: " + method.Name),
        });
    }

    private object? Open(bool main)
    {
        if (main) MainCalls++; else ConfigCalls++;
        if (ThrowAction) throw new InvalidOperationException("fake target failed");
        return null;
    }
}

sealed class FakeEnvironment
{
    public List<FakePlugin> Plugins { get; set; } = [];
    public Func<IEnumerable<IExposedPlugin>>? DirectoryProvider { get; set; }
    public Dictionary<string, IReadOnlyCommandInfo> Registered { get; } = new(StringComparer.Ordinal);
    public List<string> PluginInterfaceCalls { get; } = [];
    public List<string> CommandCalls { get; } = [];
    public List<string> ProcessedCommands { get; } = [];
    public List<(string Method, object?[] Arguments)> LogCalls { get; } = [];
    public int DirectoryReads { get; private set; }
    public bool ProcessResult { get; set; } = true;
    public bool ThrowCommand { get; set; }
    public DalamudBackend Backend { get; }

    public FakeEnvironment()
    {
        var pluginInterface = HandlerProxy.Create<IDalamudPluginInterface>((method, _) =>
        {
            PluginInterfaceCalls.Add(method.Name);
            if (method.Name != "get_InstalledPlugins")
                throw new InvalidOperationException("Unexpected plugin interface call: " + method.Name);
            DirectoryReads++;
            return DirectoryProvider?.Invoke() ?? Plugins.Select(x => x.Instance).ToArray();
        });
        var commands = HandlerProxy.Create<ICommandManager>((method, arguments) =>
        {
            CommandCalls.Add(method.Name);
            if (method.Name == "get_Commands")
                return new ReadOnlyDictionary<string, IReadOnlyCommandInfo>(Registered);
            if (method.Name != "ProcessCommand")
                throw new InvalidOperationException("Unexpected command API call: " + method.Name);
            ProcessedCommands.Add((string)arguments[0]!);
            if (ThrowCommand) throw new InvalidOperationException("fake registered command failed");
            return ProcessResult;
        });
        var log = HandlerProxy.Create<IPluginLog>((method, arguments) =>
        {
            if (method.Name != "Error") throw new InvalidOperationException("Unexpected log API call: " + method.Name);
            LogCalls.Add((method.Name, arguments));
            return null;
        });
        Backend = new DalamudBackend(pluginInterface, commands, log);
    }

    public void Register(string command) => Registered[command] = null!;
}
