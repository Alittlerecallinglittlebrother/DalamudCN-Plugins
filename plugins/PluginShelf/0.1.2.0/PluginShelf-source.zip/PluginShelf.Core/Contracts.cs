namespace PluginShelf.Core;

public enum LaunchKind { MainUi, ConfigUi, Command }

public sealed record PluginEntry(string InternalName, string Name, string Version,
    bool IsLoaded, bool HasMainUi, bool HasConfigUi, bool IsOutdated);

public sealed class Shortcut
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string PluginId { get; set; } = "";
    public string Label { get; set; } = "";
    public LaunchKind Kind { get; set; }
    public string Command { get; set; } = "";
}

public sealed class ShelfConfig
{
    public int Version { get; set; } = 1;
    public List<Shortcut> Favorites { get; set; } = [];
    public bool ShowDock { get; set; } = true;
    public bool DockLocked { get; set; } = true;
    public bool Vertical { get; set; }
    public bool Compact { get; set; }
    public bool HideInCombat { get; set; }
    public bool HasCompletedSetup { get; set; }
    public float Scale { get; set; } = 1;
    public float DockX { get; set; } = 80;
    public float DockY { get; set; } = 160;
    public int DockItemsPerLine { get; set; } = 8; // Retained for compatibility with existing v1 configs.
    public int PinnedCount { get; set; } = 3;
}

public interface IPluginBackend
{
    IReadOnlyList<PluginEntry> Snapshot();
    PluginEntry? Find(string id);
    void OpenMainUi(string id);
    void OpenConfigUi(string id);
    bool IsCommandRegistered(string fullCommand);
    bool ProcessCommand(string fullCommand);
}

public sealed record LaunchResult(bool Dispatched, string Message);
public sealed record ConfigLoadResult(ShelfConfig Config, bool CanSave, string Message);
