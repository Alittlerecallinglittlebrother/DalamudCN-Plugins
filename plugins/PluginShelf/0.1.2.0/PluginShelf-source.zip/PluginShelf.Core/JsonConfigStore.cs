using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace PluginShelf.Core;

/// <summary>Own config only; corrupt/future files are preserved and block saving.</summary>
public sealed class JsonConfigStore
{
    private readonly string path;
    private readonly object gate = new();
    private bool writeBlocked;
    private bool loaded;
    private byte[]? expectedHash;
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter<LaunchKind>() },
    };

    public JsonConfigStore(string path)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        this.path = Path.GetFullPath(path);
    }

    public ConfigLoadResult Load()
    {
        lock (gate)
        {
            loaded = true;
            if (!File.Exists(path))
            {
                writeBlocked = false;
                expectedHash = null;
                return new(new ShelfConfig(), true, "首次使用，尚无配置文件。");
            }
            try
            {
                var bytes = File.ReadAllBytes(path);
                expectedHash = SHA256.HashData(bytes);
                using var reader = new StreamReader(new MemoryStream(bytes));
                var json = reader.ReadToEnd();
                using var document = JsonDocument.Parse(json);
                if (document.RootElement.ValueKind != JsonValueKind.Object)
                    return Block("配置格式损坏，原文件已保留；当前仅使用临时配置。");
                // Inspect version before deserializing newer fields/enums.
                foreach (var property in document.RootElement.EnumerateObject())
                {
                    if (!property.Name.Equals("Version", StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (!property.Value.TryGetInt32(out var version))
                        return Block("配置版本格式无效，原文件已保留；已禁止覆盖。");
                    if (version > ShelfOperations.CurrentConfigVersion)
                        return Block("配置来自更新版本，原文件已保留；请更新插件，当前禁止保存。");
                }
                var config = JsonSerializer.Deserialize<ShelfConfig>(json, Options);
                if (config is null)
                    return Block("配置内容为空，原文件已保留；已禁止覆盖。");
                ShelfOperations.Normalize(config);
                writeBlocked = false;
                return new(config, true, "配置已加载。");
            }
            catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException
                                       or InvalidOperationException or NotSupportedException)
            {
                return Block("配置无法读取或格式损坏，原文件已保留；当前禁止保存。");
            }
        }
    }

    public void Save(ShelfConfig config)
    {
        ArgumentNullException.ThrowIfNull(config);
        lock (gate)
        {
            // A caller cannot bypass preservation just by skipping Load().
            if (!loaded)
                Load();
            if (writeBlocked)
                throw new InvalidOperationException("配置文件处于保护状态，禁止覆盖损坏或高版本原文件。");
            // Avoid clobbering an externally edited/replaced config since the last load/save.
            if (File.Exists(path))
            {
                var currentHash = SHA256.HashData(File.ReadAllBytes(path));
                if (expectedHash is null || !currentHash.AsSpan().SequenceEqual(expectedHash))
                    throw new IOException("配置文件已被其他程序修改，请重新加载后再保存。");
            }
            else if (expectedHash is not null)
                throw new IOException("配置文件在加载后被移动或删除，请重新加载后再保存。");
            ShelfOperations.Normalize(config);
            var serialized = JsonSerializer.SerializeToUtf8Bytes(config, Options);
            var directory = Path.GetDirectoryName(path)!;
            Directory.CreateDirectory(directory);
            var temp = Path.Combine(directory, $".{Path.GetFileName(path)}.{Guid.NewGuid():N}.tmp");
            try
            {
                using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    stream.Write(serialized);
                    stream.Flush(flushToDisk: true);
                }
                if (File.Exists(path))
                    File.Replace(temp, path, path + ".bak", ignoreMetadataErrors: true);
                else
                    File.Move(temp, path);
                expectedHash = SHA256.HashData(serialized);
            }
            finally
            {
                // The original is never deleted as a fallback. Failed replace remains an error.
                try { if (File.Exists(temp)) File.Delete(temp); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
    }

    private ConfigLoadResult Block(string message)
    {
        writeBlocked = true;
        return new(new ShelfConfig(), false, message);
    }
}
