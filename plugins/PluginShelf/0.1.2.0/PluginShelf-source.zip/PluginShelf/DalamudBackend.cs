using System;
using System.Collections.Generic;
using System.Linq;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using PluginShelf.Core;

namespace PluginShelf;

/// <summary>
/// Uses only Dalamud's public plugin/command APIs. Exposed plugin instances are
/// intentionally never retained across calls: a target may reload at any time.
/// </summary>
internal sealed class DalamudBackend : IPluginBackend
{
    private const string SelfInternalName = "PluginShelf";
    private readonly IDalamudPluginInterface pluginInterface;
    private readonly ICommandManager commandManager;
    private readonly IPluginLog log;

    public DalamudBackend(IDalamudPluginInterface pluginInterface,
        ICommandManager commandManager, IPluginLog log)
    {
        this.pluginInterface = pluginInterface;
        this.commandManager = commandManager;
        this.log = log;
    }

    public IReadOnlyList<PluginEntry> Snapshot()
    {
        // Snapshot values, not live IExposedPlugin objects. A development copy
        // and a release copy can share an InternalName; prefer the loaded one.
        var entries = this.pluginInterface.InstalledPlugins
            .Where(IsOtherPlugin)
            .Select(ToEntry)
            .GroupBy(entry => entry.InternalName, StringComparer.Ordinal)
            .Select(group => group.OrderByDescending(entry => entry.IsLoaded)
                .ThenBy(entry => entry.IsOutdated).First())
            .OrderBy(entry => entry.Name, StringComparer.OrdinalIgnoreCase)
            .ThenBy(entry => entry.InternalName, StringComparer.Ordinal)
            .ToArray();
        return Array.AsReadOnly(entries);
    }

    public PluginEntry? Find(string id)
    {
        var current = this.FindCurrent(id);
        return current is null ? null : ToEntry(current);
    }

    public void OpenMainUi(string id) => this.OpenUi(id, mainUi: true);

    public void OpenConfigUi(string id) => this.OpenUi(id, mainUi: false);

    public bool IsCommandRegistered(string fullCommand)
        => TryParseCommand(fullCommand, out _, out var token)
            && this.commandManager.Commands.ContainsKey(token);

    public bool ProcessCommand(string fullCommand)
    {
        if (!TryParseCommand(fullCommand, out var normalized, out var token)
            || !this.commandManager.Commands.ContainsKey(token))
            return false;

        try
        {
            // This is registered-command dispatch only. Never submit chat text,
            // run game macros, or try another action when dispatch returns false.
            return this.commandManager.ProcessCommand(normalized);
        }
        catch (Exception exception)
        {
            // Do not log user-supplied command arguments.
            this.log.Error(exception, "PluginShelf command dispatch failed: {Command}", token);
            throw new InvalidOperationException("指令调用发生异常；未尝试其他动作。", exception);
        }
    }

    private static bool IsOtherPlugin(IExposedPlugin plugin)
        => !string.IsNullOrWhiteSpace(plugin.InternalName)
            && !string.Equals(plugin.InternalName, SelfInternalName, StringComparison.Ordinal);

    private static PluginEntry ToEntry(IExposedPlugin plugin)
        => new(plugin.InternalName, plugin.Name, plugin.Version.ToString(),
            plugin.IsLoaded, plugin.HasMainUi, plugin.HasConfigUi, plugin.IsOutdated);

    private IExposedPlugin? FindCurrent(string id)
    {
        if (string.IsNullOrWhiteSpace(id)
            || string.Equals(id, SelfInternalName, StringComparison.Ordinal))
            return null;

        // This query occurs again at the point of invocation. Keeping a previous
        // directory snapshot is fine; keeping the old plugin object is not.
        return this.pluginInterface.InstalledPlugins
            .Where(plugin => string.Equals(plugin.InternalName, id, StringComparison.Ordinal))
            .OrderByDescending(plugin => plugin.IsLoaded)
            .ThenBy(plugin => plugin.IsOutdated)
            .FirstOrDefault();
    }

    private void OpenUi(string id, bool mainUi)
    {
        var current = this.FindCurrent(id)
            ?? throw new InvalidOperationException("目标插件不存在或已卸载；收藏仍会保留。");
        if (current.IsOutdated)
            throw new InvalidOperationException("目标插件的 API 版本已过期，请先更新目标插件。");
        if (!current.IsLoaded)
            throw new InvalidOperationException("目标插件未加载，请先在卫月插件列表中启用。");
        if (mainUi ? !current.HasMainUi : !current.HasConfigUi)
            throw new InvalidOperationException(mainUi
                ? "目标插件目前没有标准主界面入口，请编辑此快捷方式。"
                : "目标插件目前没有标准设置入口，请编辑此快捷方式。");

        try
        {
            if (mainUi)
                current.OpenMainUi();
            else
                current.OpenConfigUi();
        }
        catch (Exception exception)
        {
            this.log.Error(exception, "PluginShelf UI request failed: {PluginId}, {Action}",
                id, mainUi ? "MainUi" : "ConfigUi");
            throw new InvalidOperationException("目标插件的界面调用发生异常；未尝试其他动作。", exception);
        }
    }

    private static bool TryParseCommand(string? fullCommand, out string normalized, out string token)
    {
        normalized = string.Empty;
        token = string.Empty;
        if (LaunchService.ValidateCommand(fullCommand) is not null)
            return false;

        normalized = fullCommand!;

        // Dalamud ProcessCommand splits on an ASCII space, not arbitrary Unicode
        // whitespace. Use the same delimiter and reject ambiguous token spacing.
        var separator = normalized.IndexOf(' ');
        token = separator < 0 ? normalized : normalized[..separator];
        return true;
    }
}
