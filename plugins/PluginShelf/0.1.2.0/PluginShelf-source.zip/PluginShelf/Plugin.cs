using System.Collections.Concurrent;
using System.Diagnostics;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.Command;
using Dalamud.Game.Gui.Dtr;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using PluginShelf.Core;

namespace PluginShelf;

public sealed class Plugin : IDalamudPlugin
{
    private readonly IDalamudPluginInterface pi;
    private readonly ICommandManager commands;
    private readonly IPluginLog log;
    private readonly IFramework framework;
    private readonly ICondition condition;
    private readonly DalamudBackend backend;
    private readonly LaunchService launcher;
    private readonly JsonConfigStore store;
    private readonly ShelfConfig config;
    private readonly ShelfUi ui;
    private readonly ConcurrentQueue<Shortcut> pending = new();
    private readonly List<string> registeredCommands = [];
    private IDtrBarEntry? dtr;
    private IReadOnlyList<PluginEntry> catalog = [];
    private string status = "就绪 · 点击收藏即可发送打开请求。";
    private bool canSave;
    private volatile bool disposed;
    private int openRequested;
    private int catalogDirty = 1;
    private long nextCatalogRefresh;
    private long lastLaunch;

    public Plugin(IDalamudPluginInterface pluginInterface, ICommandManager commandManager,
        IPluginLog pluginLog, IFramework framework, ICondition condition, IDtrBar dtrBar)
    {
        pi = pluginInterface;
        commands = commandManager;
        log = pluginLog;
        this.framework = framework;
        this.condition = condition;
        backend = new DalamudBackend(pi, commands, log);
        launcher = new LaunchService(backend);
        store = new JsonConfigStore(Path.Combine(pi.GetPluginConfigDirectory(), "shelf.json"));
        var loaded = store.Load();
        config = loaded.Config;
        canSave = loaded.CanSave;
        if (!string.IsNullOrWhiteSpace(loaded.Message)) status = loaded.Message;
        ui = new ShelfUi(config, () => catalog, QueueLaunch, Save, () => status)
        {
            IsOpen = !config.HasCompletedSetup || !canSave,
            ReadOnly = !canSave,
        };
        foreach (var command in new[] { "/pluginshelf", "/pshelf" })
        {
            if (commands.AddHandler(command, new CommandInfo(OnCommand)
                { HelpMessage = "打开插件收纳盒；dock 显示快捷栏；reset 将快捷栏移回屏幕内。" }))
                registeredCommands.Add(command);
            else log.Warning("PluginShelf command {Command} is already registered; leaving it untouched.", command);
        }

        pi.UiBuilder.Draw += Draw;
        pi.UiBuilder.OpenMainUi += Open;
        pi.UiBuilder.OpenConfigUi += Open;
        pi.ActivePluginsChanged += PluginsChanged;
        framework.Update += Update;
        // Optional mouse-only recovery entry; no dependency on remembering our command.
        try
        {
            dtr = dtrBar.Get("PluginShelf", new SeStringBuilder().AddText("收纳盒").Build());
            dtr.Tooltip = new SeStringBuilder().AddText("点击整理插件 / 找回快捷栏").Build();
            dtr.OnClick = _ => Open();
        }
        catch (Exception ex) { log.Warning(ex, "Could not create optional PluginShelf DTR entry."); }
    }

    private void Open() => Interlocked.Exchange(ref openRequested, 1);
    private void PluginsChanged(IActivePluginsChangedEventArgs args) => Interlocked.Exchange(ref catalogDirty, 1);

    private void OnCommand(string command, string args)
    {
        if (string.Equals(args.Trim(), "reset", StringComparison.OrdinalIgnoreCase))
            Interlocked.Exchange(ref openRequested, 3);
        else if (string.Equals(args.Trim(), "dock", StringComparison.OrdinalIgnoreCase))
            Interlocked.Exchange(ref openRequested, 2);
        else Open();
    }

    private void QueueLaunch(Shortcut source)
    {
        var now = Stopwatch.GetTimestamp();
        if (disposed || now - lastLaunch < Stopwatch.Frequency / 4) return;
        lastLaunch = now;
        pending.Enqueue(new Shortcut
        {
            Id = source.Id, PluginId = source.PluginId, Label = source.Label,
            Kind = source.Kind, Command = source.Command,
        });
        status = "已排队 · 正在检查目标插件。";
    }

    private void Update(IFramework _)
    {
        if (disposed || !pending.TryDequeue(out var shortcut)) return;
        var result = launcher.Launch(shortcut);
        status = result.Message;
        if (!result.Dispatched) log.Information("PluginShelf: {Message}", result.Message);
    }

    private void Draw()
    {
        if (disposed) return;
        var request = Interlocked.Exchange(ref openRequested, 0);
        if (request != 0)
        {
            ui.IsOpen = true;
            if (request >= 2 && canSave)
            {
                config.ShowDock = true;
                if (request == 3) { config.DockX = 80; config.DockY = 160; }
                Save();
            }
        }
        var now = Stopwatch.GetTimestamp();
        if (Interlocked.Exchange(ref catalogDirty, 0) != 0 || now >= nextCatalogRefresh)
        {
            try { catalog = backend.Snapshot(); }
            catch (Exception ex) { log.Warning(ex, "PluginShelf catalog refresh failed."); status = "插件目录暂时无法读取，将自动重试。"; }
            nextCatalogRefresh = now + Stopwatch.Frequency * 2;
        }
        ui.Draw(condition[ConditionFlag.InCombat]);
    }

    private void Save()
    {
        if (!canSave) return;
        try { store.Save(config); }
        catch (Exception ex)
        {
            canSave = false;
            ui.ReadOnly = true;
            status = "配置保存失败，已停止写入；当前修改仅在内存中。请检查日志和配置目录。";
            log.Error(ex, "PluginShelf config save failed; original file preserved and writes disabled.");
        }
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        framework.Update -= Update;
        pi.ActivePluginsChanged -= PluginsChanged;
        pi.UiBuilder.Draw -= Draw;
        pi.UiBuilder.OpenMainUi -= Open;
        pi.UiBuilder.OpenConfigUi -= Open;
        foreach (var command in registeredCommands) commands.RemoveHandler(command);
        dtr?.Remove();
        pending.Clear();
        // Save only on explicit edits, never overwrite a file merely because a plugin unloads.
    }
}
