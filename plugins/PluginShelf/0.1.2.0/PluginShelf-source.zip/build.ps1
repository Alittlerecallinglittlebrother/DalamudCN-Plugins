param(
    [string]$DalamudHome = $env:DALAMUD_HOME,
    [switch]$Validate,
    [switch]$UiTests
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ([string]::IsNullOrWhiteSpace($DalamudHome)) {
    foreach ($candidate in @("$env:APPDATA\XIVLauncherCN\addon\Hooks\dev", "$env:APPDATA\XIVLauncher\addon\Hooks\dev")) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'Dalamud.dll')) { $DalamudHome = $candidate; break }
    }
}
if ([string]::IsNullOrWhiteSpace($DalamudHome) -or !(Test-Path -LiteralPath (Join-Path $DalamudHome 'Dalamud.dll'))) {
    throw 'Provide -DalamudHome <API 15 Hooks/dev SDK directory> or set DALAMUD_HOME.'
}
$DalamudHome = (Resolve-Path -LiteralPath $DalamudHome).Path
$previousDalamudHome = $env:DALAMUD_HOME
$env:DALAMUD_HOME = $DalamudHome
Push-Location $PSScriptRoot
try {
    & dotnet build '.\PluginShelf\PluginShelf.csproj' -c Release "-p:DalamudHome=$DalamudHome" --nologo
    if ($LASTEXITCODE -ne 0) { throw 'Plugin build failed.' }
    if ($Validate) {
        & dotnet run --project '.\PluginShelf.Core.Tests\PluginShelf.Core.Tests.csproj' -c Release
        if ($LASTEXITCODE -ne 0) { throw 'Core tests failed.' }
        & dotnet run --project '.\PluginShelf.BackendTests\PluginShelf.BackendTests.csproj' -c Release "-p:DalamudHome=$DalamudHome"
        if ($LASTEXITCODE -ne 0) { throw 'Backend tests failed.' }
    }
    if ($UiTests) {
        & dotnet run --project '.\PluginShelf.UiTests\PluginShelf.UiTests.csproj' -c Release "-p:DalamudHome=$DalamudHome" -- (Join-Path $PSScriptRoot 'artifacts\ui-validation')
        if ($LASTEXITCODE -ne 0) { throw 'Native UI tests failed.' }
    }
    Write-Host "Plugin: $(Join-Path $PSScriptRoot 'PluginShelf\bin\Release\net10.0-windows\PluginShelf.dll')"
    Write-Host 'No game configuration was changed. Offline validation does not confirm in-game loading.'
} finally { Pop-Location; $env:DALAMUD_HOME = $previousDalamudHome }
