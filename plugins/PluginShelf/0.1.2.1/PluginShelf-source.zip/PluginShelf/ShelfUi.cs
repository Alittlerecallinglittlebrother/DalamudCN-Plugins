using System.Globalization;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using PluginShelf.Core;

namespace PluginShelf;

/// <summary>Production UI, also drawn by the offline native ImGui regression host.</summary>
public sealed class ShelfUi(ShelfConfig config, Func<IReadOnlyList<PluginEntry>> catalog,
    Action<Shortcut> launch, Action save, Func<string> status)
{
    // Quiet neutral palette: no decorative accents or plugin-specific iconography.
    private static readonly Vector4 Accent = new(.88f, .90f, .92f, 1);
    private static readonly Vector4 Muted = new(.56f, .60f, .64f, 1);
    private static readonly Vector4 Warning = new(.89f, .56f, .55f, 1);
    private static readonly Vector4 Foreground = new(.93f, .94f, .95f, 1);
    private static readonly Vector4 Surface = new(.12f, .13f, .15f, 1);
    private string search = "";
    private int tab;
    private bool loadedOnly = true;
    private Guid? dragging;
    private Shortcut? editing;
    private bool editorRequested;
    private string editorError = "";
    private Vector2 dockSize = new(64, 42);
    private bool movingDock;
    private bool trayOpen;
    private string? dockToggleArmedId;
    private string traySearch = "";
    public bool IsOpen { get; set; } = true;
    public bool ReadOnly { get; set; }
    public Action<string, Vector2, Vector2>? ObserveItem { get; set; }

    private float S => config.Scale * Math.Clamp(ImGui.GetIO().FontGlobalScale, .5f, 3f);
    private void Observe(string id) => ObserveItem?.Invoke(id, ImGui.GetItemRectMin(), ImGui.GetItemRectMax());
    private static string ActionName(LaunchKind kind) => kind switch
    { LaunchKind.MainUi => "主界面", LaunchKind.ConfigUi => "设置", _ => "自定义命令" };

    public void Draw(bool inCombat)
    {
        // Dalamud may skip Draw while UI is hidden. A release can occur entirely
        // during that gap; do not treat the next ordinary click as a stale drop.
        if (!ImGui.IsMouseDown(ImGuiMouseButton.Left) && !ImGui.IsMouseReleased(ImGuiMouseButton.Left))
        {
            dragging = null;
            dockToggleArmedId = null;
            if (movingDock) { movingDock = false; save(); }
        }
        PushTheme();
        try
        {
            if (config.ShowDock && !(config.HideInCombat && inCombat)) DrawDock();
            else { trayOpen = false; dockToggleArmedId = null; }
            if (IsOpen) DrawManager();
            DrawEditor();
            if (ImGui.IsMouseReleased(ImGuiMouseButton.Left)) dragging = null;
        }
        finally { ImGui.PopStyleVar(4); ImGui.PopStyleColor(22); }
    }

    private static void PushTheme()
    {
        ImGui.PushStyleColor(ImGuiCol.Text, Foreground);
        ImGui.PushStyleColor(ImGuiCol.TextDisabled, Muted);
        ImGui.PushStyleColor(ImGuiCol.WindowBg, new Vector4(.075f, .083f, .095f, .97f));
        ImGui.PushStyleColor(ImGuiCol.ChildBg, new Vector4(.075f, .083f, .095f, .98f));
        ImGui.PushStyleColor(ImGuiCol.PopupBg, new Vector4(.105f, .115f, .13f, .98f));
        ImGui.PushStyleColor(ImGuiCol.Border, new Vector4(.24f, .26f, .29f, .72f));
        ImGui.PushStyleColor(ImGuiCol.Separator, new Vector4(.24f, .26f, .29f, .60f));
        ImGui.PushStyleColor(ImGuiCol.Button, Surface);
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(.20f, .22f, .25f, 1));
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(.25f, .27f, .30f, 1));
        ImGui.PushStyleColor(ImGuiCol.Header, new Vector4(.18f, .20f, .23f, 1));
        ImGui.PushStyleColor(ImGuiCol.HeaderHovered, new Vector4(.22f, .24f, .27f, 1));
        ImGui.PushStyleColor(ImGuiCol.FrameBg, new Vector4(.115f, .125f, .14f, 1));
        ImGui.PushStyleColor(ImGuiCol.FrameBgHovered, new Vector4(.16f, .18f, .20f, 1));
        ImGui.PushStyleColor(ImGuiCol.FrameBgActive, new Vector4(.20f, .22f, .24f, 1));
        ImGui.PushStyleColor(ImGuiCol.CheckMark, Accent);
        ImGui.PushStyleColor(ImGuiCol.SliderGrab, Muted);
        ImGui.PushStyleColor(ImGuiCol.SliderGrabActive, Accent);
        ImGui.PushStyleColor(ImGuiCol.TitleBg, new Vector4(.095f, .105f, .12f, 1));
        ImGui.PushStyleColor(ImGuiCol.TitleBgActive, new Vector4(.12f, .13f, .15f, 1));
        ImGui.PushStyleColor(ImGuiCol.ScrollbarBg, new Vector4(.08f, .09f, .10f, 1));
        ImGui.PushStyleColor(ImGuiCol.ScrollbarGrab, new Vector4(.27f, .29f, .31f, 1));
        ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, 9f);
        ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 5f);
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(14, 11));
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(8, 6));
    }

    private PluginEntry? Find(string id) => catalog().FirstOrDefault(x => x.InternalName == id);
    private static string Unavailable(Shortcut item, PluginEntry? plugin)
    {
        if (plugin is null) return "未安装 / 已移除";
        if (plugin.IsOutdated) return "插件 API 已过期";
        if (!plugin.IsLoaded) return "插件未加载";
        if (item.Kind == LaunchKind.MainUi && !plugin.HasMainUi) return "主界面入口已失效";
        if (item.Kind == LaunchKind.ConfigUi && !plugin.HasConfigUi) return "设置入口已失效";
        if (item.Kind == LaunchKind.Command && LaunchService.ValidateCommand(item.Command) is not null) return "命令格式无效";
        return "";
    }

    private static bool MouseInside(Vector2 min, Vector2 max)
    {
        var p = ImGui.GetIO().MousePos;
        return p.X >= min.X && p.Y >= min.Y && p.X < max.X && p.Y < max.Y;
    }

    private bool TrayToggleButton(string label, Vector2 size, string id)
    {
        var clicked = ImGui.Button(label, size);
        var inside = MouseInside(ImGui.GetItemRectMin(), ImGui.GetItemRectMax());
        // The tray is drawn after the dock and can own ImGui's hovered-window state.
        // A short click on the dock would then only transfer focus; use a matching
        // mouse-down/up inside this button instead of relying on ImGui.Button's mouse result.
        if (ImGui.IsMouseClicked(ImGuiMouseButton.Left) && inside) dockToggleArmedId = id;
        if (dockToggleArmedId == id && ImGui.IsMouseDragging(ImGuiMouseButton.Left, 6f)) dockToggleArmedId = null;
        if (ImGui.IsMouseReleased(ImGuiMouseButton.Left) && dockToggleArmedId == id)
        {
            dockToggleArmedId = null;
            return inside;
        }
        // Keep keyboard/gamepad activation provided by ImGui.Button.
        return clicked && !ImGui.IsMouseDown(ImGuiMouseButton.Left) && !ImGui.IsMouseReleased(ImGuiMouseButton.Left);
    }

    private void DrawDock()
    {
        var viewport = ImGui.GetMainViewport();
        var area = viewport.WorkSize;
        var x = Math.Clamp(config.DockX, 0, Math.Max(0, area.X - dockSize.X));
        var y = Math.Clamp(config.DockY, 0, Math.Max(0, area.Y - dockSize.Y));
        ImGui.SetNextWindowPos(viewport.WorkPos + new Vector2(x, y), ImGuiCond.Always);
        var flags = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove |
            ImGuiWindowFlags.NoSavedSettings | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoFocusOnAppearing |
            ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse;
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(6, 5) * S);
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(4, 4) * S);
        var dockHovered = false;
        var dockPos = viewport.WorkPos + new Vector2(x, y);
        if (ImGui.Begin("插件快捷栏###PluginShelfDock", flags))
        {
            ClampCurrentWindow();
            ImGui.SetWindowFontScale(config.Scale);
            var buttonSize = new Vector2(58, 32) * S;
            ImGui.PushStyleColor(ImGuiCol.Button, trayOpen ? new Vector4(.22f, .24f, .27f, 1) : new Vector4(.17f, .19f, .22f, 1));
            ImGui.PushStyleColor(ImGuiCol.Text, Foreground);
            if (TrayToggleButton("收纳##toggle", buttonSize, "dock:toggle")) trayOpen = !trayOpen;
            ImGui.PopStyleColor(2);
            Observe("dock:toggle");
            Tip("展开收藏夹 · 右键调整快捷栏");
            if (ImGui.BeginPopupContextItem("dock-controls"))
            {
                ImGui.BeginDisabled(ReadOnly);
                if (ImGui.MenuItem(config.DockLocked ? "解锁位置与排序" : "锁定位置与排序"))
                { config.DockLocked = !config.DockLocked; save(); }
                Observe("dock:lock");
                ImGui.EndDisabled();
                if (ImGui.MenuItem("管理全部插件")) { IsOpen = true; tab = 0; trayOpen = false; }
                ImGui.BeginDisabled(ReadOnly);
                if (ImGui.MenuItem("隐藏快捷栏")) { config.ShowDock = false; trayOpen = false; save(); }
                ImGui.EndDisabled();
                ImGui.EndPopup();
            }
            if (!config.DockLocked && !ReadOnly)
            {
                if (!config.Vertical) ImGui.SameLine();
                ImGui.Button("::##grip", new Vector2(24, 32) * S); Observe("dock:grip");
                Tip("按住拖动快捷栏");
                if (ImGui.IsItemActive() && ImGui.IsMouseDragging(ImGuiMouseButton.Left))
                {
                    var delta = ImGui.GetIO().MouseDelta;
                    config.DockX = Math.Clamp(x + delta.X, 0, Math.Max(0, area.X - dockSize.X));
                    config.DockY = Math.Clamp(y + delta.Y, 0, Math.Max(0, area.Y - dockSize.Y));
                    movingDock = true;
                }
            }
            if (movingDock && ImGui.IsMouseReleased(ImGuiMouseButton.Left)) { movingDock = false; save(); }

            // Only the first few favorites live on screen. All others stay in the flyout.
            var slot = new Vector2(config.Compact ? 44 : 62, 32) * S;
            var baseWidth = (config.DockLocked || ReadOnly ? 58 : 86) * S + 18 * S;
            var capacity = config.Vertical
                ? Math.Max(0, (int)((area.Y - 66 * S) / (slot.Y + 4 * S)))
                : Math.Max(0, (int)((area.X - baseWidth - 48 * S) / (slot.X + 4 * S)));
            var shown = Math.Min(config.Favorites.Count, Math.Min(config.PinnedCount, capacity));
            for (var i = 0; i < shown; i++)
            {
                if (!config.Vertical) ImGui.SameLine();
                DrawShortcut(config.Favorites[i], slot, "dock:", !config.DockLocked);
            }
            if (!config.Vertical) ImGui.SameLine();
            var remaining = config.Favorites.Count - shown;
            if (TrayToggleButton(remaining > 0 ? $"+{remaining}##more" : "+##more",
                    new Vector2(remaining > 9 ? 46 : 34, 32) * S, "dock:add"))
                trayOpen = !trayOpen;
            Observe("dock:add");
            Tip(remaining > 0 ? "查看其余收藏 / 搜索插件" : "添加插件 / 打开收藏夹");
            dockSize = ImGui.GetWindowSize();
            dockPos = ImGui.GetWindowPos();
            dockHovered = ImGui.IsWindowHovered(ImGuiHoveredFlags.RootAndChildWindows);
            ObserveItem?.Invoke("window:dock", ImGui.GetWindowPos(), ImGui.GetWindowPos() + dockSize);
        }
        ImGui.End();
        ImGui.PopStyleVar(2);
        if (trayOpen) DrawTray(dockHovered, dockPos);
    }

    private void DrawTray(bool dockHovered, Vector2 dock)
    {
        var viewport = ImGui.GetMainViewport();
        var area = viewport.WorkSize;
        // Include header, search, footer and child padding so short lists never hide their last row.
        var height = Math.Clamp(158 + config.Favorites.Count * 50, 204, 448);
        var size = new Vector2(Math.Min(322 * S, area.X - 16),
            Math.Min(height * S, area.Y - 16));
        var x = config.Vertical ? dock.X + dockSize.X + 6 * S : dock.X;
        var y = config.Vertical ? dock.Y : dock.Y + dockSize.Y + 6 * S;
        if (x + size.X > viewport.WorkPos.X + area.X - 8) x = dock.X - size.X - 6 * S;
        if (y + size.Y > viewport.WorkPos.Y + area.Y - 8) y = dock.Y - size.Y - 6 * S;
        var minimum = viewport.WorkPos + new Vector2(8);
        var maximum = viewport.WorkPos + area - size - new Vector2(8);
        ImGui.SetNextWindowPos(Vector2.Clamp(new Vector2(x, y), minimum, Vector2.Max(minimum, maximum)), ImGuiCond.Always);
        ImGui.SetNextWindowSize(size, ImGuiCond.Always);
        var flags = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoMove |
            ImGuiWindowFlags.NoSavedSettings | ImGuiWindowFlags.NoFocusOnAppearing;
        if (ImGui.Begin("收藏夹###PluginShelfTray", flags))
        {
            ImGui.SetWindowFontScale(config.Scale);
            ObserveItem?.Invoke("window:tray", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
            ImGui.TextUnformatted("收纳盒");
            ImGui.SameLine(); ImGui.TextDisabled($"/  {config.Favorites.Count} 个收藏");
            ImGui.Spacing();
            ImGui.SetNextItemWidth(-1);
            ImGui.InputTextWithHint("##traysearch", "搜索名称 / 别名", ref traySearch, 160);
            Observe("tray:search");
            ImGui.Spacing();
            var listHeight = Math.Max(30, ImGui.GetContentRegionAvail().Y - 70 * S);
            if (ImGui.BeginChild("entries", new Vector2(0, listHeight), false))
            {
                ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(8, 4) * S);
                var match = 0;
                foreach (var item in config.Favorites.ToArray())
                {
                    var plugin = Find(item.PluginId) ?? new PluginEntry(item.PluginId, item.PluginId, "", false, false, false, false);
                    if (!ShelfOperations.Matches(plugin, traySearch, item.Label)) continue;
                    match++;
                    DrawFavoriteRow(item, plugin, "tray:", false);
                }
                if (match == 0) ImGui.TextDisabled(config.Favorites.Count == 0 ? "暂无收藏，点下方按钮添加。" : "没有匹配的入口。");
                ImGui.PopStyleVar();
            }
            ImGui.EndChild();
            if (ImGui.Button("管理 / 添加插件", new Vector2(-1, 30 * S))) { IsOpen = true; tab = 1; trayOpen = false; }
            Observe("tray:manage");
            Tip("整理、添加、重命名或调整布局");
            ImGui.TextDisabled(Fit(status(), ImGui.GetContentRegionAvail().X));
            Tip(status());
            // Hovered-window checks fail for scrolling child regions; test the full flyout rectangle.
            if (ImGui.IsMouseClicked(ImGuiMouseButton.Left) && !dockHovered &&
                !MouseInside(dock, dock + dockSize) &&
                !MouseInside(ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize()))
                trayOpen = false;
            if (ImGui.IsKeyPressed(ImGuiKey.Escape)) trayOpen = false;
        }
        ImGui.End();
    }

    private void DrawFavoriteRow(Shortcut item, PluginEntry plugin, string prefix, bool allowDrag)
    {
        var label = ShelfOperations.LabelFor(item, plugin);
        var unavailable = Unavailable(item, plugin);
        ImGui.PushID(item.Id.ToString());
        var clicked = ImGui.InvisibleButton("##entry", new Vector2(ImGui.GetContentRegionAvail().X, 44 * S));
        Observe(prefix + item.Id);
        var hovered = ImGui.IsItemHovered();
        var min = ImGui.GetItemRectMin();
        var max = ImGui.GetItemRectMax();
        var dl = ImGui.GetWindowDrawList();
        if (hovered) dl.AddRectFilled(min, max, ImGui.GetColorU32(new Vector4(.18f, .20f, .23f, 1)), 5 * S);
        dl.AddLine(new Vector2(min.X + 10 * S, max.Y), new Vector2(max.X - 10 * S, max.Y),
            ImGui.GetColorU32(new Vector4(.23f, .25f, .28f, .55f)));
        var titleWidth = Math.Max(24, max.X - min.X - 24 * S);
        dl.AddText(min + new Vector2(11, 3) * S,
            ImGui.GetColorU32(unavailable.Length > 0 ? Muted : Foreground), Fit(label, titleWidth));
        var detail = unavailable.Length > 0 ? unavailable : ActionName(item.Kind);
        dl.AddText(min + new Vector2(11, 23) * S, ImGui.GetColorU32(Muted), Fit(detail, titleWidth));
        var sourceWasDragged = dragging == item.Id;
        if (allowDrag && !ReadOnly) HandleDrag(item);
        if (clicked && !sourceWasDragged && dragging is null && unavailable.Length == 0)
        { launch(item); if (prefix == "tray:") trayOpen = false; }
        Tip(label + "\n" + ActionName(item.Kind) + (unavailable.Length > 0 ? " · " + unavailable : " · 左键请求打开 / 右键编辑") +
            (allowDrag ? "\n拖动可排序" : ""));
        DrawContext(item, plugin);
        ImGui.PopID();
    }

    private void DrawShortcut(Shortcut item, Vector2 size, string prefix, bool allowDrag)
    {
        var plugin = Find(item.PluginId);
        var label = ShelfOperations.LabelFor(item, plugin);
        var unavailable = Unavailable(item, plugin);
        var pinned = prefix == "dock:";
        var visible = pinned ? Fit(ShortText(label, config.Compact ? 2 : 4), size.X - 8 * S)
            : Fit(label, Math.Max(30, size.X - 16 * S)) + "\n" + ActionName(item.Kind);
        ImGui.PushID(item.Id.ToString());
        // A disabled action still has an active edit/context surface for repairing the shortcut.
        if (unavailable.Length > 0) ImGui.PushStyleVar(ImGuiStyleVar.Alpha, .48f);
        var clicked = ImGui.Button(visible + "###shortcut", size);
        if (unavailable.Length > 0) ImGui.PopStyleVar();
        Observe(prefix + item.Id);
        var sourceWasDragged = dragging == item.Id;
        if (allowDrag && !ReadOnly) HandleDrag(item);
        if (clicked && !sourceWasDragged && dragging is null && unavailable.Length == 0) launch(item);
        Tip(label + "\n" + item.PluginId + "\n动作：" + ActionName(item.Kind) +
            (item.Kind == LaunchKind.Command ? "\n" + item.Command : "") +
            (unavailable.Length > 0 ? "\n不可用：" + unavailable : "\n左键请求打开 · 右键更多") +
            (allowDrag ? "\n按住拖动可排序" : ""));
        DrawContext(item, plugin);
        ImGui.PopID();
    }

    private void HandleDrag(Shortcut item)
    {
        if (ImGui.IsItemActive() && ImGui.IsMouseDragging(ImGuiMouseButton.Left, 6)) dragging = item.Id;
        if (dragging is { } source && source != item.Id &&
            ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenBlockedByActiveItem))
        {
            var dl = ImGui.GetWindowDrawList();
            dl.AddRect(ImGui.GetItemRectMin(), ImGui.GetItemRectMax(), ImGui.GetColorU32(Accent), 5, ImDrawFlags.None, 2);
            if (ImGui.IsMouseReleased(ImGuiMouseButton.Left) && ShelfOperations.Move(config, source, item.Id)) save();
        }
    }

    private void DrawContext(Shortcut item, PluginEntry? plugin)
    {
        if (!ImGui.BeginPopupContextItem("actions")) return;
        ImGui.TextUnformatted(ShelfOperations.LabelFor(item, plugin));
        ImGui.Separator();
        var ready = plugin is { IsLoaded: true, IsOutdated: false };
        if (ImGui.MenuItem("打开主界面", "", false, ready && plugin!.HasMainUi))
            launch(new Shortcut { PluginId = item.PluginId, Kind = LaunchKind.MainUi });
        if (ImGui.MenuItem("打开设置", "", false, ready && plugin!.HasConfigUi))
            launch(new Shortcut { PluginId = item.PluginId, Kind = LaunchKind.ConfigUi });
        ImGui.Separator();
        if (ImGui.MenuItem("修改名称 / 默认动作", "", false, !ReadOnly)) BeginEdit(item);
        Observe("context:edit");
        if (ImGui.MenuItem("移出快捷栏", "", false, !ReadOnly))
        { config.Favorites.RemoveAll(x => x.Id == item.Id); save(); }
        ImGui.EndPopup();
    }

    private void DrawManager()
    {
        var viewport = ImGui.GetMainViewport();
        ImGui.SetNextWindowSize(Vector2.Min(new Vector2(610, 490) * S, viewport.WorkSize - new Vector2(20)), ImGuiCond.FirstUseEver);
        ImGui.SetNextWindowPos(viewport.WorkPos + new Vector2(80, 80), ImGuiCond.FirstUseEver);
        var maximum = Vector2.Max(new Vector2(100), viewport.WorkSize - new Vector2(16));
        ImGui.SetNextWindowSizeConstraints(Vector2.Min(new Vector2(440, 330) * S, maximum), maximum);
        var open = IsOpen;
        if (ImGui.Begin("插件收纳盒###PluginShelfManager", ref open, ImGuiWindowFlags.NoCollapse))
        {
            ClampCurrentWindow();
            ObserveItem?.Invoke("window:manager", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
            ImGui.SetWindowFontScale(config.Scale);
            ImGui.TextColored(Muted, $"{catalog().Count} 个已发现插件   ·   {config.Favorites.Count} 个快捷入口");
            if (ReadOnly) ImGui.TextColored(Warning, "配置只读：原文件已保留，请检查状态信息。当前不能修改收藏。" );
            if (!config.HasCompletedSetup)
            {
                ImGui.TextWrapped("首次使用：在“全部插件”收藏常用入口。以后直接点击画面上的快捷栏，不需要输入指令。" );
                ImGui.BeginDisabled(ReadOnly);
                if (ImGui.SmallButton("完成设置，不再显示说明")) { config.HasCompletedSetup = true; save(); }
                ImGui.EndDisabled();
            }
            ImGui.Spacing();
            ImGui.SetNextItemWidth(-1);
            ImGui.InputTextWithHint("##search", "搜索插件名称 / 中文别名 / 内部名称", ref search, 160);
            Observe("shelf:search");
            ImGui.Spacing();
            Tab("我的收藏", 0, "tab:favorites"); ImGui.SameLine();
            Tab("全部插件", 1, "tab:catalog"); ImGui.SameLine();
            Tab("布局设置", 2, "tab:settings");
            ImGui.Separator();
            var footer = ImGui.GetTextLineHeightWithSpacing() * 2.8f;
            if (ImGui.BeginChild("content", new Vector2(0, -footer), false))
            {
                if (tab == 0) DrawFavorites();
                else if (tab == 1) DrawCatalog();
                else DrawSettings();
            }
            ImGui.EndChild();
            ImGui.Separator();
            ImGui.TextWrapped(status());
            ImGui.TextColored(Muted, "主界面与设置分开收藏；打开请求由目标插件处理。" );
        }
        ImGui.End();
        IsOpen = open;
    }

    private void Tab(string title, int value, string id)
    {
        var selected = tab == value;
        if (selected) ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(.24f, .26f, .29f, 1));
        if (ImGui.Button(title, new Vector2(112, 31) * S)) tab = value;
        Observe(id);
        if (selected) ImGui.PopStyleColor();
    }

    private void DrawFavorites()
    {
        if (config.Favorites.Count == 0)
        {
            ImGui.Spacing(); ImGui.TextColored(Accent, "把常用插件放到这里");
            ImGui.TextWrapped("收藏后，点击快捷栏即可调用。主界面和设置可以分别收藏，名字也可以改成自己习惯的中文。" );
            if (ImGui.Button("去添加插件", new Vector2(170, 35) * S)) tab = 1;
            return;
        }
        ImGui.TextDisabled("拖动调整顺序  ·  右键重命名 / 修改动作 / 移除" );
        var count = 0;
        foreach (var item in config.Favorites.ToArray())
        {
            var plugin = Find(item.PluginId) ?? new PluginEntry(item.PluginId, item.PluginId, "", false, false, false, false);
            if (!ShelfOperations.Matches(plugin, search, item.Label)) continue;
            count++;
            DrawFavoriteRow(item, plugin, "favorites:", true);
        }
        if (count == 0) ImGui.TextDisabled("没有匹配的收藏。" );
    }

    private void DrawCatalog()
    {
        ImGui.Checkbox("只看已加载插件", ref loadedOnly);
        var count = 0;
        foreach (var plugin in catalog())
        {
            var aliases = string.Join(" ", config.Favorites.Where(x => x.PluginId == plugin.InternalName).Select(x => x.Label));
            if ((loadedOnly && !plugin.IsLoaded) || !ShelfOperations.Matches(plugin, search, aliases)) continue;
            count++;
            ImGui.PushID(plugin.InternalName);
            ImGui.Spacing();
            var ready = plugin.IsLoaded && !plugin.IsOutdated;
            ImGui.TextColored(ready ? Foreground : Muted, Fit(plugin.Name, ImGui.GetContentRegionAvail().X - 80 * S));
            Tip(plugin.InternalName + "  ·  " + plugin.Version + (ready ? "" : plugin.IsOutdated ? "\nAPI 已过期" : "\n尚未加载"));
            ImGui.SameLine();
            ImGui.TextDisabled(ready ? "可用" : plugin.IsOutdated ? "已过期" : "未加载");
            if (plugin.HasMainUi) AddButton(plugin, LaunchKind.MainUi, ready);
            if (plugin.HasConfigUi)
            {
                if (plugin.HasMainUi && ImGui.GetContentRegionAvail().X > 130 * S) ImGui.SameLine();
                AddButton(plugin, LaunchKind.ConfigUi, ready);
            }
            if (!plugin.HasMainUi && !plugin.HasConfigUi) ImGui.TextDisabled("无标准入口" );
            if (ImGui.GetContentRegionAvail().X > 118 * S) ImGui.SameLine();
            ImGui.BeginDisabled(ReadOnly || !ready);
            if (ImGui.SmallButton("绑定命令")) BeginEdit(new Shortcut { PluginId = plugin.InternalName, Kind = LaunchKind.Command });
            ImGui.EndDisabled();
            ImGui.Separator();
            ImGui.PopID();
        }
        if (count == 0) ImGui.TextWrapped("没有匹配的插件。试试清空搜索，或取消“只看已加载插件”。" );
    }

    private void AddButton(PluginEntry plugin, LaunchKind kind, bool ready)
    {
        var exists = config.Favorites.Any(x => x.PluginId == plugin.InternalName && x.Kind == kind);
        ImGui.BeginDisabled(ReadOnly || !ready || exists);
        if (ImGui.Button((exists ? "已收藏 " : "＋ ") + ActionName(kind), new Vector2(124, 26) * S))
        {
            if (ShelfOperations.TryAdd(config, plugin, kind)) { config.ShowDock = true; save(); }
        }
        Observe($"add:{plugin.InternalName}:{kind}");
        ImGui.EndDisabled();
    }

    private void DrawSettings()
    {
        ImGui.Spacing(); ImGui.TextColored(Accent, "快捷栏布局");
        ImGui.BeginDisabled(ReadOnly);
        Check("显示快捷栏", "settings:showdock", config.ShowDock, v => config.ShowDock = v);
        Check("锁定位置和快捷栏排序", "settings:locked", config.DockLocked, v => config.DockLocked = v);
        Check("竖向排列", "settings:vertical", config.Vertical, v => config.Vertical = v);
        Check("置顶入口显示双字缩写", "settings:compact", config.Compact, v => config.Compact = v);
        Check("战斗中隐藏快捷栏", "settings:combat", config.HideInCombat, v => config.HideInCombat = v);
        ImGui.TextDisabled("常驻条只显示少量入口；点击“收纳”或“+”展开全部收藏。");
        var pinned = config.PinnedCount;
        ImGui.SetNextItemWidth(Math.Min(240 * S, ImGui.GetContentRegionAvail().X));
        if (ImGui.SliderInt("常驻入口数", ref pinned, 0, 6)) config.PinnedCount = pinned;
        if (ImGui.IsItemDeactivatedAfterEdit()) save();
        ImGui.Spacing();
        var scale = config.Scale;
        ImGui.SetNextItemWidth(Math.Min(240 * S, ImGui.GetContentRegionAvail().X));
        if (ImGui.SliderFloat("缩放", ref scale, .8f, 1.6f, "%.2f")) config.Scale = scale;
        if (ImGui.IsItemDeactivatedAfterEdit()) save();
        if (ImGui.Button("找回快捷栏 / 重置位置"))
        { config.DockX = 80; config.DockY = 160; config.ShowDock = true; save(); }
        ImGui.EndDisabled();
        ImGui.Spacing(); ImGui.Separator(); ImGui.Spacing();
        ImGui.TextColored(Muted, "使用提示");
        ImGui.TextWrapped("• 置顶入口一键打开；其余入口点“收纳”展开后可搜索。\n• 右键“收纳”解锁位置；解锁后拖动 :: 移动快捷栏，拖动置顶入口排序。\n• 展开面板右键入口可改名、换动作或移除；收纳面板也能排序。\n• 隐藏游戏 UI / 过场 / 拍照时，遵循 Dalamud 的全局显示设置。\n• 顶部服务器信息栏的“收纳盒”可随时找回本面板。\n• 部分插件的入口是显示/隐藏切换，实际行为由目标插件决定。" );
    }

    private void Check(string title, string id, bool value, Action<bool> setter)
    {
        if (ImGui.Checkbox(title, ref value)) { setter(value); save(); }
        Observe(id);
    }

    private void BeginEdit(Shortcut item)
    {
        editing = new Shortcut { Id = item.Id, PluginId = item.PluginId, Label = item.Label, Kind = item.Kind, Command = item.Command };
        editorError = "";
        editorRequested = true;
    }

    private void DrawEditor()
    {
        if (editorRequested) { ImGui.OpenPopup("编辑快捷方式###PluginShelfEditor"); editorRequested = false; }
        if (editing is null) return;
        var available = ImGui.GetMainViewport().WorkSize - new Vector2(24);
        ImGui.SetNextWindowSize(Vector2.Min(new Vector2(510, 340) * S, available), ImGuiCond.Appearing);
        var open = true;
        if (ImGui.BeginPopupModal("编辑快捷方式###PluginShelfEditor", ref open, ImGuiWindowFlags.NoSavedSettings))
        {
            ClampCurrentWindow();
            ImGui.SetWindowFontScale(config.Scale);
            ImGui.TextColored(Accent, Find(editing.PluginId)?.Name ?? editing.PluginId);
            ImGui.TextDisabled(editing.PluginId);
            ImGui.BeginDisabled(ReadOnly);
            var label = editing.Label;
            ImGui.SetNextItemWidth(-1);
            if (ImGui.InputTextWithHint("##alias", "中文别名（留空使用插件原名）", ref label, 80)) editing.Label = label;
            Observe("editor:label");
            var kind = (int)editing.Kind;
            ImGui.SetNextItemWidth(-1);
            if (ImGui.Combo("##kind", ref kind, "打开主界面\0打开设置\0自定义命令\0")) editing.Kind = (LaunchKind)kind;
            Observe("editor:kind");
            if (editing.Kind == LaunchKind.Command)
            {
                var command = editing.Command;
                ImGui.SetNextItemWidth(-1);
                if (ImGui.InputTextWithHint("##command", "/已知指令 参数", ref command, 513)) editing.Command = command;
                Observe("editor:command");
                ImGui.TextWrapped("仅填写已确认的打开指令；保存不执行。点击时检查是否已注册，不会转发到聊天频道。" );
            }
            else ImGui.TextWrapped("主界面与设置是不同入口。若插件没有对应入口，快捷方式将显示为不可用。" );
            if (editorError.Length > 0) ImGui.TextColored(Warning, editorError);
            ImGui.Spacing();
            if (ImGui.Button("保存", new Vector2(100, 32) * S)) SaveEditor();
            Observe("editor:save");
            ImGui.EndDisabled();
            ImGui.SameLine();
            if (ImGui.Button("取消", new Vector2(100, 32) * S)) { editing = null; ImGui.CloseCurrentPopup(); }
            ImGui.EndPopup();
        }
        if (!open) editing = null;
    }

    private void SaveEditor()
    {
        if (editing is null) return;
        if (editing.Kind == LaunchKind.Command && LaunchService.ValidateCommand(editing.Command) is { } error)
        { editorError = error; return; }
        if (config.Favorites.Any(x => x.Id != editing.Id && x.PluginId == editing.PluginId && x.Kind == editing.Kind &&
            (editing.Kind != LaunchKind.Command || x.Command == editing.Command)))
        { editorError = "这个入口已经在收藏中。"; return; }
        var index = config.Favorites.FindIndex(x => x.Id == editing.Id);
        if (index >= 0) config.Favorites[index] = editing;
        else if (config.Favorites.Count < 256) config.Favorites.Add(editing);
        else { editorError = "收藏已达到 256 个入口。"; return; }
        save(); editing = null; ImGui.CloseCurrentPopup();
    }

    private static string Fit(string text, float width)
    {
        text = text.Replace("\r", " ").Replace("\n", " ").Replace("##", "＃＃");
        if (ImGui.CalcTextSize(text).X <= width) return text;
        var parts = StringInfo.ParseCombiningCharacters(text);
        for (var n = parts.Length - 1; n > 0; n--)
        {
            var candidate = text[..parts[n]] + "…";
            if (ImGui.CalcTextSize(candidate).X <= width) return candidate;
        }
        return "…";
    }

    private static void ClampCurrentWindow()
    {
        var viewport = ImGui.GetMainViewport();
        var minimum = viewport.WorkPos + new Vector2(8);
        var maximum = Vector2.Max(minimum, viewport.WorkPos + viewport.WorkSize - ImGui.GetWindowSize() - new Vector2(8));
        var position = Vector2.Clamp(ImGui.GetWindowPos(), minimum, maximum);
        if (position != ImGui.GetWindowPos()) ImGui.SetWindowPos(position, ImGuiCond.Always);
    }

    private static string ShortText(string text, int count)
    {
        var indices = StringInfo.ParseCombiningCharacters(text);
        return (indices.Length > count ? text[..indices[count]] : text).Replace("#", "＃");
    }

    private static void Tip(string text)
    {
        if (!ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled)) return;
        ImGui.BeginTooltip();
        ImGui.PushTextWrapPos(ImGui.GetFontSize() * 26);
        ImGui.TextUnformatted(text);
        ImGui.PopTextWrapPos();
        ImGui.EndTooltip();
    }
}
