using System.Reflection;
using Dalamud.Plugin;
using PluginShelf;
using PluginShelf.Core;

static class LifecycleTests
{
    public static void Register(Action<string, Action> test, Action<bool, string> check)
    {
        void Ok(bool condition, string message = "lifecycle assertion failed") => check(condition, message);
        test("Installed SDK has exactly the guarded lifecycle and profile signatures", () =>
        {
            var assembly = typeof(IDalamudPluginInterface).Assembly;
            var plugin = assembly.GetType("Dalamud.Plugin.Internal.Types.LocalPlugin", true)!;
            var profile = assembly.GetType("Dalamud.Plugin.Internal.Profiles.Profile", true)!;
            var manager = assembly.GetType("Dalamud.Plugin.Internal.PluginManager", true)!;
            var profiles = assembly.GetType("Dalamud.Plugin.Internal.Profiles.ProfileManager", true)!;
            foreach (var name in new[] { "InternalName", "IsLoaded", "State", "IsOutdated", "IsBanned", "Manifest", "EffectiveWorkingPluginId", "DllFile", "EffectiveVersion", "IsDev", "Name" })
                Ok(plugin.GetProperty(name) is not null, name);
            Ok(manager.GetProperty("InstalledPlugins") is not null && manager.GetProperty("SafeMode") is not null);
            Ok(profiles.GetProperty("Profiles") is not null && profiles.GetProperty("IsBusy") is not null);
            var load = plugin.GetMethods().Single(m => m.Name == "LoadAsync" && m.GetParameters().Length == 3);
            Ok(load.GetParameters()[0].ParameterType.IsEnum && Enum.GetNames(load.GetParameters()[0].ParameterType).Contains("Installer"));
            Ok(load.GetParameters()[1].ParameterType == typeof(bool) && load.GetParameters()[2].ParameterType == typeof(CancellationToken));
            var unload = plugin.GetMethods().Single(m => m.Name == "UnloadAsync" && m.GetParameters().Length == 1);
            Ok(Enum.GetNames(unload.GetParameters()[0].ParameterType).Contains("WaitBeforeDispose"));
            Ok(typeof(Task).IsAssignableFrom(load.ReturnType) && typeof(Task).IsAssignableFrom(unload.ReturnType));
            Ok(profile.GetMethod("WantsPlugin", [typeof(Guid)])?.ReturnType == typeof(bool?));
            Ok(profile.GetMethod("CheckWantsActiveFromGameState", [typeof(ulong)])?.ReturnType == typeof(bool));
            Ok(profile.GetMethod("AddOrUpdateAsync", [typeof(Guid), typeof(string), typeof(bool), typeof(bool)])?.ReturnType == typeof(Task));
        });
        test("Lifecycle enable uses owner state then load, disable unload then owner state", () =>
        {
            var e = new Environment();
            var plugin = e.Add("A");
            var other = e.Add("Unrelated", true);
            var result = e.Run("A", true);
            Ok(result.Outcome == ControlOutcome.Changed && plugin.IsLoaded);
            Ok(e.Events.SequenceEqual(new[] { "want:A:True:False", "load:A" }));
            Ok(e.Profile.WantsPlugin(plugin.EffectiveWorkingPluginId) is true && other.IsLoaded);
            e.Events.Clear();
            result = e.Run("A", false);
            Ok(result.Outcome == ControlOutcome.Changed && !plugin.IsLoaded && other.IsLoaded);
            Ok(e.Events.SequenceEqual(new[] { "unload:A", "want:A:False:False" }));
            Ok(e.Profile.WantsPlugin(plugin.EffectiveWorkingPluginId) is false);
        });
        test("Already at target state is idempotent and has no profile writes", () =>
        {
            var e = new Environment(); e.Add("A", true); e.Add("B");
            Ok(e.Run("A", true).Outcome == ControlOutcome.Unchanged);
            Ok(e.Run("B", false).Outcome == ControlOutcome.Unchanged && e.Events.Count == 0);
        });
        test("Self, missing, safe mode and busy profile manager fail without mutation", () =>
        {
            var e = new Environment(); e.Add("PluginShelf", true); e.Add("A");
            Ok(e.Run("PluginShelf", false).Outcome == ControlOutcome.Failed);
            Ok(e.Run("Missing", true).Outcome == ControlOutcome.Failed);
            e.Manager.SafeMode = true;
            Ok(e.Run("A", true).Outcome == ControlOutcome.Failed);
            e.Manager.SafeMode = false; e.Profiles.IsBusy = true;
            Ok(e.Run("A", true).Outcome == ControlOutcome.Failed && e.Events.Count == 0);
        });
        test("Outdated, banned, deletion-scheduled, loading and error states are not force-loaded", () =>
        {
            foreach (var kind in new[] { "outdated", "banned", "delete", "Loading", "Unloading", "LoadError", "UnloadError" })
            {
                var e = new Environment(); var plugin = e.Add("A");
                if (kind == "outdated") plugin.IsOutdated = true;
                else if (kind == "banned") plugin.IsBanned = true;
                else if (kind == "delete") plugin.Manifest.ScheduledForDeletion = true;
                else plugin.State = kind;
                Ok(e.Run("A", true).Outcome == ControlOutcome.Failed && e.Events.Count == 0, kind);
            }
        });
        test("Ambiguous installation copies are rejected; sole running copy is preferred", () =>
        {
            var e = new Environment(); e.Add("A"); var selected = e.Add("A");
            Ok(e.Run("A", true).Outcome == ControlOutcome.Failed && e.Events.Count == 0);
            selected.State = "Loaded";
            Ok(e.Run("A", false).Outcome == ControlOutcome.Changed && selected.State == "Unloaded");
            e.Events.Clear(); foreach (var p in e.Manager.InstalledPlugins) p.State = "Loaded";
            Ok(e.Run("A", false).Outcome == ControlOutcome.Failed && e.Events.Count == 0);
        });
        test("Instance directory reports separate GUIDs, paths and versions without mutating anything", () =>
        {
            var e = new Environment(); e.Add("A"); var running = e.Add("A", true); e.Add("PluginShelf", true);
            var copies = e.Copies();
            Ok(copies.Count == 2 && copies.Select(x => x.Target.WorkingPluginId).Distinct().Count() == 2);
            Ok(copies.Select(x => x.Target.DllPath).Distinct().Count() == 2 && copies.All(x => x.Version == "1.0" && x.IsDev));
            Ok(copies.Single(x => x.IsLoaded).Target == running.Target && e.Events.Count == 0);
        });
        test("Explicit choice starts only chosen one of two stopped development copies", () =>
        {
            var e = new Environment(); var first = e.Add("A"); var second = e.Add("A");
            Ok(e.Run("A", true).Outcome == ControlOutcome.Failed && e.Events.Count == 0);
            var result = e.Run("A", true, second.Target);
            Ok(result.Outcome == ControlOutcome.Changed && result.Target == second.Target);
            Ok(!first.IsLoaded && second.IsLoaded && e.Profile.WantsPlugin(first.EffectiveWorkingPluginId) is false);
        });
        test("Stop remembers sole running instance so the same copy can be started again", () =>
        {
            var e = new Environment(); var first = e.Add("A"); var selected = e.Add("A", true);
            var stopped = e.Run("A", false);
            Ok(stopped.Outcome == ControlOutcome.Changed && stopped.Target == selected.Target);
            var started = e.Run("A", true, stopped.Target);
            Ok(started.Outcome == ControlOutcome.Changed && selected.IsLoaded && !first.IsLoaded);
            Ok(e.Run("A", true, started.Target).Outcome == ControlOutcome.Unchanged);
        });
        test("Disable with several already stopped copies is a no-op, not a false ambiguity error", () =>
        {
            var e = new Environment(); e.Add("A"); e.Add("A");
            var result = e.Run("A", false);
            Ok(result.Outcome == ControlOutcome.Unchanged && result.Target is null && e.Events.Count == 0);
        });
        test("Explicit stop affects only selected running copy, even when another one is loaded", () =>
        {
            var e = new Environment(); var first = e.Add("A", true); var second = e.Add("A", true);
            var result = e.Run("A", false, second.Target);
            Ok(result.Outcome == ControlOutcome.Changed && !second.IsLoaded && first.IsLoaded);
            Ok(result.Message.Contains("仍在运行") && e.Profile.WantsPlugin(first.EffectiveWorkingPluginId) is true);
        });
        test("Selection never loads a second copy alongside a running copy", () =>
        {
            var e = new Environment(); e.Add("A", true); var stopped = e.Add("A");
            Ok(e.Run("A", true, stopped.Target).Outcome == ControlOutcome.Failed && e.Events.Count == 0);
        });
        test("Missing preferred copy fails without switching to other copy", () =>
        {
            var e = new Environment(); var old = e.Add("A"); var target = old.Target;
            e.Manager.InstalledPlugins.Remove(old); e.Add("A");
            Ok(e.Run("A", true, target).Outcome == ControlOutcome.Failed && e.Events.Count == 0);
        });
        test("Two different copies sharing a profile ID cannot mutate each other's saved state", () =>
        {
            var e = new Environment(); var first = e.Add("A"); var second = e.Add("A");
            second.EffectiveWorkingPluginId = first.EffectiveWorkingPluginId;
            second.PathOverride = Path.Combine(Path.GetTempPath(), "different", "A.dll");
            Ok(e.Run("A", true, second.Target).Outcome == ControlOutcome.Failed && e.Events.Count == 0);
        });
        test("Repeated references to one runtime object are not two installations", () =>
        {
            var e = new Environment(); var plugin = e.Add("A"); e.Manager.InstalledPlugins.Add(plugin);
            Ok(e.Copies().Count == 1 && e.Run("A", true).Outcome == ControlOutcome.Changed);
            Ok(e.Events.Count(x => x == "load:A") == 1);
        });
        test("Multiple, disabled, character-filtered or missing profile owners are not rewritten", () =>
        {
            foreach (var kind in new[] { "multiple", "disabled", "character", "missing" })
            {
                var e = new Environment(); var plugin = e.Add("A");
                if (kind == "multiple")
                {
                    var other = new MockProfile(e.Events); other.States[plugin.EffectiveWorkingPluginId] = false;
                    e.Profiles.Profiles.Add(other);
                }
                if (kind == "disabled") e.Profile.IsEnabled = false;
                if (kind == "character") e.Profile.CharacterAllowed = false;
                if (kind == "missing") e.Profile.States.Clear();
                Ok(e.Run("A", true).Outcome == ControlOutcome.Failed && e.Events.Count == 0, kind);
            }
        });
        test("Failed load restores previous want state, records failure and never retries", () =>
        {
            var e = new Environment(); var plugin = e.Add("A"); plugin.FailLoad = true;
            Ok(e.Run("A", true).Outcome == ControlOutcome.Failed && !plugin.IsLoaded);
            Ok(e.Events.SequenceEqual(new[] { "want:A:True:False", "load:A", "want:A:False:False" }));
            Ok(e.Profile.WantsPlugin(plugin.EffectiveWorkingPluginId) is false && e.Errors.Count == 1);
        });
        test("Failed unload does not report success or clear saved enable state", () =>
        {
            var e = new Environment(); var plugin = e.Add("A", true); plugin.FailUnload = true;
            Ok(e.Run("A", false).Outcome == ControlOutcome.Failed);
            Ok(e.Events.SequenceEqual(new[] { "unload:A" }) && e.Profile.WantsPlugin(plugin.EffectiveWorkingPluginId) is true);
        });
        test("Completed lifecycle task with wrong resulting state is not success", () =>
        {
            foreach (var enabled in new[] { true, false })
            {
                var e = new Environment(); var plugin = e.Add("A", !enabled); plugin.IgnoreState = true;
                Ok(e.Run("A", enabled).Outcome == ControlOutcome.Failed);
                Ok(e.Profile.WantsPlugin(plugin.EffectiveWorkingPluginId) == !enabled,
                    "wrong resulting state must not leave a new saved enable intention");
            }
        });
        test("Replacement after load is re-resolved instead of trusting stale object", () =>
        {
            var e = new Environment(); var old = e.Add("A");
            old.AfterLoad = () => e.Manager.InstalledPlugins.Clear();
            Ok(e.Run("A", true).Outcome == ControlOutcome.Failed && old.IsLoaded);
        });
        test("Missing runtime members fail closed and are logged", () =>
        {
            var errors = new List<Exception>();
            var backend = new DalamudPluginControl(() => (new object(), new object(), 0UL), (ex, _) => errors.Add(ex));
            var result = backend.SetEnabledAsync("A", true, CancellationToken.None).GetAwaiter().GetResult();
            Ok(result.Outcome == ControlOutcome.Failed && result.Message.Contains("不兼容") && errors.Count == 1);
        });
        test("Pre-cancelled operation performs no reflection or mutation", () =>
        {
            var accessed = false;
            var backend = new DalamudPluginControl(() => { accessed = true; return (new object(), new object(), 0UL); }, (_, _) => { });
            using var cancellation = new CancellationTokenSource(); cancellation.Cancel();
            try { backend.SetEnabledAsync("A", true, cancellation.Token).GetAwaiter().GetResult(); Ok(false); }
            catch (OperationCanceledException) { Ok(!accessed); }
        });
    }

    private sealed class Environment
    {
        public List<string> Events { get; } = [];
        public List<Exception> Errors { get; } = [];
        public MockManager Manager { get; } = new();
        public MockProfileManager Profiles { get; } = new();
        public MockProfile Profile { get; }
        private readonly DalamudPluginControl backend;
        public Environment()
        {
            Profile = new(Events); Profiles.Profiles.Add(Profile);
            backend = new DalamudPluginControl(() => (Manager, Profiles, 123UL), (ex, _) => Errors.Add(ex));
        }
        public MockPlugin Add(string id, bool loaded = false)
        {
            var plugin = new MockPlugin(id, Events) { State = loaded ? "Loaded" : "Unloaded" };
            Manager.InstalledPlugins.Add(plugin); Profile.States[plugin.EffectiveWorkingPluginId] = loaded;
            return plugin;
        }
        public ControlResult Run(string id, bool enabled, PluginTarget? target = null) => backend.SetEnabledAsync(id, enabled, CancellationToken.None, target).GetAwaiter().GetResult();
        public IReadOnlyList<PluginInstance> Copies() => backend.SnapshotInstances();
    }
    public sealed class MockManager
    {
        public bool SafeMode { get; set; }
        public List<MockPlugin> InstalledPlugins { get; } = [];
    }
    public sealed class MockProfileManager
    {
        public bool IsBusy { get; set; }
        public List<MockProfile> Profiles { get; } = [];
    }
    public sealed class MockProfile(List<string> events)
    {
        public bool IsEnabled { get; set; } = true;
        public bool CharacterAllowed { get; set; } = true;
        public Dictionary<Guid, bool> States { get; } = [];
        public bool? WantsPlugin(Guid id) => States.TryGetValue(id, out var value) ? value : null;
        public bool CheckWantsActiveFromGameState(ulong id) => CharacterAllowed;
        public Task AddOrUpdateAsync(Guid id, string name, bool state, bool apply)
        { events.Add($"want:{name}:{state}:{apply}"); States[id] = state; return Task.CompletedTask; }
    }
    public sealed class MockManifest { public bool ScheduledForDeletion { get; set; } }
    public enum LoadReason { Installer }
    public enum DisposalMode { WaitBeforeDispose }
    public sealed class MockPlugin(string id, List<string> events)
    {
        public string InternalName => id;
        public Guid EffectiveWorkingPluginId { get; set; } = Guid.NewGuid();
        public string? PathOverride { get; set; }
        public FileInfo DllFile => new(PathOverride ?? Path.Combine(Path.GetTempPath(), "PluginShelfTests", EffectiveWorkingPluginId.ToString(), id + ".dll"));
        public Version EffectiveVersion { get; } = new(1, 0);
        public string Name => id;
        public bool IsDev => true;
        public PluginTarget Target => new(id, EffectiveWorkingPluginId, DllFile.FullName);
        public string State { get; set; } = "Unloaded";
        public bool IsLoaded => State == "Loaded";
        public bool IsOutdated { get; set; }
        public bool IsBanned { get; set; }
        public MockManifest Manifest { get; } = new();
        public bool FailLoad { get; set; }
        public bool FailUnload { get; set; }
        public bool IgnoreState { get; set; }
        public Action? AfterLoad { get; set; }
        public Task LoadAsync(LoadReason reason, bool reload, CancellationToken cancellationToken)
        {
            events.Add("load:" + id);
            if (FailLoad) throw new InvalidOperationException("failed construction");
            if (!IgnoreState) State = "Loaded";
            AfterLoad?.Invoke();
            return Task.CompletedTask;
        }
        public Task UnloadAsync(DisposalMode mode)
        {
            events.Add("unload:" + id);
            if (FailUnload) throw new InvalidOperationException("failed disposal");
            if (!IgnoreState) State = "Unloaded";
            return Task.CompletedTask;
        }
    }
}
