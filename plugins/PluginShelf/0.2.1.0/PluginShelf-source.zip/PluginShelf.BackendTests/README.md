# Backend contract tests

These tests compile the production `DalamudBackend.cs` through a linked source
item and use the real locally installed Dalamud interfaces. `DispatchProxy`
provides isolated fake implementations. Unexpected interface methods throw.

Run from the source root with .NET 10 and an API 15 SDK:

```powershell
$env:DALAMUD_HOME = "$env:APPDATA\XIVLauncherCN\addon\Hooks\dev"
dotnet run --project .\PluginShelf.BackendTests\PluginShelf.BackendTests.csproj -c Release
```

`DALAMUD_HOME` selects both compile references and optional managed dependency
resolution. The default is the same XIVLauncherCN SDK directory shown above.
No NuGet testing framework is required. SDK assemblies remain external build
prerequisites and must not be redistributed as part of the plugin package.

The suite covers snapshots, duplicate selection, re-resolution across reloads,
capability and status checks, command validation and exact registered dispatch,
exceptions, no retry/fallback, and bounded result wording.

This is offline managed contract evidence only. It does not start or connect to
the game, instantiate real target plugins, execute game commands, or verify
native plugin loading, UI appearance, visible windows, or in-game acceptance.
