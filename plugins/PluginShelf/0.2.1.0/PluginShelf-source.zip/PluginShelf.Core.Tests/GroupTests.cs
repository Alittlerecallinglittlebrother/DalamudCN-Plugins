using PluginShelf.Core;

static class GroupTests
{
    public static void Register(Action<string, Action> test, Action<bool, string> check)
    {
        void Ok(bool condition, string message = "group assertion failed") => check(condition, message);
        test("Groups normalize nulls, duplicated ids, members, limits and self protection", () =>
        {
            var id = Guid.NewGuid();
            var config = new ShelfConfig
            {
                Version = 1,
                Groups = [null!, new() { Id = id, Name = " 日常 ", PluginIds = [" A ", "A", "", "PluginShelf", "pluginshelf", null!, "Missing"] },
                    new() { Id = id, Name = null!, PluginIds = null! }, new() { Id = Guid.Empty, Name = new string('x', 100),
                        PluginIds = Enumerable.Range(0, 150).Select(x => "P" + x).ToList() }],
            };
            ShelfOperations.Normalize(config);
            Ok(config.Version == 3 && config.Groups.Count == 3);
            Ok(config.Groups[0].Name == "日常" && config.Groups[0].PluginIds.SequenceEqual(new[] { "A", "Missing" }));
            Ok(config.Groups.Select(x => x.Id).Distinct().Count() == 3 && config.Groups.All(x => x.Id != Guid.Empty));
            Ok(config.Groups[1].Name == "未命名分组" && config.Groups[1].PluginIds.Count == 0);
            Ok(config.Groups[2].Name.Length == 80 && config.Groups[2].PluginIds.Count == 128);
            config.Groups = Enumerable.Range(0, 40).Select(_ => new PluginGroup()).ToList();
            ShelfOperations.Normalize(config); Ok(config.Groups.Count == 32);
            config.Groups = null!; ShelfOperations.Normalize(config); Ok(config.Groups.Count == 0);
        });
        test("V1 favorites migrate with exact identity, and group roundtrip preserves membership order", () =>
        {
            var directory = Path.Combine(Path.GetTempPath(), "PluginShelfTests", Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            var path = Path.Combine(directory, "shelf.json");
            try
            {
                var id = Guid.NewGuid();
                var original = "{\"Version\":1,\"Favorites\":[{\"Id\":\"" + id + "\",\"PluginId\":\"A\",\"Label\":\"旧收藏\",\"Kind\":\"MainUi\"}],\"PinnedCount\":2}";
                File.WriteAllText(path, original);
                var store = new JsonConfigStore(path);
                var loaded = store.Load();
                Ok(loaded.CanSave && loaded.Config.Version == 3 && loaded.Config.Groups.Count == 0);
                Ok(loaded.Config.Favorites.Single().Id == id && loaded.Config.Favorites[0].Label == "旧收藏" && loaded.Config.PinnedCount == 2);
                var group = new PluginGroup { Name = "合奏", PluginIds = ["B", "A", "NotInstalled"] };
                loaded.Config.Groups.Add(group);
                store.Save(loaded.Config);
                Ok(File.ReadAllText(path + ".bak") == original);
                var roundtrip = new JsonConfigStore(path).Load();
                Ok(roundtrip.CanSave && roundtrip.Config.Groups.Single().Id == group.Id);
                Ok(roundtrip.Config.Groups[0].PluginIds.SequenceEqual(group.PluginIds));
                Ok(roundtrip.Config.Favorites[0].Id == id);
            }
            finally { Directory.Delete(directory, true); }
        });
        test("Enable deduplicates and skips already enabled; disable uses reverse order", () =>
        {
            var backend = new GroupBackend();
            backend.States["B"] = true;
            var controller = new GroupControlService(backend);
            var group = new PluginGroup { Name = "日常", PluginIds = ["A", "B", "A", "C"] };
            var enabled = controller.RunAsync(group, true).GetAwaiter().GetResult();
            Ok(backend.Calls.SequenceEqual(new[] { "A:on", "B:on", "C:on" }));
            Ok(enabled.Items.Count(x => x.Outcome == ControlOutcome.Changed) == 2);
            Ok(enabled.Items.Count(x => x.Outcome == ControlOutcome.Unchanged) == 1);
            backend.Calls.Clear();
            var disabled = controller.RunAsync(group, false).GetAwaiter().GetResult();
            Ok(backend.Calls.SequenceEqual(new[] { "C:off", "B:off", "A:off" }));
            Ok(disabled.Items.All(x => x.Outcome == ControlOutcome.Changed));
            Ok(!controller.IsBusy);
        });
        test("One target failure does not hide results or retry, self never reaches backend", () =>
        {
            var backend = new GroupBackend { Failing = "Bad" };
            var result = new GroupControlService(backend).RunAsync(new PluginGroup
                { PluginIds = ["A", "Bad", "PluginShelf", "C"] }, true).GetAwaiter().GetResult();
            Ok(result.Items.Count == 4 && result.Items.Count(x => x.Outcome == ControlOutcome.Failed) == 2);
            Ok(backend.Calls.SequenceEqual(new[] { "A:on", "Bad:on", "C:on" }));
            Ok(result.Summary.Contains("失败 2"));
        });
        test("In-flight operations are serial, group snapshot is stable, repeat start is rejected", () =>
        {
            var pending = new TaskCompletionSource<ControlResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            var backend = new GroupBackend { FirstTask = pending.Task };
            var service = new GroupControlService(backend);
            var group = new PluginGroup { Name = "原组名", PluginIds = ["A", "B"] };
            var task = service.RunAsync(group, true);
            Ok(service.IsBusy && backend.Calls.SequenceEqual(new[] { "A:on" }));
            group.Name = "改名"; group.PluginIds.Clear(); group.PluginIds.Add("Unrelated");
            try { service.RunAsync(group, false).GetAwaiter().GetResult(); Ok(false, "concurrent batch was accepted"); }
            catch (InvalidOperationException) { }
            pending.SetResult(new("A", ControlOutcome.Changed, "ok"));
            var result = task.GetAwaiter().GetResult();
            Ok(result.GroupName == "原组名" && backend.Calls.SequenceEqual(new[] { "A:on", "B:on" }));
            Ok(!service.IsBusy);
        });
        test("Stop lets current operation finish and cancels remaining members without rollback", () =>
        {
            using var cancellation = new CancellationTokenSource();
            var pending = new TaskCompletionSource<ControlResult>(TaskCreationOptions.RunContinuationsAsynchronously);
            var backend = new GroupBackend { FirstTask = pending.Task };
            var service = new GroupControlService(backend);
            var task = service.RunAsync(new PluginGroup { PluginIds = ["A", "B", "C"] }, false, cancellationToken: cancellation.Token);
            cancellation.Cancel();
            Ok(service.IsBusy && !task.IsCompleted);
            pending.SetResult(new("C", ControlOutcome.Changed, "ok"));
            var result = task.GetAwaiter().GetResult();
            Ok(backend.Calls.SequenceEqual(new[] { "C:off" }));
            Ok(result.Items.Count(x => x.Outcome == ControlOutcome.Cancelled) == 2 && !service.IsBusy);
        });
        test("Empty and pre-cancelled groups never dispatch", () =>
        {
            var backend = new GroupBackend();
            var service = new GroupControlService(backend);
            Ok(service.RunAsync(new PluginGroup(), true).GetAwaiter().GetResult().Items.Count == 0);
            using var cancellation = new CancellationTokenSource(); cancellation.Cancel();
            var result = service.RunAsync(new PluginGroup { PluginIds = ["A"] }, true, cancellationToken: cancellation.Token).GetAwaiter().GetResult();
            Ok(backend.Calls.Count == 0 && result.Items.Single().Outcome == ControlOutcome.Cancelled && !service.IsBusy);
        });
        test("Unknown catalog status prevents UI launch but retains shortcut", () =>
        {
            var backend = new FakeBackend { Current = new("A", "A", "1", true, true, true, false, false) };
            var result = new LaunchService(backend).Launch(new Shortcut { PluginId = "A" });
            Ok(!result.Dispatched && backend.Dispatches == 0 && result.Message.Contains("确认"));
        });
    }

    private sealed class GroupBackend : IPluginControlBackend
    {
        public Dictionary<string, bool> States { get; } = [];
        public List<string> Calls { get; } = [];
        public string? Failing { get; init; }
        public Task<ControlResult>? FirstTask { get; init; }
        public Task<ControlResult> SetEnabledAsync(string id, bool enabled, CancellationToken cancellationToken, PluginTarget? preferred = null)
        {
            Calls.Add(id + (enabled ? ":on" : ":off"));
            if (id == Failing) throw new InvalidOperationException("target failed");
            if (Calls.Count == 1 && FirstTask is not null) return FirstTask;
            var wasEnabled = States.GetValueOrDefault(id);
            States[id] = enabled;
            return Task.FromResult(new ControlResult(id, wasEnabled == enabled ? ControlOutcome.Unchanged : ControlOutcome.Changed, "ok"));
        }
    }
}
