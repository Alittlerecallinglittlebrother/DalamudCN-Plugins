using PluginShelf.Core;

static class InstanceTests
{
    public static void Register(Action<string, Action> test, Action<bool, string> check)
    {
        void Ok(bool value, string message = "instance selection assertion failed") => check(value, message);
        PluginInstance Copy(string path, string state = "Unloaded", Guid? guid = null) =>
            new(new("MidiBard2", guid ?? Guid.NewGuid(), path), "MidiBard", "3.2", true, state);
        test("Sole loaded copy wins automatically; two stopped copies require explicit choice", () =>
        {
            var a = Copy(@"D:\old\MidiBard2.dll"); var b = Copy(@"D:\new\MidiBard2.dll", "Loaded");
            Ok(PluginInstanceSelector.Select("MidiBard2", [a, b], null).Instance == b);
            b = b with { State = "Unloaded" };
            var result = PluginInstanceSelector.Select("MidiBard2", [a, b], null);
            Ok(result.Instance is null && result.Error.Contains("选择副本"));
            Ok(PluginInstanceSelector.Select("MidiBard2", [a, b], b.Target).Instance == b);
        });
        test("Saved identity survives stop/reload and never depends on enumeration order", () =>
        {
            var a = Copy(@"D:\a.dll"); var b = Copy(@"D:\b.dll");
            Ok(PluginInstanceSelector.Select("MidiBard2", [a, b], b.Target).Instance == b);
            Ok(PluginInstanceSelector.Select("MidiBard2", [b, a], b.Target).Instance == b);
        });
        test("Same GUID after installed update and same path after dev rescan resolve safely", () =>
        {
            var old = Copy(@"D:\1.0\MidiBard2.dll");
            var updated = old with { Target = old.Target with { DllPath = @"D:\2.0\MidiBard2.dll" } };
            Ok(PluginInstanceSelector.Select("MidiBard2", [updated], old.Target).Instance == updated);
            var rescanned = old with { Target = old.Target with { WorkingPluginId = Guid.NewGuid(), DllPath = "d:/1.0/MidiBard2.dll" } };
            Ok(PluginInstanceSelector.Select("MidiBard2", [rescanned], old.Target).Instance == rescanned);
        });
        test("Missing preference never silently falls back even to a sole other installed copy", () =>
        {
            var a = Copy(@"D:\a.dll"); var missing = Copy(@"D:\missing.dll");
            Ok(PluginInstanceSelector.Select("MidiBard2", [a], missing.Target).Instance is null);
        });
        test("GUID and DLL pointing at different copies is rejected", () =>
        {
            var a = Copy(@"D:\a.dll"); var b = Copy(@"D:\b.dll");
            var conflict = a.Target with { DllPath = b.Target.DllPath };
            Ok(PluginInstanceSelector.Select("MidiBard2", [a, b], conflict).Instance is null);
        });
        test("Shared GUID disambiguates by path; duplicate GUID plus path is rejected", () =>
        {
            var a = Copy(@"D:\a.dll"); var b = Copy(@"D:\b.dll", guid: a.Target.WorkingPluginId);
            Ok(PluginInstanceSelector.Select("MidiBard2", [a, b], b.Target).Instance == b);
            var duplicate = a with { Name = "duplicate record" };
            Ok(PluginInstanceSelector.Select("MidiBard2", [a, duplicate], a.Target).Instance is null);
        });
        test("Cross-plugin preference and unbound empty identity cannot resolve", () =>
        {
            var a = Copy(@"D:\a.dll");
            Ok(PluginInstanceSelector.Select("MidiBard2", [a], a.Target with { PluginId = "Other" }).Instance is null);
            Ok(PluginInstanceSelector.Select("MidiBard2", [a], new("MidiBard2", Guid.Empty, "")).Instance is null);
        });
        test("Preferences normalize safely without losing old groups and favorites", () =>
        {
            var a = Copy(@"D:\a.dll");
            var config = new ShelfConfig { Version = 2, Favorites = [new() { PluginId = "A" }],
                Groups = [new() { PluginIds = ["A", "MidiBard2"] }], PluginTargets =
                [null!, a.Target, a.Target, new("PluginShelf", Guid.NewGuid(), ""), new("B", Guid.Empty, ""), new("C", Guid.Empty, @"D:\c.dll")] };
            ShelfOperations.Normalize(config);
            Ok(config.Version == 3 && config.Favorites.Count == 1 && config.Groups[0].PluginIds.Count == 2);
            Ok(config.PluginTargets.Count == 2 && config.PluginTargets[0] == a.Target);
            Ok(!ShelfOperations.RememberTarget(config, a.Target));
            var updated = a.Target with { DllPath = @"D:\updated.dll" };
            Ok(ShelfOperations.RememberTarget(config, updated) && config.PluginTargets.Count == 2);
            Ok(!ShelfOperations.RememberTarget(config, new("PluginShelf", Guid.NewGuid(), "")));
        });
        test("V2 config migrates to V3; selected DLL and working ID survive JSON reload", () =>
        {
            var directory = Path.Combine(Path.GetTempPath(), "PluginShelfTests", Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            try
            {
                var path = Path.Combine(directory, "shelf.json");
                const string old = "{\"Version\":2,\"Groups\":[{\"Name\":\"合奏\",\"PluginIds\":[\"MidiBard2\"]}],\"Favorites\":[{\"PluginId\":\"A\"}]}";
                File.WriteAllText(path, old);
                var store = new JsonConfigStore(path); var loaded = store.Load();
                Ok(loaded.CanSave && loaded.Config.Version == 3 && loaded.Config.PluginTargets.Count == 0);
                var target = Copy(@"D:\我的开发\MidiBard2.dll").Target;
                ShelfOperations.RememberTarget(loaded.Config, target); store.Save(loaded.Config);
                var again = new JsonConfigStore(path).Load();
                Ok(again.CanSave && again.Config.PluginTargets.Single() == target && again.Config.Groups[0].Name == "合奏");
                Ok(again.Config.Favorites.Count == 1 && File.ReadAllText(path + ".bak") == old);
            }
            finally { Directory.Delete(directory, true); }
        });
        test("Batch snapshots instance preferences before awaiting first operation", () =>
        {
            var a = new PluginTarget("A", Guid.NewGuid(), @"D:\a.dll");
            var b = new PluginTarget("B", Guid.NewGuid(), @"D:\b.dll");
            var targets = new Dictionary<string, PluginTarget> { ["A"] = a, ["B"] = b };
            var backend = new CaptureBackend();
            var task = new GroupControlService(backend).RunAsync(new PluginGroup { PluginIds = ["A", "B"] }, true, preferredTargets: targets);
            targets.Clear();
            backend.Wait.SetResult(new("A", ControlOutcome.Changed, "ok", a));
            var result = task.GetAwaiter().GetResult();
            Ok(backend.Targets.SequenceEqual(new[] { a, b }) && result.Items[0].Target == a);
        });
    }

    private sealed class CaptureBackend : IPluginControlBackend
    {
        public List<PluginTarget?> Targets { get; } = [];
        public TaskCompletionSource<ControlResult> Wait { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public Task<ControlResult> SetEnabledAsync(string id, bool enabled, CancellationToken cancellationToken, PluginTarget? preferred = null)
        {
            Targets.Add(preferred);
            return Targets.Count == 1 ? Wait.Task : Task.FromResult(new ControlResult(id, ControlOutcome.Changed, "ok", preferred));
        }
    }
}
