using PluginShelf.Core;

var tests = new List<(string Name, Action Test)>();
var assertions = 0;
void Check(bool condition, string detail = "Assertion failed")
{
    assertions++;
    if (!condition) throw new InvalidOperationException(detail);
}
void Throws<T>(Action action) where T : Exception
{
    assertions++;
    try { action(); }
    catch (T) { return; }
    throw new InvalidOperationException($"Expected {typeof(T).Name}");
}
void Test(string name, Action action) => tests.Add((name, action));
PluginEntry Entry(string id = "Example", bool loaded = true, bool main = true, bool config = true, bool outdated = false)
    => new(id, "示例插件", "1.2.3", loaded, main, config, outdated);
Shortcut Favorite(LaunchKind kind = LaunchKind.MainUi, string id = "Example", string command = "")
    => new() { PluginId = id, Kind = kind, Command = command };
void WithStore(Action<string, JsonConfigStore> body)
{
    var directory = Path.Combine(Path.GetTempPath(), "PluginShelfTests", Guid.NewGuid().ToString("N"));
    Directory.CreateDirectory(directory);
    var path = Path.Combine(directory, "config.json");
    try { body(path, new JsonConfigStore(path)); }
    finally { Directory.Delete(directory, recursive: true); }
}

Test("Main UI: one dispatch and bounded success wording", () =>
{
    var backend = new FakeBackend { Current = Entry() };
    var result = new LaunchService(backend).Launch(Favorite());
    Check(result.Dispatched);
    Check(result.Message.Contains("已发送打开请求"));
    Check(backend.Calls.SequenceEqual(new[] { "find:Example", "main:Example" }));
});
Test("Config UI: selected action only", () =>
{
    var backend = new FakeBackend { Current = Entry() };
    Check(new LaunchService(backend).Launch(Favorite(LaunchKind.ConfigUi)).Dispatched);
    Check(backend.Calls.SequenceEqual(new[] { "find:Example", "config:Example" }));
});
Test("Missing, unloaded, outdated plugins never dispatch", () =>
{
    foreach (var entry in new PluginEntry?[] { null, Entry(loaded: false), Entry(outdated: true) })
    {
        var backend = new FakeBackend { Current = entry };
        Check(!new LaunchService(backend).Launch(Favorite()).Dispatched);
        Check(backend.Calls.Count == 1);
    }
});
Test("Missing UI capability never falls back", () =>
{
    foreach (var kind in new[] { LaunchKind.MainUi, LaunchKind.ConfigUi })
    {
        var backend = new FakeBackend { Current = Entry(main: kind != LaunchKind.MainUi, config: kind != LaunchKind.ConfigUi) };
        Check(!new LaunchService(backend).Launch(Favorite(kind)).Dispatched);
        Check(backend.Calls.Count == 1);
    }
});
Test("Target exceptions do not trigger a second action", () =>
{
    foreach (var kind in Enum.GetValues<LaunchKind>())
    {
        var backend = new FakeBackend { Current = Entry(), ThrowAction = true };
        Check(!new LaunchService(backend).Launch(Favorite(kind, command: "/example")).Dispatched);
        Check(backend.Dispatches == 1);
    }
});
Test("Lookup exceptions are contained", () =>
{
    var backend = new FakeBackend { ThrowFind = true };
    Check(!new LaunchService(backend).Launch(Favorite()).Dispatched);
    Check(backend.Dispatches == 0);
});
Test("Every click re-resolves plugin after reload", () =>
{
    var backend = new FakeBackend { Current = Entry() };
    var service = new LaunchService(backend);
    Check(service.Launch(Favorite()).Dispatched);
    backend.Current = Entry(loaded: false);
    Check(!service.Launch(Favorite()).Dispatched);
    backend.Current = null;
    Check(!service.Launch(Favorite()).Dispatched);
    backend.Current = Entry();
    Check(service.Launch(Favorite()).Dispatched);
    Check(backend.Calls.Count(x => x.StartsWith("find:")) == 4);
    Check(backend.Dispatches == 2);
});
Test("Null, empty and unknown shortcuts do not dispatch", () =>
{
    var backend = new FakeBackend { Current = Entry() };
    var service = new LaunchService(backend);
    Check(!service.Launch(null!).Dispatched);
    Check(!service.Launch(Favorite(id: "")).Dispatched);
    Check(!service.Launch(Favorite((LaunchKind)99)).Dispatched);
    Check(backend.Dispatches == 0);
});
Test("Commands validate before registration/dispatch", () =>
{
    string?[] invalid = [null, "", "example", " /example", "/", "/ arg", "/foo\n/bar", "/foo\r", "/foo\t", "/foo\0", "/foo\u007f", "/foo\u2028bar", "/foo\u2029bar", "/foo\u00a0bar", "/" + new string('x', 512)];
    foreach (var command in invalid)
    {
        var backend = new FakeBackend { Current = Entry() };
        Check(LaunchService.ValidateCommand(command) is not null, $"Accepted invalid command {command}");
        Check(!new LaunchService(backend).Launch(Favorite(LaunchKind.Command, command: command!)).Dispatched);
        Check(backend.Calls.Count == 1);
    }
});
Test("Valid single-line command including length boundary", () =>
{
    foreach (var command in new[] { "/example", "/example 参数 value", "/" + new string('x', 511) })
    {
        var backend = new FakeBackend { Current = Entry() };
        Check(LaunchService.ValidateCommand(command) is null);
        Check(new LaunchService(backend).Launch(Favorite(LaunchKind.Command, command: command)).Dispatched);
        Check(backend.Calls.SequenceEqual(new[] { "find:Example", "registered:" + command, "command:" + command }));
    }
});
Test("Unregistered and disappearing command never reports success", () =>
{
    var unregistered = new FakeBackend { Current = Entry(), Registered = false };
    Check(!new LaunchService(unregistered).Launch(Favorite(LaunchKind.Command, command: "/example")).Dispatched);
    Check(unregistered.Dispatches == 0);
    var disappeared = new FakeBackend { Current = Entry(), CommandResult = false };
    Check(!new LaunchService(disappeared).Launch(Favorite(LaunchKind.Command, command: "/example")).Dispatched);
    Check(disappeared.Dispatches == 1);
});
Test("Default action prioritizes main, then config; no inferred command", () =>
{
    Check(ShelfOperations.DefaultAction(Entry()) == LaunchKind.MainUi);
    Check(ShelfOperations.DefaultAction(Entry(main: false)) == LaunchKind.ConfigUi);
    Check(ShelfOperations.DefaultAction(Entry(main: false, config: false)) is null);
});
Test("Add uses plugin id plus action uniqueness", () =>
{
    var config = new ShelfConfig();
    Check(ShelfOperations.TryAdd(config, Entry(), LaunchKind.MainUi));
    Check(!ShelfOperations.TryAdd(config, Entry(), LaunchKind.MainUi));
    Check(ShelfOperations.TryAdd(config, Entry(), LaunchKind.ConfigUi));
    Check(!ShelfOperations.TryAdd(config, Entry(), (LaunchKind)99));
    Check(config.Favorites.Count == 2);
    Check(config.Favorites.Select(x => x.Id).Distinct().Count() == 2);
});
Test("Move in both directions to target original position", () =>
{
    var items = new[] { Favorite(id: "A"), Favorite(id: "B"), Favorite(id: "C"), Favorite(id: "D") };
    var config = new ShelfConfig { Favorites = items.ToList() };
    Check(ShelfOperations.Move(config, items[0].Id, items[2].Id));
    Check(config.Favorites.Select(x => x.PluginId).SequenceEqual(new[] { "B", "C", "A", "D" }));
    Check(ShelfOperations.Move(config, items[3].Id, items[1].Id));
    Check(config.Favorites.Select(x => x.PluginId).SequenceEqual(new[] { "D", "B", "C", "A" }));
    Check(!ShelfOperations.Move(config, items[0].Id, items[0].Id));
    Check(!ShelfOperations.Move(config, Guid.NewGuid(), items[1].Id));
});
Test("Search checks names, internal ids and aliases ignoring case", () =>
{
    var plugin = Entry();
    Check(ShelfOperations.Matches(plugin, "示例"));
    Check(ShelfOperations.Matches(plugin, " EXAMPLE "));
    Check(ShelfOperations.Matches(plugin, "MY", "my alias"));
    Check(ShelfOperations.Matches(plugin, "  "));
    Check(!ShelfOperations.Matches(plugin, "missing"));
});
Test("Label precedence survives an uninstalled plugin", () =>
{
    var shortcut = Favorite();
    Check(ShelfOperations.LabelFor(shortcut, Entry()) == "示例插件");
    Check(ShelfOperations.LabelFor(shortcut, null) == "Example");
    shortcut.Label = "我的名称";
    Check(ShelfOperations.LabelFor(shortcut, Entry()) == "我的名称");
});
Test("Normalize nulls, invalid entries, duplicate GUIDs and action keys", () =>
{
    var shared = Guid.NewGuid();
    var config = new ShelfConfig
    {
        Favorites = [null!, new(), Favorite((LaunchKind)99),
            new() { Id = shared, PluginId = " A ", Label = null!, Command = null! },
            new() { Id = shared, PluginId = "B", Label = " Alias " },
            new() { Id = Guid.Empty, PluginId = "C" }, Favorite(id: "A")],
    };
    ShelfOperations.Normalize(config);
    Check(config.Favorites.Count == 3);
    Check(config.Favorites.Select(x => x.Id).Distinct().Count() == 3);
    Check(config.Favorites.All(x => x.Id != Guid.Empty));
    Check(config.Favorites[0].PluginId == "A" && config.Favorites[0].Label == "" && config.Favorites[0].Command == "");
    Check(config.Favorites[1].Label == "Alias");
    config.Favorites = null!;
    ShelfOperations.Normalize(config);
    Check(config.Favorites.Count == 0);
});
Test("Normalize numeric boundaries, list limits, labels and command preservation", () =>
{
    var config = new ShelfConfig { Version = 0, Scale = float.NaN, DockX = float.PositiveInfinity, DockY = float.NaN, DockItemsPerLine = -1, PinnedCount = -9 };
    ShelfOperations.Normalize(config);
    Check(config.Version == 3 && config.Scale == 1 && config.DockX == 80 && config.DockY == 160 && config.DockItemsPerLine == 1 && config.PinnedCount == 0);
    config.Scale = 100; config.DockX = -100000; config.DockY = 100000; config.DockItemsPerLine = 100; config.PinnedCount = 999;
    config.Favorites = Enumerable.Range(0, 300).Select(x => Favorite(id: "P" + x)).ToList();
    config.Favorites[0].Label = new string('x', 300);
    config.Favorites[0].Command = "/x\n";
    ShelfOperations.Normalize(config);
    Check(config.Scale == 2 && config.DockX == -32768 && config.DockY == 32768 && config.DockItemsPerLine == 20 && config.PinnedCount == 6);
    Check(config.Favorites.Count == 256 && config.Favorites[0].Label.Length == 128);
    Check(config.Favorites[0].Command == "/x\n");
    Check(!ShelfOperations.TryAdd(config, Entry(), LaunchKind.MainUi));
    Throws<InvalidOperationException>(() => ShelfOperations.Normalize(new ShelfConfig { Version = 4 }));
});
Test("New config load and JSON full roundtrip", () => WithStore((path, store) =>
{
    var loaded = store.Load();
    Check(loaded.CanSave && loaded.Config.Favorites.Count == 0 && !File.Exists(path));
    var config = new ShelfConfig { Favorites = [Favorite(LaunchKind.Command, command: "/example 中文")], Vertical = true, Compact = true,
        HideInCombat = true, DockLocked = false, ShowDock = false, HasCompletedSetup = true, Scale = 1.25f, DockX = 400, DockY = 500, DockItemsPerLine = 4, PinnedCount = 2 };
    config.Favorites[0].Label = "我的示例";
    store.Save(config);
    var restored = new JsonConfigStore(path).Load();
    Check(restored.CanSave);
    Check(restored.Config.Favorites.Single().Id == config.Favorites[0].Id);
    Check(restored.Config.Favorites[0].Kind == LaunchKind.Command && restored.Config.Favorites[0].Command == "/example 中文" && restored.Config.Favorites[0].Label == "我的示例");
    Check(restored.Config.Vertical && restored.Config.Compact && restored.Config.HideInCombat && !restored.Config.DockLocked && !restored.Config.ShowDock && restored.Config.HasCompletedSetup);
    Check(restored.Config.Scale == 1.25f && restored.Config.DockX == 400 && restored.Config.DockY == 500 && restored.Config.DockItemsPerLine == 4 && restored.Config.PinnedCount == 2);
}));
Test("Atomic replacement keeps exact previous file as backup and cleans temp", () => WithStore((path, store) =>
{
    store.Save(new ShelfConfig());
    var previous = File.ReadAllBytes(path);
    store.Save(new ShelfConfig { Vertical = true });
    Check(File.ReadAllBytes(path + ".bak").SequenceEqual(previous));
    Check(new JsonConfigStore(path).Load().Config.Vertical);
    Check(!Directory.EnumerateFiles(Path.GetDirectoryName(path)!, "*.tmp").Any());
    previous = File.ReadAllBytes(path);
    store.Save(new ShelfConfig { Compact = true });
    Check(File.ReadAllBytes(path + ".bak").SequenceEqual(previous));
}));
Test("Distinct commands for one plugin survive normalize save and reload", () => WithStore((path, store) =>
{
    var config = new ShelfConfig { Favorites = [Favorite(LaunchKind.Command, command: "/foo a"),
        Favorite(LaunchKind.Command, command: "/foo b"), Favorite(LaunchKind.Command, command: "/foo a")] };
    ShelfOperations.Normalize(config);
    Check(config.Favorites.Count == 2);
    store.Save(config);
    var loaded = new JsonConfigStore(path).Load();
    Check(loaded.CanSave && loaded.Config.Favorites.Count == 2);
    Check(loaded.Config.Favorites.Select(x => x.Command).SequenceEqual(new[] { "/foo a", "/foo b" }));
    Check(loaded.Config.Favorites.Select(x => x.Id).Distinct().Count() == 2);
}));
Test("Null command normalizes before identity comparison", () =>
{
    var config = new ShelfConfig { Favorites = [Favorite(LaunchKind.Command, command: null!), Favorite(LaunchKind.Command, command: "")] };
    ShelfOperations.Normalize(config);
    Check(config.Favorites.Count == 1 && config.Favorites[0].Command == "");
});
Test("Corrupt JSON, non-object and bad version are preserved read-only", () =>
{
    foreach (var contents in new[] { "{bad", "null", "[]", "\"text\"", "{\"Version\":\"bad\"}", "{\"Favorites\":\"invalid\"}" })
        WithStore((path, store) =>
        {
            File.WriteAllText(path, contents);
            var result = store.Load();
            Check(!result.CanSave);
            Throws<InvalidOperationException>(() => store.Save(result.Config));
            Check(File.ReadAllText(path) == contents);
            Check(!File.Exists(path + ".bak"));
        });
});
Test("Future version is rejected before unknown enum parsing", () => WithStore((path, store) =>
{
    const string original = "{\"version\":999,\"Favorites\":[{\"Kind\":\"FutureAction\"}]}";
    File.WriteAllText(path, original);
    var result = store.Load();
    Check(!result.CanSave && result.Message.Contains("更新版本"));
    Throws<InvalidOperationException>(() => store.Save(new ShelfConfig()));
    Check(File.ReadAllText(path) == original);
}));
Test("Save without Load cannot overwrite a protected config", () => WithStore((path, store) =>
{
    File.WriteAllText(path, "{\"Version\":999}");
    Throws<InvalidOperationException>(() => store.Save(new ShelfConfig()));
    Check(File.ReadAllText(path) == "{\"Version\":999}");
}));
Test("Null favorites and legacy defaults normalize during load", () => WithStore((path, store) =>
{
    File.WriteAllText(path, "{\"Version\":0,\"Favorites\":null,\"Scale\":50,\"DockItemsPerLine\":0}");
    var result = store.Load();
    Check(result.CanSave && result.Config.Version == 3 && result.Config.Favorites.Count == 0);
    Check(result.Config.Scale == 2 && result.Config.DockItemsPerLine == 1 && result.Config.PinnedCount == 3);
}));
Test("External modification or deletion blocks stale save", () => WithStore((path, store) =>
{
    store.Save(new ShelfConfig());
    File.WriteAllText(path, "{\"Version\":999}");
    Throws<IOException>(() => store.Save(new ShelfConfig()));
    Check(File.ReadAllText(path) == "{\"Version\":999}");
    File.Delete(path);
    Throws<IOException>(() => store.Save(new ShelfConfig()));
    Check(!File.Exists(path));
}));
Test("Config appearing after missing-file load is not overwritten", () => WithStore((path, store) =>
{
    store.Load();
    File.WriteAllText(path, "unrelated");
    Throws<IOException>(() => store.Save(new ShelfConfig()));
    Check(File.ReadAllText(path) == "unrelated");
}));
Test("Failed atomic replace preserves original and removes temp", () => WithStore((path, store) =>
{
    store.Save(new ShelfConfig());
    var original = File.ReadAllBytes(path);
    Directory.CreateDirectory(path + ".bak");
    Throws<IOException>(() => store.Save(new ShelfConfig { Vertical = true }));
    Check(File.ReadAllBytes(path).SequenceEqual(original));
    Check(!Directory.EnumerateFiles(Path.GetDirectoryName(path)!, "*.tmp").Any());
}));
Test("UTF-8 BOM accepted without losing original backup", () => WithStore((path, store) =>
{
    File.WriteAllText(path, "{\"Version\":1}", new System.Text.UTF8Encoding(true));
    var original = File.ReadAllBytes(path);
    Check(store.Load().CanSave);
    store.Save(new ShelfConfig());
    Check(File.ReadAllBytes(path + ".bak").SequenceEqual(original));
}));

GroupTests.Register(Test, Check);
InstanceTests.Register(Test, Check);

var failures = new List<string>();
foreach (var (name, run) in tests)
{
    try { run(); Console.WriteLine($"PASS {name}"); }
    catch (Exception ex) { failures.Add(name); Console.Error.WriteLine($"FAIL {name}: {ex}"); }
}
Console.WriteLine($"RESULT: {tests.Count - failures.Count}/{tests.Count} cases passed; {assertions} assertions; {failures.Count} failures.");
return failures.Count == 0 ? 0 : 1;

sealed class FakeBackend : IPluginBackend
{
    public PluginEntry? Current { get; set; }
    public bool Registered { get; set; } = true;
    public bool CommandResult { get; set; } = true;
    public bool ThrowAction { get; set; }
    public bool ThrowFind { get; set; }
    public int Dispatches { get; private set; }
    public List<string> Calls { get; } = [];
    public IReadOnlyList<PluginEntry> Snapshot() => Current is null ? [] : [Current];
    public PluginEntry? Find(string id)
    {
        Calls.Add("find:" + id);
        if (ThrowFind) throw new InvalidOperationException("lookup unavailable");
        return Current;
    }
    public void OpenMainUi(string id) => Dispatch("main:" + id);
    public void OpenConfigUi(string id) => Dispatch("config:" + id);
    public bool IsCommandRegistered(string fullCommand) { Calls.Add("registered:" + fullCommand); return Registered; }
    public bool ProcessCommand(string fullCommand) { Dispatch("command:" + fullCommand); return CommandResult; }
    private void Dispatch(string action)
    {
        Calls.Add(action); Dispatches++;
        if (ThrowAction) throw new InvalidOperationException("target unavailable");
    }
}
