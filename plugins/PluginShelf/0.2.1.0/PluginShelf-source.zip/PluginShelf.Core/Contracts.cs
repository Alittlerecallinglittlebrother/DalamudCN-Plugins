namespace PluginShelf.Core;

public enum LaunchKind { MainUi, ConfigUi, Command }

public sealed record PluginEntry(string InternalName, string Name, string Version,
    bool IsLoaded, bool HasMainUi, bool HasConfigUi, bool IsOutdated,
    bool StateKnown = true, string ReadError = "");

public sealed class Shortcut
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string PluginId { get; set; } = "";
    public string Label { get; set; } = "";
    public LaunchKind Kind { get; set; }
    public string Command { get; set; } = "";
}

public sealed class ShelfConfig
{
    public int Version { get; set; } = ShelfOperations.CurrentConfigVersion;
    public List<Shortcut> Favorites { get; set; } = [];
    public List<PluginGroup> Groups { get; set; } = [];
    public List<PluginTarget> PluginTargets { get; set; } = [];
    public bool ShowDock { get; set; } = true;
    public bool DockLocked { get; set; } = true;
    public bool Vertical { get; set; }
    public bool Compact { get; set; }
    public bool HideInCombat { get; set; }
    public bool HasCompletedSetup { get; set; }
    public float Scale { get; set; } = 1;
    public float DockX { get; set; } = 80;
    public float DockY { get; set; } = 160;
    public int DockItemsPerLine { get; set; } = 8; // Retained for compatibility with existing v1 configs.
    public int PinnedCount { get; set; } = 3;
}

public interface IPluginBackend
{
    IReadOnlyList<PluginEntry> Snapshot();
    PluginEntry? Find(string id);
    void OpenMainUi(string id);
    void OpenConfigUi(string id);
    bool IsCommandRegistered(string fullCommand);
    bool ProcessCommand(string fullCommand);
}

public sealed class PluginGroup
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "新分组";
    // Internal names, not window shortcuts. A plugin occurs at most once in a group.
    public List<string> PluginIds { get; set; } = [];
}

public interface IPluginControlBackend
{
    Task<ControlResult> SetEnabledAsync(string id, bool enabled, CancellationToken cancellationToken,
        PluginTarget? preferred = null);
}

public enum ControlOutcome { Changed, Unchanged, Failed, Cancelled }
public sealed record PluginTarget(string PluginId, Guid WorkingPluginId, string DllPath);
public sealed record PluginInstance(PluginTarget Target, string Name, string Version, bool IsDev, string State, bool IsOutdated = false)
{
    public bool IsLoaded => State == "Loaded";
    public bool IsStable => State is "Loaded" or "Unloaded";
}
public sealed record InstanceSelection(PluginInstance? Instance, string Error);
public sealed record ControlResult(string PluginId, ControlOutcome Outcome, string Message, PluginTarget? Target = null);
public sealed record GroupRunResult(string GroupName, bool Enabled, IReadOnlyList<ControlResult> Items)
{
    public string Summary => $"{GroupName} · {(Enabled ? "启用" : "停用")}完成：成功 {Items.Count(x => x.Outcome == ControlOutcome.Changed)}，" +
        $"原已满足 {Items.Count(x => x.Outcome == ControlOutcome.Unchanged)}，失败 {Items.Count(x => x.Outcome == ControlOutcome.Failed)}，" +
        $"未执行 {Items.Count(x => x.Outcome == ControlOutcome.Cancelled)}";
}

public sealed record LaunchResult(bool Dispatched, string Message);
public sealed record ConfigLoadResult(ShelfConfig Config, bool CanSave, string Message);
