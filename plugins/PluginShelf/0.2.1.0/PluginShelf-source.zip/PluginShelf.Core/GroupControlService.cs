namespace PluginShelf.Core;

/// <summary>Serial, explicit desired-state operations; never toggles, retries or touches non-members.</summary>
public sealed class GroupControlService(IPluginControlBackend backend)
{
    private int busy;
    public bool IsBusy => Volatile.Read(ref busy) != 0;

    public async Task<GroupRunResult> RunAsync(PluginGroup group, bool enabled,
        Action<string>? progress = null, CancellationToken cancellationToken = default,
        IReadOnlyDictionary<string, PluginTarget>? preferredTargets = null)
    {
        if (Interlocked.CompareExchange(ref busy, 1, 0) != 0)
            throw new InvalidOperationException("已有分组操作正在执行。");
        try
        {
            // Snapshot before the first await: editing/deleting a group cannot change a running batch.
            var name = group.Name;
            var targets = preferredTargets?.ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal);
            var ids = (group.PluginIds ?? []).Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim()).Distinct(StringComparer.Ordinal).Take(ShelfOperations.MaximumGroupMembers).ToArray();
            // Stop in reverse order, useful for dependency/service-first groups.
            if (!enabled) Array.Reverse(ids);
            var results = new List<ControlResult>();
            foreach (var id in ids)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    results.Add(new(id, ControlOutcome.Cancelled, "已停止，未执行此项。"));
                    continue;
                }
                if (!ShelfOperations.IsControllableId(id))
                {
                    results.Add(new(id, ControlOutcome.Failed, "禁止操作收纳盒自身或无效插件标识。"));
                    continue;
                }
                progress?.Invoke($"{name} · {(enabled ? "启用" : "停用")} {results.Count + 1}/{ids.Length} · {id}");
                try
                {
                    results.Add(await backend.SetEnabledAsync(id, enabled, cancellationToken, targets?.GetValueOrDefault(id)).ConfigureAwait(false));
                }
                catch (OperationCanceledException)
                {
                    results.Add(new(id, ControlOutcome.Cancelled, "操作已取消；请刷新查看实际状态。"));
                }
                catch (Exception)
                {
                    results.Add(new(id, ControlOutcome.Failed, "操作发生异常；没有重试，请查看日志。"));
                }
            }
            return new(name, enabled, results.AsReadOnly());
        }
        finally { Interlocked.Exchange(ref busy, 0); }
    }
}
