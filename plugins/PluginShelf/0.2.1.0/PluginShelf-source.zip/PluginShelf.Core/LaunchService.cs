namespace PluginShelf.Core;

/// <summary>Dispatches one explicit action only. A dispatch is not visual confirmation.</summary>
public sealed class LaunchService(IPluginBackend backend)
{
    public LaunchResult Launch(Shortcut shortcut)
    {
        if (shortcut is null || string.IsNullOrWhiteSpace(shortcut.PluginId))
            return new(false, "快捷方式缺少插件标识。");

        try
        {
            // Resolve on every click: never keep a live plugin instance across reloads.
            var target = backend.Find(shortcut.PluginId);
            if (target is null)
                return new(false, "目标插件未安装，收藏已保留。");
            if (!target.StateKnown)
                return new(false, "目标插件状态暂时无法确认，请等待目录刷新后重试。");
            if (target.IsOutdated)
                return new(false, "目标插件已过期，请先更新后再试。");
            if (!target.IsLoaded)
                return new(false, "目标插件未加载，请先在插件安装器中启用。");

            switch (shortcut.Kind)
            {
                case LaunchKind.MainUi:
                    if (!target.HasMainUi)
                        return new(false, "目标插件没有标准主界面入口，请修改此收藏的动作。");
                    backend.OpenMainUi(target.InternalName);
                    break;
                case LaunchKind.ConfigUi:
                    if (!target.HasConfigUi)
                        return new(false, "目标插件没有标准设置入口，请修改此收藏的动作。");
                    backend.OpenConfigUi(target.InternalName);
                    break;
                case LaunchKind.Command:
                    var error = ValidateCommand(shortcut.Command);
                    if (error is not null)
                        return new(false, error);
                    if (!backend.IsCommandRegistered(shortcut.Command))
                        return new(false, "该指令当前未注册，请检查指令或插件状态。");
                    if (!backend.ProcessCommand(shortcut.Command))
                        return new(false, "指令未派发：注册状态可能已经改变。");
                    break;
                default:
                    return new(false, "未知的快捷方式动作，请重新添加。");
            }

            return new(true, "已发送打开请求；是否显示窗口由目标插件决定。");
        }
        catch (Exception)
        {
            // The invoked action may have partially run before throwing. Never retry/fallback.
            return new(false, "目标插件调用发生异常，已停止；没有重试或执行其他动作。");
        }
    }

    public static string? ValidateCommand(string? command)
    {
        if (string.IsNullOrWhiteSpace(command) || !command.StartsWith('/'))
            return "指令必须以 / 开头。";
        if (command.Length > 512)
            return "指令不能超过 512 个字符。";
        if (command.Any(c => char.IsControl(c) || c is '\u2028' or '\u2029'))
            return "指令必须为单行，不能包含控制字符。";
        var end = command.IndexOf(' ');
        var verb = end >= 0 ? command[..end] : command;
        if (verb.Length < 2 || verb.Skip(1).Any(char.IsWhiteSpace))
            return "请填写完整指令，例如 /example。";
        return null;
    }
}
