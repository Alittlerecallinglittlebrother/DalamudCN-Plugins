namespace PluginShelf.Core;

/// <summary>Resolve an explicit stable identity, never "newest version" or first enumeration item.</summary>
public static class PluginInstanceSelector
{
    public static InstanceSelection Select(string id, IReadOnlyList<PluginInstance> instances, PluginTarget? preferred)
    {
        var copies = instances.Where(x => x.Target.PluginId == id).ToArray();
        if (copies.Length == 0) return new(null, "插件未安装；记录已保留。");
        if (preferred is not null)
        {
            if (preferred.PluginId != id) return new(null, "副本标识不匹配，请重新选择副本。");
            var byId = preferred.WorkingPluginId == Guid.Empty ? [] :
                copies.Where(x => x.Target.WorkingPluginId == preferred.WorkingPluginId).ToArray();
            var byPath = string.IsNullOrWhiteSpace(preferred.DllPath) ? [] :
                copies.Where(x => SamePath(x.Target.DllPath, preferred.DllPath)).ToArray();
            var exact = byId.Intersect(byPath, ReferenceEqualityComparer.Instance).Cast<PluginInstance>().ToArray();
            if (exact.Length == 1) return new(exact[0], "");
            if (exact.Length > 1) return new(null, "同一路径和编号被重复注册，请先在卫月清理重复加载位置。");
            if (byId.Length == 1 && byPath.Length == 0) return new(byId[0], ""); // same install after update
            if (byId.Length == 0 && byPath.Length == 1) return new(byPath[0], ""); // dev rescan, same DLL
            return new(null, "记住的副本已失效或标识冲突，请点“选择副本”重新指定；未改用其它副本。");
        }
        var loaded = copies.Where(x => x.IsLoaded).ToArray();
        if (loaded.Length == 1) return new(loaded[0], "");
        if (copies.Length == 1) return new(copies[0], "");
        return new(null, $"有 {copies.Length} 个同名副本，请点该插件旁的“选择副本”指定要控制的一份。");
    }

    public static bool SamePath(string a, string b) =>
        !string.IsNullOrWhiteSpace(a) && !string.IsNullOrWhiteSpace(b) &&
        string.Equals(a.Replace('/', '\\'), b.Replace('/', '\\'), StringComparison.OrdinalIgnoreCase);
}
