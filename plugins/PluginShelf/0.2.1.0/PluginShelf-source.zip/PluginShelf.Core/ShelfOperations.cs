namespace PluginShelf.Core;

public static class ShelfOperations
{
    public const int CurrentConfigVersion = 3;
    public const int MaximumFavorites = 256;
    public const int MaximumGroups = 32;
    public const int MaximumGroupMembers = 128;

    public static LaunchKind? DefaultAction(PluginEntry plugin) =>
        plugin.HasMainUi ? LaunchKind.MainUi : plugin.HasConfigUi ? LaunchKind.ConfigUi : null;

    public static void Normalize(ShelfConfig config)
    {
        ArgumentNullException.ThrowIfNull(config);
        // Future schemas must be rejected by the store, not silently downgraded here.
        if (config.Version > CurrentConfigVersion)
            throw new InvalidOperationException("不能规范化高版本配置。");
        config.Version = CurrentConfigVersion;
        config.Scale = float.IsFinite(config.Scale) ? Math.Clamp(config.Scale, .6f, 2f) : 1f;
        config.DockX = float.IsFinite(config.DockX) ? Math.Clamp(config.DockX, -32768, 32768) : 80;
        config.DockY = float.IsFinite(config.DockY) ? Math.Clamp(config.DockY, -32768, 32768) : 160;
        config.DockItemsPerLine = Math.Clamp(config.DockItemsPerLine, 1, 20);
        config.PinnedCount = Math.Clamp(config.PinnedCount, 0, 6);

        var clean = new List<Shortcut>();
        var ids = new HashSet<Guid>();
        var keys = new HashSet<(string, LaunchKind, string)>();
        foreach (var item in config.Favorites ?? [])
        {
            if (item is null || string.IsNullOrWhiteSpace(item.PluginId) ||
                item.PluginId.Length > 256 || !Enum.IsDefined(item.Kind))
                continue;
            item.PluginId = item.PluginId.Trim();
            // A plugin can expose several deliberate command shortcuts with different arguments.
            // Keep exact command text: whitespace and arguments can change the requested action.
            item.Command ??= "";
            if (!keys.Add((item.PluginId, item.Kind, item.Kind == LaunchKind.Command ? item.Command : "")))
                continue;
            if (item.Id == Guid.Empty || !ids.Add(item.Id))
            {
                do { item.Id = Guid.NewGuid(); } while (!ids.Add(item.Id));
            }
            item.Label = (item.Label ?? "").Trim();
            if (item.Label.Length > 128)
                item.Label = item.Label[..128];
            // Do not trim away a newline or silently rewrite commands to executable ones.
            clean.Add(item);
            if (clean.Count == MaximumFavorites)
                break;
        }
        config.Favorites = clean;

        var groups = new List<PluginGroup>();
        var groupIds = new HashSet<Guid>();
        foreach (var group in config.Groups ?? [])
        {
            if (group is null) continue;
            if (group.Id == Guid.Empty || !groupIds.Add(group.Id))
            {
                do { group.Id = Guid.NewGuid(); } while (!groupIds.Add(group.Id));
            }
            group.Name = (group.Name ?? "").Trim();
            if (group.Name.Length == 0) group.Name = "未命名分组";
            if (group.Name.Length > 80) group.Name = group.Name[..80];
            group.PluginIds = (group.PluginIds ?? []).Where(IsControllableId)
                .Select(x => x.Trim()).Distinct(StringComparer.Ordinal).Take(MaximumGroupMembers).ToList();
            groups.Add(group);
            if (groups.Count == MaximumGroups) break;
        }
        config.Groups = groups;
        config.PluginTargets = (config.PluginTargets ?? [])
            .Where(t => t is not null && IsControllableId(t.PluginId) && t.DllPath is not null &&
                t.DllPath.Length <= 4096 && (t.WorkingPluginId != Guid.Empty || !string.IsNullOrWhiteSpace(t.DllPath)))
            .Select(t => t with { PluginId = t.PluginId.Trim() })
            .DistinctBy(t => t.PluginId, StringComparer.Ordinal).Take(1024).ToList();
    }

    public static bool RememberTarget(ShelfConfig config, PluginTarget target)
    {
        if (!IsControllableId(target.PluginId)) return false;
        var index = config.PluginTargets.FindIndex(t => t.PluginId == target.PluginId);
        if (index >= 0 && config.PluginTargets[index] == target) return false;
        if (index >= 0) config.PluginTargets[index] = target;
        else config.PluginTargets.Add(target);
        return true;
    }

    public static bool IsControllableId(string? id) =>
        !string.IsNullOrWhiteSpace(id) && id.Length <= 256 &&
        !string.Equals(id.Trim(), "PluginShelf", StringComparison.OrdinalIgnoreCase);

    public static bool TryAdd(ShelfConfig config, PluginEntry plugin, LaunchKind kind)
    {
        ArgumentNullException.ThrowIfNull(config);
        ArgumentNullException.ThrowIfNull(plugin);
        if (string.IsNullOrWhiteSpace(plugin.InternalName) || !Enum.IsDefined(kind))
            return false;
        config.Favorites ??= [];
        if (config.Favorites.Count >= MaximumFavorites ||
            config.Favorites.Any(x => x is not null && x.PluginId == plugin.InternalName && x.Kind == kind))
            return false;
        config.Favorites.Add(new Shortcut { PluginId = plugin.InternalName, Kind = kind });
        return true;
    }

    /// <summary>Moves the source to the target's original list index.</summary>
    public static bool Move(ShelfConfig config, Guid source, Guid target)
    {
        ArgumentNullException.ThrowIfNull(config);
        if (source == target || config.Favorites is null)
            return false;
        var from = config.Favorites.FindIndex(x => x is not null && x.Id == source);
        var to = config.Favorites.FindIndex(x => x is not null && x.Id == target);
        if (from < 0 || to < 0)
            return false;
        var item = config.Favorites[from];
        config.Favorites.RemoveAt(from);
        config.Favorites.Insert(to, item);
        return true;
    }

    public static bool Matches(PluginEntry plugin, string query, string? alias = null)
    {
        if (string.IsNullOrWhiteSpace(query))
            return true;
        query = query.Trim();
        return (plugin.Name?.Contains(query, StringComparison.OrdinalIgnoreCase) ?? false) ||
               (plugin.InternalName?.Contains(query, StringComparison.OrdinalIgnoreCase) ?? false) ||
               (alias?.Contains(query, StringComparison.OrdinalIgnoreCase) ?? false);
    }

    public static string LabelFor(Shortcut shortcut, PluginEntry? plugin) =>
        !string.IsNullOrWhiteSpace(shortcut.Label) ? shortcut.Label :
        !string.IsNullOrWhiteSpace(plugin?.Name) ? plugin.Name : shortcut.PluginId;
}
