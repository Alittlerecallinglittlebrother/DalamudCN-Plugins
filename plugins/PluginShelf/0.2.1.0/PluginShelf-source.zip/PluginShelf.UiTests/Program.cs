using System.Numerics;
using System.Text.Json;
using Dalamud.Bindings.ImGui;
using PluginShelf;
using PluginShelf.Core;

var output = Path.GetFullPath(args.ElementAtOrDefault(0) ?? Path.Combine(AppContext.BaseDirectory, "validation", "ui"));
Directory.CreateDirectory(output);
var log = new List<string>();
var failures = 0;
void Check(bool passed, string message)
{
    var line = $"{(passed ? "PASS" : "FAIL")} {message}";
    Console.WriteLine(line); log.Add(line); if (!passed) failures++;
}
void Test(string name, Action action)
{
    try { action(); }
    catch (Exception ex) { Check(false, $"{name}: {ex}"); }
}

Test("empty shelf and catalog", () =>
{
    using var h = new UiHarness(output);
    h.Render("01-empty-1280x800.png");
    Check(h.Items.ContainsKey("dock:add"), "empty favorites retain an add entry in the dock");
    h.Click("tab:catalog");
    h.Render("02-catalog-1280x800.png");
    Check(h.Items.ContainsKey("add:MidiBard2:MainUi"), "catalog exposes supported MainUi add action");
    h.Click("add:MidiBard2:MainUi");
    Check(h.Config.Favorites.Count(x => x.PluginId == "MidiBard2" && x.Kind == LaunchKind.MainUi) == 1, "native catalog click adds one main-window favorite");
    Check(h.Launches.Count == 0, "adding a favorite never launches a plugin");
    Check(h.SaveCount > 0, "native addition invokes persistence callback");
    if (h.Items.ContainsKey("add:MidiBard2:MainUi")) h.Click("add:MidiBard2:MainUi");
    Check(h.Config.Favorites.Count(x => x.PluginId == "MidiBard2" && x.Kind == LaunchKind.MainUi) == 1, "repeating the same add action does not duplicate a favorite");
    h.Click("tab:catalog");
    h.EnterText("shelf:search", "演奏");
    Check(h.Items.ContainsKey("add:MidiBard2:MainUi") && !h.Items.ContainsKey("add:SimpleTweaksPlugin:ConfigUi"), "native search filters the catalog by Chinese display name");
    h.Render("03-search-1280x800.png");
    h.EnterText("shelf:search", "");
    h.Click("tab:favorites");
    h.Render("04-favorites-1280x800.png");
});

Test("one-click dock dispatch and disabled entries", () =>
{
    var config = UiHarness.FilledConfig();
    using var h = new UiHarness(output, config);
    h.View.IsOpen = false;
    h.Render("05-dock-1280x800.png");
    Check(h.Items["window:dock"].Max.X - h.Items["window:dock"].Min.X < 400 &&
        h.Items["window:dock"].Max.Y - h.Items["window:dock"].Min.Y < 60,
        "collapsed dock uses a small single-row footprint even with legacy full-size config");
    var first = config.Favorites[0];
    h.Click("dock:" + first.Id);
    Check(h.Launches.Count == 1 && h.Launches[0].Id == first.Id, "one native dock click dispatches the selected shortcut exactly once");
    for (var i = 0; i < 8; i++) h.Frame();
    Check(h.Launches.Count == 1, "subsequent frames do not repeat dispatch");
    h.Click("dock:add");
    Check(h.Items.ContainsKey("window:tray") && !h.View.IsOpen, "overflow opens the flyout instead of a large manager");
    h.Render("06-compact-tray-1280x800.png");
    var unavailable = config.Favorites.Single(x => x.PluginId == "UnavailablePlugin");
    h.Click("tray:" + unavailable.Id);
    Check(h.Launches.Count == 1, "disabled unloaded favorite does not dispatch");
    var removed = config.Favorites.Single(x => x.PluginId == "RemovedPlugin");
    h.Click("tray:" + removed.Id);
    Check(h.Launches.Count == 1, "disabled missing favorite does not dispatch");
    h.EnterText("tray:search", "已移除");
    Check(h.Items.ContainsKey("tray:" + removed.Id) && !h.Items.ContainsKey("tray:" + first.Id),
        "flyout search filters favorites without opening the manager");
    h.EnterText("tray:search", "");
    h.Click("tray:manage");
    Check(h.View.IsOpen, "flyout management opens the full catalog only on request");
    h.Render("06-unavailable-favorites-1280x800.png");
});

Test("shelf button closes flyout with ordinary single clicks", () =>
{
    using var h = new UiHarness(output, UiHarness.FilledConfig());
    h.View.IsOpen = false; h.Frame(); h.Frame();
    h.Click("dock:toggle");
    Check(h.Items.ContainsKey("window:tray"), "first ordinary click opens the flyout");
    h.Click("dock:toggle");
    Check(!h.Items.ContainsKey("window:tray"), "second ordinary click closes the flyout without holding the mouse");
    h.Click("dock:toggle");
    h.QuickClick("dock:toggle");
    Check(!h.Items.ContainsKey("window:tray"), "quick second click closes without a prior mouse-hover frame");
    h.Click("dock:toggle");
    h.Click("tray:search");
    h.QuickClick("dock:toggle");
    Check(!h.Items.ContainsKey("window:tray"), "button closes flyout after focus was inside its search box");
    h.Click("dock:add");
    Check(h.Items.ContainsKey("window:tray"), "overflow button opens flyout");
    h.Click("dock:add");
    Check(!h.Items.ContainsKey("window:tray"), "overflow button also closes with one ordinary click");
    h.Click("dock:toggle");
    h.QuickClick("dock:add");
    Check(!h.Items.ContainsKey("window:tray"), "either dock button can close a tray opened by the other");
});

Test("settings and responsive captures", () =>
{
    using var h = new UiHarness(output, UiHarness.FilledConfig());
    h.Frame(); h.Frame();
    h.Click("tab:settings");
    h.Render("07-settings-1280x800.png");
    h.Click("settings:vertical");
    Check(h.Config.Vertical, "native settings change dock orientation");
    h.Click("settings:compact");
    Check(h.Config.Compact, "native settings change compact mode");
    h.Click("settings:locked");
    Check(!h.Config.DockLocked, "native settings unlock the dock");
    h.Click("settings:combat");
    Check(h.Config.HideInCombat, "native settings enable combat hiding");
    Check(h.SaveCount >= 4, "changed settings request persistence");
    h.View.IsOpen = false;
    h.Render("08-vertical-compact-dock-1280x800.png");
    h.Frame(true);
    Check(!h.Items.Keys.Any(x => x.StartsWith("dock:", StringComparison.Ordinal)), "combat hiding removes dock widgets when enabled");
    h.Frame(false);
    Check(h.Items.Keys.Any(x => x.StartsWith("dock:", StringComparison.Ordinal)), "dock returns after combat ends");
    h.View.IsOpen = true; h.Frame(); h.Frame();
    h.Click("tab:favorites");
    h.Width = 960; h.Height = 640;
    h.Render("09-favorites-960x640.png");
    Check(h.WindowFits("window:manager"), "existing manager is clamped inside resized 960x640 work area");
    h.Config.Scale = 1.5f;
    h.Render("10-favorites-scale150-960x640.png");
    Check(h.WindowFits("window:manager") && h.WindowFits("window:dock"), "manager and dock remain in bounds at scale 1.5 after resize");
    h.Click("tab:settings");
    h.Render("11-settings-scale150-960x640.png");
    h.Click("settings:showdock");
    Check(!h.Config.ShowDock, "native settings can hide the dock");
});

Test("manager drag does not inflate the interface", () =>
{
    using var h = new UiHarness(output, UiHarness.FilledConfig());
    h.Frame(); h.Frame(); h.Frame();
    var before = h.Items["window:manager"].Max - h.Items["window:manager"].Min;
    h.DragBy("manager:resize", new Vector2(300, 240));
    var after = h.Items["window:manager"].Max - h.Items["window:manager"].Min;
    Check(after.X <= before.X + 1 && after.Y <= before.Y + 1,
        "bottom-right drag cannot expand the manager to cover the game screen");
    h.DragBy("manager:title", new Vector2(950, 620));
    Check(h.WindowFits("window:manager"), "moving the title keeps the manager completely inside the viewport");
    var manager = h.Items["window:manager"];
    var tab = h.Items["tab:catalog"];
    Check(tab.Min.X >= manager.Min.X && tab.Max.X <= manager.Max.X && tab.Min.Y >= manager.Min.Y,
        "after dragging, the manager controls stay inside the window instead of clipping offscreen");
    h.Render("18-manager-after-drag-1280x800.png");
    h.Width = 960; h.Height = 800; h.Config.Scale = 1.6f;
    h.Frame(); h.Frame();
    var scaled = h.Items["window:manager"].Max - h.Items["window:manager"].Min;
    Check(scaled.X <= 720.5f && scaled.Y <= 580.5f && h.WindowFits("window:manager"),
        "high UI scale does not turn the manager into a nearly fullscreen window");
});

Test("native drag reorder", () =>
{
    var config = UiHarness.FilledConfig();
    config.Favorites.RemoveAll(x => x.PluginId is "UnavailablePlugin" or "RemovedPlugin");
    config.DockLocked = false;
    using var h = new UiHarness(output, config);
    h.View.IsOpen = false;
    h.Frame(); h.Frame();
    var firstId = config.Favorites[0].Id;
    var secondId = config.Favorites[1].Id;
    h.Drag("dock:" + firstId, "dock:" + secondId);
    Check(config.Favorites[0].Id == secondId && config.Favorites[1].Id == firstId, "native dock drag reorders favorites");
    Check(h.Launches.Count == 0, "drag reorder never launches a plugin");
    Check(h.SaveCount > 0, "native reorder invokes persistence");
    h.Render("12-reordered-dock-1280x800.png");
});

Test("minimal list keeps click and reorder behavior", () =>
{
    var config = UiHarness.FilledConfig();
    using var h = new UiHarness(output, config);
    h.View.IsOpen = false; h.Frame(); h.Frame();
    h.Click("dock:toggle");
    var first = config.Favorites[0];
    h.Click("tray:" + first.Id);
    Check(h.Launches.Count == 1 && h.Launches[0].Id == first.Id && !h.Items.ContainsKey("window:tray"),
        "minimal tray row launches exactly once and closes after selection");
    h.View.IsOpen = true; h.Frame(); h.Frame();
    h.Click("tab:favorites");
    var second = config.Favorites[1].Id;
    h.Drag("favorites:" + first.Id, "favorites:" + second);
    Check(config.Favorites[0].Id == second && config.Favorites[1].Id == first.Id,
        "minimal manager rows still reorder favorites without changing shortcuts");
    Check(h.Launches.Count == 1 && h.SaveCount == 1, "manager row drag only persists one reorder");
});

Test("locked dock, movement, and readonly configuration", () =>
{
    var config = UiHarness.FilledConfig();
    using var h = new UiHarness(output, config);
    h.View.IsOpen = false; h.Frame(); h.Frame();
    var ids = config.Favorites.Select(x => x.Id).ToArray();
    h.Drag("dock:" + ids[0], "dock:" + ids[1]);
    Check(config.Favorites.Select(x => x.Id).SequenceEqual(ids), "locked dock ignores reorder gestures");
    Check(h.Launches.Count == 0, "locked reorder gesture does not accidentally launch");
    var oldPosition = new Vector2(config.DockX, config.DockY);
    Check(!h.Items.ContainsKey("dock:grip"), "locked dock hides the movement handle entirely");
    h.RightClick("dock:toggle");
    h.Click("dock:lock");
    var savesBeforeMove = h.SaveCount;
    h.DragBy("dock:grip", new Vector2(60, 40));
    Check(new Vector2(config.DockX, config.DockY) != oldPosition, "unlocked dock grip moves the dock");
    Check(h.SaveCount == savesBeforeMove + 1, "dock movement saves exactly once on release");
    h.View.ReadOnly = true;
    h.Click("dock:" + ids[0]);
    Check(h.Launches.Count == 1, "readonly configuration still permits available shortcut launch");
    h.Click("dock:add");
    h.Click("tray:manage");
    var favoritesBefore = config.Favorites.Count;
    var savesBeforeReadonly = h.SaveCount;
    h.Click("add:MidiBard2:ConfigUi");
    Check(config.Favorites.Count == favoritesBefore, "readonly catalog prevents adding a new action");
    h.Click("tab:settings");
    h.Click("settings:compact");
    Check(!config.Compact && h.SaveCount == savesBeforeReadonly, "readonly settings reject edits and do not save");
    h.Render("13-readonly-settings-1280x800.png");
});

Test("fresh small-screen high-scale layout", () =>
{
    var config = UiHarness.FilledConfig(); config.Scale = 1.5f; config.DockX = 9999; config.DockY = 9999;
    using var h = new UiHarness(output, config) { Width = 960, Height = 640 };
    h.Frame(); h.Frame(); h.Frame();
    h.Render("14-first-open-scale150-960x640.png");
    Check(h.WindowFits("window:manager") && h.WindowFits("window:dock"), "fresh 960x640 high-scale windows and stale offscreen dock position fit work area");
    h.Width = 640; h.Height = 480; h.Frame(); h.Frame(); h.Frame();
    h.Render("15-minimum-screen-scale150-640x480.png");
    Check(h.WindowFits("window:manager") && h.WindowFits("window:dock"), "640x480 high-scale windows remain entirely within work area");
    h.View.IsOpen = false; h.Frame(); h.Frame();
    h.Click("dock:add");
    h.Render("15-minimum-screen-tray-640x480.png");
    Check(h.WindowFits("window:tray"), "flyout stays inside the 640x480 work area even with stale dock coordinates and 150% scale");
});

Test("drag interrupted while UI is not drawn", () =>
{
    var config = UiHarness.FilledConfig(); config.DockLocked = false;
    using var h = new UiHarness(output, config);
    h.View.IsOpen = false; h.Frame(); h.Frame(); h.Frame();
    var ids = config.Favorites.Select(x => x.Id).ToArray();
    h.StartDrag("dock:" + ids[0], "dock:" + ids[1]);
    h.FrameWithoutView();
    ImGui.GetIO().AddMouseButtonEvent(0, false);
    h.FrameWithoutView(); h.FrameWithoutView();
    h.Frame(); h.Frame();
    h.Click("dock:" + ids[1]);
    Check(config.Favorites.Select(x => x.Id).SequenceEqual(ids), "release while hidden does not leave a stale reorder gesture");
    Check(h.Launches.Count == 1 && h.Launches[0].Id == ids[1], "first normal click after interrupted drag dispatches exactly once");
});

Test("context menu, alias editor, and alias search", () =>
{
    var config = UiHarness.FilledConfig();
    using var h = new UiHarness(output, config);
    h.View.IsOpen = false; h.Frame(); h.Frame(); h.Frame();
    var id = config.Favorites[0].Id; var favoriteCount = config.Favorites.Count;
    h.RightClick("dock:" + id);
    Check(h.Items.ContainsKey("context:edit"), "native dock right-click opens the action context menu");
    h.Click("context:edit");
    Check(h.Items.ContainsKey("editor:label") && h.Items.ContainsKey("editor:save"), "context edit opens native modal with alias and save controls");
    h.EnterText("editor:label", "常用合奏入口");
    h.Render("16-alias-editor-1280x800.png");
    h.Click("editor:save");
    Check(config.Favorites.Single(x => x.Id == id).Label == "常用合奏入口" && config.Favorites.Count == favoriteCount,
        "native alias save updates the original shortcut without duplicating it");
    Check(h.SaveCount == 1 && h.Launches.Count == 0, "native alias edit saves once and never dispatches a plugin action");
    Check(!h.Items.ContainsKey("editor:label"), "saving closes the modal and leaves a balanced native popup stack");
    h.View.IsOpen = true; h.Frame(); h.Frame();
    h.Click("tab:favorites");
    h.EnterText("shelf:search", "常用合奏");
    Check(h.Items.ContainsKey("favorites:" + id) && h.Items.Keys.Count(x => x.StartsWith("favorites:", StringComparison.Ordinal) && Guid.TryParse(x[10..], out _)) == 1,
        "new Chinese alias immediately participates in favorites search");
    h.Render("17-alias-search-1280x800.png");
    h.RightClick("favorites:" + id);
    h.Click("context:edit");
    h.EnterText("editor:label", "常用合奏第二入口");
    h.Click("editor:save");
    Check(config.Favorites.Single(x => x.Id == id).Label == "常用合奏第二入口" && h.SaveCount == 2 && h.Launches.Count == 0,
        "favorites context can reopen the modal and save another alias without dispatch");
});

Test("group create, edit, enable, disable, quick controls and delete", () =>
{
    using var h = new UiHarness(output, UiHarness.FilledConfig());
    h.Frame(); h.Frame(); h.Click("tab:groups");
    h.Click("groups:new");
    h.EnterText("groupeditor:name", "日常总控");
    h.Click("groupeditor:member:MidiBard2");
    h.Click("groupeditor:member:UnavailablePlugin");
    h.Render("19-group-editor-1280x800.png");
    Check(h.WindowFits("window:groupeditor"), "group editor fits viewport and includes unloaded plugins");
    h.Click("groupeditor:save");
    Check(h.Config.Groups.Count == 1 && h.Config.Groups[0].Name == "日常总控", "native group creation saves name");
    var group = h.Config.Groups[0];
    Check(group.PluginIds.SequenceEqual(new[] { "MidiBard2", "UnavailablePlugin" }), "native membership preserves explicit selection order including disabled targets");
    Check(h.GroupRuns.Count == 0 && h.Launches.Count == 0, "saving a group never starts plugins or opens windows");
    h.Render("20-group-console-1280x800.png");
    h.Click("group:" + group.Id + ":on");
    Check(h.GroupRuns.Count == 1 && h.GroupRuns[0].Enabled, "group enable dispatches desired enabled state once");
    h.Click("group:" + group.Id + ":off");
    Check(h.GroupRuns.Count == 2 && !h.GroupRuns[1].Enabled && h.Launches.Count == 0, "group disable is a separate explicit operation, not a window toggle");
    h.View.ControlBusy = () => true;
    h.Click("group:" + group.Id + ":on");
    Check(h.GroupRuns.Count == 2, "busy guard blocks overlapping group operations");
    h.View.ControlBusy = () => false;
    h.View.ReadOnly = true;
    h.Click("group:" + group.Id + ":off");
    Check(h.GroupRuns.Count == 2, "read-only recovery mode blocks group mutation");
    h.View.ReadOnly = false; h.Frame(); h.Frame();
    h.Click("group:" + group.Id + ":edit");
    h.EnterText("groupeditor:name", "不应保存");
    h.Click("groupeditor:member:MidiBard2");
    h.Click("groupeditor:cancel");
    Check(group.Name == "日常总控" && group.PluginIds.Count == 2 && h.SaveCount == 1, "cancel discards group draft and membership changes");
    h.View.IsOpen = false; h.Frame(); h.Frame();
    h.Click("dock:toggle"); h.Click("tray:groups");
    h.Render("21-group-quick-controls-1280x800.png");
    h.Click("traygroup:" + group.Id + ":off");
    Check(h.GroupRuns.Count == 3 && !h.GroupRuns[2].Enabled && !h.View.IsOpen, "flyout group switch works without opening manager");
    h.Click("tray:manage");
    Check(h.View.IsOpen && h.Items.ContainsKey("groups:new"), "flyout manage opens group page directly");
    h.Click("group:" + group.Id + ":delete");
    h.Click("groupdelete:cancel");
    Check(h.Config.Groups.Count == 1, "delete confirmation can be cancelled");
    h.Click("group:" + group.Id + ":delete");
    h.Click("groupdelete:confirm");
    Check(h.Config.Groups.Count == 0 && h.GroupRuns.Count == 3 && h.Config.Favorites.Count == 5,
        "deleting a group only removes its record, never stops plugins or deletes favorites");
});

Test("unknown catalog, group search, single controls and scaled group editor", () =>
{
    var config = UiHarness.FilledConfig();
    config.Groups.Add(new PluginGroup { Name = "日常", PluginIds = ["MidiBard2", "RemovedPlugin"] });
    using var h = new UiHarness(output, config);
    h.Frame(); h.Frame(); h.Click("tab:groups");
    h.View.CatalogAvailable = () => false;
    h.View.CatalogMessage = () => "目录读取失败 · 状态未知，不是未加载";
    h.Click("group:" + config.Groups[0].Id + ":on");
    Check(h.GroupRuns.Count == 0, "unknown directory never initiates lifecycle operations");
    h.View.IsOpen = false; h.Frame(); h.Frame();
    h.Click("dock:" + config.Favorites[0].Id);
    Check(h.Launches.Count == 0, "last-known loaded favorite is not dispatched when catalog is stale");
    h.Click("dock:toggle");
    h.Render("22-unknown-catalog-1280x800.png");
    h.Click("dock:toggle");
    h.View.IsOpen = true; h.View.CatalogAvailable = () => true; h.View.CatalogMessage = () => "";
    h.Frame(); h.Frame(); h.Click("tab:catalog");
    h.Click("control:MidiBard2");
    Check(h.GroupRuns.Count == 1 && !h.GroupRuns[0].Enabled && h.GroupRuns[0].Group.PluginIds.SequenceEqual(new[] { "MidiBard2" }),
        "individual plugin switch dispatches only selected plugin, not its window");
    h.Click("tab:groups"); h.Click("group:" + config.Groups[0].Id + ":edit");
    h.EnterText("groupeditor:search", "Removed");
    Check(h.Items.ContainsKey("groupeditor:member:RemovedPlugin") && !h.Items.ContainsKey("groupeditor:member:MidiBard2"),
        "group editor search retains missing members for removal");
    h.Width = 960; h.Height = 640; h.Config.Scale = 1.5f;
    h.Render("23-group-editor-scaled-960x640.png");
    Check(h.WindowFits("window:groupeditor"), "scaled group editor stays in small viewport");
    h.Click("groupeditor:cancel");
});

Test("individual switches are available in favorites, flyout, context and group members", () =>
{
    var config = UiHarness.FilledConfig();
    var group = new PluginGroup { Name = "日常", PluginIds = ["MidiBard2", "UnavailablePlugin"] };
    config.Groups.Add(group);
    using var h = new UiHarness(output, config);
    h.Frame(); h.Frame();
    h.Click("favorites:" + config.Favorites[0].Id + ":control");
    Check(h.GroupRuns.Count == 1 && !h.GroupRuns[0].Enabled && h.GroupRuns[0].Group.PluginIds.SequenceEqual(new[] { "MidiBard2" }),
        "favorite row checkbox stops only its plugin");
    Check(h.Launches.Count == 0 && config.Favorites.Count == 5, "favorite checkbox never opens window or removes favorite");
    h.Render("24-individual-favorites-1280x800.png");
    h.View.IsOpen = false; h.Frame(); h.Frame(); h.Click("dock:toggle");
    h.Click("tray:" + config.Favorites[3].Id + ":control");
    Check(h.GroupRuns.Count == 2 && h.GroupRuns[1].Enabled && h.GroupRuns[1].Group.PluginIds.Single() == "UnavailablePlugin",
        "unloaded favorite can be individually enabled from flyout");
    Check(h.Items.ContainsKey("window:tray"), "individual flyout switch keeps panel open for other controls");
    h.Click("dock:toggle"); h.RightClick("dock:" + config.Favorites[0].Id);
    h.Click("context:control");
    Check(h.GroupRuns.Count == 3 && !h.GroupRuns[2].Enabled, "pinned shortcut context provides individual lifecycle switch");
    h.View.IsOpen = true; h.Frame(); h.Frame(); h.Click("tab:groups");
    h.Click("group:" + group.Id + ":member:UnavailablePlugin");
    Check(h.GroupRuns.Count == 4 && h.GroupRuns[3].Enabled && h.GroupRuns[3].Group.PluginIds.Single() == "UnavailablePlugin",
        "group member checkbox controls only that member, not the whole group");
    Check(group.PluginIds.Count == 2 && h.SaveCount == 0 && h.Launches.Count == 0, "individual member control does not edit group membership");
    h.Render("26-individual-group-members-1280x800.png");
    h.View.ControlBusy = () => true; h.Frame(); h.Frame();
    h.Click("group:" + group.Id + ":member:MidiBard2");
    Check(h.GroupRuns.Count == 4, "busy group member switches cannot overlap a running operation");
    h.View.ControlBusy = () => false; h.InCombat = true; h.Frame(); h.Frame();
    h.Click("group:" + group.Id + ":member:MidiBard2");
    Check(h.GroupRuns.Count == 4, "combat guard applies to individual member switches too");
    h.InCombat = false; h.View.IsOpen = false; h.Frame(); h.Frame(); h.Click("dock:toggle"); h.Click("tray:groups");
    h.Click("traygroup:" + group.Id + ":member:UnavailablePlugin");
    Check(h.GroupRuns.Count == 5 && h.GroupRuns[4].Group.PluginIds.Single() == "UnavailablePlugin",
        "compact group flyout includes each member switch");
    h.Render("27-individual-group-flyout-1280x800.png");
});

Test("duplicate-copy picker saves explicit source and switch uses selected state", () =>
{
    var config = UiHarness.FilledConfig();
    var group = new PluginGroup { Name = "合奏", PluginIds = ["MidiBard2"] }; config.Groups.Add(group);
    var a = new PluginInstance(new("MidiBard2", Guid.NewGuid(), @"D:\旧版\MidiBard2.dll"), "合奏旧版", "3.2.5.50", true, "Unloaded");
    var b = new PluginInstance(new("MidiBard2", Guid.NewGuid(), @"D:\新版\MidiBard2.dll"), "深海回响供版", "3.2.5.77", true, "Unloaded");
    using var h = new UiHarness(output, config);
    h.View.Instances = id => id == "MidiBard2" ? new[] { a, b } : [];
    h.Frame(); h.Frame(); h.Click("tab:groups");
    h.Click("group:" + group.Id + ":member:MidiBard2");
    Check(h.GroupRuns.Count == 0, "ambiguous individual switch cannot guess a copy");
    h.Click("group:" + group.Id + ":member:MidiBard2:copy");
    h.Render("25-duplicate-copy-picker-1280x800.png");
    Check(h.Items.ContainsKey("instancepicker:copy:0") && h.Items.ContainsKey("instancepicker:copy:1") && h.WindowFits("window:instancepicker"),
        "copy picker lists both sources with versions, paths and state");
    h.Click("instancepicker:copy:1"); h.Click("instancepicker:save");
    Check(config.PluginTargets.Single() == b.Target && h.SaveCount == 1 && h.GroupRuns.Count == 0 && h.Launches.Count == 0,
        "saving source preference does not enable anything");
    h.Click("group:" + group.Id + ":member:MidiBard2");
    Check(h.GroupRuns.Count == 1 && h.GroupRuns[0].Enabled, "member switch uses selected unloaded copy even if public catalog representative was loaded");
    b = b with { State = "Loaded" }; h.Frame(); h.Frame();
    h.Click("group:" + group.Id + ":member:MidiBard2");
    Check(h.GroupRuns.Count == 2 && !h.GroupRuns[1].Enabled, "same selected copy now exposes stop action");
    h.Click("group:" + group.Id + ":member:MidiBard2:copy");
    h.Click("instancepicker:copy:0"); h.Click("instancepicker:cancel");
    Check(config.PluginTargets.Single() == b.Target && h.SaveCount == 1, "cancelled source selection leaves preference unchanged");
    h.Click("group:" + group.Id + ":member:MidiBard2:copy");
    h.Width = 960; h.Height = 640; h.Config.Scale = 1.5f;
    h.Render("28-copy-picker-scaled-960x640.png");
    Check(h.WindowFits("window:instancepicker"), "copy picker remains within small scaled viewport");
    h.Click("instancepicker:clear");
    Check(config.PluginTargets.Count == 0 && h.GroupRuns.Count == 2, "restore automatic selection only clears preference, never toggles plugins");
});

Test("catalog defaults to both running and stopped plugins for individual control", () =>
{
    using var h = new UiHarness(output, UiHarness.FilledConfig());
    h.Frame(); h.Frame(); h.Click("tab:catalog");
    Check(h.Items.ContainsKey("control:UnavailablePlugin"), "default catalog includes individual start controls for stopped plugins");
    h.EnterText("shelf:search", "Unavailable");
    h.Click("control:UnavailablePlugin");
    Check(h.GroupRuns.Count == 1 && h.GroupRuns[0].Enabled, "catalog starts stopped plugin without changing the loaded-only filter");
});

var captures = UiHarness.Captures.Order().ToArray();
Check(captures.Length >= 12, "twelve or more nonblank native ImGui screenshot captures exist");
log.Add($"RESULT {log.Count(x => x.StartsWith("PASS ", StringComparison.Ordinal))} passed; {failures} failed.");
log.Add("Evidence scope: offline native cimgui rendering with Chinese font, synthetic catalog, and callback recording. No game process was installed, loaded, or controlled; no real plugin window was opened.");
File.WriteAllLines(Path.Combine(output, "ui-validation.txt"), log);
File.WriteAllText(Path.Combine(output, "ui-captures.json"), JsonSerializer.Serialize(captures, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine(log[^2]);
return failures == 0 ? 0 : 1;

internal sealed unsafe class UiHarness : IDisposable
{
    public static List<string> Captures { get; } = [];
    readonly ImGuiContextPtr context;
    readonly string output;
    public ShelfConfig Config { get; }
    public ShelfUi View { get; }
    public int Width { get; set; } = 1280;
    public int Height { get; set; } = 800;
    public bool InCombat { get; set; }
    public Dictionary<string, (Vector2 Min, Vector2 Max)> Items { get; } = new(StringComparer.Ordinal);
    public List<Shortcut> Launches { get; } = [];
    public List<(PluginGroup Group, bool Enabled)> GroupRuns { get; } = [];
    public int SaveCount { get; private set; }
    public static IReadOnlyList<PluginEntry> Catalog { get; } = new List<PluginEntry>
    {
        new("MidiBard2", "MidiBard 2 合奏演奏", "3.2.5.53", true, true, true, false),
        new("SimpleTweaksPlugin", "Simple Tweaks 简易界面调整", "1.10.0", true, false, true, false),
        new("DiceStats", "点数统计", "1.1.0.0", true, true, true, false),
        new("UnavailablePlugin", "暂未加载插件", "1.0.0", false, true, true, false),
        new("NoUiPlugin", "后台服务（没有公开窗口）", "1.0.0", true, false, false, false),
        new("OutdatedPlugin", "版本过期示例", "0.1.0", false, true, false, true),
    };
    public UiHarness(string output, ShelfConfig? config = null)
    {
        this.output = output; Config = config ?? new ShelfConfig();
        context = ImGui.CreateContext();
        var io = ImGui.GetIO(); io.IniFilename = null; io.DeltaTime = 1f / 60;
        io.Fonts.AddFontFromFileTTF("C:/Windows/Fonts/msyh.ttc", 18, default, io.Fonts.GetGlyphRangesChineseFull());
        if (!io.Fonts.Build()) throw new InvalidOperationException("Chinese font atlas build failed");
        ImGui.StyleColorsDark();
        View = new ShelfUi(Config, () => Catalog, s => Launches.Add(s), () => SaveCount++, () => "离线界面验证 · 未连接游戏");
        View.RunGroup = (g, enabled) => GroupRuns.Add((new PluginGroup { Id = g.Id, Name = g.Name, PluginIds = g.PluginIds.ToList() }, enabled));
        View.ObserveItem = (id, min, max) => Items[id] = (min, max);
    }
    public static ShelfConfig FilledConfig() => new()
    {
        HasCompletedSetup = true,
        Favorites =
        [
            new() { PluginId = "MidiBard2", Label = "合奏演奏", Kind = LaunchKind.MainUi },
            new() { PluginId = "SimpleTweaksPlugin", Label = "界面微调", Kind = LaunchKind.ConfigUi },
            new() { PluginId = "DiceStats", Label = "点数统计", Kind = LaunchKind.MainUi },
            new() { PluginId = "UnavailablePlugin", Label = "暂未加载", Kind = LaunchKind.MainUi },
            new() { PluginId = "RemovedPlugin", Label = "已移除插件", Kind = LaunchKind.MainUi },
        ],
    };
    public void Frame(bool inCombat = false)
    {
        Items.Clear();
        var io = ImGui.GetIO(); io.DisplaySize = new(Width, Height); io.DeltaTime = 1f / 60;
        ImGui.NewFrame(); View.Draw(inCombat || InCombat); ImGui.Render();
    }
    public void Render(string filename)
    {
        ImGui.GetIO().AddMousePosEvent(-100, -100); Frame(); Frame(); Frame();
        if (ImGui.GetDrawData().TotalVtxCount == 0) throw new InvalidOperationException("Blank native UI frame");
        SoftwareRenderer.Save(Path.Combine(output, filename)); Captures.Add(filename);
    }
    public Vector2 Center(string id)
    {
        if (!Items.TryGetValue(id, out var rect))
            throw new InvalidOperationException($"Widget '{id}' absent. Available: {string.Join(", ", Items.Keys)}");
        return (rect.Min + rect.Max) * 0.5f;
    }
    public bool WindowFits(string id)
    {
        return Items.TryGetValue(id, out var r) && r.Min.X >= 0 && r.Min.Y >= 0 && r.Max.X <= Width + .01f && r.Max.Y <= Height + .01f;
    }
    public void Click(string id)
    {
        var p = Center(id); var io = ImGui.GetIO();
        io.AddMousePosEvent(p.X, p.Y); Frame();
        io.AddMouseButtonEvent(0, true); Frame();
        io.AddMouseButtonEvent(0, false); Frame(); Frame();
    }
    public void QuickClick(string id)
    {
        var p = Center(id); var io = ImGui.GetIO();
        io.AddMousePosEvent(p.X, p.Y); io.AddMouseButtonEvent(0, true); Frame();
        io.AddMouseButtonEvent(0, false); Frame(); Frame();
    }
    public void RightClick(string id)
    {
        var p = Center(id); var io = ImGui.GetIO();
        io.AddMousePosEvent(p.X, p.Y); Frame();
        io.AddMouseButtonEvent(1, true); Frame();
        io.AddMouseButtonEvent(1, false); Frame(); Frame();
    }
    public void EnterText(string id, string text)
    {
        Click(id); var io = ImGui.GetIO();
        io.AddKeyEvent(ImGuiKey.ModCtrl, true); io.AddKeyEvent(ImGuiKey.A, true); Frame();
        io.AddKeyEvent(ImGuiKey.A, false); io.AddKeyEvent(ImGuiKey.ModCtrl, false); Frame();
        io.AddKeyEvent(ImGuiKey.Backspace, true); Frame(); io.AddKeyEvent(ImGuiKey.Backspace, false); Frame();
        foreach (var character in text) io.AddInputCharacter(character);
        Frame(); Frame();
    }
    public void Drag(string source, string target)
    {
        DragTo(Center(source), Center(target));
    }
    public void FrameWithoutView()
    {
        Items.Clear(); ImGui.NewFrame(); ImGui.Render();
    }
    public void StartDrag(string source, string target)
    {
        var a = Center(source); var b = Center(target); var io = ImGui.GetIO();
        io.AddMousePosEvent(a.X, a.Y); Frame(); io.AddMouseButtonEvent(0, true); Frame();
        for (var i = 1; i <= 8; i++) { var p = Vector2.Lerp(a, b, i / 8f); io.AddMousePosEvent(p.X, p.Y); Frame(); }
        Frame();
    }
    public void DragBy(string source, Vector2 delta)
    {
        var a = Center(source); DragTo(a, a + delta);
    }
    void DragTo(Vector2 a, Vector2 b)
    {
        var io = ImGui.GetIO();
        io.AddMousePosEvent(a.X, a.Y); Frame(); io.AddMouseButtonEvent(0, true); Frame();
        for (var i = 1; i <= 8; i++) { var p = Vector2.Lerp(a, b, i / 8f); io.AddMousePosEvent(p.X, p.Y); Frame(); }
        Frame(); io.AddMouseButtonEvent(0, false); Frame(); Frame();
    }
    public void Dispose() => ImGui.DestroyContext(context);
}




