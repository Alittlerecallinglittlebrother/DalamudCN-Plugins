# PluginShelf offline native UI tests

This executable directly compiles the production `ShelfUi.cs` and calls its `Draw` method inside native cimgui frames. It does not add another window around the production UI. Mouse clicks, dragging, text input, and checkboxes are dispatched via the native input event queue. `ObserveItem` supplies widget hit rectangles and window bounds.

Run from the source root with .NET 10 on Windows and a local Dalamud SDK:

```powershell
dotnet run --project .\PluginShelf.UiTests\PluginShelf.UiTests.csproj -c Release -- .\validation\ui
```

`DALAMUD_HOME` can override the default SDK path `%APPDATA%\XIVLauncherCN\addon\Hooks\dev`. Required local SDK files: `cimgui.dll`, `Dalamud.Bindings.ImGui.dll`, and `HexaGen.Runtime.dll`. Native dependencies and Microsoft YaHei are not redistributed.

The test catalog is synthetic. Launch callbacks are recorded, not forwarded to a game process. The PNGs demonstrate offline native ImGui layout, not game loading, real plugin discovery, real IPC/command execution, or target-plugin window visibility. The software renderer uses bilinear atlas sampling; this is not a Direct3D game screenshot.

Coverage: catalog discovery display; main/config action labels; native add and deduplication; Chinese search; single dispatch; unavailable/missing no-dispatch; horizontal and vertical/compact dock; configuration callbacks; combat hiding; locked/unlocked reorder and move; readonly persistence barriers; drag interruption during suppressed Draw; resized and first-open small screens at scale 1.5; full-window work-area containment; native dock/favorites right-click context menus; modal alias editing and balanced popup lifecycle; save-without-dispatch and immediate alias search.

