using System;
using System.Collections.Generic;
using System.Linq;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using PluginShelf.Core;

namespace PluginShelf;

/// <summary>
/// Uses only Dalamud's public plugin/command APIs. Exposed plugin instances are
/// intentionally never retained across calls: a target may reload at any time.
/// </summary>
internal sealed class DalamudBackend : IPluginBackend
{
    private const string SelfInternalName = "PluginShelf";
    private readonly IDalamudPluginInterface pluginInterface;
    private readonly ICommandManager commandManager;
    private readonly IPluginLog log;
    private readonly System.Collections.Concurrent.ConcurrentDictionary<string, byte> reportedErrors = new();

    public DalamudBackend(IDalamudPluginInterface pluginInterface,
        ICommandManager commandManager, IPluginLog log)
    {
        this.pluginInterface = pluginInterface;
        this.commandManager = commandManager;
        this.log = log;
    }

    public IReadOnlyList<PluginEntry> Snapshot()
    {
        // Snapshot values, not live IExposedPlugin objects. A development copy
        // and a release copy can share an InternalName; prefer the loaded one.
        var entries = this.ReadDirectory()
            .Select(item => item.Entry)
            .GroupBy(entry => entry.InternalName, StringComparer.Ordinal)
            .Select(group => group.OrderByDescending(entry => entry.StateKnown && entry.IsLoaded)
                .ThenByDescending(entry => entry.StateKnown).ThenBy(entry => entry.IsOutdated).First())
            .OrderBy(entry => entry.Name, StringComparer.OrdinalIgnoreCase)
            .ThenBy(entry => entry.InternalName, StringComparer.Ordinal)
            .ToArray();
        return Array.AsReadOnly(entries);
    }

    public PluginEntry? Find(string id)
    {
        var current = this.FindCurrent(id);
        return current is null ? null : this.ToEntry(current, id);
    }

    public void OpenMainUi(string id) => this.OpenUi(id, mainUi: true);

    public void OpenConfigUi(string id) => this.OpenUi(id, mainUi: false);

    public bool IsCommandRegistered(string fullCommand)
        => TryParseCommand(fullCommand, out _, out var token)
            && this.commandManager.Commands.ContainsKey(token);

    public bool ProcessCommand(string fullCommand)
    {
        if (!TryParseCommand(fullCommand, out var normalized, out var token)
            || !this.commandManager.Commands.ContainsKey(token))
            return false;

        try
        {
            // This is registered-command dispatch only. Never submit chat text,
            // run game macros, or try another action when dispatch returns false.
            return this.commandManager.ProcessCommand(normalized);
        }
        catch (Exception exception)
        {
            // Do not log user-supplied command arguments.
            this.log.Error(exception, "PluginShelf command dispatch failed: {Command}", token);
            throw new InvalidOperationException("指令调用发生异常；未尝试其他动作。", exception);
        }
    }

    private IEnumerable<(IExposedPlugin Plugin, PluginEntry Entry)> ReadDirectory()
    {
        // Materialize the directory once, then isolate every plugin and every optional getter.
        // A bad manifest (including a null Version) must not invalidate healthy plugins.
        foreach (var plugin in this.pluginInterface.InstalledPlugins.ToArray())
        {
            string? id;
            try { id = plugin?.InternalName; }
            catch (Exception ex) { this.Report("directory:identity", ex); continue; }
            if (string.IsNullOrWhiteSpace(id) || string.Equals(id, SelfInternalName, StringComparison.Ordinal)) continue;
            yield return (plugin!, this.ToEntry(plugin!, id));
        }
    }

    private PluginEntry ToEntry(IExposedPlugin plugin, string id)
    {
        var errors = new List<string>();
        T Read<T>(string field, Func<T> getter, T fallback)
        {
            try { return getter(); }
            catch (Exception ex)
            {
                errors.Add(field);
                this.Report(id + ":" + field, ex);
                return fallback;
            }
        }
        var loaded = Read("加载状态", () => plugin.IsLoaded, false);
        var outdated = Read("API 状态", () => plugin.IsOutdated, false);
        var known = errors.Count == 0;
        var name = Read("名称", () => plugin.Name, id);
        var version = Read("版本", () => plugin.Version?.ToString() ?? "未知", "未知");
        var main = Read("主界面入口", () => plugin.HasMainUi, false);
        var settings = Read("设置入口", () => plugin.HasConfigUi, false);
        return new(id, string.IsNullOrWhiteSpace(name) ? id : name, version, loaded, main, settings, outdated,
            known, errors.Count == 0 ? "" : "部分资料无法读取：" + string.Join("、", errors));
    }

    private void Report(string key, Exception exception)
    {
        // At most one warning for the same plugin/property per session, not every two seconds.
        if (this.reportedErrors.TryAdd(key, 0))
            this.log.Warning(exception, "PluginShelf skipped unreadable plugin field: {Field}", key);
    }

    private IExposedPlugin? FindCurrent(string id)
    {
        if (string.IsNullOrWhiteSpace(id)
            || string.Equals(id, SelfInternalName, StringComparison.Ordinal))
            return null;

        // This query occurs again at the point of invocation. Keeping a previous
        // directory snapshot is fine; keeping the old plugin object is not.
        return this.ReadDirectory()
            .Where(item => string.Equals(item.Entry.InternalName, id, StringComparison.Ordinal))
            .OrderByDescending(item => item.Entry.StateKnown && item.Entry.IsLoaded)
            .ThenByDescending(item => item.Entry.StateKnown)
            .ThenBy(item => item.Entry.IsOutdated)
            .Select(item => item.Plugin)
            .FirstOrDefault();
    }

    private void OpenUi(string id, bool mainUi)
    {
        var current = this.FindCurrent(id)
            ?? throw new InvalidOperationException("目标插件不存在或已卸载；收藏仍会保留。");
        var entry = this.ToEntry(current, id);
        if (!entry.StateKnown)
            throw new InvalidOperationException("目标插件状态暂时无法确认，请等待刷新。");
        if (entry.IsOutdated)
            throw new InvalidOperationException("目标插件的 API 版本已过期，请先更新目标插件。");
        if (!entry.IsLoaded)
            throw new InvalidOperationException("目标插件未加载，请先在卫月插件列表中启用。");
        if (mainUi ? !entry.HasMainUi : !entry.HasConfigUi)
            throw new InvalidOperationException(mainUi
                ? "目标插件目前没有标准主界面入口，请编辑此快捷方式。"
                : "目标插件目前没有标准设置入口，请编辑此快捷方式。");

        try
        {
            if (mainUi)
                current.OpenMainUi();
            else
                current.OpenConfigUi();
        }
        catch (Exception exception)
        {
            this.log.Error(exception, "PluginShelf UI request failed: {PluginId}, {Action}",
                id, mainUi ? "MainUi" : "ConfigUi");
            throw new InvalidOperationException("目标插件的界面调用发生异常；未尝试其他动作。", exception);
        }
    }

    private static bool TryParseCommand(string? fullCommand, out string normalized, out string token)
    {
        normalized = string.Empty;
        token = string.Empty;
        if (LaunchService.ValidateCommand(fullCommand) is not null)
            return false;

        normalized = fullCommand!;

        // Dalamud ProcessCommand splits on an ASCII space, not arbitrary Unicode
        // whitespace. Use the same delimiter and reject ambiguous token spacing.
        var separator = normalized.IndexOf(' ');
        token = separator < 0 ? normalized : normalized[..separator];
        return true;
    }
}
