using System.Collections;
using System.Reflection;
using System.Runtime.ExceptionServices;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using PluginShelf.Core;

namespace PluginShelf;

/// <summary>
/// API 15 has no public plugin lifecycle API. This deliberately narrow adapter follows
/// the installed CN installer's single-plugin path. Missing members fail closed.
/// Never writes fields, edits manifests/files, removes collections, or applies ALL profiles.
/// </summary>
internal sealed class DalamudPluginControl : IPluginControlBackend
{
    private const BindingFlags PublicInstance = BindingFlags.Public | BindingFlags.Instance;
    private readonly Func<(object Plugins, object Profiles, ulong ContentId)> resolve;
    private readonly Action<Exception, string> report;

    public DalamudPluginControl(IPluginLog log, Func<ulong> contentId)
        : this(() => (GetService("Dalamud.Plugin.Internal.PluginManager"),
            GetService("Dalamud.Plugin.Internal.Profiles.ProfileManager"), contentId()),
            (ex, id) => log.Error(ex, "PluginShelf lifecycle operation failed: {PluginId}", id)) { }

    internal DalamudPluginControl(Func<(object Plugins, object Profiles, ulong ContentId)> resolve,
        Action<Exception, string> report)
    {
        this.resolve = resolve;
        this.report = report;
    }

    public IReadOnlyList<PluginInstance> SnapshotInstances()
    {
        var items = new List<PluginInstance>();
        foreach (var plugin in Objects(Get<object>(resolve().Plugins, "InstalledPlugins")).Distinct(ReferenceEqualityComparer.Instance))
        {
            var id = Optional(plugin, "InternalName", "");
            if (!ShelfOperations.IsControllableId(id)) continue;
            try { items.Add(Describe(plugin, id)); }
            catch { /* A partially disposed item will be retried on the next refresh. */ }
        }
        return items.AsReadOnly();
    }

    public async Task<ControlResult> SetEnabledAsync(string id, bool enabled, CancellationToken cancellationToken,
        PluginTarget? preferred = null)
    {
        ControlResult Fail(string message) => new(id, ControlOutcome.Failed, message);
        if (!ShelfOperations.IsControllableId(id)) return Fail("禁止操作收纳盒自身或无效插件标识。");
        cancellationToken.ThrowIfCancellationRequested();
        try
        {
            var (manager, profiles, contentId) = resolve();
            if (Get<bool>(manager, "SafeMode")) return Fail("卫月处于安全模式，未执行开关。");
            if (Get<bool>(profiles, "IsBusy")) return Fail("卫月正在切换合集，请稍后重试。");
            var candidates = Candidates(manager, id);
            if (candidates.Length == 0) return Fail("插件未安装；分组记录已保留。");
            if (!enabled && preferred is null && candidates.All(x => x.Info.State == "Unloaded"))
                return new(id, ControlOutcome.Unchanged, "所有同名副本均已停用，未重复卸载。",
                    candidates.Length == 1 ? candidates[0].Info.Target : null);
            var selection = PluginInstanceSelector.Select(id, candidates.Select(x => x.Info).ToArray(), preferred);
            if (selection.Instance is null) return Fail(selection.Error);
            var chosen = candidates.Single(x => ReferenceEquals(x.Info, selection.Instance));
            var plugin = chosen.Plugin;
            var target = chosen.Info.Target;
            if (enabled && candidates.Any(x => !ReferenceEquals(x.Plugin, plugin) && x.Info.State != "Unloaded"))
                return Fail("另一个同名副本仍在运行或未完成卸载，请先选择并停用那一份；未同时加载第二份。");
            var state = Get<object>(plugin, "State").ToString();
            if (state is not ("Loaded" or "Unloaded"))
                return Fail($"当前状态 {state}，请等待加载完成或先在卫月处理错误。");
            if (Get<bool>(plugin, "IsLoaded") == enabled)
                return new(id, ControlOutcome.Unchanged, enabled ? "已经启用，未重复加载。" : "所选副本已经停用，未重复卸载。", target);
            if (enabled && (Get<bool>(plugin, "IsOutdated") || Get<bool>(plugin, "IsBanned")))
                return Fail("插件 API 已过期或被卫月禁用，请先在插件安装器处理。");
            if (enabled && Get<bool>(Get<object>(plugin, "Manifest"), "ScheduledForDeletion"))
                return Fail("插件已计划删除，未擅自恢复或加载。");

            var workingId = Get<Guid>(plugin, "EffectiveWorkingPluginId");
            if (candidates.Count(x => x.Info.Target.WorkingPluginId == workingId) != 1)
                return Fail("不同副本共用同一卫月编号，无法独立保存启停状态；请先在卫月处理重复注册。");
            var owners = Objects(Get<object>(profiles, "Profiles"))
                .Where(p => Invoke(p, "WantsPlugin", [typeof(Guid)], [workingId]) is not null).ToArray();
            if (owners.Length != 1)
                return Fail("插件不属于唯一卫月合集，不能安全切换；请先在卫月中调整合集归属。");
            var owner = owners[0];
            if (!Get<bool>(owner, "IsEnabled") ||
                Invoke(owner, "CheckWantsActiveFromGameState", [typeof(ulong)], [contentId]) is not true)
                return Fail("插件所属卫月合集未启用或不适用于当前角色；未修改合集开关。");
            var previousWant = (bool)Invoke(owner, "WantsPlugin", [typeof(Guid)], [workingId])!;
            // Resolve every member and argument BEFORE making any change.
            var update = RequiredMethod(owner.GetType(), "AddOrUpdateAsync",
                [typeof(Guid), typeof(string), typeof(bool), typeof(bool)]);
            var load = plugin.GetType().GetMethods(PublicInstance).SingleOrDefault(m => m.Name == "LoadAsync" &&
                m.GetParameters() is var p && p.Length == 3 && p[0].ParameterType.IsEnum &&
                p[1].ParameterType == typeof(bool) && p[2].ParameterType == typeof(CancellationToken))
                ?? throw new MissingMethodException("Unsupported LocalPlugin.LoadAsync signature");
            var unload = plugin.GetType().GetMethods(PublicInstance).SingleOrDefault(m => m.Name == "UnloadAsync" &&
                m.GetParameters() is var p && p.Length == 1 && p[0].ParameterType.IsEnum)
                ?? throw new MissingMethodException("Unsupported LocalPlugin.UnloadAsync signature");
            EnsureTask(update); EnsureTask(load); EnsureTask(unload);
            var loadReason = Enum.Parse(load.GetParameters()[0].ParameterType, "Installer");
            var unloadMode = Enum.Parse(unload.GetParameters()[0].ParameterType, "WaitBeforeDispose");
            cancellationToken.ThrowIfCancellationRequested();
            if (enabled)
            {
                await InvokeTask(owner, update, [workingId, id, true, false]).ConfigureAwait(false);
                try
                {
                    // SDK supplies its own load timeout. Cancelling a batch stops remaining
                    // members, not an already-started third-party Dispose/constructor.
                    await InvokeTask(plugin, load, [loadReason, false, CancellationToken.None]).ConfigureAwait(false);
                    if (Get<object>(plugin, "State").ToString() != "Loaded")
                        throw new InvalidOperationException("Load task completed without reaching Loaded state");
                }
                catch
                {
                    // Do not leave an auto-enable request behind after failed construction.
                    if (!Get<bool>(plugin, "IsLoaded") &&
                        Invoke(owner, "WantsPlugin", [typeof(Guid)], [workingId]) is true)
                        await InvokeTask(owner, update, [workingId, id, previousWant, false]).ConfigureAwait(false);
                    throw;
                }
            }
            else
            {
                await InvokeTask(plugin, unload, [unloadMode]).ConfigureAwait(false);
                if (Get<object>(plugin, "State").ToString() != "Unloaded")
                    throw new InvalidOperationException("Unload task completed without reaching Unloaded state");
                await InvokeTask(owner, update, [workingId, id, false, false]).ConfigureAwait(false);
            }
            // Re-resolve instead of reporting success merely because a Task completed.
            var current = Candidates(resolve().Plugins, id);
            var selected = PluginInstanceSelector.Select(id, current.Select(x => x.Info).ToArray(), target).Instance;
            if (selected is null || selected.State != (enabled ? "Loaded" : "Unloaded"))
                return Fail("请求已执行，但所选副本实际状态未达到目标；请刷新检查，未自动重试。");
            var otherRunning = current.Any(x => !ReferenceEquals(x.Info, selected) && x.Info.IsLoaded);
            if (enabled && otherRunning) return Fail("所选副本已加载，但另一个同名副本也在运行；请检查并单独处理。");
            return new(id, ControlOutcome.Changed, enabled ? "已启用并核验所选副本。" :
                otherRunning ? "已停用所选副本；另一同名副本仍在运行，未操作它。" : "已停用并核验所选副本；文件与配置保留。", selected.Target);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception ex)
        {
            report(ex, id);
            return Fail(ex is MissingMemberException or AmbiguousMatchException or TypeLoadException
                ? "当前卫月内部接口不兼容，已停止操作；请更新收纳盒。"
                : "开关失败；可能已有部分状态变更，请查看日志/卫月安装器，未自动重试。");
        }
    }

    private static (object Plugin, PluginInstance Info)[] Candidates(object manager, string id) =>
        Objects(Get<object>(manager, "InstalledPlugins")).Distinct(ReferenceEqualityComparer.Instance)
            .Where(x => Optional(x, "InternalName", "") == id).Select(x => (x, Describe(x, id))).ToArray();

    private static PluginInstance Describe(object plugin, string id) => new(
        new(id, Get<Guid>(plugin, "EffectiveWorkingPluginId"), Optional<FileInfo?>(plugin, "DllFile", null)?.FullName ?? ""),
        Optional(plugin, "Name", id), Optional<Version?>(plugin, "EffectiveVersion", null)?.ToString() ?? "未知",
        Optional(plugin, "IsDev", false), Get<object>(plugin, "State").ToString() ?? "Unknown", Get<bool>(plugin, "IsOutdated"));

    private static T Optional<T>(object instance, string property, T fallback)
    {
        try { return Get<T>(instance, property); }
        catch { return fallback; }
    }

    private static object GetService(string name)
    {
        var assembly = typeof(IDalamudPluginInterface).Assembly;
        var serviceType = assembly.GetType(name, throwOnError: true)!;
        var generic = assembly.GetType("Dalamud.Service`1", throwOnError: true)!.MakeGenericType(serviceType);
        var get = generic.GetMethod("Get", BindingFlags.Public | BindingFlags.Static, Type.EmptyTypes)
            ?? throw new MissingMethodException(generic.FullName, "Get");
        return Call(get, null, []) ?? throw new InvalidOperationException("Dalamud service unavailable");
    }

    private static object[] Objects(object value) => ((IEnumerable)value).Cast<object>().ToArray();
    private static T Get<T>(object instance, string property)
    {
        var member = instance.GetType().GetProperty(property, PublicInstance)
            ?? throw new MissingMemberException(instance.GetType().FullName, property);
        return (T)(member.GetValue(instance) ?? throw new InvalidOperationException(property + " is null"));
    }
    private static MethodInfo RequiredMethod(Type type, string name, Type[] types) =>
        type.GetMethod(name, PublicInstance, types) ?? throw new MissingMethodException(type.FullName, name);
    private static object? Invoke(object instance, string method, Type[] types, object?[] args) =>
        Call(RequiredMethod(instance.GetType(), method, types), instance, args);
    private static object? Call(MethodInfo method, object? instance, object?[] args)
    {
        try { return method.Invoke(instance, args); }
        catch (TargetInvocationException ex) when (ex.InnerException is not null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
    private static void EnsureTask(MethodInfo method)
    {
        if (!typeof(Task).IsAssignableFrom(method.ReturnType))
            throw new MissingMethodException("Expected asynchronous lifecycle method: " + method.Name);
    }
    private static Task InvokeTask(object instance, MethodInfo method, object?[] args) =>
        (Task)(Call(method, instance, args) ?? throw new InvalidOperationException("Lifecycle task missing"));
}
