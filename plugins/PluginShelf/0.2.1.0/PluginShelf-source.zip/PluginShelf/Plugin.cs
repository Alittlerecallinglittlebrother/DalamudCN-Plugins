using System.Collections.Concurrent;
using System.Diagnostics;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.Command;
using Dalamud.Game.Gui.Dtr;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using PluginShelf.Core;

namespace PluginShelf;

public sealed class Plugin : IDalamudPlugin
{
    private readonly IDalamudPluginInterface pi;
    private readonly ICommandManager commands;
    private readonly IPluginLog log;
    private readonly IFramework framework;
    private readonly ICondition condition;
    private readonly DalamudBackend backend;
    private readonly LaunchService launcher;
    private readonly GroupControlService groupController;
    private readonly DalamudPluginControl controlBackend;
    private readonly ConcurrentQueue<PluginTarget> rememberedTargets = new();
    private IReadOnlyList<PluginInstance> instances = [];
    private bool controlCatalogAvailable;
    private bool controlCatalogFailureLogged;
    private readonly object batchGate = new();
    private CancellationTokenSource? batchCancellation;
    private int batchRunning;
    private GroupRunResult? lastGroupResult;
    private bool catalogAvailable;
    private string catalogMessage = "正在读取插件目录…";
    private bool catalogFailureLogged;
    private readonly JsonConfigStore store;
    private readonly ShelfConfig config;
    private readonly ShelfUi ui;
    private readonly ConcurrentQueue<Shortcut> pending = new();
    private readonly List<string> registeredCommands = [];
    private IDtrBarEntry? dtr;
    private IReadOnlyList<PluginEntry> catalog = [];
    private string status = "就绪 · 点击收藏即可发送打开请求。";
    private bool canSave;
    private volatile bool disposed;
    private int openRequested;
    private int catalogDirty = 1;
    private long nextCatalogRefresh;
    private long lastLaunch;

    public Plugin(IDalamudPluginInterface pluginInterface, ICommandManager commandManager,
        IPluginLog pluginLog, IFramework framework, ICondition condition, IDtrBar dtrBar, IPlayerState playerState)
    {
        pi = pluginInterface;
        commands = commandManager;
        log = pluginLog;
        this.framework = framework;
        this.condition = condition;
        backend = new DalamudBackend(pi, commands, log);
        launcher = new LaunchService(backend);
        controlBackend = new DalamudPluginControl(log, () => playerState.ContentId);
        groupController = new GroupControlService(controlBackend);
        store = new JsonConfigStore(Path.Combine(pi.GetPluginConfigDirectory(), "shelf.json"));
        var loaded = store.Load();
        config = loaded.Config;
        canSave = loaded.CanSave;
        if (!string.IsNullOrWhiteSpace(loaded.Message)) status = loaded.Message;
        ui = new ShelfUi(config, () => catalog, QueueLaunch, Save, () => status)
        {
            IsOpen = !config.HasCompletedSetup || !canSave,
            ReadOnly = !canSave,
            CatalogAvailable = () => catalogAvailable,
            CatalogMessage = () => catalogMessage,
            RunGroup = StartGroup,
            Instances = id => instances.Where(x => x.Target.PluginId == id).ToArray(),
            ControlCatalogAvailable = () => controlCatalogAvailable,
            ControlBusy = () => Volatile.Read(ref batchRunning) != 0,
            LastGroupResult = () => Volatile.Read(ref lastGroupResult),
            CancelGroup = CancelGroup,
        };
        foreach (var command in new[] { "/pluginshelf", "/pshelf" })
        {
            if (commands.AddHandler(command, new CommandInfo(OnCommand)
                { HelpMessage = "打开插件收纳盒；dock 显示快捷栏；reset 将快捷栏移回屏幕内。" }))
                registeredCommands.Add(command);
            else log.Warning("PluginShelf command {Command} is already registered; leaving it untouched.", command);
        }

        pi.UiBuilder.Draw += Draw;
        pi.UiBuilder.OpenMainUi += Open;
        pi.UiBuilder.OpenConfigUi += Open;
        pi.ActivePluginsChanged += PluginsChanged;
        framework.Update += Update;
        // Optional mouse-only recovery entry; no dependency on remembering our command.
        try
        {
            dtr = dtrBar.Get("PluginShelf", new SeStringBuilder().AddText("收纳盒").Build());
            dtr.Tooltip = new SeStringBuilder().AddText("点击整理插件 / 找回快捷栏").Build();
            dtr.OnClick = _ => Open();
        }
        catch (Exception ex) { log.Warning(ex, "Could not create optional PluginShelf DTR entry."); }
    }

    private void Open() => Interlocked.Exchange(ref openRequested, 1);
    private void PluginsChanged(IActivePluginsChangedEventArgs args) => Interlocked.Exchange(ref catalogDirty, 1);

    private void OnCommand(string command, string args)
    {
        if (string.Equals(args.Trim(), "reset", StringComparison.OrdinalIgnoreCase))
            Interlocked.Exchange(ref openRequested, 3);
        else if (string.Equals(args.Trim(), "dock", StringComparison.OrdinalIgnoreCase))
            Interlocked.Exchange(ref openRequested, 2);
        else Open();
    }

    private void QueueLaunch(Shortcut source)
    {
        var now = Stopwatch.GetTimestamp();
        if (disposed || Volatile.Read(ref batchRunning) != 0 || now - lastLaunch < Stopwatch.Frequency / 4) return;
        lastLaunch = now;
        pending.Enqueue(new Shortcut
        {
            Id = source.Id, PluginId = source.PluginId, Label = source.Label,
            Kind = source.Kind, Command = source.Command,
        });
        status = "已排队 · 正在检查目标插件。";
    }

    private void StartGroup(PluginGroup source, bool enabled)
    {
        if (disposed || !canSave) return;
        if (condition[ConditionFlag.InCombat]) { status = "战斗中暂停启停插件，请脱战后操作。"; return; }
        lock (batchGate)
        {
            if (batchRunning != 0) return;
            var group = new PluginGroup { Id = source.Id, Name = source.Name, PluginIds = source.PluginIds.ToList() };
            var targets = config.PluginTargets.ToDictionary(x => x.PluginId, StringComparer.Ordinal);
            if (group.PluginIds.Count == 0) { status = "请先给分组添加插件。"; return; }
            pending.Clear();
            var cancellation = new CancellationTokenSource();
            batchCancellation = cancellation;
            Volatile.Write(ref batchRunning, 1);
            Volatile.Write(ref lastGroupResult, null);
            status = group.Name + " · 操作已排队。";
            _ = Task.Run(async () =>
            {
                try
                {
                    var result = await groupController.RunAsync(group, enabled, message =>
                    {
                        if (!disposed) status = message;
                    }, cancellation.Token, targets).ConfigureAwait(false);
                    if (!disposed)
                    {
                        foreach (var item in result.Items.Where(x => x.Target is not null &&
                            x.Outcome is ControlOutcome.Changed or ControlOutcome.Unchanged))
                            rememberedTargets.Enqueue(item.Target!);
                        Volatile.Write(ref lastGroupResult, result);
                        status = result.Items.Count == 1 ? group.Name + "：" + result.Items[0].Message : result.Summary;
                    }
                }
                catch (Exception ex)
                {
                    if (!disposed) { status = "分组操作中断，请查看逐项状态与日志。"; log.Error(ex, "PluginShelf group operation failed."); }
                }
                finally
                {
                    lock (batchGate)
                    {
                        batchCancellation = null;
                        cancellation.Dispose();
                        Volatile.Write(ref batchRunning, 0);
                    }
                    Interlocked.Exchange(ref catalogDirty, 1);
                }
            });
        }
    }

    private void CancelGroup()
    {
        lock (batchGate) { batchCancellation?.Cancel(); }
        status = "正在停止队列；当前插件操作完成后，不再执行后续插件。";
    }

    private void Update(IFramework _)
    {
        if (disposed) return;
        if (Volatile.Read(ref batchRunning) != 0)
        {
            if (condition[ConditionFlag.InCombat]) CancelGroup();
            return;
        }
        if (!pending.TryDequeue(out var shortcut)) return;
        var result = launcher.Launch(shortcut);
        status = result.Message;
        if (!result.Dispatched) log.Information("PluginShelf: {Message}", result.Message);
    }

    private void Draw()
    {
        if (disposed) return;
        var targetsChanged = false;
        while (rememberedTargets.TryDequeue(out var target))
            if (canSave) targetsChanged |= ShelfOperations.RememberTarget(config, target);
        if (targetsChanged) Save();
        var request = Interlocked.Exchange(ref openRequested, 0);
        if (request != 0)
        {
            ui.IsOpen = true;
            if (request >= 2 && canSave)
            {
                config.ShowDock = true;
                if (request == 3) { config.DockX = 80; config.DockY = 160; }
                Save();
            }
        }
        var now = Stopwatch.GetTimestamp();
        if (Interlocked.Exchange(ref catalogDirty, 0) != 0 || now >= nextCatalogRefresh)
        {
            try
            {
                catalog = backend.Snapshot();
                catalogAvailable = true;
                catalogFailureLogged = false;
                var partial = catalog.Count(x => x.ReadError.Length > 0);
                catalogMessage = partial == 0 ? "" : $"{partial} 个插件资料不完整；其余插件可正常使用。";
            }
            catch (Exception ex)
            {
                catalogAvailable = false;
                catalogMessage = "插件目录读取失败，状态未知；将自动重试（不是全部未加载）。";
                catalog = catalog.Select(x => x with { StateKnown = false }).ToArray();
                if (!catalogFailureLogged) log.Warning(ex, "PluginShelf catalog refresh failed.");
                catalogFailureLogged = true;
            }
            try
            {
                instances = controlBackend.SnapshotInstances();
                controlCatalogAvailable = true;
                controlCatalogFailureLogged = false;
            }
            catch (Exception ex)
            {
                if (!controlCatalogFailureLogged) log.Warning(ex, "PluginShelf instance directory unavailable.");
                controlCatalogFailureLogged = true;
                controlCatalogAvailable = false;
                instances = [];
                catalogMessage = (catalogMessage.Length == 0 ? "" : catalogMessage + " ") + "副本目录暂不可用，启停功能等待刷新。";
            }
            nextCatalogRefresh = now + Stopwatch.Frequency * 2;
        }
        ui.Draw(condition[ConditionFlag.InCombat]);
    }

    private void Save()
    {
        if (!canSave) return;
        try { store.Save(config); }
        catch (Exception ex)
        {
            canSave = false;
            ui.ReadOnly = true;
            status = "配置保存失败，已停止写入；当前修改仅在内存中。请检查日志和配置目录。";
            log.Error(ex, "PluginShelf config save failed; original file preserved and writes disabled.");
        }
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        lock (batchGate) { batchCancellation?.Cancel(); }
        // Never synchronously wait for a plugin unload that may need the framework thread.
        framework.Update -= Update;
        pi.ActivePluginsChanged -= PluginsChanged;
        pi.UiBuilder.Draw -= Draw;
        pi.UiBuilder.OpenMainUi -= Open;
        pi.UiBuilder.OpenConfigUi -= Open;
        foreach (var command in registeredCommands) commands.RemoveHandler(command);
        dtr?.Remove();
        pending.Clear();
        // Save only on explicit edits, never overwrite a file merely because a plugin unloads.
    }
}
