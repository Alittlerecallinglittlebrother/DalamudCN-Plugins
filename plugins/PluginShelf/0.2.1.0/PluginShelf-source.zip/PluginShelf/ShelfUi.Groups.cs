using System.Numerics;
using Dalamud.Bindings.ImGui;
using PluginShelf.Core;

namespace PluginShelf;

public sealed partial class ShelfUi
{
    public Func<bool> CatalogAvailable { get; set; } = () => true;
    public Func<string> CatalogMessage { get; set; } = () => "";
    public Action<PluginGroup, bool>? RunGroup { get; set; }
    public Func<bool> ControlBusy { get; set; } = () => false;
    public Func<GroupRunResult?> LastGroupResult { get; set; } = () => null;
    public Action? CancelGroup { get; set; }
    private bool controlsInCombat;
    private bool trayGroups;
    private PluginGroup? groupEditing;
    private bool groupEditorRequested;
    private Guid? groupDeleting;
    private bool groupDeleteRequested;
    private string groupSearch = "";
    private string groupError = "";

    private static PluginEntry MissingEntry(string id) => new(id, id, "", false, false, false, false, false);
    private bool ControlsBlocked => ReadOnly || ControlBusy() || controlsInCombat || RunGroup is null ||
        !CatalogAvailable() || !ControlCatalogAvailable();
    private string PluginStateText(PluginEntry? entry) => !CatalogAvailable() ? "状态未知" : entry is null ? "未安装" :
        !entry.StateKnown ? "状态未知" : entry.IsLoaded ? "已启用" : entry.IsOutdated ? "API 已过期" : "未启用";

    private void DrawSingleControl(PluginEntry plugin, string? observeId = null, bool compact = false)
    {
        var (controlled, reason) = ControlledPlugin(plugin);
        var enabled = controlled.IsLoaded;
        ImGui.BeginDisabled(ControlsBlocked || !controlled.StateKnown || (!enabled && controlled.IsOutdated));
        if (ImGui.Checkbox(compact ? "启用" : controlled.StateKnown ? (enabled ? "已启用" : "未启用") : "待选副本 / 未知", ref enabled))
            RunGroup?.Invoke(new PluginGroup { Name = controlled.Name, PluginIds = [plugin.InternalName] }, enabled);
        Observe(observeId ?? "control:" + plugin.InternalName);
        ImGui.EndDisabled();
        Tip(reason.Length > 0 ? reason : "只启停这个插件，不影响组内其它插件；不是切换窗口。\n战斗中或批量操作期间不可用。");
        if (Instances(plugin.InternalName).Count > 1 || config.PluginTargets.Any(t => t.PluginId == plugin.InternalName))
        {
            if (!compact) ImGui.SameLine();
            ImGui.BeginDisabled(ReadOnly || ControlBusy());
            if (ImGui.SmallButton(compact ? "副本" : "选择副本")) BeginInstancePicker(plugin.InternalName);
            Observe((observeId ?? "control:" + plugin.InternalName) + ":copy");
            ImGui.EndDisabled();
            Tip("查看版本和 DLL 路径，指定并记住要控制的副本；只保存选择，不执行启停。");
        }
    }

    private void DrawGroups()
    {
        ImGui.TextWrapped("只切换组内插件运行，不切换窗口；保留文件及配置。");
        ImGui.TextWrapped("卫月会记住启停状态；多个分组共用插件时，以最后一次操作为准。");
        ImGui.BeginDisabled(ReadOnly || ControlBusy() || config.Groups.Count >= ShelfOperations.MaximumGroups);
        if (ImGui.Button("新建分组")) BeginGroupEdit(new PluginGroup());
        Observe("groups:new");
        ImGui.EndDisabled();
        ImGui.SameLine(); ImGui.TextDisabled($"{config.Groups.Count}/{ShelfOperations.MaximumGroups} 组");
        if (controlsInCombat) ImGui.TextColored(Warning, "战斗中暂停启停插件；脱战后可用。");
        if (ControlBusy())
        {
            ImGui.SameLine();
            if (ImGui.SmallButton("停止后续操作")) CancelGroup?.Invoke();
            Observe("groups:cancel");
            Tip("等待当前插件操作结束，然后停止队列；不回滚已经完成的项目。");
        }
        ImGui.Separator();
        DrawGroupList(search, compact: false);
        if (LastGroupResult() is { } result)
        {
            ImGui.Separator();
            ImGui.TextWrapped(result.Summary);
            if (ImGui.CollapsingHeader("上次操作 · 逐项结果"))
                foreach (var item in result.Items)
                {
                    ImGui.TextColored(item.Outcome == ControlOutcome.Failed ? Warning : Muted,
                        Fit(Find(item.PluginId)?.Name ?? item.PluginId, ImGui.GetContentRegionAvail().X));
                    ImGui.TextWrapped(item.Message);
                }
        }
    }

    private void DrawGroupList(string query, bool compact)
    {
        var matches = 0;
        foreach (var group in config.Groups.ToArray())
        {
            if (!string.IsNullOrWhiteSpace(query) && !group.Name.Contains(query.Trim(), StringComparison.OrdinalIgnoreCase) &&
                !group.PluginIds.Any(id => ShelfOperations.Matches(Find(id) ?? MissingEntry(id), query))) continue;
            matches++;
            ImGui.PushID((compact ? "tray-group:" : "group:") + group.Id);
            var loaded = group.PluginIds.Count(id => CatalogAvailable() && ControlledPlugin(Find(id) ?? MissingEntry(id)).Entry is { StateKnown: true, IsLoaded: true });
            var unknown = group.PluginIds.Count(id => !CatalogAvailable() || !ControlledPlugin(Find(id) ?? MissingEntry(id)).Entry.StateKnown);
            ImGui.TextUnformatted(Fit(group.Name, ImGui.GetContentRegionAvail().X));
            ImGui.TextDisabled($"已启用 {loaded}/{group.PluginIds.Count}" + (unknown > 0 ? $" · 未知 {unknown}" : ""));
            var prefix = compact ? "traygroup:" : "group:";
            ImGui.BeginDisabled(ControlsBlocked || group.PluginIds.Count == 0);
            if (ImGui.Button("整组启用")) RunGroup?.Invoke(group, true);
            Observe(prefix + group.Id + ":on");
            ImGui.SameLine();
            if (ImGui.Button("整组停用")) RunGroup?.Invoke(group, false);
            Observe(prefix + group.Id + ":off");
            ImGui.EndDisabled();
            Tip("按组内顺序启用，逆序停用。已在目标状态的插件自动跳过；失败项显示具体原因。\n不自动执行游戏操作或第三方插件的任务命令。");
            if (!compact)
            {
                ImGui.SameLine();
                ImGui.BeginDisabled(ReadOnly || ControlBusy());
                if (ImGui.Button("编辑")) BeginGroupEdit(group);
                Observe(prefix + group.Id + ":edit");
                ImGui.SameLine();
                if (ImGui.Button("删除")) { groupDeleting = group.Id; groupDeleteRequested = true; }
                Observe(prefix + group.Id + ":delete");
                ImGui.EndDisabled();
            }
            foreach (var id in group.PluginIds)
                DrawControlMember(id, prefix + group.Id + ":member:");
            ImGui.Separator();
            ImGui.PopID();
        }
        if (matches == 0) ImGui.TextDisabled(config.Groups.Count == 0 ? "还没有分组，点“新建分组”选择需要的插件。" : "没有匹配的分组。");
    }

    private void DrawControlMember(string id, string prefix)
    {
        var plugin = Find(id) ?? MissingEntry(id);
        var controlled = ControlledPlugin(plugin).Entry;
        ImGui.PushID("member:" + id);
        var available = ImGui.GetContentRegionAvail().X;
        var controlsWidth = 82 * S;
        ImGui.BeginGroup();
        ImGui.TextUnformatted(Fit(controlled.Name, Math.Max(20, available - controlsWidth - 8 * S)));
        Tip(controlled.Name + "\n" + id);
        ImGui.TextDisabled(PluginStateText(controlled));
        ImGui.EndGroup();
        ImGui.SameLine(ImGui.GetCursorPosX() + Math.Max(20, available - controlsWidth));
        ImGui.BeginGroup();
        DrawSingleControl(plugin, prefix + id, compact: true);
        ImGui.EndGroup();
        ImGui.PopID();
    }

    private void BeginGroupEdit(PluginGroup group)
    {
        groupEditing = new PluginGroup { Id = group.Id, Name = group.Name, PluginIds = group.PluginIds.ToList() };
        groupSearch = "";
        groupError = "";
        groupEditorRequested = true;
    }

    private void DrawGroupEditor()
    {
        if (groupEditorRequested) { ImGui.OpenPopup("编辑分组###PluginShelfGroupEditor"); groupEditorRequested = false; }
        if (groupEditing is null) return;
        var size = Vector2.Min(new Vector2(560, 510) * S, ImGui.GetMainViewport().WorkSize - new Vector2(20));
        ImGui.SetNextWindowSize(size, ImGuiCond.Always);
        var open = true;
        if (ImGui.BeginPopupModal("编辑分组###PluginShelfGroupEditor", ref open,
                ImGuiWindowFlags.NoSavedSettings | ImGuiWindowFlags.NoResize))
        {
            ClampCurrentWindow();
            ImGui.SetWindowFontScale(config.Scale);
            ObserveItem?.Invoke("window:groupeditor", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
            ImGui.BeginDisabled(ReadOnly || ControlBusy());
            var name = groupEditing.Name;
            ImGui.SetNextItemWidth(-1);
            if (ImGui.InputTextWithHint("##name", "分组名称，例如：日常 / 合奏", ref name, 81)) groupEditing.Name = name;
            Observe("groupeditor:name");
            ImGui.TextWrapped("勾选插件加入分组（包括未启用的插件）。保存只保存名单，不会执行启停。取消勾选再加入可调到末尾。");
            ImGui.SetNextItemWidth(-1);
            ImGui.InputTextWithHint("##groupsearch", "搜索插件名称 / 内部名称", ref groupSearch, 160);
            Observe("groupeditor:search");
            ImGui.TextDisabled($"已选 {groupEditing.PluginIds.Count}/{ShelfOperations.MaximumGroupMembers} 个插件");
            var listHeight = Math.Max(30, ImGui.GetContentRegionAvail().Y - 92 * S);
            if (ImGui.BeginChild("members", new Vector2(0, listHeight), false))
            {
                var entries = catalog().Where(p => ShelfOperations.IsControllableId(p.InternalName)).ToList();
                foreach (var missing in groupEditing.PluginIds.Where(id => entries.All(p => p.InternalName != id)).ToArray())
                    entries.Add(MissingEntry(missing));
                foreach (var plugin in entries.OrderBy(p => p.Name, StringComparer.OrdinalIgnoreCase))
                {
                    if (!ShelfOperations.Matches(plugin, groupSearch)) continue;
                    ImGui.PushID(plugin.InternalName);
                    var selected = groupEditing.PluginIds.Contains(plugin.InternalName);
                    ImGui.BeginDisabled(!selected && groupEditing.PluginIds.Count >= ShelfOperations.MaximumGroupMembers);
                    var label = Fit(plugin.Name, Math.Max(30, ImGui.GetContentRegionAvail().X - 120 * S));
                    if (ImGui.Checkbox(label + "###member", ref selected))
                    {
                        if (selected) groupEditing.PluginIds.Add(plugin.InternalName);
                        else groupEditing.PluginIds.RemoveAll(id => id == plugin.InternalName);
                    }
                    Observe("groupeditor:member:" + plugin.InternalName);
                    ImGui.EndDisabled();
                    Tip(plugin.InternalName);
                    ImGui.SameLine(); ImGui.TextDisabled(PluginStateText(Find(plugin.InternalName)));
                    ImGui.PopID();
                }
                if (entries.Count == 0) ImGui.TextWrapped(CatalogAvailable() ? "未发现可加入的插件。" : CatalogMessage());
            }
            ImGui.EndChild();
            if (groupError.Length > 0) ImGui.TextColored(Warning, groupError);
            if (ImGui.Button("保存分组", new Vector2(116, 31) * S))
            {
                if (string.IsNullOrWhiteSpace(groupEditing.Name)) groupError = "请填写分组名称。";
                else if (config.Groups.Any(g => g.Id != groupEditing.Id && g.Name.Equals(groupEditing.Name.Trim(), StringComparison.OrdinalIgnoreCase)))
                    groupError = "已有同名分组，请使用不同名称。";
                else
                {
                    var index = config.Groups.FindIndex(g => g.Id == groupEditing.Id);
                    if (index < 0 && config.Groups.Count >= ShelfOperations.MaximumGroups) groupError = "分组数量已达上限。";
                    else
                    {
                        groupEditing.Name = groupEditing.Name.Trim();
                        if (index >= 0) config.Groups[index] = groupEditing;
                        else config.Groups.Add(groupEditing);
                        save(); groupEditing = null; ImGui.CloseCurrentPopup();
                    }
                }
            }
            Observe("groupeditor:save");
            ImGui.EndDisabled();
            ImGui.SameLine();
            if (ImGui.Button("取消", new Vector2(90, 31) * S)) { groupEditing = null; ImGui.CloseCurrentPopup(); }
            Observe("groupeditor:cancel");
            ImGui.EndPopup();
        }
        if (!open) groupEditing = null;
    }

    private void DrawGroupDelete()
    {
        if (groupDeleteRequested) { ImGui.OpenPopup("删除分组###PluginShelfDeleteGroup"); groupDeleteRequested = false; }
        if (ImGui.BeginPopupModal("删除分组###PluginShelfDeleteGroup", ImGuiWindowFlags.AlwaysAutoResize))
        {
            ImGui.TextUnformatted("只删除分组名单，不会停用或删除组内插件。");
            ImGui.BeginDisabled(ReadOnly || ControlBusy());
            if (ImGui.Button("确认删除"))
            { config.Groups.RemoveAll(g => g.Id == groupDeleting); save(); groupDeleting = null; ImGui.CloseCurrentPopup(); }
            Observe("groupdelete:confirm");
            ImGui.EndDisabled();
            ImGui.SameLine();
            if (ImGui.Button("取消")) { groupDeleting = null; ImGui.CloseCurrentPopup(); }
            Observe("groupdelete:cancel");
            ImGui.EndPopup();
        }
    }
}
