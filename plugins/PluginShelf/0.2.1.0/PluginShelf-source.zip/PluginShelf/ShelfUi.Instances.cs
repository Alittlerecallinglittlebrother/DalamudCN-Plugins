using System.Numerics;
using Dalamud.Bindings.ImGui;
using PluginShelf.Core;

namespace PluginShelf;

public sealed partial class ShelfUi
{
    public Func<string, IReadOnlyList<PluginInstance>> Instances { get; set; } = _ => [];
    public Func<bool> ControlCatalogAvailable { get; set; } = () => true;
    private string? pickingInstance;
    private PluginTarget? instanceDraft;
    private bool instancePickerRequested;
    private string instanceError = "";

    private (PluginEntry Entry, string Reason) ControlledPlugin(PluginEntry plugin)
    {
        var preferred = config.PluginTargets.FirstOrDefault(t => t.PluginId == plugin.InternalName);
        var copies = Instances(plugin.InternalName);
        if (!ControlCatalogAvailable())
            return (plugin with { StateKnown = false }, "副本目录暂不可用，正在重试。");
        // Public directory remains useful when an instance has incomplete private metadata.
        if (copies.Count == 0 && preferred is null) return (plugin, "");
        var selection = PluginInstanceSelector.Select(plugin.InternalName, copies, preferred);
        if (selection.Instance is not { } chosen)
            return (plugin with { StateKnown = false }, selection.Error);
        return (plugin with { Name = chosen.Name, Version = chosen.Version, IsLoaded = chosen.IsLoaded,
            StateKnown = chosen.IsStable, IsOutdated = chosen.IsOutdated }, chosen.IsStable ? "" : "所选副本正在切换或处于错误状态，请先在卫月中处理。");
    }

    private void BeginInstancePicker(string id)
    {
        pickingInstance = id;
        var preferred = config.PluginTargets.FirstOrDefault(t => t.PluginId == id);
        instanceDraft = PluginInstanceSelector.Select(id, Instances(id), preferred).Instance?.Target;
        instancePickerRequested = true;
        instanceError = "";
    }

    private void DrawInstancePicker()
    {
        if (instancePickerRequested) { ImGui.OpenPopup("选择运行副本###PluginShelfInstancePicker"); instancePickerRequested = false; }
        if (pickingInstance is null) return;
        var open = true;
        var size = Vector2.Min(new Vector2(600, 440) * S, ImGui.GetMainViewport().WorkSize - new Vector2(20));
        ImGui.SetNextWindowSize(size, ImGuiCond.Always);
        if (ImGui.BeginPopupModal("选择运行副本###PluginShelfInstancePicker", ref open,
                ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoSavedSettings))
        {
            ClampCurrentWindow(); ImGui.SetWindowFontScale(config.Scale);
            ObserveItem?.Invoke("window:instancepicker", ImGui.GetWindowPos(), ImGui.GetWindowPos() + ImGui.GetWindowSize());
            ImGui.TextUnformatted(pickingInstance);
            ImGui.TextWrapped("请选择要控制的副本。保存只记住版本来源，不执行启停，也不删除其它副本。");
            ImGui.TextWrapped("关掉后再打开会使用同一份；如另一份已在运行，先选中那一份并停用，再切换。");
            ImGui.BeginDisabled(ReadOnly || ControlBusy());
            if (ImGui.BeginChild("copies", new Vector2(0, Math.Max(30, ImGui.GetContentRegionAvail().Y - 100 * S)), false))
            {
                var copies = Instances(pickingInstance);
                for (var index = 0; index < copies.Count; index++)
                {
                    var copy = copies[index];
                    ImGui.PushID(index);
                    var title = $"{copy.Name} · {(copy.IsDev ? "开发副本" : "已安装副本")} · {copy.Version}";
                    if (ImGui.RadioButton(Fit(title, ImGui.GetContentRegionAvail().X - 30 * S) + "###copy", instanceDraft == copy.Target))
                        instanceDraft = copy.Target;
                    Observe("instancepicker:copy:" + index);
                    ImGui.TextDisabled(copy.IsLoaded ? "已启用" : copy.State == "Unloaded" ? "未启用" : copy.State);
                    ImGui.TextWrapped(string.IsNullOrEmpty(copy.Target.DllPath) ? "DLL 路径未知（使用卫月副本编号）" : copy.Target.DllPath);
                    ImGui.TextDisabled("编号：" + copy.Target.WorkingPluginId);
                    ImGui.Separator(); ImGui.PopID();
                }
                if (copies.Count == 0) ImGui.TextWrapped("暂未读到副本，请等候自动刷新。原选择不会被清除。");
            }
            ImGui.EndChild();
            if (instanceError.Length > 0) ImGui.TextColored(Warning, instanceError);
            if (ImGui.Button("记住此副本", new Vector2(116, 31) * S))
            {
                if (instanceDraft is null) instanceError = "请先选中一项。";
                else if (PluginInstanceSelector.Select(pickingInstance, Instances(pickingInstance), instanceDraft) is { Instance: { } selected })
                {
                    ShelfOperations.RememberTarget(config, selected.Target);
                    save(); pickingInstance = null; instanceDraft = null; ImGui.CloseCurrentPopup();
                }
                else instanceError = "该副本已消失或重复，请刷新后重新选择。";
            }
            Observe("instancepicker:save");
            ImGui.SameLine();
            if (ImGui.Button("恢复自动选择", new Vector2(128, 31) * S))
            {
                config.PluginTargets.RemoveAll(t => t.PluginId == pickingInstance);
                save(); pickingInstance = null; instanceDraft = null; ImGui.CloseCurrentPopup();
            }
            Observe("instancepicker:clear");
            ImGui.EndDisabled();
            ImGui.SameLine();
            if (ImGui.Button("取消", new Vector2(76, 31) * S))
            { pickingInstance = null; instanceDraft = null; ImGui.CloseCurrentPopup(); }
            Observe("instancepicker:cancel");
            ImGui.EndPopup();
        }
        if (!open) { pickingInstance = null; instanceDraft = null; }
    }
}
