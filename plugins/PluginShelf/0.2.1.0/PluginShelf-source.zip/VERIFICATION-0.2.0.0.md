# PluginShelf 0.2.0.0 验证与交付说明

## 本次改动
- 目录按条目/字段容错，Version 为 null 也不会使整个目录失败；状态读取错误有“未知”状态。
- 刷新异常不再把缺失的收藏当作“未加载”，恢复后清除目录错误提示。
- 独立分组配置（v2）及 v1 原收藏迁移；分组编辑、整组/单项启停、快捷面板开关和逐项结果。
- 操作使用明确目标状态而非 toggle；顺序执行，停止后续、去重、幂等、自身保护和战斗保护。

## 证据与边界
截图底部的目录读取失败提示对应旧版 catch；源代码中任意条目异常会中止全部 LINQ 投影，
而界面将未查到的条目构造成 IsLoaded=false。这两条路径已修复并有回归覆盖。
本次现存日志没有找到截图时的具体异常堆栈，不能断言是哪一个真实插件触发，
也不能以离线修复代替原现场复现。

实测编译 SDK：本机国服 Dalamud 15.0.3.9 / API 15 / .NET 10。
Dalamud.dll SHA256：
AF15D754340C659F9F57C110C9914D8C68A068F588725CAAE50AC237B07DA1C4

已核对本机程序集的：
- ExposedPlugin、IExposedPlugin、DalamudPluginInterface.InstalledPlugins
- LocalPlugin.LoadAsync / UnloadAsync 与 State
- Profile.WantsPlugin / CheckWantsActiveFromGameState / AddOrUpdateAsync
- PluginInstallerWindow 的单项启停顺序

分组没有公开的 Dalamud 生命周期 API，因此采用 fail-closed 的内部接口适配。
只调用标准加载/卸载和目标所属唯一合集的 AddOrUpdateAsync(..., apply:false)。
不写反射字段，不改目标配置文件，不删除 DLL，不调用 ApplyAllWantStatesAsync，
不绕过安全模式、API 检查、合集归属或角色过滤。

## 自动验证
执行（PowerShell 7）：
```powershell
.\build.ps1 -Validate -UiTests
```

- 主工程：0 warning / 0 error。
- 核心：38/38 cases，214 assertions。
- 后端及生命周期：38/38 cases，197 assertions。
- 原生 cimgui 鼠标与界面：81 checks，0 failed。
- 已查看分组页、分组编辑、快速开关、目录异常和高缩放窗口的离线截图。
- 所有目标插件均为模拟对象；没有在用户真实插件上执行启停。
- 游戏进程未运行，FFXIV MCP 端点不可连接。真实国服进程加载/启停验收尚未完成。
- 未发布线上仓库，未覆盖当前安装，也未注册开发插件位置。

## 回退
源码修改前备份：
D:\codex\2026-10-10\xi\work\PluginShelf-backup-20261024-041930

v1 配置首次保存为 v2 时，原文件放入 shelf.json.bak，之后 .bak 滚动覆盖。
若计划回退旧版，请升级前额外保存 v1 shelf.json。
旧版会拒绝覆写 v2，避免丢失分组。

## 游戏内待验收
1. 替换前停用 PluginShelf，保留原 shelf.json；将新包完整解压/覆盖原插件目录。
2. 核对版本 0.2.0.0，截图中的 AutoGail、AutoDuty 等状态和卫月安装器一致。
3. 用不影响当前游戏操作的两个插件建立测试组，一项已开、一项已关。
4. 确认保存名单不触发启停；整组开/关与卫月安装器和日志的实际加载状态一致。
5. 重复开/关无重复加载，单个失败显示具体原因，失败不被计作成功。
6. 停止后续/战斗中/同名副本/合集冲突路径能阻止危险或含糊的操作。
7. 重载后旧收藏、分组成员、别名与位置保留；删除分组只删除名单。
